package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.unifiedParameters.entity.MDictionaryList

interface IUnifiedParamBusiness {
    /**
     * 获取系统参数.
     *
     * @param id
     *            .
     * @return .
     * @throws Exception .
     */
    public String getSysParam(String id) throws Exception;

    /**
     * 获取字典参数.
     *
     * @param id
     *            .
     * @return .
     * @throws Exception .
     */
    public List<String> getDictionaryParamList(String id) throws Exception;

    /**
     * 获取字典参数.
     *
     * @param id
     *            .
     * @return .
     * @throws Exception .
     */
    public MDictionaryList getSrcDictionaryParamList(String id) throws Exception;

    /**
     * 获取部门参数.
     *
     * @param deptId
     *            部门ID
     * @param paramId
     *            参数id
     * @return 部门参数
     * @throws Exception .
     */
    public String getDeptParam(String deptId, String paramId) throws Exception;
}
