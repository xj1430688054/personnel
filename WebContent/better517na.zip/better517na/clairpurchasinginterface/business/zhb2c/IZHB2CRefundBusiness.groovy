package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2c

import com.better517na.zhb2cService.ReturnTicketInfoRequest
import com.better517na.zhb2cService.ReturnTicketInfoResponse

interface IZHB2CRefundBusiness {

    /**
     * 提交退票
     * @param request
     * @param url
     * @return
     */
    ReturnTicketInfoResponse returnTicket(ReturnTicketInfoRequest request, String url);
}