package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2c

import com.better517na.payInteractionService.MYeepayPayOutParam
import com.better517na.payInteractionService.MYeepayPayParam
import com.better517na.zhb2cService.GetAvInfoRequest
import com.better517na.zhb2cService.GetAvInfoResponse
import com.better517na.zhb2cService.OrderInfoDetailRequest
import com.better517na.zhb2cService.OrderInfoDetailResponse
import com.better517na.zhb2cService.OutTicketInfoRequest
import com.better517na.zhb2cService.OutTicketInfoResponse
import com.better517na.zhb2cService.SubmitOrderInfoRequest
import com.better517na.zhb2cService.SubmitOrderInfoResponse
import com.better517na.zhb2cService.OrderPayInfoRequest
import com.better517na.zhb2cService.OrderPayInfoResponse

interface IZHB2CBusiness {
    /**
     * ѯ��
     * @param request
     * @param url
     * @return
     */
    GetAvInfoResponse queryPrice(GetAvInfoRequest request,String url);

    /**
     * ����
     * @param request
     * @param url
     * @return
     */
    SubmitOrderInfoResponse createOrder(SubmitOrderInfoRequest request, String url);

    /**
     * ��Ʊ
     * @param request
     * @param url
     * @return
     */
    OutTicketInfoResponse outTicket(OutTicketInfoRequest request,String url);

    OrderInfoDetailResponse queryOrderDetail(OrderInfoDetailRequest request, String url) throws Exception;

    OrderPayInfoResponse orderPay(OrderPayInfoRequest request, String url) throws Exception;

    MYeepayPayOutParam yeepayPay(MYeepayPayParam request,String pidUniqueKey, String pid, String url) throws Exception;

}