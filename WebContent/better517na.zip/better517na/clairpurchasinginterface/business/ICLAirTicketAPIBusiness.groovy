package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.clairticketapi.model.vo.refund.ApplyRefundInVo
import com.better517na.clairticketapi.model.vo.refund.ApplyRefundOutVo
import com.better517na.clairticketapi.model.vo.refund.RefundOrderSearchInVo
import com.better517na.clairticketapi.model.vo.refund.RefundOrderSearchOutVo
import com.better517na.clairticketapi.model.vo.refund.RefundSearchInVo
import com.better517na.clairticketapi.model.vo.refund.RefundSearchOutVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.OrderCreateInVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.OrderCreateOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayOrderInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayOrderResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayValidateInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayValidateOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.QueryTicketOrderInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.QueryTicketOrderOutVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.RequestVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.ResponseVo

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/19
 * Time: 20:10
 */
public interface ICLAirTicketAPIBusiness {
    ResponseVo<OrderCreateOutVo> createOrder(RequestVo<OrderCreateInVo> requestVo, String secret, String url);

    /**
     * 支付前验价.
     * @param param 参数
     * @return 结果
     */
    ResponseVo<PayValidateOutVo> payValidate(RequestVo<PayValidateInVo> param, String secret, String url);

    ResponseVo<PayOrderResVo> payOrder(RequestVo<PayOrderInVo> requestVo, String secret, String url);

    ResponseVo<QueryTicketOrderOutVo> queryOrder(RequestVo<QueryTicketOrderInVo> requestVo, String secret, String url);

    /**
     * @CLAirTicketAPI的退票订单查询
     * @param param 请求参数
     * @param secret 安全码
     * @param url 地址
     * @return 处理结果
     */
    ResponseVo<RefundOrderSearchOutVo> refundOrderSearch(RequestVo<RefundOrderSearchInVo> param, String secret, String url);

    /**
     * 申请退票.
     * @param param 退票参数
     * @return 申请结果
     */
    ResponseVo<ApplyRefundOutVo> applyRefund(RequestVo<ApplyRefundInVo> param, String secret, String url);

    /**
     * 申请退票查询.
     * @param param 参数
     * @return 结果
     */
    ResponseVo<RefundSearchOutVo> refundSearch(RequestVo<RefundSearchInVo> param, String secret, String url);

}
