package config.groovyFiles.com.better517na.clairpurchasinginterface.business.threeUB2G

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.InChannelChangeParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelApplyChangeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelChangePayNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelQueryChangeFeeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelQueryChangeInfoNewVo

interface IThreeUB2GChangeBusiness{
    OutChannelQueryChangeFeeNewVo channelQueryChangeFee(InChannelChangeParamVo inChannelChangeParamVo,SupplySystemInfo supplySystemInfo);

    OutChannelApplyChangeNewVo channelApplyChange(InChannelChangeParamVo inChannelChangeParamVo,SupplySystemInfo supplySystemInfo);

    OutChannelChangePayNewVo channelChangePay(InChannelChangeParamVo inChannelChangeParamVo,SupplySystemInfo supplySystemInfo);

    OutChannelQueryChangeInfoNewVo channelQueryChangeInfo(InChannelChangeParamVo inChannelChangeParamVo,SupplySystemInfo supplySystemInfo);
}