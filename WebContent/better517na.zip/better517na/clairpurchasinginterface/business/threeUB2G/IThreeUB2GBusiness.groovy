package config.groovyFiles.com.better517na.clairpurchasinginterface.business.threeUB2G

import com.better517na.threeb2gService.MCreateOrderRequest
import com.better517na.threeb2gService.MCreateOrderResponse
import com.better517na.threeb2gService.MPayOrderRequest
import com.better517na.threeb2gService.MPayOrderResponse
import com.better517na.threeb2gService.MQueryFlightRequest
import com.better517na.threeb2gService.MQueryFlightResponse
import com.better517na.threeb2gService.MQueryOrderNewResponse
import com.better517na.threeb2gService.MQueryOrderRequest

public interface IThreeUB2GBusiness {
    MCreateOrderResponse createOrder(MCreateOrderRequest orderInfo, String url) throws Exception;

    MQueryOrderNewResponse queryOrderDetail(MQueryOrderRequest requestVo, String url) throws Exception;

    MPayOrderResponse ticketing(MPayOrderRequest requestVo, String url) throws Exception;

    MQueryFlightResponse queryFlightInfo(MQueryFlightRequest  requestVo, String url) throws Exception;
}
