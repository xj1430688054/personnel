package config.groovyFiles.com.better517na.clairpurchasinginterface.business.threeUB2G

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.commons.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelRefundParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelApplyRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelQueryRefundInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelQueryRefundRateVo

interface IThreeUB2GRefundBusiness{
    OutChannelApplyRefundVo returnTicket(InChannelRefundParamVo inChannelRefundParamVo, SupplySystemInfo supplySystemInfo);

    OutChannelQueryRefundRateVo queryReturnTicketRate(InChannelRefundParamVo inChannelRefundParamVo, SupplySystemInfo supplySystemInfo);

    OutChannelQueryRefundInfoVo getRefundOrderDetail(InChannelRefundParamVo inChannelRefundParamVo, SupplySystemInfo supplySystemInfo);
}