package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.model.entity.InsuranceAgentInfo;
import com.better517na.model.request.CreateInsuranceOrderParam;
import com.better517na.model.request.InsuranceCancleOrderData;
import com.better517na.model.request.InsuranceOrderQueryData;
import com.better517na.model.request.NotifyInsuranceInsureParam;
import com.better517na.model.request.NotifyInsurancePayParam;
import com.better517na.model.response.CreateInsuranceOrderResponse;
import com.better517na.model.response.InsuranceCancleOrderResponse;
import com.better517na.model.response.InsuranceOrderQueryResponse;
import com.better517na.model.response.NotifyInsuraceInsureResponse;
import com.better517na.model.response.NotifyInsurancePayResponse;
import com.better517na.model.response.ResponseData;


/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * <pre>
 * </pre>
 *
 * @author     qiyue
 */
public interface IInsurance517NaBusiness {

    ResponseData<InsuranceOrderQueryResponse> queryInsuranceOrder(InsuranceOrderQueryData request, InsuranceAgentInfo agentInfo);

    ResponseData<CreateInsuranceOrderResponse> insuranceCreateOrder(CreateInsuranceOrderParam request, InsuranceAgentInfo agent);

    ResponseData<NotifyInsurancePayResponse> notifyInsurancePayOrder(NotifyInsurancePayParam request, InsuranceAgentInfo agent);

    ResponseData<NotifyInsuraceInsureResponse> notifyInsuranceInSure(NotifyInsuranceInsureParam request, InsuranceAgentInfo agent);

    ResponseData<InsuranceCancleOrderResponse> notifyInsuranceCancel(InsuranceCancleOrderData request, InsuranceAgentInfo agent);
}

