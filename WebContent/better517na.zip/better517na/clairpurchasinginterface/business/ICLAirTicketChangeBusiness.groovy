package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.clairticketapi.model.vo.CancelChangeInVo
import com.better517na.clairticketapi.model.vo.CancelChangeOutVo
import com.better517na.clairticketapi.model.vo.refund.ApplyChangeInVo
import com.better517na.clairticketapi.model.vo.refund.ApplyChangeOutVo
import com.better517na.clairticketapi.model.vo.refund.ChangeOrderSearchInVo
import com.better517na.clairticketapi.model.vo.refund.ChangeOrderSearchOutVo
import com.better517na.clairticketapi.model.vo.refund.ChangePayInVo
import com.better517na.clairticketapi.model.vo.refund.ChangePayOutVo
import com.better517na.clairticketapi.model.vo.refund.ChangeSearchInVo
import com.better517na.clairticketapi.model.vo.refund.ChangeSearchOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.ResponseVo

interface ICLAirTicketChangeBusiness {
    /**
     * 申请改签.
     * @param param 请求参数.
     * @return 响应结果.
     */
    ResponseVo<ApplyChangeOutVo> applyChange(RequestVo<ApplyChangeInVo> requestVo, String secret, String url);

    /**
     * 改签客规查询.
     *
     * @param param 请求参数.
     * @return 响应结果.
     */
    ResponseVo<ChangeSearchOutVo> changeSearch(RequestVo<ChangeSearchInVo> requestVo, String secret, String url);


    /**
     * @CLAirTicketAPI的改签订单查询
     * @param requestVo 请求参数
     * @param secret 安全码
     * @param url 地址
     * @return 处理结果
     */
    ResponseVo<ChangeOrderSearchOutVo> changeOrderSearch(RequestVo<ChangeOrderSearchInVo> requestVo, String secret, String url);

    /**
     * @CLAirTicketAPI的改签支付
     * @param requestVo 请求参数
     * @param secret 安全码
     * @param url 地址
     * @return 处理结果
     */
    ResponseVo<ChangePayOutVo> changePay(RequestVo<ChangePayInVo> requestVo, String secret, String url);

    /**
     * @CLAirTicketAPI的改签支付
     * @param requestVo 请求参数
     * @param secret 安全码
     * @param url 地址
     * @return 处理结果
     */
    ResponseVo<CancelChangeOutVo> cancelChange(RequestVo<CancelChangeInVo > requestVo, String secret, String url);



}
