package config.groovyFiles.com.better517na.clairpurchasinginterface.business

public interface IQueryTicketRefundOrderDetailBusiness {

}
