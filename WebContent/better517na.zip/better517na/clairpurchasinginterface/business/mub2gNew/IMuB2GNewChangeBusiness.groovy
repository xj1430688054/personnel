package config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew

import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeAVReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeCheckReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeOrderReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeTaxReq
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeAVRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeCheckRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeOrderRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeTaxRes

interface IMuB2GNewChangeBusiness {

    public PostUpgradeAVRes postUpgradeAV(PostUpgradeAVReq req);

    public PostUpgradeOrderRes postUpgradeOrder(PostUpgradeOrderReq req);

    public PostUpgradeCheckRes postUpgradeCheck(PostUpgradeCheckReq req);

    public PostUpgradeTaxRes postUpgradeTax(PostUpgradeTaxReq req);
}