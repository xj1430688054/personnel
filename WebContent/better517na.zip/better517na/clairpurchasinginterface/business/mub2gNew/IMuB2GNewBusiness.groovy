package config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew

import com.ceair.b2g.client.vo.order.cancel.input.CancelOrderReq
import com.ceair.b2g.client.vo.order.cancel.output.CancelOrderRes
import com.ceair.b2g.client.vo.order.status.input.OrderStatusReq
import com.ceair.b2g.client.vo.order.status.output.OrderStatusRes
import com.ceair.b2g.client.vo.order.input.AirOrderReq
import com.ceair.b2g.client.vo.order.output.AirOrderRes
import com.ceair.b2g.client.vo.pay.input.PayInfo
import com.ceair.b2g.client.vo.pay.output.PayResult
import com.ceair.b2g.client.vo.pricing.input.EcQueryReq
import com.ceair.b2g.client.vo.pricing.output.EcQueryRes
import com.ceair.b2g.client.vo.tax.input.OrderTaxReq
import com.ceair.b2g.client.vo.tax.output.OrderTaxRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.CreateOrderRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.TicketBuyOrderInfoVo


import com.ceair.b2g.client.vo.order.input.AirOrderReq
import com.ceair.b2g.client.vo.order.output.AirOrderRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.CreateOrderRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.TicketBuyOrderInfoVo

interface IMuB2GNewBusiness {
    AirOrderRes creatOrder(AirOrderReq airOrderReq);
    ResponseVo<CreateOrderRes> creatOrder(RequestVo<TicketBuyOrderInfoVo> requestVo);


    /**
     * 出票
     * @param requestVo
     * @return
     */
    public PayResult  ticketing(PayInfo  info);


    /**
     * 查询订单信息
     * @param requestVo
     * @return
     */
    public OrderStatusRes queryOrderDetail(OrderStatusReq req);
    /**
     * 订单取消
     * @param requestVo
     * @return
     */
    public CancelOrderRes cancelOrder(CancelOrderReq req);


    public OrderTaxRes orderTax(OrderTaxReq req);

    public EcQueryRes ecFareQuery(EcQueryReq req);
}