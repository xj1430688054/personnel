package config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew

import com.ceair.b2g.client.vo.refund.apply.input.RefundApplyTicketReq
import com.ceair.b2g.client.vo.refund.apply.output.RefundApplyTicketRes
import com.ceair.b2g.client.vo.refund.input.RefundApplyInfoSearchReq
import com.ceair.b2g.client.vo.refund.input.RefundTicketReq
import com.ceair.b2g.client.vo.refund.output.RefundApplyInfoSearchRes
import com.ceair.b2g.client.vo.refund.output.RefundTicketRes


public interface IMuB2GNewRefundBusiness {
    public RefundTicketRes ticketRefundCheck(RefundTicketReq refundTicketReq);

    public RefundApplyTicketRes ticketRefundApply(RefundApplyTicketReq refundApplyTicketReq);

    public RefundApplyInfoSearchRes searchRefundApplyInfo(RefundApplyInfoSearchReq req)

}