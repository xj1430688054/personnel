package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.mub2cChangeTicket.IUniChangeLitersService
import com.better517na.mub2cChangeTicket.ReBookReq
import com.better517na.mub2cChangeTicket.ReBookRes
import com.better517na.mub2cChangeTicket.ReShoppingReq
import com.better517na.mub2cChangeTicket.ReShoppingRes
import com.better517na.mub2cFlightBook.BookingReq
import com.better517na.mub2cFlightBook.BookingRes
import com.better517na.mub2cFlightQuery.ShoppingReq
import com.better517na.mub2cFlightQuery.ShoppingRes
import com.better517na.mub2cOrderPay.PayConfirmAndTicketOutReq
import com.better517na.mub2cOrderPay.PayConfirmAndTicketOutRes
import com.better517na.mub2cOrderQuery.OrderSearchReq
import com.better517na.mub2cOrderQuery.OrderTicketNoReq
import com.better517na.mub2cOrderQuery.OrderTicketNoRes
import com.better517na.mub2cOrderQuery.OtaOrderSearchRes
import com.better517na.mub2cPriceQuery.PriceCalReq
import com.better517na.mub2cPriceQuery.PricingReq
import com.better517na.mub2cPriceQuery.PricingRes
import com.better517na.mub2cReturnTicket.CalcFeeRes
import com.better517na.mub2cReturnTicket.CalcFeeV2Req
import com.better517na.mub2cReturnTicket.ReApplyReq
import com.better517na.mub2cReturnTicket.ReCalcFeeReq
import com.better517na.mub2cReturnTicket.RefundApplyReq
import com.better517na.mub2cReturnTicket.RefundApplyRes
import com.better517na.mub2cReturnTicket.RefundDetailReq
import com.better517na.mub2cReturnTicket.RefundDetailRes
import com.better517na.mub2cReturnTicket.RefundRes
import com.better517na.mub2cReturnTicket.RefundV2Req
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CChangeFactoryBean

import javax.jws.WebParam

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.business
 * Author: gaoshun
 * DateTime: 2018/11/6 15:37
 * Desc: 说明类的作用
 */
public interface IMuB2CBussiness {
    /**
     * 预订查询.
     *
     * @param request
     *            request
     * @return ResponseVo
     * @throws Exception
     *             Exception
     */
    public ShoppingRes shopping(ShoppingReq request, String url) throws Exception;

    /**
     * 根据用户选择的航班舱位查询税费、生成临时订单并返回订单相关信息（航班信息、税费等）.
     *
     * @param request
     *            request
     * @return ResponseVo
     * @throws Exception
     *             Exception
     */
    public PricingRes pricing(PricingReq request, String url) throws Exception;

    /**
     * 生成订单.
     *
     * @param request
     *            request
     * @return ResponseVo
     * @throws Exception
     *             Exception
     */
    public BookingRes booking(BookingReq request, String url) throws Exception;

    /**
     * 根据用户选择的航班舱位查询税费、生成临时订单并返回订单相关信息、常用乘机人、常用联系人给前端.
     *
     * @param request
     *            request
     * @return ResponseVo
     * @throws Exception
     *             Exception
     */
    public PricingRes priceCal(PriceCalReq request, String url) throws Exception;

    /**
     * 支付出票.
     *
     * @param request
     *            request
     * @return ResponseVo
     * @throws Exception
     *             Exception
     */
    public PayConfirmAndTicketOutRes payConfirmAndTicketOut(PayConfirmAndTicketOutReq request, String url) throws Exception;

    /**
     * 订单的详细信息，包含了航班，乘机人，票号等相关信息.
     *
     * @param request
     *            request
     * @throws Exception
     *             Exception
     * @return ResponseVo
     */
    public OtaOrderSearchRes detail(OrderSearchReq request, String url) throws Exception;

    /**
     * 退票申请 返回可以退票的乘机人信息和航段信息，供用户选择要退的乘机人和航段.
     *
     * @param request
     *            request
     * @return RefundApplyRes
     * @throws Exception
     *             Exception
     */
    public RefundApplyRes refundApply(RefundApplyReq request, String url) throws Exception;

    /**
     * 确认退票.
     *
     * @param request
     *            request
     * @return RefundRes
     * @throws Exception
     *             Exception
     */
    public RefundRes refundV2(RefundV2Req request, String url) throws Exception;

    /**
     * 退票详情.
     *
     * @param request
     *            request
     * @return RefundDetailRes
     * @throws Exception
     *             Exception
     */
    public RefundDetailRes refundDetail(RefundDetailReq request, String url) throws Exception;

    /**
     * 查询退票手续费.
     *
     * @param paramCalcFeeReq
     *            paramCalcFeeReq
     * @return CalcFeeRes
     * @throws Exception
     *             Exception
     */
    public CalcFeeRes calcFee2(CalcFeeV2Req paramCalcFeeReq, String url) throws Exception;

    /**
     *
     * TODO查询票号.
     *
     * @param request
     *            请求
     * @return 票号信息
     * @throws Exception
     *             异常
     */
    public OrderTicketNoRes getTicketNo(OrderTicketNoReq request, String url) throws Exception;

    /**
     * 重新提交退票申请
     * @param request 请求入参
     * @param url 地址
     * @return 返回值
     * @throws Exception 异常
     */
    public RefundRes reApply(ReApplyReq request, String url) throws Exception;

    /**
     *
     * TODO改签航班查询.
     *
     * @param request
     *            请求
     * @return 票号信息
     * @throws Exception
     *             异常
     */
    public ReShoppingRes reShopping(ReShoppingReq request, String url) throws Exception;

    /**
     *
     * TODO改签航班查询.
     *
     * @param request
     *            请求
     * @return 票号信息
     * @throws Exception
     *             异常
     */
    public ReBookRes reBooking(ReBookReq request, String url) throws Exception;

    /**
     * 非自愿转自愿
     * @param request 请求入参
     * @param url 地址
     * @return 返回值
     * @throws Exception 异常
     */
    public CalcFeeRes reCalcFee(ReCalcFeeReq request, String url) throws Exception;
}