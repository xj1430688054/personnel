package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.InChannelFlightInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.OutChannelQueryFlightVo

/**
 * 渠道改签接口类.
 */
public interface IChannelChange {
    /**
     * 申请改签.
     * @param inChannelApplyChangeVo 申请改签入参.
     * @return 申请改签返回.
     */
    OutChannelApplyChangeVo channelApplyChange(InChannelApplyChangeVo inChannelApplyChangeVo) throws Exception;

    /**
     * 查询改签手续费.
     * @param inChannelQueryChangeFeeVo 查询改签手续费入参.
     * @return 查询改签手续费返回.
     */
    OutChannelQueryChangeFeeVo channelQueryChangeFee(InChannelQueryChangeFeeVo inChannelQueryChangeFeeVo) throws Exception;

    /**
     * 改签支付.
     * @param inChannelChangePayVo 改签支付入参.
     * @return 改签支付返回
     */
    OutChannelChangePayVo channelChangePay(InChannelChangePayVo inChannelChangePayVo);

    /**
     * 查询改签信息.
     * @param inChannelQueryChangeInfoVo 查询改签信息入参.
     * @return 查询改签信息返回.
     */
    OutChannelQueryChangeInfoVo channelQueryChangeInfo(InChannelQueryChangeInfoVo inChannelQueryChangeInfoVo);


    /**
     * 查询航班信息.
     * @param infoVo 查询航班信息入参.
     * @return
     */
    OutChannelQueryFlightVo queryFlightInfo(InChannelFlightInfoVo infoVo);
}
