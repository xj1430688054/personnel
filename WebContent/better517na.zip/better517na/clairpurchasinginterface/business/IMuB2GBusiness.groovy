package config.groovyFiles.com.better517na.clairpurchasinginterface.business;

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.*;
import com.better517na.muB2gService.*;

public interface IMuB2GBusiness {
    /**
     * TODO 添加方法注释.
     *
     * @param orderInfo 订单信息.
     * @param url   channel.
     * @return 结果
     * @throws Exception 异常
     */
    RtnOrderInfo createOrder(OrderInfo orderInfo, String url) throws Exception;

    RtnEcfareInfo validPrice(EcfareInfoInput request, String url) throws Exception;

    /**
     * 订单状态查询接口.
     */
    ResponseVo<OutQueryOrderInfoVo> queryOrderDetail(RequestVo<InQueryOrderInfoVo> requestVo);

    /**
     * 出票
     *
     * @param requestVo 出票入参
     * @return 返回结果
     */
    ResponseVo<OutTicketingVo> ticketing(RequestVo<InTicketingVo> requestVo);



    /**
     *航班查询&&询价接口.
     * @param searchInfoVo
     * @return
     * @throws Exception
     */
    SearchResponse queryFlight(SearchInfo searchInfoVo) throws Exception;


    /**
     *
     * queryChangeOrderStatus.
     *
     * @param statusQueryInfo
     *            订单
     * @param channel
     *            channel.
     * @return statusQueryInfo 结果
     * @throws Exception
     *             异常
     */
    RtnOrderStatusInfo queryChangeOrderStatus(StatusQueryInfo statusQueryInfo, String channel) throws Exception;

}
