package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FightVetifiRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FightVetifiRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.QueryChangeInfo.QueryChangInfoReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.QueryChangeInfo.QueryChangInfoRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRS

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.InGetOrderListReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.OutGetOrderListResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.queryOrderDetail.InQueryOrderDetailReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.queryOrderDetail.OutQueryOrderDetailResVo

public interface IZHB2GBusiness {
String seartchSingleLine();//////////

    public FightVetifiRS fightVetifiRS(FightVetifiRQ fightVetifiRQ);

    public StandardFareRS standardFareRS (StandardFareRQ standardFareRQ);

    /**
     * 查询订单详细信息
     * @param req
     * @return
     */
   public  OutQueryOrderDetailResVo OrderDetail(InQueryOrderDetailReqVo req,String url);

    /**
     * 获取订单列表
     * @param req
     * @return
     */
    public  OutGetOrderListResVo getOrderList(InGetOrderListReqVo req,String url);

    /**
     * 查询改签订单信息
     * @param
     * @return
     */
    public QueryChangInfoRes changInfoRes(QueryChangInfoReq req);
}