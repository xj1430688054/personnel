package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * md5���ܹ���
 * 
 * @author Administrator
 * 
 */
public class MD5Tool {
	/**
	 * Ĭ����utf-8����
	 * 
	 * @param source
	 * @return
	 */
	public static String MD5Encode(String source) {
		return MD5Encode(source, "UTF-8");
	}
	public static String MD5Encode(String source, String encode) {
		if (source == null) {
			return null;
		}
		if (StringUtils.isBlank(encode)) {
			return null;
		}

		try {
			return DigestUtils.md5Hex(source.getBytes(encode));
		} catch (Exception e) {
			return null;
		}
	}

	public static void main(String[] args) {
		System.out.println(MD5Tool.MD5Encode(MD5Tool.MD5Encode("test")+"shgm_hbsl"));
        //System.out.println(MD5Tool.MD5Encode("190930105510314722"+"ZMJADMIN"+"hatcu8corpzjc5g7ywog"));


	}

}
