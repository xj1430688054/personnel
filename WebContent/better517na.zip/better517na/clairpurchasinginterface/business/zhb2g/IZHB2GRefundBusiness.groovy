package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g


import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelChangOrRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.InChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHChangLegResConvertt
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHResConvert
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHChangLegResConvert
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.InChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.OutChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.ApplyRefund.ApplyRefundRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.ApplyRefund.ApplyRefundRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.canRefundLeg.CanRefundLegRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.canRefundLeg.CanRefundLegRs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundCost.RefundCostRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundCost.RefundCostRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundInfo.RefundOrderDetailRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundInfo.RefundOrderDetailRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundOrder.RefundOrderRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundOrder.RefundOrderRS

public interface IZHB2GRefundBusiness {

    /**
     * 获取改签或者退票原因
     * @param request
     * @return
     */
    ZHResConvert getChangOrRefundReason(InChannelChangOrRefundVo inChannelChangOrRefundVo, String url);


    /**
     * 获取可改签航段接口
     * @param request
     * @return
     */
    ZHChangLegResConvert getChannelChangeLeg(InChannelChangeValidateTktStateParaVo inChannelChangOrRefundVo, String url);


    /**
     * 获取退款订单详细
     * @param airDocDisplayRQ
     * @return
     */
    RefundOrderDetailRS getRefundOrderDetail(RefundOrderDetailRQ refundOrderDetailRQ,String url);

    /**
     * 申请退款
     * @param airDocDisplayRQ
     * @return
     */
    ApplyRefundRS applyRefund(ApplyRefundRQ airDocDisplayRQ,String url);

    /**
     * 获取退票订单列表
     * @param refundOrderRQ
     * @return
     */
    RefundOrderRS queryRefundOrder(RefundOrderRQ refundOrderRQ,String url);

    /**
     * 查询退票费用
     * @param refundCostRQ
     * @return
     */
    RefundCostRS getRefundCost(RefundCostRQ refundCostRQ,String url);

    /**
     * 获取可退航段接口
     * @param canRefundLegRQ
     * @return
     */
    CanRefundLegRs getCanRefundLeg(CanRefundLegRQ canRefundLegRQ,String url)


}