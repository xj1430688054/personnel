package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory

public class HttpClientHelper {


    private static Logger logger = LoggerFactory.getLogger(HttpClientHelper.class);

    private HttpClientHelper() {

    }

    /**
     * 发起POST请求
     *
     * @param url       url
     */
    public static String sendPost(String url,String dataxml, String hyid,String secrect,String clkid,String method) {

        Map<String, String> map = null;


        System.out.println(dataxml);
        map = DemoUtils.getInstance().getB2GParams(dataxml, method, hyid, secrect);//�����ѯ��
        NameValuePair[] params = new NameValuePair[map.size()];
        int i = 0;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            params[i++] = new NameValuePair(entry.getKey(), entry.getValue());
        }

        String result =null;
        try {
        result=DemoUtils.getInstance().sendHttpClient(url, params, "UTF-8");
        } catch (UnknownHostException e){
           e.printStackTrace();
        } catch (Exception e) {
           e.printStackTrace();

        }
        //打印深航返回json，测试用
        System.out.println("深航返回JSON："+result);
        return result;
    }

    /**
     * 发起GET请求
     *
     * @param urlParam url请求，包含参数
     */
    public static String sendGet(String urlParam) {
        logger.info("开始发起GET请求，请求地址为{}", urlParam);
        // 创建httpClient实例对象
        HttpClient httpClient = new HttpClient();
        // 设置httpClient连接主机服务器超时时间：15000毫秒
        httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(15000);
        // 创建GET请求方法实例对象
        GetMethod getMethod = new GetMethod(urlParam);
        // 设置post请求超时时间
        getMethod.getParams().setParameter(HttpMethodParams.SO_TIMEOUT, 60000);
        getMethod.addRequestHeader("Content-Type", "application/json");
        try {
            httpClient.executeMethod(getMethod);
            String result = getMethod.getResponseBodyAsString();
            getMethod.releaseConnection();
            logger.info("返回信息为{}", result);
            return result;
        } catch (IOException e) {
            logger.error("GET请求发出失败，请求的地址为{}，错误信息为{}", urlParam, e.getMessage(), e);
        }
        return null;
    }

    /*public static void main(String[] args) {
        String url = "https://jiashubing.cn/tencenttest";
        String param = "{\"aaa\":\"bbbbbbb\"}";
        sendPost(url, param);
        String urlParam = "https://jiashubing.cn/talk/document?fileid=1234";
        sendGet(urlParam);
    }*/





}
