package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.InChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHChangLegResConvert
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.DoBookRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.DoBookRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.ReshopReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.ReshopResp
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.EndorseCostResRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.InChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.OutChangeOrderListVo

interface IZHB2GChangeBusiness {

    ReshopResp reshop(ReshopReq request,String url)

    /**
     * 改期升舱
     * @param request
     * @param url
     * @return
     */
    DoBookRS dochange(DoBookRQ request,String url)

    /**
     * 获取可改签航段接口
     * @param request
     * @return
     */
    ZHChangLegResConvert getChannelChangeLeg(InChannelChangeValidateTktStateParaVo inChannelChangOrRefundVo, String url)

    /**
     * 获取改签费用
     * @param request
     * @param url
     * @return
     */
    EndorseCostResRoot getEndorseCost(DoBookRQ request, String url);

    /**
     * 获取改签集合接口
     * @param canRefundLegRQ
     * @return
     */
    OutChangeOrderListVo getChangeList(InChangeOrderListVo inChangeOrderListVo, String url)
}