package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g
/**
 * 常量定义类
 * 需要配置的信息可以现在这个类定义
 */
class AppConst {

    //深航创单接口字段
    public static final String CREATE_ORDER_URL = "http://113.100.141.235:8088/openapi/b2g/lticket";
    public static final String CREATE_ORDER_METHOD = "DTICK_B2G_bookTicket";
    public static final String HY_ID = "191108112148948883";
    public static final String CLK_ID = "191108112148803";
    public static final String CREATE_ORDER_SECRECT = "myped43gn2owixv8vhgb";
    //深航支付接口字段
    public static final String PAY_URL = "http://113.100.141.235:8088/openapi/b2g/Onlinepay";
    public static final String PAY_METHOD = "PAY_B2G_autoPay";

}
