package config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils

/**
 * ���Թ�����
 * Created by youj on 2018/10/8.
 */
public class DemoUtils {

    private static DemoUtils instance = null;
    private DemoUtils(){}
    public static DemoUtils getInstance(){
        if (instance == null) {
            synchronized (DemoUtils.class) {
                if (instance == null) {
                    instance = new DemoUtils();
                }
            }
        }
        return instance;
    }


    public static Map<String,String>  getB2GParams(String dataXml,String Method,String hyid,String secrect){
        Map<String, String> map = new HashMap<String, String>();

        map.put("responseType", "2");
        map.put("data", dataXml);
        map.put("sign", MD5Tool.MD5Encode(MD5Tool.MD5Encode(hyid) + dataXml+ secrect));
        map.put("service", Method);
        map.put("logOpen", "1");
        map.put("account", hyid);
        map.put("websiteCode", "y");
        map.put("compid","SHGM");
        map.put("version","1");
        map.put("channel", "WECHAT");
        return map;
    }


    public static String sendHttpClient(String url, org.apache.commons.httpclient.NameValuePair[] params, String encode) throws Exception {
        if (StringUtils.isBlank(encode)) {
            encode = "UTF-8";
        }
        HttpClient client = new HttpClient();
        PostMethod method = new PostMethod(url);
        method.addParameters(params);
        method.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        int statusCode = 0;
        String res = "";
        try {
            statusCode = client.executeMethod(method);
            byte[] responseBody = method.getResponseBody();
            res = StringUtils.trimToEmpty(new String(responseBody, encode));
        } catch (UnknownHostException e){
            //���������쳣
            throw e;
        } catch (Exception e) {
            throw e;
        } finally {
            method.releaseConnection();
            client.getHttpConnectionManager().closeIdleConnections(0);
        }
        if (statusCode == HttpStatus.SC_OK) {
            return res;
        } else {
            throw new Exception("HTTP���������쳣��״̬�룺" + statusCode + "��������:" + res);
        }
    }
}
