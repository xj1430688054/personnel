package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.utils.DateUtil
import com.better517na.clairpurchasinginterface.utils.MD5Util
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogAcc
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.Direction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.muB2gService.*
import com.better517na.mub2gPayService.DaikouWsService
import com.better517na.mub2gPayService.DaikouWsService_Service
import com.better517na.mub2gUatpPayService.UatpWsService_Service
import com.better517na.mub2gUatpPayService.UatpWsService
import com.better517na.mub2gPayService.MessageBean
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IMuB2GBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyTicketInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mub2g.MPayParamIn
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.MPResult
import org.apache.cxf.jaxws.binding.soap.SOAPBindingImpl
import com.google.gson.reflect.TypeToken
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import org.springframework.util.StringUtils

import javax.xml.bind.JAXB
import javax.xml.ws.Service
import java.text.DecimalFormat

@Component
public class MuB2GBusinessImpl implements IMuB2GBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 东航B2G接口地址.
     */
    @Value(value = '${muB2G.url}')
    private String url;

    private Gson gson = new Gson();

    /**
     * 创单接口.
     */
    @Override
    public RtnOrderInfo createOrder(OrderInfo orderInfo, String url) throws Exception {
        RtnOrderInfo response = null;
        Long totalTime = null;
        try {
            Service service = Service.create(CeaEcFacadeService.SERVICE);
            service.addPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url);
            CeaEcFacadeServicePortType ceaEcFacadeService = service.getPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, CeaEcFacadeServicePortType.class);
            long startTime = System.currentTimeMillis();
            response = ceaEcFacadeService.sendOrder(orderInfo);
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '东航B2G创建订单出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final OrderInfo newrequest = orderInfo;
                final RtnOrderInfo newresponse = response;
                final String curl = url;
                final Long newTotalTime = totalTime;
                new Thread() {
                    public void run() {
                        try {
                            OutputStream requestXml = new ByteArrayOutputStream();
                            OutputStream responsetXml = new ByteArrayOutputStream();
                            JAXB.marshal(newrequest, requestXml);
                            if (newresponse != null) {
                                JAXB.marshal(newresponse, responsetXml);
                            }
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('B2G接口交互');
                            interactionParam.setKey1('sendOrder');
                            if (newTotalTime != null) {
                                interactionParam.setKey2(newTotalTime.toString());
                            }
                            interactionParam.setSendAddress(curl);
                            interactionParam.setSendContent(requestXml.toString());
                            interactionParam.setReceiveContent(responsetXml.toString());
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    /**
     * 验价{@inheritDoc}.
     */
    @Override
    public RtnEcfareInfo validPrice(EcfareInfoInput request, String url) throws Exception {
        RtnEcfareInfo response = null;
        Long totalTime = null;
        try {
            Service service = Service.create(CeaEcFacadeService.SERVICE);
            service.addPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url);
            CeaEcFacadeServicePortType ceaEcFacadeService = service.getPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, CeaEcFacadeServicePortType.class);
            long startTime = System.currentTimeMillis();
            response = ceaEcFacadeService.ecfareQuery(request);
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '东航B2G验价信息出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final EcfareInfoInput newrequest = request;
                final RtnEcfareInfo newresponse = response;
                final Long newTotalTime = totalTime;
                final String curl = url;
                new Thread() {
                    public void run() {
                        try {
                            OutputStream requestXml = new ByteArrayOutputStream();
                            OutputStream responsetXml = new ByteArrayOutputStream();
                            JAXB.marshal(newrequest, requestXml);
                            if (newresponse != null) {
                                JAXB.marshal(newresponse, responsetXml);
                            }
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('B2G接口交互');
                            interactionParam.setKey1('ecfareQuery');
                            if (newTotalTime != null) {
                                interactionParam.setKey2(newTotalTime.toString());
                            }
                            interactionParam.setSendAddress(curl);
                            interactionParam.setSendContent(requestXml.toString());
                            interactionParam.setReceiveContent(responsetXml.toString());
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    /**
     * 订单状态查询接口
     *
     * @param requestVo 请求参数
     * @return 返回结果
     */
    public ResponseVo<OutQueryOrderInfoVo> queryOrderDetail(RequestVo<InQueryOrderInfoVo> requestVo) {
        ResponseVo<OutQueryOrderInfoVo> responseVo = new ResponseVo<OutQueryOrderInfoVo>();
        StatusQueryInfo statusQueryInfo = null;
        RtnOrderStatusInfo response = null;
        try {
            statusQueryInfo = this.createQueryOrderStatusRequest(requestVo.getSupplySystemInfo(), requestVo.getBody().getBigCustomerNo(), requestVo.getBody().getAirOrderId());
            response = this.queryChangeOrderStatus(statusQueryInfo, requestVo.getSupplySystemInfo().getInterfaceUrl() + 'CeaEcFacadeService');

            if (response == null) {
                responseVo.setSuccess(false);
                responseVo.setMsg('返回值为空');
                return responseVo;
            }

            if (!''.equals(response.getRTNERRID().getValue())) {
                responseVo.setSuccess(false);
                responseVo.setMsg(response.getRTNERRID().getValue() + response.getRTNERRMSG().getValue());
                return responseVo;
            }

            responseVo.setSuccess(true);
            responseVo.setMsg(response.getRTNERRID().getValue());
            responseVo.setResult(this.createQueryOrderStatusResponse(response));
            return responseVo;
        } catch (Exception e) {
            responseVo.setSuccess(false);
            responseVo.setMsg('调用东航B2G接口异常：' + e.getMessage());
            return responseVo;
        } finally {
            try {
                // 使用异步方式记日志
                final StatusQueryInfo newrequest = statusQueryInfo;
                final RtnOrderStatusInfo newresponse = response;
                new Thread() {
                    public void run() {
                        OutputStream requestXml = new ByteArrayOutputStream();
                        OutputStream responsetXml = new ByteArrayOutputStream();
                        JAXB.marshal(newrequest, requestXml);
                        if (null != newresponse) {
                            JAXB.marshal(newresponse, responsetXml);
                        }
                        MLogInteraction interactionParam = new MLogInteraction();
                        interactionParam.setModule('B2G订单查询接口交互');
                        interactionParam.setKey1('orderStatus');
                        interactionParam.setSendContent(requestXml.toString());
                        interactionParam.setReceiveContent(responsetXml.toString());
                        logBusiness.writeInteractionLog(interactionParam);
                    }
                }.start();
            } catch (Exception ex) {
            }
        }
    }

    /**
     * 出票
     *
     * @param requestVo 出票入参
     * @return 返回结果
     */
    public ResponseVo<OutTicketingVo> ticketing(RequestVo<InTicketingVo> requestVo) {
        ResponseVo<OutTicketingVo> responseVo = new ResponseVo<OutTicketingVo>();
        // //先查询订单状态，订单状态满足在做支付
        OutTicketingVo result = new OutTicketingVo();
        try {
            StatusQueryInfo queryInParam = this.createQueryOrderStatusRequest(requestVo.getSupplySystemInfo(), requestVo.getBody().getBigCustomerNo(), requestVo.getBody().getAirOrderId());
            RtnOrderStatusInfo queryOrderStatus = this.queryChangeOrderStatus(queryInParam, requestVo.getSupplySystemInfo().getInterfaceUrl() + 'CeaEcFacadeService');
            if (queryOrderStatus == null) {
                responseVo.setSuccess(false);
                responseVo.setMsg('接口调用异常');
                return responseVo;
            }

            if (!''.equals(queryOrderStatus.getRTNERRID().getValue())) {
                responseVo.setSuccess(false);
                responseVo.setMsg(queryOrderStatus.getRTNERRMSG().getValue());
                return responseVo;
            }

            // 尚未支付，调用支付
            if ('N'.equals(queryOrderStatus.getPAYSTATUS().getValue()) && 'N'.equals(queryOrderStatus.getORDERSTATUS().getValue())) {
                // 支付前要先判断支付方式，6易宝，8商旅卡，9UATP
                InTicketingVo ticketInfoVo = requestVo.getBody();
                if (StringUtils.isEmpty(ticketInfoVo.getPayInfo())) {
                    responseVo.setSuccess(false);
                    responseVo.setMsg('构建支付信息失败');
                    return responseVo;
                }

                // payInfo长度为4位或者长度为5位，并且PayType=6的走易宝，否则按支付方式走
                String[] payInfo = ticketInfoVo.getPayInfo().split('\\|');
                if (payInfo.length < 4) {
                    responseVo.setSuccess(false);
                    responseVo.setMsg('构建支付信息失败');
                    return responseVo;
                }

                com.better517na.mub2gPayService.MessageBean resultBean = null;
                MPayParamIn buildPayInParam = null;
                if (payInfo.length == 4 || (payInfo.length > 4 && payInfo[4].equals('6'))) {
                    //走易宝支付
                    buildPayInParam = this.buildPayInParam(requestVo);
                    if (buildPayInParam == null) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg('构建支付信息失败');
                        return responseVo;
                    }

                    resultBean = this.ticketingPay(buildPayInParam);
                } else if (payInfo[4].equals('8')) {
                    //走商旅卡支付
                    buildPayInParam = this.buildPayInParamByBusCard(requestVo);
                    if (buildPayInParam == null) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg('构建支付信息失败');
                        return responseVo;
                    }

                    resultBean = this.ticketingPayBusCard(buildPayInParam);
                } else {
                    responseVo.setSuccess(false);
                    responseVo.setMsg('暂不支持该支付方式：PayType=' + payInfo[4]);
                    return responseVo;
                }

                if (resultBean == null) {
                    responseVo.setSuccess(false);
                    responseVo.setMsg('接口调用异常,未获取到返回值');
                    return responseVo;
                }

                //成功的再做一次查询
                if ('0000'.equalsIgnoreCase(resultBean.getErrCode().getValue()) || (payInfo[4].equals('8') && '333333'.equalsIgnoreCase(resultBean.getErrCode().getValue()))) {
                    result.setOutOrderId(resultBean.getExternalOrderId().getValue() == null ? '' : resultBean.getExternalOrderId().getValue());
                    Thread.sleep((long) 2 * 1000);
                    queryOrderStatus = this.queryChangeOrderStatus(queryInParam, requestVo.getSupplySystemInfo().getInterfaceUrl() + 'CeaEcFacadeService');
                    if (!''.equals(queryOrderStatus.getRTNERRID().getValue())) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg(queryOrderStatus.getRTNERRMSG().getValue());
                        return responseVo;
                    }
                } else {
                    responseVo.setSuccess(false);
                    responseVo.setMsg(resultBean.getErrMsg().getValue());
                    return responseVo;
                }

            } else if ('X'.equals(queryOrderStatus.getORDERSTATUS().getValue())) {
                responseVo.setSuccess(false);
                responseVo.setMsg('订单已取消');
                return responseVo;
            }

            return this.anylysisQueryResult(queryOrderStatus, requestVo.getBody().getAirOrderId(), result);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '系统出错', e));
            responseVo.setSuccess(false);
            responseVo.setMsg('系统处理异常');
            return responseVo;
        }
    }

    /**
     * 商旅卡出票支付.
     * @param buildPayInParam 入参.
     * @return 返回结果.
     */
    public com.better517na.mub2gPayService.MessageBean ticketingPayBusCard(MPayParamIn buildPayInParam) {
        com.better517na.mub2gPayService.MessageBean result = null;
        com.better517na.mub2gUatpPayService.MessageBean uatpResultBean = null;
        try {
            Service service = Service.create(UatpWsService_Service.SERVICE);
            service.addPort(UatpWsService_Service.UatpWsServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, buildPayInParam.getServiceUrl());
            UatpWsService uatpService = service.getPort(UatpWsService_Service.UatpWsServiceHttpPort, UatpWsService.class);
            uatpResultBean = uatpService
                    .zhj(buildPayInParam.getOrderId(), buildPayInParam.getEncrypt(), buildPayInParam.getAmt(), buildPayInParam.getPushurl());
            if (uatpResultBean != null) {
                result = new com.better517na.mub2gPayService.MessageBean();
                result.setErrCode(uatpResultBean.getErrCode());
                result.setErrMsg(uatpResultBean.getErrMsg());
                result.setExternalOrderId(uatpResultBean.getExternalOrderId());
            }
        } catch (Exception e) {
            System.out.println(e.toString());
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '商旅卡支付访问航司出错', e));
        } finally {
            try {
                final MPayParamIn payInParam = buildPayInParam;
                com.better517na.mub2gUatpPayService.MessageBean newresponse = uatpResultBean;
                new Thread() {
                    public void run() {
                        MPayParamIn inParam = payInParam;
                        OutputStream responsetXml = new ByteArrayOutputStream();
                        if (null != newresponse) {
                            JAXB.marshal(newresponse, responsetXml);
                        }
                        MLogInteraction interactionParam = new MLogInteraction();
                        interactionParam.setModule('B2G订单支付接口交互');
                        interactionParam.setKey1('zhj');
                        interactionParam.setReceiveContent(responsetXml.toString());
                        interactionParam.setSendContent(gson.toJson(inParam));
                        logBusiness.writeInteractionLog(interactionParam);
                    }
                }.start();
            } catch (Exception e) {
            }
        }

        return result;
    }

    /**
     * 商旅卡出票支付.
     * @param buildPayInParam 入参.
     * @return 返回结果.
     */
    public com.better517na.mub2gPayService.MessageBean ticketingPay(MPayParamIn buildPayInParam) {
        com.better517na.mub2gPayService.MessageBean result = null;
        try {
            Service service = Service.create(DaikouWsService_Service.SERVICE);
            service.addPort(DaikouWsService_Service.DaikouWsServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, buildPayInParam.getServiceUrl());
            DaikouWsService daikouService = service.getPort(DaikouWsService_Service.DaikouWsServiceHttpPort, DaikouWsService.class);
            result = daikouService
                    .daikou(buildPayInParam.getOrderId(), buildPayInParam.getEncrypt(), buildPayInParam.getAmt(), buildPayInParam.getPaidTp(), buildPayInParam.getPushurl());
        } catch (Exception e) {
            System.out.println(e.toString());
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '商旅卡支付访问航司出错', e));
        } finally {
            try {
                final MPayParamIn payInParam = buildPayInParam;
                com.better517na.mub2gPayService.MessageBean newresponse = result;
                new Thread() {
                    public void run() {
                        MPayParamIn inParam = payInParam;
                        OutputStream responsetXml = new ByteArrayOutputStream();
                        if (null != newresponse) {
                            JAXB.marshal(newresponse, responsetXml);
                        }
                        MLogInteraction interactionParam = new MLogInteraction();
                        interactionParam.setModule('B2G订单支付接口交互');
                        interactionParam.setKey1('daikou');
                        interactionParam.setReceiveContent(responsetXml.toString());
                        interactionParam.setSendContent(gson.toJson(inParam));
                        logBusiness.writeInteractionLog(interactionParam);
                    }
                }.start();
            } catch (Exception e) {
            }
        }

        return result;
    }

    /**
     * 订单查询原子方法
     *
     * @param statusQueryInfo 查询参数
     * @param url 请求地址
     * @return 返回结果
     * @throws Exception 异常
     */
    @Override
    public RtnOrderStatusInfo queryChangeOrderStatus(StatusQueryInfo statusQueryInfo, String url) throws Exception {
        RtnOrderStatusInfo rtnOrderStatusInfo = null;
        try {
            Service service = Service.create(CeaEcFacadeService.SERVICE);
            service.addPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url);
            CeaEcFacadeServicePortType ceaEcFacadeService = service.getPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, CeaEcFacadeServicePortType.class);
            rtnOrderStatusInfo = ceaEcFacadeService.orderStatus(statusQueryInfo);
        } finally {

            try {
                // 使用异步方式记日志
                final StatusQueryInfo newrequest = statusQueryInfo;
                final RtnOrderStatusInfo newresponse = rtnOrderStatusInfo;
                new Thread() {
                    public void run() {
                        OutputStream requestXml = new ByteArrayOutputStream();
                        OutputStream responsetXml = new ByteArrayOutputStream();
                        JAXB.marshal(newrequest, requestXml);
                        if (null != newresponse) {
                            JAXB.marshal(newresponse, responsetXml);
                        }
                        MLogInteraction interactionParam = new MLogInteraction();
                        interactionParam.setModule('B2G订单查询接口交互');
                        interactionParam.setKey1('orderStatus');
                        interactionParam.setReceiveContent(responsetXml.toString());
                        interactionParam.setSendContent(requestXml.toString());
                        logBusiness.writeInteractionLog(interactionParam);
                    }
                }.start();
            } catch (Exception ex) {
            }
        }

        return rtnOrderStatusInfo;
    }

    /**
     * TODO 构建支付请求入参.
     *
     * @param requestVo 请求
     * @return 结果
     */
    private MPayParamIn buildPayInParam(RequestVo<InTicketingVo> requestVo) {
        InTicketingVo ticketInfoVo = requestVo.getBody();
        SupplySystemInfo supplySystemInfo = requestVo.getSupplySystemInfo();
        String[] payInfo = ticketInfoVo.getPayInfo().split('\\|');
        if (supplySystemInfo == null) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '未获取到账户信息，请检查入参!', new Exception('未获取到账户信息，请检查入参!')));
            return null;
        }

        MPayParamIn payInParam = new MPayParamIn();
        String customerName = ticketInfoVo.getBigCustomerNo();
        String orderId = ticketInfoVo.getAirOrderId();
        String cardNo = payInfo[0]; // 'chenfuming2@test.com';
        String signKey = payInfo[1]; // '1794941b-c15d-491a-9a8d-16d71cc2a607';
        String userNameString = supplySystemInfo.getInterfaceAccount();
        String password = supplySystemInfo.getInterfacePassWord();
        String sign = MD5Util.md5Hex((customerName + orderId + cardNo + signKey).getBytes()).toUpperCase();
        String encrypt = 'customerName=' + customerName + '&orderId=' + orderId + '&cardNo=' + cardNo + '&signMsg=' + sign + '&userId=' + userNameString + '&password=' + password;
        BigInteger e = new BigInteger('65537');

        BigInteger n = new BigInteger('19088884874345537868197456139999183195584621814137005' + '709517008924265378761074128004769930595545052' + '4284144975170623710456573144454170656337707433'
                + '41669147122887594204420544425331025195283965770' + '15023502735042564678681062962824706950878663730' + '40815048275798304875024255366782116655907180184'
                + '18027077172986537508764414819485429305431448645' + '90122288392440347193562165043148371310560931610' + '70071547119869393423515186164308315548820022972'
                + '14477828256683830764847804234342898655578096580' + '76429677728383731480606039191566442587188099975' + '01838786572095047231501225037523282208069369949'
                + '83848348919610405719539262015200707475346107381623');
        String cs = '';
        try {
            byte[] ptext = encrypt.getBytes('utf-8');
            BigInteger m = new BigInteger(ptext);
            BigInteger c = m.modPow(e, n);
            cs = c.toString();
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        payInParam.setOrderId(ticketInfoVo.getAirOrderId());
        payInParam.setAmt(new DecimalFormat('######0.00').format(ticketInfoVo.getPayMoney()));
        payInParam.setEncrypt(cs);
        payInParam.setPushurl(payInfo[2]);
        payInParam.setServiceUrl(payInfo[3]);
        return payInParam;
    }

    /**
     * TODO 构建支付请求入参(商旅卡支付).
     *
     * @param requestVo 请求
     * @return 结果
     */
    private MPayParamIn buildPayInParamByBusCard(RequestVo<InTicketingVo> requestVo) {
        InTicketingVo ticketInfoVo = requestVo.getBody();
        SupplySystemInfo supplySystemInfo = requestVo.getSupplySystemInfo();
        String[] payInfo = ticketInfoVo.getPayInfo().split('\\|');
        if (payInfo.length < 6) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '未获取到支付信息', new Exception('未获取到支付信息')));
            return null;
        }
        if (supplySystemInfo == null) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '未获取到账户信息，请检查入参!', new Exception('未获取到账户信息，请检查入参!')));
            return null;
        }

        MPayParamIn payInParam = new MPayParamIn();
        String customerName = ticketInfoVo.getBigCustomerNo();
        String orderId = ticketInfoVo.getAirOrderId();
        String cardNo = payInfo[0]; // 'chenfuming2@test.com';
        String signKey = payInfo[1]; // '1794941b-c15d-491a-9a8d-16d71cc2a607';
        //这里拿到的是年月日这种，2018-07-15，要处理成0718
        String expiredDate = DateUtil.dateToString(DateUtil.stringToDate(payInfo[5], 'yyyy-MM-dd'), 'MMyy');
        String userNameString = supplySystemInfo.getInterfaceAccount();
        String password = supplySystemInfo.getInterfacePassWord();
        String sign = MD5Util.md5Hex((customerName + orderId + cardNo + expiredDate + signKey).getBytes()).toUpperCase();
        String encrypt = 'customerName=' + customerName + '&orderId=' + orderId + '&cardNo=' + cardNo + '&expiredDate=' + expiredDate + '&signMsg=' + sign + '&userId=' + userNameString + '&password=' + password;
        BigInteger e = new BigInteger('65537');

        BigInteger n = new BigInteger('19088884874345537868197456139999183195584621814137005' + '709517008924265378761074128004769930595545052' + '4284144975170623710456573144454170656337707433'
                + '41669147122887594204420544425331025195283965770' + '15023502735042564678681062962824706950878663730' + '40815048275798304875024255366782116655907180184'
                + '18027077172986537508764414819485429305431448645' + '90122288392440347193562165043148371310560931610' + '70071547119869393423515186164308315548820022972'
                + '14477828256683830764847804234342898655578096580' + '76429677728383731480606039191566442587188099975' + '01838786572095047231501225037523282208069369949'
                + '83848348919610405719539262015200707475346107381623');
        String cs = '';
        try {
            byte[] ptext = encrypt.getBytes('utf-8');
            BigInteger m = new BigInteger(ptext);
            BigInteger c = m.modPow(e, n);
            cs = c.toString();
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        payInParam.setOrderId(ticketInfoVo.getAirOrderId());
        payInParam.setAmt(new DecimalFormat('######0.00').format(ticketInfoVo.getPayMoney()));
        payInParam.setEncrypt(cs);
        payInParam.setPushurl(payInfo[2]);
        payInParam.setServiceUrl(payInfo[3]);
        return payInParam;
    }

    /**
     * TODO 解析出票结果.
     *
     * @param queryOrderStatus 查询结果
     * @param airOrderID 航司订单号
     * @param result 结果
     * @return 结果
     */
    private ResponseVo<OutTicketingVo> anylysisQueryResult(RtnOrderStatusInfo queryOrderStatus, String airOrderID, OutTicketingVo result) {
        ResponseVo<OutTicketingVo> responseVo = new ResponseVo<OutTicketingVo>();
        if ('Y'.equals(queryOrderStatus.getTKTSTATUS().getValue())) {
            List<BuyTicketInfoBo> ticketList = new ArrayList<BuyTicketInfoBo>();
            // //result.setOutOrderId(airOrderID);
            for (TktItem item : queryOrderStatus.getTktItemList().getValue().getTktItem()) {
                ticketList.add(this.GetTicketInfo(item));
            }

            result.setTicketItem(ticketList);
        }

        responseVo.setSuccess(true);
        responseVo.setResult(result);
        responseVo.setMsg('调用成功');
        return responseVo;
    }

    private BuyTicketInfoBo GetTicketInfo(TktItem item) {
        BuyTicketInfoBo ticketItemVo = new BuyTicketInfoBo();

        // 获取乘机人信息
        String passengerName = '';
        if (item.getPAXCNM().getValue() != null && item.getPAXCNM().getValue().length() > 0) {
            passengerName = item.getPAXCNM().getValue().trim().replace(' ', '');
        }
        //获取乘机人证件号
        String passengerNo = '';
        if (item.getPASSNO().getValue() != null && item.getPASSNO().getValue().length() > 0) {
            passengerNo = item.getPASSNO().getValue().trim().replace(' ', ' ');
        }
        ticketItemVo.setCardNo(passengerNo);
        ticketItemVo.setUserName(passengerName);

        // 票号
        ticketItemVo.setTicketNo(item.getTKTNO().getValue().toString());
        if (ticketItemVo.getTicketNo() != null && !ticketItemVo.getTicketNo().contains('-') && ticketItemVo.getTicketNo().length() > 3) {
            StringBuilder buffer = new StringBuilder(ticketItemVo.getTicketNo());
            buffer.insert(3, '-');
            ticketItemVo.setTicketNo(buffer.toString());
        }

        int cardType = 2;
        if (item.getPASSTP().getValue().equals('NI')) {
            cardType = 0;
        } else if (item.getPASSTP().getValue().equals('PP')) {
            cardType = 1;
        }

        ticketItemVo.setCardType(cardType);

        return ticketItemVo;
    }

    /**
     * 构造订单状态查询请求
     *
     * @param supplySystemInfo 供应商信息
     * @param bigCustomerNo 大客户号
     * @param orderId 订单号
     * @return 返回结果
     * @throws Exception 异常
     */
    private StatusQueryInfo createQueryOrderStatusRequest(SupplySystemInfo supplySystemInfo, String bigCustomerNo, String orderId) throws Exception {
        if (null == supplySystemInfo) {
            throw new Exception('用户信息为空');
        }
        ObjectFactory objectFactory = new ObjectFactory();
        StatusQueryInfo statusQueryInfo = objectFactory.createStatusQueryInfo();

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        statusQueryInfo.setUSRDESC(objectFactory.createStatusQueryInfoUSRDESC(this.GetUserDesc(supplySystemInfo, bigCustomerNo)));

        // 用户账号
        statusQueryInfo.setUSRID(objectFactory.createStatusQueryInfoUSRID(supplySystemInfo.getInterfaceAccount()));

        // 用户密码
        statusQueryInfo.setUSRPWD(objectFactory.createStatusQueryInfoUSRPWD(supplySystemInfo.getInterfacePassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        statusQueryInfo.setUSRSQ(objectFactory.createStatusQueryInfoUSRSQ(supplySystemInfo.getpID()));

        // 要支付订单的订单编号
        statusQueryInfo.setOPSQ(objectFactory.createStatusQueryInfoOPSQ(orderId));
        return statusQueryInfo;
    }

    /**
     * 获取大客户号
     *
     * @param supplySystemInfo 供应接口信息
     * @param bigCustomerNo 大客户号
     * @return 返回用户描述
     */
    private String GetUserDesc(SupplySystemInfo supplySystemInfo, String bigCustomerNo) {
        return String.format(supplySystemInfo.getSecurityCode(), bigCustomerNo);
    }

    /**
     * 构造订单状态查询返回内容.
     *
     * @param rtnOrderStatusInfo 订单信息
     * @return outQueryOrderInfoVo 入参
     * @throws Exception 异常
     */
    private OutQueryOrderInfoVo createQueryOrderStatusResponse(RtnOrderStatusInfo rtnOrderStatusInfo) throws Exception {
        OutQueryOrderInfoVo outQueryOrderInfoVo = new OutQueryOrderInfoVo();
        OrderInfoVo orderInfo = new OrderInfoVo();
        List<BuyTicketInfoBo> ticketInfoList = new ArrayList<BuyTicketInfoBo>();

        // 订单状态1:已预订,等待支付;2:已支付;3:已出票;4:已取消;
        orderInfo.setOrderDisplayID(1);
        orderInfo.setOrderDisplayName('已预订,等待支付');

        // 订单状态（ N未处理/X已取消/C处理完成）
        if ('X'.equals(rtnOrderStatusInfo.getORDERSTATUS().getValue())) {
            orderInfo.setOrderDisplayID(4);
            orderInfo.setOrderDisplayName('已取消');
        }

        // 支付状态（ Y已支付/N未支付/I支付中）
        if ('Y'.equals(rtnOrderStatusInfo.getPAYSTATUS().getValue())) {
            orderInfo.setOrderDisplayID(2);
            orderInfo.setOrderDisplayName('已支付');
        }

        // 开票状态（ Y已开票/N未开票）
        if ('Y'.equals(rtnOrderStatusInfo.getTKTSTATUS().getValue())) {
            orderInfo.setOrderDisplayID(3);
            orderInfo.setOrderDisplayName('已出票');
        }

        // 订单编号
        orderInfo.setOrderId(rtnOrderStatusInfo.getOPSQ().getValue());
        for (TktItem tktItem : rtnOrderStatusInfo.getTktItemList().getValue().getTktItem()) {
            ticketInfoList.add(this.GetTicketInfo(tktItem));
        }

        outQueryOrderInfoVo.setOrderInfo(orderInfo);
        outQueryOrderInfoVo.setTicketInfoList(ticketInfoList);

        return outQueryOrderInfoVo;
    }

    /**
     * 航班查询&&询价接口.
     */
    @Override
    public SearchResponse queryFlight(SearchInfo searchInfo) throws Exception {
        SearchResponse response = null;
        try {
            Service service = Service.create(CeaEcFacadeService.SERVICE);
            service.addPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url);
            CeaEcFacadeServicePortType ceaEcFacadeService = service.getPort(CeaEcFacadeService.CeaEcFacadeServiceHttpPort, CeaEcFacadeServicePortType.class);
            response = ceaEcFacadeService.getAV(searchInfo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '东航B2G查询航班信息出错', e));
            e.printStackTrace();
            throw e;
        } finally {
            OutputStream requestXml = new ByteArrayOutputStream();
            JAXB.marshal(searchInfo, requestXml);
            String requestStr = requestXml.toString();
            String responseStr = '';
            if (response != null) {
                OutputStream responseXml = new ByteArrayOutputStream();
                JAXB.marshal(response, responseXml);
                responseStr = responseXml.toString();
            }

            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('queryFlight');
            interactionParam.setSendContent(requestStr);
            interactionParam.setReceiveContent(responseStr);
            interactionParam.setSendAddress(url);
            logBusiness.writeInteractionLog(interactionParam);
        }

        return response;
    }

    /**
     * TODO 添加方法注释.
     *
     * @param buildPayInParam 支付入参
     * @return 结果
     */
    public com.better517na.mub2gPayService.MessageBean payOrder(config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.MPayParamIn buildPayInParam) {
        com.better517na.mub2gPayService.MessageBean result = null;
        try {
            Service service = Service.create(DaikouWsService_Service.SERVICE);
            service.addPort(DaikouWsService_Service.DaikouWsServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, buildPayInParam.getServiceUrl());
            DaikouWsService daikouService = service.getPort(DaikouWsService_Service.DaikouWsServiceHttpPort, DaikouWsService.class);
            result = daikouService.daikou(buildPayInParam.getOrderId(), buildPayInParam.getEncrypt(), buildPayInParam.getAmt(), buildPayInParam.getPaidTp(), buildPayInParam.getPushurl());
        } catch (Exception e) {
            System.out.println(e.toString());
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '访问航司出错', e));
        } finally {
            try {
                logBusiness.writeAccLog(new MLogAcc(Direction.Response, 'PayOrder', gson.toJson(buildPayInParam), gson.toJson(this.convertPayResult(result)), '支付订单', buildPayInParam.getOrderId()));
                OutputStream requestXml = new ByteArrayOutputStream();
                JAXB.marshal(buildPayInParam, requestXml);
                String requestStr = requestXml.toString();
                String responseStr = '';
                if (result != null) {
                    OutputStream responseXml = new ByteArrayOutputStream();
                    JAXB.marshal(result, responseXml);
                    responseStr = responseXml.toString();
                }
                logBusiness.writeInteractionLog(new MLogInteraction('gwCommunicateJavaService', 'payOrder', null, buildPayInParam.getOrderId(), requestStr, responseStr));
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '改签支付结果解析异常', e));
            }
        }

        return result;
    }

    /**
     * TODO 添加方法注释.
     *
     * @param buildPayInParam 支付入参
     * @return 结果
     */
    public com.better517na.mub2gPayService.MessageBean payOrderBusCard(config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.MPayParamIn buildPayInParam) {
        com.better517na.mub2gPayService.MessageBean result = null;
        com.better517na.mub2gUatpPayService.MessageBean res = null;
        try {
            Service service = Service.create(UatpWsService_Service.SERVICE);
            service.addPort(UatpWsService_Service.UatpWsServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, buildPayInParam.getServiceUrl());
            UatpWsService uatpService = service.getPort(UatpWsService_Service.UatpWsServiceHttpPort, UatpWsService.class);
            res = uatpService.zhj(buildPayInParam.getOrderId(), buildPayInParam.getEncrypt(), buildPayInParam.getAmt(), buildPayInParam.getPushurl());
            if (res != null) {
                result = new com.better517na.mub2gPayService.MessageBean();
                result.setErrCode(res.getErrCode());
                result.setErrMsg(res.getErrMsg());
                result.setExternalOrderId(res.getExternalOrderId());
            }
        } catch (Exception e) {
            System.out.println(e.toString());
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '访问航司出错', e));
        } finally {
            try {
                logBusiness.writeAccLog(new MLogAcc(Direction.Response, 'PayOrder', gson.toJson(buildPayInParam), gson.toJson(this.convertPayResult(res)), '支付订单', buildPayInParam.getOrderId()));
                OutputStream requestXml = new ByteArrayOutputStream();
                JAXB.marshal(buildPayInParam, requestXml);
                String requestStr = requestXml.toString();
                String responseStr = '';
                if (res != null) {
                    OutputStream responseXml = new ByteArrayOutputStream();
                    JAXB.marshal(res, responseXml);
                    responseStr = responseXml.toString();
                }
                logBusiness.writeInteractionLog(new MLogInteraction('gwCommunicateJavaService', 'payOrder', null, buildPayInParam.getOrderId(), requestStr, responseStr));
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '改签支付结果解析异常', e));
            }
        }

        return result;
    }

    /**
     * TODO 转换支付结果.
     *
     * @param payRsult 支付记过
     * @return 结果
     */
    private MPResult convertPayResult(com.better517na.mub2gPayService.MessageBean payRsult) {
        if (payRsult == null) {
            return null;
        }

        MPResult result = new MPResult();
        result.setErrCode(payRsult.getErrCode().getValue());
        result.setErrMsg(payRsult.getErrMsg().getValue());
        result.setB2gOrderId(payRsult.getB2GOrderId().getValue());
        result.setAmount(payRsult.getAmount().getValue());
        result.setBankOrderID(payRsult.getPcSysSeqId().getValue());
        result.setOutTradeNo(payRsult.getExternalOrderId().getValue());
        return result;
    }

    /**
     * TODO 转换支付结果.
     *
     * @param payRsult 支付记过
     * @return 结果
     */
    private MPResult convertPayResult(com.better517na.mub2gUatpPayService.MessageBean payRsult) {
        if (payRsult == null) {
            return null;
        }

        MPResult result = new MPResult();
        result.setErrCode(payRsult.getErrCode().getValue());
        result.setErrMsg(payRsult.getErrMsg().getValue());
        result.setB2gOrderId(payRsult.getB2GOrderId().getValue());
        result.setAmount(payRsult.getAmount().getValue());
        result.setBankOrderID(payRsult.getPcSysSeqId().getValue());
        result.setOutTradeNo(payRsult.getExternalOrderId().getValue());
        return result;
    }
}
