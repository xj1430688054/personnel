package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.springAir

import com.better517na.clairpurchasinginterface.utils.MD5Util
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.springAirSalesService.BookOrderBookBean
import com.better517na.springAirSalesService.BookOrderResultBean
import com.better517na.springAirSalesService.GetFlightBgAppInputBean
import com.better517na.springAirSalesService.GetFlightBgAppResultBean
import com.better517na.springAirSalesService.GetOrderDetailInfoQueryBean
import com.better517na.springAirSalesService.GetOrderDetailInfoResultBean
import com.better517na.springAirSalesService.GetSpecificPriceInputBean
import com.better517na.springAirSalesService.GetSpecificPriceResultBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ISpringAirBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.springAir.SpringAirPayIn
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/10/22
 * Time: 19:47
 */
@Component
class SpringAirBusinessImpl extends SpringAirBaseBusiness implements ISpringAirBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 计算订单金额（售前）.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    GetSpecificPriceResultBean getSpecificPrice(GetSpecificPriceInputBean request, String url) {
        GetSpecificPriceResultBean result = (GetSpecificPriceResultBean) execute(request, 'getSpecificPrice', url);
        return result;
    }

    /**
     * 预订订单.
     * @param requestVo 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    BookOrderResultBean bookOrder(BookOrderBookBean request, String url) {
        BookOrderResultBean result = (BookOrderResultBean) execute(request, 'bookOrder', url);
        return result;
    }

    /**
     * 提交支付.
     * @param request request.
     * @return 结果.
     */
    @Override
    String pay(SpringAirPayIn request) {
        StringBuilder sb = new StringBuilder();
        sb.append('partner=' + request.getPartner());
        sb.append('&orderId=' + request.getOrderId());
        sb.append('&txnAmt=' + request.getTxnAmt());
        // 签名
        String oriSignStr = request.getPartner() + request.getOrderId() + request.getTxnAmt() + request.getSecret();
        String sign = MD5Util.md5Hex(oriSignStr.getBytes());
        sb.append('&signMsg=' + sign);
        sb.append('&authNo=' + request.getAuthNo());
        sb.append('&yeepartner=' + request.getYeepartner());
        sb.append('&catalog=' + request.getCatalog()); // 订单类型(缺省值:0)  0-机票订单，1-辅助订单，2-变更申请
        sb.append('&subProID=' + request.getSubProID()); // 辅助订单号 (二次购买辅助产品id或是航班变更id ,一次购买时为空)
        setLogBusiness(logBusiness);
        String res = this.doGet(request.getUrl(), sb.toString(), '春秋航空接口', '提交支付', 'UTF-8')
        return res; // 正确返回示例(扣款成功):0  错误返回示例(扣款失败): 签名有误！...
    }

    /**
     * 查询订单明细信息.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    GetOrderDetailInfoResultBean getOrderDetailInfo(GetOrderDetailInfoQueryBean request, String url) {
        GetOrderDetailInfoResultBean result = (GetOrderDetailInfoResultBean) execute(request, 'getOrderDetailInfo', url);
        return result;
    }

    /**
     * 查询订单明细信息.
     * @param request 请求.
     * @return 结果.
     */
    @Override
    GetFlightBgAppResultBean queryChangeFee(GetFlightBgAppInputBean request, String url){
        GetFlightBgAppResultBean result = (GetFlightBgAppResultBean) execute(request,'getFlightBgApp',url);
        return result;
    }
}
