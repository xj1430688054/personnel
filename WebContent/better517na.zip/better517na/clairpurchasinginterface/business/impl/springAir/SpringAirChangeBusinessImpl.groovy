package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.springAir

import com.better517na.springAirSalesService.GetFlightsCanBgInputBean
import com.better517na.springAirSalesService.GetFlightsCanBgResultBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoInputBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoResultBean
import com.better517na.springAirSalesService.SubmitFlightBgAppInputBean
import com.better517na.springAirSalesService.SubmitFlightBgAppResultBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ISpringAirChangeBusiness
import org.springframework.stereotype.Component

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/10/26
 * Time: 11:33
 */
@Component
class SpringAirChangeBusinessImpl extends SpringAirBaseBusiness implements ISpringAirChangeBusiness {
    @Override
    GetFlightsCanBgResultBean getFlightsCanBg(GetFlightsCanBgInputBean getFlightsCanBgInputBean, String url) {
        GetFlightsCanBgResultBean result = (GetFlightsCanBgResultBean) execute(getFlightsCanBgInputBean, 'getFlightsCanBg', url);
        return result;
    }

    /**
     * 提交网上航班变更申请2.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    SubmitFlightBgAppResultBean submitFlightBgApp2(SubmitFlightBgAppInputBean request, String url) {
        SubmitFlightBgAppResultBean result = (SubmitFlightBgAppResultBean) execute(request, 'submitFlightBgApp2', url);
        return result;
    }

    /**
     * 查询网上航班变更申请.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    QueryFlightBgAppInfoResultBean queryFlightBgAppInfo(QueryFlightBgAppInfoInputBean request, String url) {
        QueryFlightBgAppInfoResultBean result = (QueryFlightBgAppInfoResultBean) execute(request, 'queryFlightBgAppInfo', url);
        return result;
    }
}
