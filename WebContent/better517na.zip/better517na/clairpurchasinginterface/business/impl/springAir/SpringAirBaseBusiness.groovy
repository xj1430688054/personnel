package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.springAir

import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.springAirSalesService.ApplyReturnTicketInputBean
import com.better517na.springAirSalesService.BookOrderBookBean
import com.better517na.springAirSalesService.CalcRetTktFeeInputBean
import com.better517na.springAirSalesService.GetFlightBgAppInputBean
import com.better517na.springAirSalesService.GetFlightsCanBgInputBean
import com.better517na.springAirSalesService.GetOrderDetailInfoQueryBean
import com.better517na.springAirSalesService.GetSpecificPriceInputBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoInputBean
import com.better517na.springAirSalesService.SearchFlightsBatchSearchBean
import com.better517na.springAirSalesService.SearchFlightsBySegIdBean
import com.better517na.springAirSalesService.SearchFlightsDayBean
import com.better517na.springAirSalesService.SpringServiceSearchBookInterface
import com.better517na.springAirSalesService.SpringServiceSearchBookInterfaceService
import com.better517na.springAirSalesService.SubmitFlightBgAppInputBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.HttpBaseBusiness
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/10/23
 * Time: 18:14
 */
@Component
class SpringAirBaseBusiness extends HttpBaseBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 请求.
     *
     * @param request request.
     * @param method method.
     * @param url url.
     * @return 响应.
     */
    Object execute(Object request, String method, String url) {
        long totalTime = 0; // 记录耗时
        Object result = null;
        try {
            long begin = System.currentTimeMillis();
            SpringServiceSearchBookInterface sssb = getSpringServiceInterface(url);
            switch (method) {
                case 'getSpecificPrice':
                    result = sssb.getSpecificPrice((GetSpecificPriceInputBean) request);
                    break;
                case 'bookOrder':
                    result = sssb.bookOrder((BookOrderBookBean) request);
                    break;
                case 'getOrderDetailInfo':
                    result = sssb.getOrderDetailInfo((GetOrderDetailInfoQueryBean) request);
                    break;
                case 'calcRetTktFee':
                    result = sssb.calcRetTktFee((CalcRetTktFeeInputBean) request);
                    break;
                case 'applyReturnTicket2':
                    result = sssb.applyReturnTicket2((ApplyReturnTicketInputBean) request);
                    break;
                case 'getFlightsCanBg':
                    result = sssb.getFlightsCanBg((GetFlightsCanBgInputBean) request);
                    break;
                case 'submitFlightBgApp2':
                    result = sssb.submitFlightBgApp2((SubmitFlightBgAppInputBean) request);
                    break;
                case 'queryFlightBgAppInfo':
                    result = sssb.queryFlightBgAppInfo((QueryFlightBgAppInfoInputBean) request);
                    break;
                case 'searchFlightsBatch':
                    result = sssb.searchFlightsBatch((SearchFlightsBatchSearchBean) request);
                    break;
                case 'searchFlightsBySegId2':
                    result = sssb.searchFlightsBySegId2((SearchFlightsBySegIdBean) request);
                    break;
                case 'searchFlightsOtaDay':
                    result = sssb.searchFlightsOtaDay((SearchFlightsDayBean) request);
                    break;
                case 'getFlightBgApp':
                    result = sssb.getFlightBgApp((GetFlightBgAppInputBean) request);
                default: break;
            }
            totalTime = System.currentTimeMillis() - begin;
        } finally {
            setLogBusiness(logBusiness);
            writeInteractionLog('春秋航空接口', method, url, GsonUtil.gson.toJson(request), GsonUtil.gson.toJson(result), String.valueOf(totalTime));
        }
        return result;
    }

    /**
     * getSpringServiceInterface.
     * @param url url.
     * @return SpringServiceInterface.
     */
    static SpringServiceSearchBookInterface getSpringServiceInterface(String url) {
        SpringServiceSearchBookInterfaceService ss = new SpringServiceSearchBookInterfaceService(new URL(url));
        return ss.getSpringServiceSearchBookInterfacePort();
    }
}
