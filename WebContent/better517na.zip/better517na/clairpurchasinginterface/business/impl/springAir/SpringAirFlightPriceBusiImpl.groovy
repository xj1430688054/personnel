package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.springAir

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.springAirSalesService.FlightBasicInfo
import com.better517na.springAirSalesService.FlightEndPointInfo
import com.better517na.springAirSalesService.FlightInfo2
import com.better517na.springAirSalesService.NormSeatPriceInfo
import com.better517na.springAirSalesService.NormSeatPriceInfo2
import com.better517na.springAirSalesService.SearchFlightsBatchResultBean
import com.better517na.springAirSalesService.SearchFlightsBatchResultBean2
import com.better517na.springAirSalesService.SearchFlightsBatchSearchBean
import com.better517na.springAirSalesService.SearchFlightsBySegIdBean
import com.better517na.springAirSalesService.SearchFlightsDayBean
import com.better517na.springAirSalesService.SuperSeatPriceInfo
import com.better517na.springAirSalesService.SuperSeatPriceInfo2
import com.better517na.springAirSalesService.UsernameToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IFlightPriceBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.AirportCityInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.CabinInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.FlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.InterfaceSetting
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.ProductInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightSegIDParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightsBatchParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.StopOverInfo
import org.apache.commons.collections.CollectionUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import java.text.DecimalFormat

@Component('springAirFlightPrice')
public class SpringAirFlightPriceBusiImpl extends SpringAirBaseBusiness implements IFlightPriceBusiness {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 批量航班查询(按出发、到达、查询天数范围 查询航班信息)
     * @param param
     * @param url
     * @return
     */
    @Override
    QueryFlightResult searchFlightsBatch(QueryFlightRequest<QueryFlightsBatchParam> param, String url) {
        SearchFlightsBatchSearchBean request = new SearchFlightsBatchSearchBean();
        //参数转换；QueryFlightsBatchParam->SearchFlightsBatchSearchBean
        request = ConvertToSearchFlightsBatchSearchBean(param);
        SearchFlightsBatchResultBean resultBean = new SearchFlightsBatchResultBean();
        resultBean = (SearchFlightsBatchResultBean) execute(request, 'searchFlightsBatch', url);
        //返回值转换；
        QueryFlightResult result = ConvertToQueryFlightResult(resultBean);
        return result;
    }

    @Override
    QueryFlightResult searchFlightsBySegId2(QueryFlightRequest<QueryFlightSegIDParam> param, String url) {
        SearchFlightsBySegIdBean request = new SearchFlightsBySegIdBean();
        //参数转换；QueryFlightsBatchParam->SearchFlightsBySegIdBean
        request = ConvertToQueryFlightResult(param);
        SearchFlightsBatchResultBean2 resultBean2 = (SearchFlightsBatchResultBean2) execute(request, 'searchFlightsBySegId2', url);

        //返回值转换；SearchFlightsBatchResultBean2->QueryFlightResult
        QueryFlightResult result = ConvertToQueryFlightResultBySegId2(resultBean2);

        return result;
    }

    @Override
    QueryFlightResult searchFlightsOtaDay(QueryFlightRequest<QueryFlightParam> param, String url) {
        //参数转换；

        SearchFlightsDayBean request = new SearchFlightsDayBean();

        request = ConvertToSearchFlightsDayBean(param);

        SearchFlightsBatchResultBean resultBean2 = (SearchFlightsBatchResultBean) execute(request, 'searchFlightsOtaDay', url);

        //返回值转换；
        QueryFlightResult result = ConvertToQueryFlightResultOtaDay(resultBean2);

        return result
    }

    //region searchFlightsBatch-参数转换

    /**
     * 参数转换；QueryFlightRequest<QueryFlightsBatchParam>->SearchFlightsBySegIdBean
     * @param param 入参
     * @return 返回结果
     */
    private SearchFlightsBatchSearchBean ConvertToSearchFlightsBatchSearchBean(QueryFlightRequest<QueryFlightsBatchParam> param) {
        SearchFlightsBatchSearchBean result = new SearchFlightsBatchSearchBean();
        try {
            //代理客户端身份信息（NN）
            result.setUsernameToken(getUsernameToken(param.getInterfaceSetting()));
            //语言(NN)
            result.setLang('zh_cn');
            //销售币种id
            result.setMoneyClassId(0);
            //始发地三字码（NN）
            result.setOriCode(param.getQueryFlightParam().getDepAirport());
            //抵达地三字码（NN）
            result.setDestCode(param.getQueryFlightParam().getArrAirport());
            //三字码类型（oriCode和destCode的三字码类型，1-机场三字码，2-城市三字码。目前只支持传入1）（NN）
            result.setCodeType(1);
            //查询日期范围标识（NN，只能是1、2、3、4；1-查询当前时间开始向后0天到30天内的航班数据，2-查询31天到60天的航班数据，3-查询61天到90天的航班数据，4-查询91天到110天的航班数据）
            result.setDateRangeFlag(param.getQueryFlightParam().getQueryDateRangeType());
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '批量航班查询-searchFlightsBatch入参转换异常', ex));
        }
        return result;
    }

    /**
     * 参数转换；QueryFlightRequest<QueryFlightsBatchParam>->SearchFlightsBySegIdBean
     * @param param 入参
     * @return 返回结果
     */
    private QueryFlightResult ConvertToQueryFlightResult(SearchFlightsBatchResultBean resultBean) {
        QueryFlightResult result = new QueryFlightResult();
        try {
            List<FlightInfo> flightInfoList = new ArrayList<>();
            //春秋入参；
            List<com.better517na.springAirSalesService.FlightInfo> springAirflightInfolist = resultBean.getFlightsList();
            flightInfoList = getSpringAirFlightinfos(springAirflightInfolist);
            result.setFlightInfos(flightInfoList);
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '批量航班查询-searchFlightsBatch返回值转化异常', ex));
        }
        return result;
    }

    //endregion searchFlightsBatch-参数转换

    //region searchFlightsBySegId2-参数转换
    /**
     * 参数转换；QueryFlightRequest<QueryFlightSegIDParam>->SearchFlightsBySegIdBean
     * @param param 入参
     * @return 返回结果
     */
    private SearchFlightsBySegIdBean ConvertToQueryFlightResult(QueryFlightRequest<QueryFlightSegIDParam> param) {

        SearchFlightsBySegIdBean result = new SearchFlightsBySegIdBean();
        try {
            //代理客户端身份信息（NN）
            result.setUsernameToken(getUsernameToken(param.getInterfaceSetting()));
            //语言(NN)
            result.setLang('zh_cn');
            //销售币种id(NN)
            result.setMoneyClassId(0);
            //航段ID(NN)
            result.setSegmentHeadId(param.getQueryFlightParam().getSegID());
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '航班查询-searchFlightsBySegId2入参转换异常', ex));
        }
        return result;
    }

    /**
     * 参数转换；QueryFlightRequest<QueryFlightSegIDParam>->SearchFlightsBySegIdBean
     * @param param 入参
     * @return 返回结果
     */
    private QueryFlightResult ConvertToQueryFlightResultBySegId2(SearchFlightsBatchResultBean2 resultBean2) {
        QueryFlightResult result = new QueryFlightResult();
        try {
            List<FlightInfo> flightInfos = new ArrayList<>();
            List<FlightInfo2> flightsList = resultBean2.getFlightsList();
            flightInfos = getSpringAirFlightinfos2(flightsList);
            result.setFlightInfos(flightInfos);
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '航班查询-searchFlightsBySegId2返回值转换异常', ex));
        }
        return result;
    }

    //endregion searchFlightsBySegId2-参数转换

    //region searchFlightsOtaDay-参数转换
    /**
     * 参数转换；QueryFlightRequest<QueryFlightParam>->SearchFlightsDayBean
     * @param param 入参
     * @return 返回结果
     */
    private SearchFlightsDayBean ConvertToSearchFlightsDayBean(QueryFlightRequest<QueryFlightParam> param) {
        SearchFlightsDayBean result = new SearchFlightsDayBean();
        try {
            result.setUsernameToken(getUsernameToken(param.getInterfaceSetting()));
            //codeType;
            result.setCodeType(1);
            //destCode-抵达地---arrAirport-到达机场三字码;
            result.setDestCode(param.getQueryFlightParam().getArrAirport());
            //OriCode-出发地---depAirport-出发机场三字码;
            result.setOriCode(param.getQueryFlightParam().getDepAirport());
            //flightDay;
            result.setFlightDay(param.getQueryFlightParam().getDepDate());
            //lang
            result.setLang('zh_cn');
            //moneyClassId
            result.setMoneyClassId(0);
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '航班查询-searchFlightsOtaDay入参转换异常', ex));
        }
        return result;
    }

    /**
     * 参数转换；QueryFlightRequest<QueryFlightParam>->SearchFlightsDayBean
     * @param param 入参
     * @return 返回结果
     */
    private QueryFlightResult ConvertToQueryFlightResultOtaDay(SearchFlightsBatchResultBean resultBean2) {
        QueryFlightResult result = new QueryFlightResult();
        try {
            List<FlightInfo> flightInfos = new ArrayList<>();
            List<com.better517na.springAirSalesService.FlightInfo> flightsList = resultBean2.getFlightsList();
            flightInfos = getSpringAirFlightinfos(flightsList);
            result.setFlightInfos(flightInfos);
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '航班查询-searchFlightsOtaDay返回值转化异常', ex));
        }
        return result;
    }

    /**
     * 获取UsernameToken.
     * @param supplySystemInfo supplySystemInfo.
     * @return UsernameToken.
     */
    static UsernameToken getUsernameToken(InterfaceSetting interfaceSetting) {
        UsernameToken usernameToken = new UsernameToken();
        usernameToken.setUsername(interfaceSetting.getAccount());
        usernameToken.setPassword(interfaceSetting.getPassword());
        return usernameToken;
    }

    //endregion searchFlightsOtaDay-参数转换

    /**
     * 参数转换；SpringAirportCityInfo->AirportCityInfo
     * @param param 入参
     * @return 返回结果
     */
    private AirportCityInfo getSpringAirAirportCityInfo(com.better517na.springAirSalesService.AirportCityInfo springAirportCityInfo) {
        AirportCityInfo airportCityInfo = new AirportCityInfo();
        airportCityInfo.setAirportCode(springAirportCityInfo.getAirportCode());
        airportCityInfo.setAirportName(springAirportCityInfo.getAirportName());
        airportCityInfo.setTerminal(springAirportCityInfo.getAirportTerminal());
        airportCityInfo.setCityCode(springAirportCityInfo.getCityCode());
        airportCityInfo.setCityName(springAirportCityInfo.getCityName());
        return airportCityInfo
    }

    /**
     * 参数转换；com.better517na.springAirSalesService.FlightInfo->FlightInfo
     * @param param 入参
     * @return 返回结果
     */
    private List<FlightInfo> getSpringAirFlightinfos(List<com.better517na.springAirSalesService.FlightInfo> springAirFlightinfos) {
        List<FlightInfo> flightInfoList = new ArrayList<>();
        for (com.better517na.springAirSalesService.FlightInfo springAirFlightinfo : springAirFlightinfos) {
            FlightInfo flightInfo = new FlightInfo();
            //航段ID-segHeadId;springAirflightInfo.getFlightBasicInfo().getSegHeadId()
            String sSegHeadId = String.valueOf(springAirFlightinfo.getFlightBasicInfo().getSegHeadId());
            flightInfo.setSegmentID(sSegHeadId);
            //航司二字码-9C(春秋航空二字码);
            flightInfo.setAirCode('9C');
            //航司名称-春秋航空;
            flightInfo.setAirCodeDesc('春秋航空');
            //航班号，带航司-flightNo;
            flightInfo.setFlightNo(springAirFlightinfo.getFlightBasicInfo().getFlightNo());
            //起飞时间-oriEndPoint(航班始发节点)-timeBJ(国内航班);
            flightInfo.setTakeOffTime(getSpringAirTakeOffTime(springAirFlightinfo.getFlightBasicInfo().getOriEndPoint()));
            //到达时间-destEndPoint(航班抵达节点)-timeBJ(国内航班);
            flightInfo.setArriveTime(getSpringAirArriveTime(springAirFlightinfo.getFlightBasicInfo().getDestEndPoint()));
            //基建费(String)-portPay(Double);
            flightInfo.setBuildFee(springAirFlightinfo.getFlightBasicInfo().getPortPay().toString());
            //燃油费(String)-fuelFee(Double);
            flightInfo.setFuelFee(springAirFlightinfo.getFlightBasicInfo().getFuelFee().toString());
            //飞机大小;
            //飞机型号-机型acType
            flightInfo.setAirPlaneType(springAirFlightinfo.getFlightBasicInfo().getAcType());
            //共享航班信息,为空表示非共享航班
            //出发机场城市信息-oriEndPoint航班始发节点信息-FlightEndPointInfo：AirportCityInfo航段节点机场城市信息
            flightInfo.setDepAirportCityInfo(getSpringAirAirportCityInfo(springAirFlightinfo.getFlightBasicInfo().getOriEndPoint().getAirportCityInfo()));
            //到达机场城市信息-destEndPoint航班抵达节点信息
            flightInfo.setArrAirportCityInfo(getSpringAirAirportCityInfo(springAirFlightinfo.getFlightBasicInfo().getDestEndPoint().getAirportCityInfo()));
            //经停信息;
            flightInfo.setStopOverInfos(getSpringStopOverInfos(springAirFlightinfo.getFlightBasicInfo()));
            //舱位列表;
            flightInfo.setCabinInfos(getSpringAirCabinInfos(springAirFlightinfo.getNormSeatPriceList(), springAirFlightinfo.getSuperSeatPriceList()));
            flightInfoList.add(flightInfo);
        }
        return flightInfoList;
    }

    /**
     * 参数转换；com.better517na.springAirSalesService.FlightInfo->FlightInfo
     * @param param 入参
     * @return 返回结果
     */
    private List<FlightInfo> getSpringAirFlightinfos2(List<FlightInfo2> springAirFlightinfos2) {
        List<FlightInfo> flightInfoList = new ArrayList<>();
        for (FlightInfo2 springAirFlightinfo2 : springAirFlightinfos2) {
            FlightInfo flightInfo = new FlightInfo();
            //航段ID-segHeadId;
            String sSegHeadId = String.valueOf(springAirFlightinfo2.getFlightBasicInfo().getSegHeadId());
            flightInfo.setSegmentID(sSegHeadId);
            //航司二字码-9C(春秋航空二字码);
            flightInfo.setAirCode('9C');
            //航司名称-春秋航空;
            flightInfo.setAirCodeDesc('春秋航空');
            //航班号，带航司-flightNo;
            flightInfo.setFlightNo(springAirFlightinfo2.getFlightBasicInfo().getFlightNo());
            //起飞时间-oriEndPoint(航班始发节点)-timeBJ(国内航班);
            flightInfo.setTakeOffTime(getSpringAirTakeOffTime(springAirFlightinfo2.getFlightBasicInfo().getOriEndPoint()));
            //到达时间-destEndPoint(航班抵达节点)-timeBJ(国内航班);
            flightInfo.setArriveTime(getSpringAirArriveTime(springAirFlightinfo2.getFlightBasicInfo().getDestEndPoint()));
            //基建费(String)-portPay(Double);
            flightInfo.setBuildFee(springAirFlightinfo2.getFlightBasicInfo().getPortPay().toString());
            //燃油费(String)-fuelFee(Double);
            flightInfo.setFuelFee(springAirFlightinfo2.getFlightBasicInfo().getFuelFee().toString());
            //飞机大小;
            //飞机型号-机型acType
            flightInfo.setAirPlaneType(springAirFlightinfo2.getFlightBasicInfo().getAcType());
            //共享航班信息,为空表示非共享航班
            //出发机场城市信息-oriEndPoint航班始发节点信息-FlightEndPointInfo：AirportCityInfo航段节点机场城市信息
            flightInfo.setDepAirportCityInfo(getSpringAirAirportCityInfo(springAirFlightinfo2.getFlightBasicInfo().getOriEndPoint().getAirportCityInfo()));
            //到达机场城市信息-destEndPoint航班抵达节点信息
            flightInfo.setArrAirportCityInfo(getSpringAirAirportCityInfo(springAirFlightinfo2.getFlightBasicInfo().getDestEndPoint().getAirportCityInfo()));
            //经停信息;
            flightInfo.setStopOverInfos(getSpringStopOverInfos(springAirFlightinfo2.getFlightBasicInfo()));
            //舱位列表;
            flightInfo.setCabinInfos(getSpringAirCabinInfos2(springAirFlightinfo2.getNormSeatPriceList(), springAirFlightinfo2.getSuperSeatPriceList()));
            flightInfoList.add(flightInfo);
        }
        return flightInfoList;
    }

    /**
     * 参数转换；FlightEndPointInfo->String
     * @param param 入参
     * @return 返回结果
     */
    private String getSpringAirTakeOffTime(FlightEndPointInfo pointInfo) {
        String time = null;
        time = pointInfo.getOriTimeInfo().getTimeBJ();
        return time;
    }

    /**
     * 参数转换；FlightEndPointInfo->String
     * @param param 入参
     * @return 返回结果
     */
    private String getSpringAirArriveTime(FlightEndPointInfo pointInfo) {
        String time = null;
        time = pointInfo.getDestTimeInfo().getTimeBJ();
        return time;
    }

    /**
     * 参数转换；FlightEndPointInfo->String
     * @param param 入参
     * @return 返回结果
     */
    private List<StopOverInfo> getSpringStopOverInfos(FlightBasicInfo flightBasicInfo) {
        List<StopOverInfo> stopOverInfoList = new ArrayList<>();
        FlightEndPointInfo springAirfirstStopover = flightBasicInfo.getFirstStopover();
        FlightEndPointInfo springAirsecondStopover = flightBasicInfo.getSecondStopover();
        if ((null != springAirfirstStopover) && (null != springAirsecondStopover)) {
            StopOverInfo firstStopover = new StopOverInfo();
            //经停序号;
            firstStopover.setSegID(1);
            //到港时间(String);
            firstStopover.setArrTime(springAirfirstStopover.getDestTimeInfo().getTimeBJ())
            //起飞时间(String);
            firstStopover.setTakeOffTime(springAirfirstStopover.getOriTimeInfo().getTimeBJ());
            //机场城市信息;
            firstStopover.setAirportCityInfo(getSpringAirAirportCityInfo(springAirfirstStopover.getAirportCityInfo()));
            stopOverInfoList.add(firstStopover);
            StopOverInfo secondStopover = new StopOverInfo();
            //经停序号;
            secondStopover.setSegID(2);
            //到港时间(String);
            secondStopover.setArrTime(springAirfirstStopover.getDestTimeInfo().getTimeBJ());
            //起飞时间(String);
            secondStopover.setTakeOffTime(springAirfirstStopover.getOriTimeInfo().getTimeBJ());
            //机场城市信息;
            secondStopover.setAirportCityInfo(getSpringAirAirportCityInfo(springAirfirstStopover.getAirportCityInfo()));
            stopOverInfoList.add(secondStopover);
        }
        return stopOverInfoList;
    }

    /**
     * 参数转换；NormSeatPriceList+SuperSeatPriceList->CabinInfos
     * @param param 入参
     * @return 返回结果
     */
    private List<CabinInfo> getSpringAirCabinInfos(List<NormSeatPriceInfo> normSeatPriceList, List<SuperSeatPriceInfo> superSeatPriceList) {
        List<CabinInfo> cabinInfoList = new ArrayList<>();
        //先转换-普通座舱位和价格信息
        if (null != normSeatPriceList) {
            for (NormSeatPriceInfo normSeatPriceInfo : normSeatPriceList) {
                CabinInfo cabinInfo = new CabinInfo();
                //舱位代码-SeatName
                cabinInfo.setCabinCode(normSeatPriceInfo.getSeatName());
                //舱位类型-都赋值为0-经济舱；
                cabinInfo.setCabinName('经济舱');
                cabinInfo.setCabinType(0);
                //舱位价格(BigDecimal)-seatPrice(Double)
                cabinInfo.setCabinPrice(new BigDecimal(normSeatPriceInfo.getSeatPrice()));
                //剩余座位数;
                //舱位产品信息列表;
                cabinInfo.setProductInfos(getSpringAirNormCabinInfoproductInfos(normSeatPriceInfo));
                //加到舱位列表中；
                cabinInfoList.add(cabinInfo);
            }
        }
        if (null != superSeatPriceList) {
            //后转换-商务座舱位和价格信息
            for (SuperSeatPriceInfo superSeatPriceInfo : superSeatPriceList) {
                CabinInfo cabinInfo = new CabinInfo();
                //舱位代码
                cabinInfo.setCabinCode(superSeatPriceInfo.getSeatName());
                //舱位名称,都赋值为经济舱？
                cabinInfo.setCabinName('经济舱');
                //航司折扣；
                //舱位类型-都赋值为0-经济舱；
                cabinInfo.setCabinType(0);
                //舱位价格(BigDecimal)-seatPrice(Double);
                cabinInfo.setCabinPrice(new BigDecimal(superSeatPriceInfo.getSeatPrice()));
                //剩余座位数；
                //舱位产品信息列表;
                cabinInfo.setProductInfos(getSpringAirsuperCabinInfoproductInfos(superSeatPriceInfo));
                //加到舱位列表中；
                cabinInfoList.add(cabinInfo);
            }
        }
        return cabinInfoList;
    }

    /**
     * 参数转换；NormSeatPriceList+SuperSeatPriceList->CabinInfos
     * @param param 入参
     * @return 返回结果
     */
    private List<CabinInfo> getSpringAirCabinInfos2(List<NormSeatPriceInfo2> normSeatPriceList2, List<SuperSeatPriceInfo2> superSeatPriceList2) {
        List<CabinInfo> cabinInfoList = new ArrayList<>();

        //获取Y或Y1舱的价格
        double highestPrice = 0;
        if (CollectionUtils.isNotEmpty(normSeatPriceList2)) {
            for (NormSeatPriceInfo2 normSeatPriceInfo : normSeatPriceList2) {
                if ("Y".equals(normSeatPriceInfo.getSeatName()) || "Y1".equals(normSeatPriceInfo.getSeatName())) {
                    highestPrice = normSeatPriceInfo.getSeatPrice();
                }
            }
        }
        if (CollectionUtils.isNotEmpty(superSeatPriceList2)) {
            for (SuperSeatPriceInfo2 superSeatPriceInfo : superSeatPriceList2) {
                if ("Y".equals(superSeatPriceInfo.getSeatName()) || "Y1".equals(superSeatPriceInfo.getSeatName())) {
                    highestPrice = superSeatPriceInfo.getSeatPrice();
                }
            }
        }

        //先转换-普通座舱位和价格信息
        if (null != normSeatPriceList2) {
            for (NormSeatPriceInfo2 normSeatPriceInfo : normSeatPriceList2) {
                CabinInfo cabinInfo = new CabinInfo();
                //舱位代码-SeatName
                cabinInfo.setCabinCode(normSeatPriceInfo.getSeatName());
                cabinInfo.setCabinName('普通经济舱');
                //舱位类型-都赋值为0-经济舱；
                cabinInfo.setCabinType(0);
                //舱位价格(BigDecimal)-seatPrice(Double)
                cabinInfo.setCabinPrice(new BigDecimal(normSeatPriceInfo.getSeatPrice()));
                if (highestPrice != 0) {
                    DecimalFormat df = new DecimalFormat("0");
                    cabinInfo.setCarrierDiscount(new Integer(df.format(normSeatPriceInfo.getSeatPrice() * 100 / highestPrice)));
                }
                //剩余座位数(Integer)-remSeatNum(Integer);
                cabinInfo.setRemSeatNum(normSeatPriceInfo.getRemSeatNum());
                //舱位产品信息列表;
                cabinInfo.setProductInfos(getSpringAirNormCabinInfoproductInfos2(normSeatPriceInfo));
                //加到舱位列表中；
                cabinInfoList.add(cabinInfo);
            }
        }
        if (null != superSeatPriceList2) {
            //后转换-商务座舱位和价格信息
            for (SuperSeatPriceInfo2 superSeatPriceInfo : superSeatPriceList2) {
                CabinInfo cabinInfo = new CabinInfo();
                //舱位代码
                cabinInfo.setCabinCode(superSeatPriceInfo.getSeatName());
                //舱位名称,都赋值为经济舱？
                cabinInfo.setCabinName('商务经济舱');
                //航司折扣；
                if (highestPrice != 0) {
                    DecimalFormat df = new DecimalFormat("0");
                    cabinInfo.setCarrierDiscount(new Integer(df.format(superSeatPriceInfo.getSeatPrice() * 100 / highestPrice)));
                }
                //舱位类型-都赋值为0-经济舱；
                cabinInfo.setCabinType(0);
                //舱位价格(BigDecimal)-seatPrice(Double);
                cabinInfo.setCabinPrice(new BigDecimal(superSeatPriceInfo.getSeatPrice()));
                //剩余座位数(Integer)-remSeatNum(Integer);
                cabinInfo.setRemSeatNum(superSeatPriceInfo.getRemSeatNum());
                //舱位产品信息列表;
                cabinInfo.setProductInfos(getSpringAirsuperCabinInfoproductInfos2(superSeatPriceInfo));
                //加到舱位列表中；
                cabinInfoList.add(cabinInfo);
            }
        }

        return cabinInfoList;
    }

/**
 * 参数转换；NormSeatPriceInfo->List<ProductInfo>
 * @param param 入参
 * @return 返回结果
 */
    private List<ProductInfo> getSpringAirNormCabinInfoproductInfos(NormSeatPriceInfo normSeatPriceInfo) {
        List<ProductInfo> productInfoList = new ArrayList<>();
        ProductInfo productInfo = new ProductInfo();
        //产品名称
        productInfo.setProductName('普通产品');
        //产品类型
        productInfo.setProductType(0);
        //产品销售价??(BigDecimal)-因为此处并没有实际意义上的打包增值产品;
        productInfo.setProductSalePrice(new BigDecimal(0));
        //附属产品ID;
        //附属产品名称;
        //附属产品价格;
        //销售段ID;
        productInfoList.add(productInfo);
        return productInfoList;
    }

/**
 * 参数转换；NormSeatPriceInfo2->List<ProductInfo>
 * @param param 入参
 * @return 返回结果
 */
    private List<ProductInfo> getSpringAirNormCabinInfoproductInfos2(NormSeatPriceInfo2 normSeatPriceInfo) {
        List<ProductInfo> productInfoList = new ArrayList<>();
        ProductInfo productInfo = new ProductInfo();
        //产品名称
        productInfo.setProductName('普通产品');
        //产品类型
        productInfo.setProductType(0);
        //产品销售价??(BigDecimal)-因为此处并没有实际意义上的打包增值产品;
        productInfo.setProductSalePrice(new BigDecimal(0));
        //附属产品ID;
        //附属产品名称;
        //附属产品价格;
        //销售段ID;
        productInfoList.add(productInfo);
        return productInfoList;
    }

/**
 * 参数转换；NormSeatPriceInfo->List<ProductInfo>
 * @param param 入参
 * @return 返回结果
 */
    private List<ProductInfo> getSpringAirsuperCabinInfoproductInfos(SuperSeatPriceInfo superSeatPriceInfo) {
        List<ProductInfo> productInfoList = new ArrayList<>();
        ProductInfo productInfo = new ProductInfo();
        //产品名称
        productInfo.setProductName('特殊产品PP');
        //产品类型
        productInfo.setProductType(7);
        //产品销售价??(BigDecimal)-seatPrice???(Double);
        productInfo.setProductSalePrice(new BigDecimal(superSeatPriceInfo.getSeatPrice()));
        //附属产品ID(String)-商务座打包增值产品id（Long）;
        String sSubProdId = String.valueOf(superSeatPriceInfo.getSubProdId());
        productInfo.setSubProductID(sSubProdId);
        //附属产品名称-商务座打包增值产品名称（根据语言）;
        productInfo.setSubProductName(superSeatPriceInfo.getSubProdName());
        //附属产品价格(BigDecimal)-商务座打包增值产品价格（根据币种）;
        productInfo.setSubProdPrice(new BigDecimal(superSeatPriceInfo.getSubProdPrice()));
        //销售段ID(String)-商务座打包增值产品id(Long);
        String sSaleSegId = String.valueOf(superSeatPriceInfo.getSaleSegId());
        productInfo.setSaleSegID(sSaleSegId);
        productInfoList.add(productInfo);
        return productInfoList;
    }

/**
 * 参数转换；NormSeatPriceInfo2->List<ProductInfo>
 * @param param 入参
 * @return 返回结果
 */
    private List<ProductInfo> getSpringAirsuperCabinInfoproductInfos2(SuperSeatPriceInfo2 superSeatPriceInfo) {
        List<ProductInfo> productInfoList = new ArrayList<>();
        ProductInfo productInfo = new ProductInfo();
        //产品名称
        productInfo.setProductName('特殊产品PP');
        //产品类型
        productInfo.setProductType(7);
        //产品销售价??(BigDecimal)-seatPrice???(Double);
        productInfo.setProductSalePrice(new BigDecimal(superSeatPriceInfo.getSeatPrice()));
        //附属产品ID(String)-商务座打包增值产品id（Long）;
        String sSubProdId = String.valueOf(superSeatPriceInfo.getSubProdId());
        productInfo.setSubProductID(sSubProdId);
        //附属产品名称-商务座打包增值产品名称（根据语言）;
        productInfo.setSubProductName(superSeatPriceInfo.getSubProdName());
        //附属产品价格(BigDecimal)-商务座打包增值产品价格（根据币种）;
        productInfo.setSubProdPrice(new BigDecimal(superSeatPriceInfo.getSubProdPrice()));
        //销售段ID(String)-商务座打包增值产品id(Long);
        String sSaleSegId = String.valueOf(superSeatPriceInfo.getSaleSegId());
        productInfo.setSaleSegID(sSaleSegId);
        productInfoList.add(productInfo);
        return productInfoList;
    }


}
