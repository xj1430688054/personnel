package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.springAir

import com.better517na.springAirSalesService.ApplyReturnTicketInputBean
import com.better517na.springAirSalesService.ApplyReturnTicketResultBean2
import com.better517na.springAirSalesService.CalcRetTktFeeInputBean
import com.better517na.springAirSalesService.CalcRetTktFeeResultBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ISpringAirRefundBusiness
import org.springframework.stereotype.Component

@Component
class SpringAirRefundBusinessImpl extends SpringAirBaseBusiness implements ISpringAirRefundBusiness {
    @Override
    CalcRetTktFeeResultBean calcRetTktFee(CalcRetTktFeeInputBean calcRetTktFeeInputBean, String url) {
        CalcRetTktFeeResultBean result = (CalcRetTktFeeResultBean) execute(calcRetTktFeeInputBean, 'calcRetTktFee', url);
        return result;
    }

    @Override
    ApplyReturnTicketResultBean2 applyReturnTicket2(ApplyReturnTicketInputBean applyReturnTicketInputBean, String url) {
        ApplyReturnTicketResultBean2 result = (ApplyReturnTicketResultBean2) execute(applyReturnTicketInputBean, 'applyReturnTicket2', url);
        return result;
    }
}
