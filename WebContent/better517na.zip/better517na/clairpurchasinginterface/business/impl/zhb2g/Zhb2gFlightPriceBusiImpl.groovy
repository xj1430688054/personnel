package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2g

import com.alibaba.fastjson.JSON
import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IFlightPriceBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.AirportCityInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.CabinInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.FlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightSegIDParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightsBatchParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.ShareFlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.StopOverInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.Cwdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.Ddjcdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.Hbdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.Hkgsdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.Qfjcdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.QuerySingleFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.QuerySingleFlightResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.singleLine.ResponseRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.DateUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import groovy.json.JsonSlurper
import org.springframework.stereotype.Component

/**
 * 深航
 */
@Component('ZHB2GAirFlightPrice')
public class Zhb2gFlightPriceBusiImpl implements IFlightPriceBusiness {

    private String key="myped43gn2owixv8vhgb";//秘钥

    @Override
    QueryFlightResult searchFlightsBatch(QueryFlightRequest<QueryFlightsBatchParam> param, String url) {
        return null
    }

    @Override
    QueryFlightResult searchFlightsBySegId2(QueryFlightRequest<QueryFlightSegIDParam> param, String url) {
        return null;
    }

    @Override
    QueryFlightResult searchFlightsOtaDay(QueryFlightRequest<QueryFlightParam> param, String url) {
        //组织请求对象
        QuerySingleFlightRequest request = ConvertDto(param);
        //dto转xml
        String dataxml = XmlUtil.convertToXml(request)
        //请求接口
        String result = HttpClientHelper.sendPost(url,dataxml,request.getHyid(),key,request.getClkid(),"DTICK_B2G_searchTicket");
        //json字符串转换为dto
        ResponseRoot root = CommonJsonUtils.toObject(result,ResponseRoot.class)
        //ResponseRoot root = JSON.parseObject(result,ResponseRoot.class)
        QueryFlightResult response = new QueryFlightResult();
        if(root!=null&&root.getRes()!=null){
                //判断接口返回数据是否正确
                if("1".equals(root.getRes().getSts())&&"SUCCESS".equals(root.getRes().getErc())){
                    response.setSessionId(root.getRes().getSid());
                    //对象转换
                    response.setFlightInfos(this.coverFlightInfo(root))
                }else{
                    throw new Exception(root.getRes().getEmg());
                }
        }else{
            throw new Exception("接口返回数据为null");
        }
        return response


    }


    /**
     * 深航-单航班查询对象转换：QueryFlightRequest<QueryFlightParam>--》QuerySingleFlightRequest
     * @param param
     * @return
     */
    QuerySingleFlightRequest ConvertDto(QueryFlightRequest<QueryFlightParam> param) {

        QuerySingleFlightRequest request = new QuerySingleFlightRequest();
        //出发城市
        request.setCfcs(param.getQueryFlightParam().getDepAirport());
        //到达城市
        request.setDdcs(param.getQueryFlightParam().getArrAirport());
        //出发日期
        request.setCfrq(param.getQueryFlightParam().getDepDate());
        if(request.getCfcs()==null||"".equals(request.getCfcs())){
            throw new Exception("出发城市不能为空")
        }else if(request.getDdcs()==null||"".equals(request.getDdcs())){
            throw new Exception("到达城市不能为空")
        }else if(request.getCfrq()==null||"".equals(request.getCfrq())){
            throw new Exception("出发日期不能为空")
        }
        //默认值
        request.setCfszmbs("1");
        request.setDdszmbs("1");
        request.setHyid("191108112148948883");
        request.setClkid("191108112148803");
        request.setZdzz("1")
        request.setCllx("2")
        return request;
    }
    /**
     * 转存航班信息
     * @param root
     * @return
     */
    List<FlightInfo> coverFlightInfo(ResponseRoot root){
        QuerySingleFlightResponse res = root.getRes();
        List<FlightInfo> list = new ArrayList<FlightInfo>()

        //获取航司集合
        List<Hkgsdx> airCompanyList = res.getHkgsjh()
        //航段号
        int i =1;
        for(Hbdx hbdx:res.getHbjh()){
            //乘机人类型为成人（1）且预定状态为可预订（1）时，返回航班查询信息
            if(hbdx.getCwdx().getSycjrlx()!=null
                    &&hbdx.getCwdx().getSycjrlx().contains("1")
                    &&"1".equals(hbdx.getCwdx().getYdfs())){
                FlightInfo info = new FlightInfo();
                info.setSegmentID(i+"")
                info.setAirCode(hbdx.getHbh().substring(0,2))
                info.setFlightNo(hbdx.getHbh().replace("*",""));
                //航空公司简称
                for(Hkgsdx hkgs:airCompanyList){
                    if(hbdx.getHkgs()!=null&&hbdx.getHkgs().equals(hkgs.getEzm())){
                        info.setAirCodeDesc(hkgs.getHkgsjc())
                        info.setAirCode(hkgs.getEzm());
                    }
                }
                //出发时间
                if(hbdx.getCprq()!=null&&hbdx.getCfsj()!=null){
                    info.setTakeOffTime(hbdx.getCprq()+" "+hbdx.getCfsj())
                }
                //计算到达时间
                Date cfsj = DateUtil.stringToDate(hbdx.getCfsj(),"HH:mm")
                Date ddsj = DateUtil.stringToDate(hbdx.getDdsj(),"HH:mm")
                if(cfsj!=null&&ddsj!=null&&cfsj.compareTo(ddsj)<=0){
                    info.setArriveTime(hbdx.getCprq()+" "+hbdx.getDdsj())
                }else{
                    Calendar cal = Calendar.getInstance()
                    cal.setTime(ddsj)
                    cal.add(Calendar.DATE,1)
                    info.setArriveTime(DateUtil.dateToString(ddsj,"yyyyMMdd HH:mm"))
                }
                //基建费
                info.setBuildFee(hbdx.getJcjsf())
                //燃油费
                info.setFuelFee(hbdx.getRys())
                //飞机型号
                if("1".equals(hbdx.getJxzl())){
                    info.setAirPlaneSize("大飞机")
                }else if("2".equals(hbdx.getJxzl())){
                    info.setAirPlaneSize("中型飞机")
                }else if("3".equals(hbdx.getJxzl())){
                    info.setAirPlaneSize("小飞机")
                }
                info.setAirPlaneType(hbdx.getJx())
                //共享航班信息
                ShareFlightInfo shareFlightInfo = new ShareFlightInfo()
                shareFlightInfo.setActureFlightNo(hbdx.getCyhbh())
                info.setShareFlightInfo(shareFlightInfo)
                //出发机场城市信息
                AirportCityInfo depAirportCityInfo = new AirportCityInfo()
                List<Qfjcdx> listOfQfjcdx = res.getQfjcjh()
                depAirportCityInfo.setTerminal(hbdx.getCfhzl())
                depAirportCityInfo.setAirportCode(hbdx.getCfjc())
                for(Qfjcdx qfjcdx:listOfQfjcdx ){
                    if(hbdx.getCfjc()!=null
                            &&hbdx.getCfjc().equals(qfjcdx.getSzm())){
                        depAirportCityInfo.setAirportName(qfjcdx.getJcmc())
                        depAirportCityInfo.setCityName(qfjcdx.getCsmc())
                    }
                }
                info.setDepAirportCityInfo(depAirportCityInfo)
                //depAirportCityInfo.setCityCode() 未找到城市三字码
                //到达机场城市信息
                AirportCityInfo arrAirportCityInfo = new AirportCityInfo()
                List<Ddjcdx> listQfjcjhdx = res.getDdjcjh()
                arrAirportCityInfo.setTerminal(hbdx.getDdhzl())
                arrAirportCityInfo.setAirportCode(hbdx.getDdjc())
                for(Ddjcdx ddjcdx:listQfjcjhdx){
                    if(hbdx.getDdjc()!=null
                            &&hbdx.getDdjc().equals(ddjcdx.getSzm())){
                        arrAirportCityInfo.setAirportName(ddjcdx.getJcmc())
                        arrAirportCityInfo.setCityName(ddjcdx.getCsmc())
                    }
                }
                info.setArrAirportCityInfo(arrAirportCityInfo)
                //经停信息
                if("1".equals(hbdx.getSfjt())){
                    List<StopOverInfo> stopOverInfos  = new ArrayList<StopOverInfo>()
                    StopOverInfo stopOverInfo = new StopOverInfo();
                    stopOverInfo.setSegID(1)
                    stopOverInfos.add(stopOverInfo)
                    info.setStopOverInfos(stopOverInfos)
                }
                //舱位列表
                List<CabinInfo> cabinInfos = new ArrayList<CabinInfo>()
                CabinInfo cabinInfo = new CabinInfo();
                Cwdx cwdx = hbdx.getCwdx()
                if(cwdx!=null){
                    cabinInfo.setCabinCode(cwdx.getCwdm())
                    cabinInfo.setCabinName(cwdx.getCwmc())
                    cabinInfo.setCarrierDiscount(Double.valueOf(Double.valueOf(cwdx.getCwzk())*100).intValue())
                    if(cwdx.getCwlx()!=null){
                        cabinInfo.setCabinType(Integer.parseInt(cwdx.getCwlx()))
                    }
                    //舱位类型
                    if("1".equals(cwdx.getCwlx())||"2".equals(cwdx.getCwlx())){
                        cabinInfo.setCabinType(0);
                    }else if("3".equals(cwdx.getCwlx())){
                        cabinInfo.setCabinType(1);
                    }else if("4".equals(cwdx.getCwlx())){
                        cabinInfo.setCabinType(2);
                    }
                    //座位数
                   if("A".equals(cwdx.getZws())){
                       cabinInfo.setRemSeatNum(9);
                    }else {
                       cabinInfo.setRemSeatNum(Integer.parseInt(cwdx.getZws()))
                   }
                    //销售价
                   if(cwdx.getXsj()!=null&&!"".equals(cwdx.getXsj())){
                       cabinInfo.setCabinPrice(new BigDecimal(cwdx.getXsj()))
                   }
                    //Y舱价
                   if(hbdx.getYcj()!=null&&!"".equals(hbdx.getYcj())){
                       cabinInfo.setBasePrice(new BigDecimal(hbdx.getYcj()))
                   }
                    //政策ID
                   info.setPolicyExInfo(cwdx.getZcid())
                }
                cabinInfos.add(cabinInfo)
                info.setCabinInfos(cabinInfos)
                //餐食代号
                info.setFqtvCode(hbdx.getCs())
                //餐食名称
                info.setFqtvName(hbdx.getCsmc())
                //添加到list中
                list.add(info)
                i++
            }
        }
        return list;
    }
}
