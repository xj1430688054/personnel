package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2g

import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.AppConst
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyTicketInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyVoyageInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.TicketBuyOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.order.in.Cjrdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.order.in.CreateOrderRequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.order.in.Hcdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.order.out.ResRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.pay.AirPayRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.pay.AirPayResRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.pay.Ddxx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.pay.Zfxx
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import java.text.SimpleDateFormat


@Component('ZHB2GTicketPositiveBussImpl')
class ZHB2GTicketPositiveBussImpl  {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusinessLocal;



    /*
    * 创单接口
    */
    ResRoot createOrder(RequestVo<TicketBuyOrderInfoVo> requestVo){

        CreateOrderRequestVo request = this.buildRequest(requestVo);
        String dataxml = XmlUtil.convertToXml(request)
        //String url = AppConst.CREATE_ORDER_URL;
        String url = requestVo.getSupplySystemInfo().getInterfaceUrl();
        String method = AppConst.CREATE_ORDER_METHOD;
        String hyid = AppConst.HY_ID;
        String clkid = AppConst.CLK_ID;
        String key = AppConst.CREATE_ORDER_SECRECT;

        //创建发送请求对象
        String repDate = HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid, method);
        ResRoot responseDate = CommonJsonUtils.toObject(repDate, ResRoot.class, "yyyy-MM-dd HH:mm");
        return responseDate;
    }

    /*
    *构建请求对象
    */
    private CreateOrderRequestVo buildRequest(RequestVo<TicketBuyOrderInfoVo> requestVo){
        CreateOrderRequestVo vo = new CreateOrderRequestVo();
        vo.setClkid(AppConst.CLK_ID);
        vo.setHyid(AppConst.HY_ID);
        //设置航程集合
        List<Hcdx> hcdxList = new ArrayList<>();
        for (BuyVoyageInfoBo bo : requestVo.getBody().getBuyVoyageInfoBoList()){
            Hcdx hcdx = new Hcdx();
            hcdx.setHbh(bo.getFlightNo());
            hcdx.setSid(bo.getSid());
            hcdx.setCwdm(bo.getCabin());
            hcdx.setZcid(bo.getPolicyId());
            hcdx.setCllx("2");
            //设置备注
            if(bo.getRemark() != null){
                hcdx.setBz(bo.getRemark());
            }
            hcdxList.add(hcdx);
        }
        vo.setHcdx(hcdxList);
        //设置其他字段
        vo.setLxrsj(requestVo.getBody().getBuyOrderInfoBo().getLinkPhone());
        vo.setLxrxm(requestVo.getBody().getBuyOrderInfoBo().getLinkPhone());
        //设置乘机人集合
        List<Cjrdx> cjrdxList = new ArrayList<>();
        for (BuyTicketInfoBo ti :requestVo.getBody().getBuyTicketInfoBoList()){
            Cjrdx cjrdx = new Cjrdx();
            //cjrdx.setCjrlx(String.valueOf(ti.getPassengerType()));
            //转换乘机人类型
            String reqCjrlx = String.valueOf(ti.getPassengerType());
            if("0".equals(reqCjrlx)){
                cjrdx.setCjrlx("1");
            }else if("1".equals(reqCjrlx)){
                cjrdx.setCjrlx("2");
            }else if("2".equals(reqCjrlx)){
                cjrdx.setCjrlx("3");
            }else{
                throw new Exception("乘机人信息中乘机人类型错误");
            }
            cjrdx.setXm(ti.getUserName());
            //性别，需要转换
            String xb = (String)ti.getPassengerType();
            if("1".equals(xb)){
                cjrdx.setXb("M");
            }else if("0".equals(xb)){
                cjrdx.setXb("F");
            }else{
                throw new Exception("乘机人信息中性别信息错误");
            }
            //转换出生日期
            /*try {
                cjrdx.setCsrq(new SimpleDateFormat("yyyy-MM-dd").format(requestVo.getBody().getBuyTicketInfoBoList().get(0).getBirthDay()));
            } catch (Exception) {
                throw new Exception("乘机人信息中出生日期格式转换错误");
            }*/
            //转换证件类型
            String cardType = String.valueOf(ti.getCardType());
            if("0".equals(cardType)){
                cjrdx.setZjlx("NI");
            }else if("1".equals(cardType)){
                cjrdx.setZjlx("PP");
            }else{
                cjrdx.setZjlx("ID");
            }
            //设置证件号码
            cjrdx.setZjhm(ti.getCardNo());
            cjrdx.setCjrsj(ti.getPassengerPhoneNum());
            if(ti.getNeedInsurance() != null){
                cjrdx.setSfxybx(String.valueOf(ti.getNeedInsurance()));
            }
            cjrdxList.add(cjrdx);
        }
        vo.setCjrdx(cjrdxList);
        return vo;
    }

    /*
    *支付接口
    */
    AirPayResRoot ticketing(RequestVo<InTicketingVo> requestVo,String type){
        String url = requestVo.getSupplySystemInfo().getInterfaceUrl();
        //1、转换请求对象
        AirPayRequest airPay = this.bulidReq(requestVo,type);
        String dataxml = XmlUtil.convertToXml(airPay)
        String result = HttpClientHelper.sendPost(url,dataxml,AppConst.HY_ID,AppConst.CREATE_ORDER_SECRECT,AppConst.CLK_ID,AppConst.PAY_METHOD);
        //json字符串转换为dto
        AirPayResRoot root = CommonJsonUtils.toObject(result,AirPayResRoot.class);
        return root;
    }
    /*
    *构建请求对象
    */
    private AirPayRequest bulidReq(RequestVo<InTicketingVo> requestVo,String type){
        AirPayRequest pay = new AirPayRequest();
        //TODO
        //获取程序部署主机IP
        pay.setIp();
        pay.setHyid(AppConst.HY_ID);
        pay.setClkid(AppConst.CLK_ID);
        pay.setSpmc("机票预定");
        pay.setSpms("机票预定");
        pay.setCzlx("81053405");
        pay.setHddxmc("ticketOrderPayCallBack");
        //创建订单集合
        List<Ddxx> ddlist = new ArrayList<>();
        Ddxx ddxx = new Ddxx();
        ddxx.setCpbh("0100");
        if("1".equals(type)){
            ddxx.setDdlx("01001");
        }else{
            ddxx.setDdlx("01003");
        }
        ddxx.setDdje(String.valueOf(requestVo.getBody().getPayMoney()));//金额
        ddxx.setDdbh(requestVo.getBody().getPtOrderId());//订单编号
        ddlist.add(ddxx);
        pay.setDdxx(ddlist);
        //创建支付信息
        List<Zfxx> zfxxlist = new ArrayList<>();
        Zfxx zfxx = new Zfxx();
        zfxx.setZffs("1006305");
        zfxx.setZffsmc("预存款");
        zfxx.setZfje(String.valueOf(requestVo.getBody().getPayMoney()));
        zfxx.setZfsxf("0");
        zfxxlist.add(zfxx);
        pay.setZfxx(zfxxlist);
        return pay;
    }
}
