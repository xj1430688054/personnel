package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2g

import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.IZHB2GBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FightVetifiRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FightVetifiRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FigthVeReponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.QueryChangeInfo.QueryChangInfoReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.QueryChangeInfo.QueryChangInfoRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.QueryChangeInfo.QueryChangInfoResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRSVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import org.springframework.beans.factory.annotation.Autowired
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.GetListResponseRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.InGetOrderListReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.OutGetOrderListResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.queryOrderDetail.InQueryOrderDetailReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.queryOrderDetail.OutQueryOrderDetailResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.queryOrderDetail.ResponseRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FightVetifiRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FightVetifiRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.FightVetifi.FigthVeReponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.StandardFare.StandardFareRSVo
import org.springframework.stereotype.Component
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil


/**
 *
 * 深航B2G功能开发
 */
@Component(value = "zhB2GBusiness")
class ZHB2GBussinessImpl implements IZHB2GBusiness  {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusinessLocal;

    /**
     * 以下各自定义负责接口的方法
     */

    @Override
    FightVetifiRS fightVetifiRS(FightVetifiRQ fightVetifiRQ){
        String urlair="http://14.21.67.172:8088/openapi/b2g/lticket";
        String dataxml="";//接口业务参数
        String account="";//授权验证账号
        String sign="";//生成签名
        String hyid=fightVetifiRQ.getHyid();//旅客户id
        String key="myped43gn2owixv8vhgb";//秘钥
        String clkid=fightVetifiRQ.getClkid();
        String method = "DTICK_B2G_bookVerify";

        dataxml= XmlUtil.convertToXml(fightVetifiRQ);
//        dataxml= "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
//                "<request>" +
//                "  <ip></ip>" +
//                "  <hyid></hyid>" +
//                "  <clkid></clkid>"+
//                "  <start></start>"+
//                "  <count></count>"+
//                "  <hbh>"+fightVetifiRQ.getHbh()+"</hbh>"+
//                "  <sid>"+fightVetifiRQ.getSid()+"</sid>"+
//                "  <cwdm>"+fightVetifiRQ.getCwdm()+"</cwdm>"+
//                "  <zcid>"+fightVetifiRQ.getZcid()+"</zcid>"+
//                "  <clkid>"+fightVetifiRQ.getClkid()+"</clkid>"+
//                "  <hyid>"+fightVetifiRQ.getHyid()+"</hyid>"+
//                "  <hbh>ZH9401</hbh>"+
//                "  <sid>fc4f7369-fc71-4f2b-ba71-7a69fcb4f830</sid>"+
//                "  <cwdm>E</cwdm>"+
//                "  <zcid>LOCAL_PT_NO</zcid>"+
//                "  <clkid>191108112148803</clkid>"+
//                "  <hyid>191108112148948883</hyid>"+
//                "</request>";
        String   result= HttpClientHelper.sendPost(fightVetifiRQ.getUrl(),dataxml,hyid,key,clkid,method);
        FigthVeReponseVo figthVeReponseVo = CommonJsonUtils.toObject(result,FigthVeReponseVo.class);
        return figthVeReponseVo.getRes();
    }

    @Override
    StandardFareRS standardFareRS(StandardFareRQ standardFareRQ) {
        String urlair="http://14.21.67.172:8088/openapi/b2g/lticket";
        String dataxml="";//接口业务参数
        String account="";//授权验证账号
        String sign="";//生成签名
        String hyid=standardFareRQ.getHyid()//旅客户id
        String key="myped43gn2owixv8vhgb";//秘钥
        String clkid=standardFareRQ.getClkid();
        String method = "DTICK_B2G_queryStandarPrice";

        dataxml= XmlUtil.convertToXml(standardFareRQ);
        String   result= HttpClientHelper.sendPost(standardFareRQ.getUrl(),dataxml,hyid,key,clkid,method);
        StandardFareRSVo standardFareRSVo = CommonJsonUtils.toObject(result,StandardFareRSVo.class);

        return standardFareRSVo.getRes();
    }
    @Override
    String seartchSingleLine() {
        return null
    }

    public final String urlair="http://14.21.67.172:8088/openapi/b2g/lticket";


    /**
     *查询订单详细信息
     * @return
     */
    @Override
    OutQueryOrderDetailResVo OrderDetail(InQueryOrderDetailReqVo req,String url) {
       String  method="DTICK_B2G_getOrderInfo";
       String key="myped43gn2owixv8vhgb";//秘钥
       String clkid="191108112148803";
       String hyid="191108112148948883";//旅客户id
       String dataxml="";//接口业务参数
       String account="";//授权验证账号
       String sign="";//生成签名
        /* dataxml= "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                  "<request>" +
                  "  <hyid>"+191108112148948883+"</hyid>" +
                  "  <ddbh>"+191011000046+"</ddbh>" +
                  "</request>";*/

        dataxml= XmlUtil.convertToXml(req);
        String   result= HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        ResponseRoot root=CommonJsonUtils.toObject(result,ResponseRoot.class);
        return root.getRes();
    }


/**
     * 获取订单列表
     * @param req
     * @return
     */
    @Override
    OutGetOrderListResVo getOrderList(InGetOrderListReqVo req,String url) {
        String   method="DTICK_B2G_queryTicketOrder";
        String key="myped43gn2owixv8vhgb";//秘钥
        String clkid="191108112148803";
        String hyid="191108112148948883";//旅客户id
        String dataxml="";//接口业务参数
        String account="";//授权验证账号
        String sign="";//生成签名
        dataxml= XmlUtil.convertToXml(req);
        String   result=HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        GetListResponseRoot root= CommonJsonUtils.toObject(result,GetListResponseRoot.class);
        return root.getRes();
    }

    @Override
    QueryChangInfoRes changInfoRes(QueryChangInfoReq req) {
        String method="DTICK_B2G_getEndorseInfo";
        String key="myped43gn2owixv8vhgb";//秘钥
        String clkid="191108112148803";
        String hyid="191108112148948883";//旅客户id
        String dataxml="";//接口业务参数
        String account="";//授权验证账号
        String sign="";//生成签名
        dataxml= XmlUtil.convertToXml(req);
        String   result=HttpClientHelper.sendPost(req.getUrl(),dataxml,hyid,key,clkid,method);
        QueryChangInfoResVo root= CommonJsonUtils.toObject(result,QueryChangInfoResVo.class);
        return root.getRes();
    }
}