package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2g

import com.alibaba.fastjson.JSON
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.ChannelChangeValidateTicketInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.InChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHChangLegResConvertt
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.GetListResponseRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.InChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.OutChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.ApplyRefund.ApplyRefundRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.ApplyRefund.ApplyRefundRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.canRefundLeg.CanRefundLegRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.canRefundLeg.CanRefundLegRs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundCost.RefundCostRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundCost.RefundCostRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundInfo.RefundOrderDetailRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundInfo.RefundOrderDetailRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundOrder.RefundOrderRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundOrder.RefundOrderRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.IZHB2GRefundBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelChangOrRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHChangLegResConvert
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHResConvert
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import javax.xml.bind.JAXBContext
import javax.xml.bind.Marshaller
@Component
class IZHB2GRefundBusinessImpl implements IZHB2GRefundBusiness {

    /** 日志组件.
    */
    @Autowired
    private LogBusiness logBusinessLocal;
    public        String hyid="191108112148948883";//旅客户id
    public        String key="myped43gn2owixv8vhgb";//秘钥
    public        String clkid="191108112148803";
    public        String method="DTICK_B2G_getApplyReason";
    public        String dataxml="";//接口业务参数
    /**
     * 以下各自定义负责接口的方法
     */

    /**
     * 获取改签或者退票原因
     * @param request
     * @return
     */
    ZHResConvert getChangOrRefundReason(InChannelChangOrRefundVo inChannelChangOrRefundVo, String url){
        method="DTICK_B2G_getApplyReason";
        // 创建输出流
        StringWriter sw = new StringWriter();
        // 利用jdk中自带的转换类实现
        JAXBContext context = JAXBContext.newInstance(inChannelChangOrRefundVo.getClass());

        Marshaller marshaller = context.createMarshaller();
        // 格式化xml输出的格式
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                Boolean.TRUE);
        // 将对象转换成输出流形式的xml
        marshaller.marshal(inChannelChangOrRefundVo, sw);

        dataxml=sw.toString()

        String   result=HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);

        ZHResConvert zHResConvert = CommonJsonUtils.toObject(result,ZHResConvert);

        return zHResConvert;

    };


    /**
     * 获取可改签航段接口
     * @param request
     * @return
     */
    ZHChangLegResConvert getChannelChangeLeg(InChannelChangeValidateTktStateParaVo inChannelChangeValidateTktStateParaVo, String url){
        method="DTICK_B2G_getCanEndorseLeg";
        // 创建输出流
        StringWriter sw = new StringWriter();
        InChannelChangOrRefundVo inChannelChangOrRefundVo = new InChannelChangOrRefundVo();

//        ChannelChangeValidateTicketInfoVo reqVo = inChannelChangeValidateTktStateParaVo.getTickets().get(0);
        inChannelChangOrRefundVo.setDdbh(inChannelChangeValidateTktStateParaVo.getChannelOrderId());

        // 利用jdk中自带的转换类实现
        JAXBContext context = JAXBContext.newInstance(inChannelChangOrRefundVo.getClass());

        Marshaller marshaller = context.createMarshaller();
        // 格式化xml输出的格式
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                Boolean.TRUE);
        // 将对象转换成输出流形式的xml
        marshaller.marshal(inChannelChangOrRefundVo, sw);

        dataxml=sw.toString();

        String   result=HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);

        ZHChangLegResConvert zHChangLegResConvert = CommonJsonUtils.toObject(result,ZHChangLegResConvert);

        return zHChangLegResConvert;
    }


    /**
     * 查询退票订单详细
     * @param refundOrderDetailRQ
     * @return
     */
    @Override
    RefundOrderDetailRS getRefundOrderDetail(RefundOrderDetailRQ refundOrderDetailRQ,String url) {
        //组织请求信息
        String hyid = "191108112148948883";//旅客户id
        String key = "myped43gn2owixv8vhgb";//秘钥
        String method = "DTICK_B2G_getRefundInfo";
        refundOrderDetailRQ.setHyid(hyid);
        refundOrderDetailRQ.setClkid(clkid);
        String dataxml = XmlUtil.convertToXml(refundOrderDetailRQ);
        //发起POST请求
        String result = HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        //组织返回信息
        RefundOrderDetailRS refundOrderDetailRS = CommonJsonUtils.toObject(result, RefundOrderDetailRS.class);
        return refundOrderDetailRS;
    }
    /**
     * 申请退票
     * @param airDocDisplayRQ
     * @return
     */
    @Override
    ApplyRefundRS applyRefund(ApplyRefundRQ airDocDisplayRQ,String url) {
        //组织请求信息
        String hyid = "191108112148948883";//旅客户id
        String key = "myped43gn2owixv8vhgb";//秘钥
        String method = "DTICK_B2G_applyRefund";
        airDocDisplayRQ.setHyid(hyid);
        airDocDisplayRQ.setClkid(clkid);
        //生成xml
        String dataxml = XmlUtil.convertToXml(airDocDisplayRQ);
        //发起POST请求
        String result = HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        //组织返回信息
        ApplyRefundRS applyRefundRS = CommonJsonUtils.toObject(result, ApplyRefundRS.class);
        return applyRefundRS;
    }

    @Override
    /**
     * 获取退票订单列表
     * @param refundOrderRQ
     * @return
     */
    RefundOrderRS queryRefundOrder(RefundOrderRQ refundOrderRQ,String url){
        //组织请求信息
        String hyid = "191108112148948883";//旅客户id
        String key = "myped43gn2owixv8vhgb";//秘钥
        String method = "DTICK_B2G_queryRefundOrder";
        refundOrderRQ.setHyid(hyid);
        refundOrderRQ.setClkid(clkid);
        //生成xml
        String dataxml = XmlUtil.convertToXml(refundOrderRQ);
        //发起POST请求
        String result = HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        //组织返回信息
        RefundOrderRS refundOrderRS = CommonJsonUtils.toObject(result, RefundOrderRS.class);
        return refundOrderRS;
    }


    /**
     * 查询退票费用费
     * @param refundCotRQ
     * @return
     */
    @Override
    RefundCostRS getRefundCost(RefundCostRQ refundCostRQ,String url) {
        //组织请求信息
        String hyid = "191108112148948883";//旅客户id
        String key = "myped43gn2owixv8vhgb";//秘钥
        String method = "DTICK_B2G_getRefundCost";
        refundCostRQ.setHyid(hyid);
        refundCostRQ.setClkid(clkid);
        //生成xml
        String dataxml = XmlUtil.convertToXml(refundCostRQ);
        //发起POST请求
        String result = HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        //组织返回信息
        RefundCostRS refundCostRS = CommonJsonUtils.toObject(result, RefundCostRS.class);
        return refundCostRS;
    }
    /**
     * 获取可退航段接口
     * @return
     */
    @Override
    CanRefundLegRs getCanRefundLeg(CanRefundLegRQ canRefundLegRQ,String url) {
        String hyid = "191108112148948883";//旅客户id
        String key = "myped43gn2owixv8vhgb";//秘钥
        String method = "DTICK_B2G_getCanRefundLeg";
        //生成xml
        String dataxml = XmlUtil.convertToXml(canRefundLegRQ);
        //发起POST请求
        String result = HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        //组织返回信息
        CanRefundLegRs canRefundLegRs = JSON.parseObject(result, CanRefundLegRs.class);
        return canRefundLegRs;
    }


}
