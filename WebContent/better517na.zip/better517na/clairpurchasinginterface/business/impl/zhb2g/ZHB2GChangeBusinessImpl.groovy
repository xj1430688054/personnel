package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2g

import com.better517na.clairpurchasinginterface.utils.CommonJsonUtils
import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.HttpClientHelper
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2g.IZHB2GChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelChangOrRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.ChannelChangeValidateTicketInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.InChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ZHChangLegResConvert
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.Cxrdx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.DoBookRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.DoBookRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.EndorseCostResRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.Gqhddx
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.ReshopReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.change.ReshopResp
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.GetListResponseRoot
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.InChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.OutChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.xml.bind.JAXBContext
import javax.xml.bind.Marshaller

@Component
class ZHB2GChangeBusinessImpl implements IZHB2GChangeBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusinessLocal;
    private String key = "myped43gn2owixv8vhgb";//秘钥

    @Override
    ReshopResp reshop(ReshopReq request,String url) {
        ReshopResp reshopResp = new ReshopResp();
        String method = "DTICK_B2G_changeTicket";
        String dataxml= XmlUtil.convertToXml(request);
        String result = HttpClientHelper.sendPost(url, dataxml, request.getHyid(), key, "", method);
        System.out.println(result);
        reshopResp = CommonJsonUtils.toObject(result, ReshopResp.class, "yyyy-MM-dd HH:mm");
        System.out.println(reshopResp);
        return reshopResp;
    }

    /**
     * 改期升舱
     *
     * @param request
     * @param url
     * @return
     */
    @Override
    DoBookRS dochange(DoBookRQ request,String url) {
        DoBookRS doBookRS = new DoBookRS();
        String method = "DTICK_B2G_endorseApply";
        String dataxml= XmlUtil.convertToXml(request)
        String result = HttpClientHelper.sendPost(url, dataxml, request.getHyid(), key, "", method);
        System.out.println(result);
        doBookRS = CommonJsonUtils.toObject(result, DoBookRS.class, "yyyy-MM-dd HH:mm");
        System.out.println(doBookRS);
        return doBookRS;
    }
    /**
     * 获取改签费用
     * @param request
     * @param url
     * @return
     */
    @Override
    EndorseCostResRoot getEndorseCost(DoBookRQ request, String url) {
        EndorseCostResRoot endorseCostResRoot = new EndorseCostResRoot();
        String dataxml= XmlUtil.convertToXml(request);
        String result = HttpClientHelper.sendPost(url, dataxml, request.getHyid(), key, request.getClkid(), "DTICK_B2G_getEndorseCost");
        System.out.println(result);
        endorseCostResRoot = CommonJsonUtils.toObject(result, EndorseCostResRoot.class, "yyyy-MM-dd HH:mm");
        System.out.println(endorseCostResRoot);
        return endorseCostResRoot;
    }

    /**
     *
     * @param inChannelChangeValidateTktStateParaVo
     * @param url
     * @return
     */
    @Override
    ZHChangLegResConvert getChannelChangeLeg(InChannelChangeValidateTktStateParaVo inChannelChangeValidateTktStateParaVo, String url) {
        String method = "DTICK_B2G_getCanEndorseLeg";
        String dataxml="";
        String hyid="191108112148948883";
        String clkid="191108112148803"
        // 创建输出流
        StringWriter sw = new StringWriter();
        InChannelChangOrRefundVo inChannelChangOrRefundVo = new InChannelChangOrRefundVo();
        inChannelChangOrRefundVo.setDdbh(inChannelChangeValidateTktStateParaVo.getChannelOrderId());

        // 利用jdk中自带的转换类实现
        JAXBContext context = JAXBContext.newInstance(inChannelChangOrRefundVo.getClass());

        Marshaller marshaller = context.createMarshaller();
        // 格式化xml输出的格式
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                Boolean.TRUE);
        // 将对象转换成输出流形式的xml
        marshaller.marshal(inChannelChangOrRefundVo, sw);

        dataxml=sw.toString();

        String   result=HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);

        ZHChangLegResConvert zHChangLegResConvert = CommonJsonUtils.toObject(result,ZHChangLegResConvert);

        return zHChangLegResConvert;
    }
    @Override
    OutChangeOrderListVo getChangeList(InChangeOrderListVo req, String url) {
        String clkid="191108112148803";
        String   method="DTICK_B2G_queryEndorseOrder";
        String key="myped43gn2owixv8vhgb";//秘钥
//        String clkid="191108112148803";
        String hyid="191108112148948883";//旅客户id
        String dataxml="";//接口业务参数
        String account="";//授权验证账号
        String sign="";//生成签名
        dataxml= XmlUtil.convertToXml(req);
        String   result=HttpClientHelper.sendPost(url,dataxml,hyid,key,clkid,method);
        GetListResponseRoot res= CommonJsonUtils.toObject(result,GetListResponseRoot.class);
        return res.getRes();
    }
}
