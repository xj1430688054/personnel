package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mfb2c

import com.travelsky.et.web.cwip.CWIPRequest
import com.travelsky.et.web.cwip.CWIPResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.mfb2c.IMFB2CRefundBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFQueryOrderDetailOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundApplyInParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundApplyOutResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundQueryInParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundQueryOutResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTARequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTAResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import org.springframework.stereotype.Component

/**
 \* Created with IntelliJ IDEA.
 \* User: lulin
 \* Date: 2019-03-06
 \* Time: 16:04
 \* To change this template use File | Settings | File Templates.
 \* Description: 
 \*/
@Component
class MFB2CRefundBusinessImpl extends MFB2CBaseBusiness implements IMFB2CRefundBusiness {
    @Override
    OTAResponse<MFRefundApplyOutResult> applyRefund(OTARequest<MFRefundApplyInParam> param, String url) {
        OTAResponse<MFRefundApplyOutResult> res = new OTAResponse();

        // 调接口创单
        CWIPRequest cwipRequest = buildCWIPRequest(param, "REFUND_APPLY_SERVICE");

        //发送请求
        CWIPResponse response = execute(cwipRequest, url);

        buildOTAResponse(response, res, MFRefundApplyOutResult.class);

        return res;
    }

    @Override
    OTAResponse<MFRefundQueryOutResult> queryReturnTicketRate(OTARequest<MFRefundQueryInParam> param, String url) {
        OTAResponse<MFRefundQueryOutResult> res = new OTAResponse();
        // 调接口创单
        CWIPRequest cwipRequest = buildCWIPRequest(param, "REFUND_QUERY_SERVICE");

        //发送请求
        CWIPResponse response = execute(cwipRequest, url);

        // 解析返回结果
        buildOTAResponse(response, res, MFRefundQueryOutResult.class);

        return res;
    }

    @Override
    OTAResponse<MFRefundQueryOutResult> getRefundOrderDetail(OTARequest<MFRefundQueryInParam> param, String url) {
        OTAResponse<MFRefundQueryOutResult> res = new OTAResponse();
        // 调接口创单
        CWIPRequest cwipRequest = buildCWIPRequest(param, "REFUND_QUERY_SERVICE");

        //发送请求
        CWIPResponse response = execute(cwipRequest, url);

        // 解析返回结果
        buildOTAResponse(response, res, MFRefundQueryOutResult.class);

        return res;
    }
}
