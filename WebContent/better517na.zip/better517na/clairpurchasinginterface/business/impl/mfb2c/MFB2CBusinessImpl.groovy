package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mfb2c

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.payInteractionService.MYeepayPayOutParam
import com.better517na.payInteractionService.MYeepayPayParam
import com.better517na.payInteractionService.WebService1Soap
import com.google.gson.Gson
import com.travelsky.et.web.cwip.CWIPRequest
import com.travelsky.et.web.cwip.CWIPResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.mfb2c.IMFB2CBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFOrderDetailResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFQueryOrderDetailOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MfOrderQueryInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTARequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTAResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.createOrder.MFCreateOrderInParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.createOrder.MFCreateOrderOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentApplyReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentApplyResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentConfirmReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentConfirmResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.queryFlight.MFQueryFlightInParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.queryFlight.MFQueryFlightOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import org.apache.cxf.frontend.ClientProxy
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean
import org.apache.cxf.transport.Conduit
import org.apache.cxf.transport.http.HTTPConduit
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * @Auther: beitian
 * @Date: 2019/3/5 14:11
 * @Description:
 */
@Component
class MFB2CBusinessImpl extends MFB2CBaseBusiness implements IMFB2CBusiness {

    /**
     * 添加字段注释.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    OTAResponse<MFQueryFlightOutResultVo> queryFlight(OTARequest<MFQueryFlightInParamVo> requestVo, String url) {

        OTAResponse<MFQueryFlightOutResultVo> res = new OTAResponse<>();
        //构造请求
        CWIPRequest request = buildCWIPRequest(requestVo, "AV_SERVICE");
        //发送请求
        CWIPResponse response = this.execute(request, url);
        //解析返回结果
        buildOTAResponse(response, res, MFQueryFlightOutResultVo.class);
        return res;
    }

    @Override
    OTAResponse<MFCreateOrderOutResultVo> createOrder(OTARequest<MFCreateOrderInParamVo> requestVo, String url) {
        OTAResponse<MFCreateOrderOutResultVo> res = new OTAResponse<>();
        //构造请求
        CWIPRequest request = buildCWIPRequest(requestVo, "BOOK_SERVICE");
        //发送请求
        CWIPResponse response = this.execute(request, url);
        //解析返回结果
        buildOTAResponse(response, res, MFCreateOrderOutResultVo.class);
        return res;
    }

    @Override
    OTAResponse<MFQueryOrderDetailOutResultVo> orderDetail(OTARequest<MfOrderQueryInVo> requestVo, String url) {
        OTAResponse<MFQueryOrderDetailOutResultVo> res = new OTAResponse();
        // 构造请求
        CWIPRequest request = buildCWIPRequest(requestVo, "ORDER_QUERY_SERVICE");
        //发送请求
        CWIPResponse response = this.execute(request, url);
        // 解析返回结果
        buildOTAResponse(response, res, MFQueryOrderDetailOutResultVo.class);
        return res;
    }

    @Override
    OTAResponse<PaymentApplyResVo> paymentApply(OTARequest<PaymentApplyReqVo> requestVo, String url) {
        OTAResponse<PaymentApplyResVo> res = new OTAResponse();
        // 构造请求
        CWIPRequest request = buildCWIPRequest(requestVo, "PAYMENT_APPLY_SERVICE");
        // 发起请求
        CWIPResponse response = this.execute(request, url);
        // 解析返回结果
        buildOTAResponse(response, res, PaymentApplyResVo.class)
        return res;
    }

    @Override
    OTAResponse<PaymentConfirmResVo> paymentConfirm(OTARequest<PaymentConfirmReqVo> requestVo, String url) {
        OTAResponse<PaymentConfirmResVo> res = new OTAResponse();
        // 构造请求
        CWIPRequest request = buildCWIPRequest(requestVo, "PAYMENT_CONFIRM_SERVICE");
        // 发起请求
        CWIPResponse response = this.execute(request, url);
        // 解析返回结果
        buildOTAResponse(response, res, PaymentConfirmResVo.class)
        return res;
    }

    @Override
    MYeepayPayOutParam yeepayPay(MYeepayPayParam request, String pidUniqueKey, String pid, String url) throws Exception {
        MYeepayPayOutParam response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(WebService1Soap.class);
            factoryBean.setAddress(url);
            WebService1Soap create = (WebService1Soap) factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit) conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.yeepayExternalPay(request, pidUniqueKey, pid);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '公共支付服务支付失败', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread(new Runnable() {
                    @Override
                    void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('公共支付服务交互');
                            interactionParam.setKey1('yeepayExternalPay');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }).start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }
}
