package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mfb2c

import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.travelsky.et.web.cwip.CWIPRequest
import com.travelsky.et.web.cwip.CWIPResponse
import com.travelsky.et.web.cwip.CWIPService
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFQueryOrderDetailOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTARequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTAResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.XmlUtil
import org.apache.cxf.jaxws.binding.soap.SOAPBindingImpl
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.xml.namespace.QName
import javax.xml.ws.Service

/**
 * @Auther: beitian
 * @Date: 2019/3/5 16:05
 * @Description: 从官网交互java服务
 */
@Component
class MFB2CBaseBusiness {
    /**
     * 添加字段注释.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 服务名称.
     */
    private static final QName SERVICE_NAME = new QName("http://cwip.web.et.travelsky.com", "CWIPService");


    static CWIPRequest buildCWIPRequest(OTARequest<?> requestVo, String serviceType) {
        CWIPRequest request = new CWIPRequest();
        request.setAirline(requestVo.getAirline());
        request.setUserId(requestVo.getUserId());
        request.setAppUserId(requestVo.getAppUserId());
        request.setServiceType(serviceType);
        request.setRequestXML(XmlUtil.convertToXml(requestVo.getRequestData()));
        request.setVersion("1.0");
        request.setUserType("1");
        return request
    }

    static <T> void buildOTAResponse(CWIPResponse cwipResponse, OTAResponse<T> otaResponse, Class<?> type) {
        otaResponse.setErrorDesc(cwipResponse.getErrorDesc());
        otaResponse.setResultCode(cwipResponse.getResultCode());
        if (!StringUtil.isStringParamNotLegal(cwipResponse.getResponseXML())) {
            T responseData = (T) XmlUtil.convertToObject(cwipResponse.getResponseXML(), type);
            otaResponse.setResponseData(responseData);
        }
    }

    /**
     * 公共的请求方法
     * @param request request.
     * @param url url.
     * @return
     */
    CWIPResponse execute(CWIPRequest request, String url) {
        CWIPResponse response = null;
        long startTime = System.currentTimeMillis();
        try {
            // 特殊处理
            if (request.getServiceType().equals("AV_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<av_request>", "<av_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("BOOK_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<book_request>", "<book_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("ORDER_CANCEL_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<order_cancel_request>", "<order_cancel_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("ORDER_QUERY_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<order_query_request>", "<order_query_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("REFUND_APPLY_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<refundApply_request>", "<refundApply_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("PAYMENT_APPLY_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<payment_apply_request>", "<payment_apply_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("PAYMENT_CONFIRM_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<payment_confirm_request>", "<payment_confirm_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            } else if (request.getServiceType().equals("REFUND_QUERY_SERVICE")) {
                request.setRequestXML(request.getRequestXML().replaceAll("<refundQuery_request>", "<refundQuery_request xmlns=\"http://xml.cwip.web.et.travelsky.com\">"));
            }

            Service service = Service.create(SERVICE_NAME);
            service.addPort(SERVICE_NAME, SOAPBindingImpl.SOAP11HTTP_BINDING, url);
            CWIPService mfService = service.getPort(SERVICE_NAME, CWIPService.class);
            response = mfService.handler(request);
            if (response.getResponseXML() != null) {
                response.setResponseXML(response.getResponseXML().replaceAll("xmlns=\"http://xml.cwip.web.et.travelsky.com\"", ""));
                response.setResponseXML(response.getResponseXML().replaceAll("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", ""));
                response.setResponseXML(response.getResponseXML().replaceAll("xsi:nil=\"true\"", ""));
            }
        } catch (Exception e) {
            e.printStackTrace();
            response = new CWIPResponse();
            response.setErrorDesc(e.getMessage());
            response.setResultCode(0);
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "调用航司接口异常", e));
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule(request.getAirline() + "B2C接口");
            interactionParam.setKey1(request.getServiceType());
            interactionParam.setKey2(String.valueOf(System.currentTimeMillis() - startTime));
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(GsonUtil.gson.toJson(request));
            interactionParam.setReceiveContent(GsonUtil.gson.toJson(response));
            logBusiness.writeInteractionLog(interactionParam);
        }
        return response;
    }
}
