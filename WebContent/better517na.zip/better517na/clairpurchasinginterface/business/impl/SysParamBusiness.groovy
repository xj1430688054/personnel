package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ISysParamBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IUnifiedParamBusiness
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.annotation.Resource

@Component
class SysParamBusiness implements ISysParamBusiness  {

    /**
     * 系统参数获取对象.
     */
    @Autowired
    private IUnifiedParamBusiness unifiedParamBusiness;



    /**
     * 获取乘机人联系电话参数.
     *
     * @return .
     * @throws Exception .
     */
    @Override
    public List<String> getPassengerLinkPhoneParam() throws Exception {
        return unifiedParamBusiness.getDictionaryParamList('CLYPG_CLJY_PassengerLinkPhoneParam'); // ServiceProviderID|PassengerLinkPhone^PassengerLinkPhone
    }
}
