package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.qunar

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.qunar.IQunarRefundBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Tag
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.ApplyRefundInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.ApplyRefundOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.QueryRefundRateParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.RefundRateQueryResult
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class QunarRefundBusinessImpl extends config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.QunarBaseBusiness implements IQunarRefundBusiness {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 去哪儿申请退票
     * @param requestVo
     * @param key 安全码
     * @param url 地址
     * @return
     */
    @Override
    Response<List<ApplyRefundOutVo>> returnTicket(Request<ApplyRefundInVo> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.APPLYREFUND.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<List<ApplyRefundOutVo>>> typeToken = new TypeToken<Response<List<ApplyRefundOutVo>>>() {
        };
        Response<List<ApplyRefundOutVo>> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    /**
     * 查询去哪儿退票手续费
     * @param requestVo
     * @param key 安全码
     * @param url 地址
     * @return
     */
    @Override
    public Response<List<RefundRateQueryResult>> queryReturnTicketRate(Request<QueryRefundRateParam> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.REFUNDSEARCH.getValue());

        }
        String reponse = this.execute(requestVo, key, url);
        TypeToken<Response<List<RefundRateQueryResult>>> typeToken = new TypeToken<Response<List<RefundRateQueryResult>>>() {
        };

        Response<List<RefundRateQueryResult>> res = GsonUtil.getGson().fromJson(reponse, typeToken.getType());
        return res
    }

    @Override
    Response<OrderDetailResponse> getRefundOrderDetail(Request<?> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.GETDETAIL.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<OrderDetailResponse>> typeToken = new TypeToken<Response<OrderDetailResponse>>() {
        };
        Response<OrderDetailResponse> response = GsonUtil.getGson().fromJson(str,typeToken.getType());
        return response;
    }
}
