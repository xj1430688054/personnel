package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.qunar

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.QunarBaseBusiness
import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.qunar.IQunarChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Tag
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeApplyParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeApplyResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeQueryParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeQueryResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.SearchFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.SearchFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.QueryParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.pay.ChangePayResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.InChannelChangePayNewVo
import org.apache.commons.lang.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class QunarChangeBusinessImpl extends QunarBaseBusiness implements IQunarChangeBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    ChangeQueryResultVo changeSearch(Request<ChangeQueryParamVo> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtils.isEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.CHANGESEARCH.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<ChangeQueryResultVo> typeToken = new TypeToken<ChangeQueryResultVo>() {
        };
        ChangeQueryResultVo res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    Response<ChangePayResult> channelChangePay(Request<InChannelChangePayNewVo> inChannelChangePayVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtils.isEmpty(inChannelChangePayVo.getTag())) {
            inChannelChangePayVo.setTag(Tag.CHANGEPAY.getValue());
        }
        String str = this.execute(inChannelChangePayVo, key, url);
//        String str = "{\n" +
//                "\t\"code\": 0,\n" +
//                "\t\"message\": \"SUCCESS\",\n" +
//                "\t\"createTime\": 1542702378765,\n" +
//                "\t\"result\": {\n" +
//                "\t\t\"code\": 0,\n" +
//                "\t\t\"errMsg\": null,\n" +
//                "\t\t\"results\": [{\n" +
//                "\t\t\t\"orderNo\": \"xep181120161759644p2617378cash\",\n" +
//                "\t\t\t\"orderDate\": \"20181120162617\",\n" +
//                "\t\t\t\"pmCode\": \"OUTDAIKOU\",\n" +
//                "\t\t\t\"bankCode\": \"ALIPAYSN\",\n" +
//                "\t\t\t\"payId\": \"newttszzgq,ALIPAY2018112016261749076690;\",\n" +
//                "\t\t\t\"payAmount\": \"78.00\",\n" +
//                "\t\t\t\"payStatus\": \"SUCCESS\",\n" +
//                "\t\t\t\"payTime\": \"20181120162618\",\n" +
//                "\t\t\t\"errCode\": \"0\",\n" +
//                "\t\t\t\"errMsg\": \"\"\n" +
//                "\t\t}]\n" +
//                "\t},\n" +
//                "\t\"success\": true\n" +
//                "}"
        TypeToken<Response<ChangePayResult>> typeToken = new TypeToken<Response<ChangePayResult>>() {
        };
        Response<ChangePayResult> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    ChangeApplyResultVo changeApply(Request<ChangeApplyParamVo> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtils.isEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.APPLYCHANGE.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<ChangeApplyResultVo> typeToken = new TypeToken<ChangeApplyResultVo>() {
        };
        ChangeApplyResultVo res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    Response<SearchFlightResult> searchFlight(Request<SearchFlightRequest> searchFlightRequestRequest, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtils.isEmpty(searchFlightRequestRequest.getTag())) {
            searchFlightRequestRequest.setTag(Tag.SEARCHFLIGHT.getValue());
        }
        String str = this.execute(searchFlightRequestRequest, key, url);
        TypeToken<Response<SearchFlightResult>> typeToken = new TypeToken<Response<SearchFlightResult>>() {
        };
        Response<SearchFlightResult> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    Response<OrderDetailResponse> queryOrder(Request<QueryParam> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.GETDETAIL.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<OrderDetailResponse>> typeToken = new TypeToken<Response<OrderDetailResponse>>() {
        };
        Response<OrderDetailResponse> response = com.better517na.javaloghelper.util.GsonUtil.getGson().fromJson(str, typeToken.getType());
        return response;
    }
}
