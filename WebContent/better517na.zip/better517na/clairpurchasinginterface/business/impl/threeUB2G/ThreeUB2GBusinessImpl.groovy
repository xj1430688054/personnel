package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.threeUB2G

import com.better517na.JavaServiceRouteHelper.business.cxfInterceptor.ClientOutInterceptor
import com.better517na.JavaServiceRouteHelper.business.cxfInterceptor.ClientSetPostSubmitInterceptor
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.threeb2gService.MCreateOrderRequest
import com.better517na.threeb2gService.MCreateOrderResponse
import com.better517na.threeb2gService.MPayOrderRequest
import com.better517na.threeb2gService.MPayOrderResponse
import com.better517na.threeb2gService.MQueryFlightRequest
import com.better517na.threeb2gService.MQueryFlightResponse
import com.better517na.threeb2gService.MQueryOrderNewResponse
import com.better517na.threeb2gService.MQueryOrderRequest
import com.better517na.threeb2gService.WebService1
import com.better517na.threeb2gService.WebService1Soap
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.threeUB2G.IThreeUB2GBusiness
import org.apache.cxf.frontend.ClientProxy
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean
import org.apache.cxf.jaxws.binding.soap.SOAPBindingImpl
import org.apache.cxf.transport.Conduit
import org.apache.cxf.transport.http.HTTPConduit
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.xml.ws.BindingProvider
import javax.xml.ws.Service

@Component
public class ThreeUB2GBusinessImpl implements IThreeUB2GBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    public MCreateOrderResponse createOrder(MCreateOrderRequest orderInfo, String url) throws Exception {
        MCreateOrderResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(url);
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.createOrder(orderInfo);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G创建订单出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('川航B2G接口交互');
                            interactionParam.setKey1('createOrder');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(orderInfo));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    @Override
    public MQueryOrderNewResponse queryOrderDetail(MQueryOrderRequest requestVo, String url) throws Exception {
        MQueryOrderNewResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(url);
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.queryOrder(requestVo);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G查询订单出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('川航B2G接口交互');
                            interactionParam.setKey1('queryOrder');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(requestVo));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    @Override
    public MPayOrderResponse ticketing(MPayOrderRequest requestVo, String url) throws Exception {
        MPayOrderResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(url);
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.payOrder(requestVo);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G获取支付链接出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('川航B2G接口交互');
                            interactionParam.setKey1('payOrder');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(requestVo));
                            interactionParam.setReceiveContent(response == null ? null : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    @Override
    public MQueryFlightResponse queryFlightInfo(MQueryFlightRequest  requestVo, String url) throws Exception{
        MQueryFlightResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(url);
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.queryFlightInfo(requestVo);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G验价出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('川航B2G接口交互');
                            interactionParam.setKey1('queryFlightInfo');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(requestVo));
                            interactionParam.setReceiveContent(response == null ? null : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }
}
