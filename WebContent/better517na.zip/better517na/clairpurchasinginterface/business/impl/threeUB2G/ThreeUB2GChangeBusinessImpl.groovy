package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.threeUB2G

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.threeb2gService.ArrayOfMChangePasModel
import com.better517na.threeb2gService.ArrayOfString
import com.better517na.threeb2gService.MChangePasModel
import com.better517na.threeb2gService.MChangePayRequest
import com.better517na.threeb2gService.MChangeTicketNewResponse
import com.better517na.threeb2gService.MChangeTicketRequest
import com.better517na.threeb2gService.MPayOrderResponse
import com.better517na.threeb2gService.MQueryChangeFeeResponse
import com.better517na.threeb2gService.MQueryChangeNewResponse
import com.better517na.threeb2gService.MQueryChangeRequest
import com.better517na.threeb2gService.MResultStatusCode
import com.better517na.threeb2gService.WebService1
import com.better517na.threeb2gService.WebService1Soap
import com.better517na.unifiedParameters.business.ParamBusiness
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.qs.PayExchange
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.threeUB2G.IThreeUB2GChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qs.MNoPassPayArgs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qs.MNoPassPayResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qs.PayInterfacePayType
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qs.PayInterfaceSubBusinessType
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.BuyChangeTicketInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.BuyChangeVoyageInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.InChannelChangeParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelApplyChangeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelChangePayNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelQueryChangeFeeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelQueryChangeInfoNewVo
import org.apache.cxf.frontend.ClientProxy
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean
import org.apache.cxf.jaxws.binding.soap.SOAPBindingImpl
import org.apache.cxf.transport.Conduit
import org.apache.cxf.transport.http.HTTPConduit
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import org.apache.commons.codec.binary.Base64;
import javax.xml.bind.JAXB
import javax.xml.datatype.DatatypeConfigurationException
import javax.xml.datatype.DatatypeFactory
import javax.xml.datatype.XMLGregorianCalendar
import javax.xml.ws.Service
import java.nio.charset.StandardCharsets

@Component
class ThreeUB2GChangeBusinessImpl implements IThreeUB2GChangeBusiness {
    @Autowired
    private ParamBusiness paramBusiness;
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;
    /**
     * 获取改签手续费方法
     * @param inChannelChangeParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelQueryChangeFeeNewVo channelQueryChangeFee(InChannelChangeParamVo inChannelChangeParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelQueryChangeFeeNewVo response = null;
        MChangeTicketRequest mChangeTicketRequest = new MChangeTicketRequest();
        MQueryChangeFeeResponse mQueryChangeFeeResponse = null;
        try {
            OutChannelQueryChangeFeeNewVo result = new OutChannelQueryChangeFeeNewVo();
            //构造入参"outOrderId", "passagerNames", "newTakeOffTime", "newFlightNo", "newCarbin", "payMoney", "changeOrderId",
            // "sellDeptId", "validType", "cardBankID", "budgetUnitName", "cvv2", "validDateStr"
            //买入出票订单号
            mChangeTicketRequest.setOutOrderId(inChannelChangeParamVo.getOrder().getOutChannelOrderId());
            //航班号,仓位，起飞时间
            BuyChangeVoyageInfoBo newChangeVoyage = null;
            if (inChannelChangeParamVo.getVoyages() != null && inChannelChangeParamVo.getVoyages().size() > 0) {
                for (int i = 0;i < inChannelChangeParamVo.getVoyages().size(); i++) {
                    if (inChannelChangeParamVo.getVoyages().get(i) != null && 1 == inChannelChangeParamVo.getVoyages().get(i).getVoyageType()) {
                        newChangeVoyage = inChannelChangeParamVo.getVoyages().get(i);
                        break;
                    }
                }
            }

            if (newChangeVoyage == null) {
                return null;
            }

            mChangeTicketRequest.setNewFlightNo(newChangeVoyage.getFlightNo());
            mChangeTicketRequest.setNewTakeOffTime(dateToXmlDate(newChangeVoyage.getDeptTime()));
            mChangeTicketRequest.setNewCarbin(newChangeVoyage.getCabin());
            //改签订单号
            mChangeTicketRequest.setChangeOrderId(inChannelChangeParamVo.getOrder().getOrderId());
            //乘机人
            List<String> stringList = new ArrayList<>();
            for (BuyChangeTicketInfoBo buyChangeTicketInfoBo : inChannelChangeParamVo.getTickets()) {
                String passagerName = buyChangeTicketInfoBo.getUserName();
                stringList.add(passagerName);
            }
            if (stringList.size() != 0) {
                ArrayOfString arrayOfString = new ArrayOfString();
                arrayOfString.string = stringList;
                mChangeTicketRequest.setPassagerNames(arrayOfString);
            }
            //账号密码
            mChangeTicketRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 0));
            mChangeTicketRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            mChangeTicketRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 1));
            mChangeTicketRequest.setCarrier("3UVIP");
            mChangeTicketRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mQueryChangeFeeResponse = create.queryChangeFee(mChangeTicketRequest);
            //构造返参  "passName", "cardNo", "ticketNo", "newTicketPrice", "totalPoundage"
            //totalPoundage = 升舱费+改签费
            //newTicketPrice - 原票价 = 改签费
            if (mQueryChangeFeeResponse.getResult().value() == 'Success') {
                BigDecimal totalUpgradeFee = 0;
                BigDecimal totalChangeDateFee = 0;
                List<BuyChangeTicketInfoBo> bInfoList = new ArrayList<>();
                for (int i = 0; i < inChannelChangeParamVo.getTickets().size(); i++) {
                    BigDecimal changeFee = 0;
                    BigDecimal upFee = 0;
                    for (MChangePasModel mChangePasModel : mQueryChangeFeeResponse.getPasList().getMChangePasModel()) {
                        if (inChannelChangeParamVo.getTickets().get(i).getUserName() == mChangePasModel.getPassName()) {
                            upFee = mChangePasModel.getNewTicketPrice() - inChannelChangeParamVo.getTickets().get(i).getSellSalesPrice();
                            changeFee = mChangePasModel.getTotalPoundage() - upFee;
                            BuyChangeTicketInfoBo bInfo = inChannelChangeParamVo.getTickets().get(i);
                            bInfo.setChangeTickFee(mChangePasModel.getTotalPoundage());
                            bInfo.setUpgradeFee(upFee);
                            bInfo.setChangeDateFee(changeFee);
                            bInfo.setNewTickPrice(mChangePasModel.getNewTicketPrice());
                            bInfoList.add(bInfo);
                            totalUpgradeFee = totalUpgradeFee.add(upFee);
                            totalChangeDateFee = totalChangeDateFee.add(changeFee);
                            break;
                        }
                    }
                }
                result.setTickets(bInfoList);
                result.setTotalChangeDateFee(totalChangeDateFee);
                result.setTotalUpgradeFee(totalUpgradeFee);
                result.setChangeOrderId(inChannelChangeParamVo.getOrder().getOrderId());
                result.setChannelOrderId(inChannelChangeParamVo.getOrder().getChannelOrderId());
            }
            response = result;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G获取改签手续出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MChangeTicketRequest newrequest = mChangeTicketRequest;
                final MQueryChangeFeeResponse newresponse = mQueryChangeFeeResponse;
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G改签订单接口交互');
                interactionParam.setKey1("queryChangeFee");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }

    /**
     * 改签申请
     * @param inChannelChangeParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelApplyChangeNewVo channelApplyChange(InChannelChangeParamVo inChannelChangeParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelApplyChangeNewVo response = null;
        MChangeTicketRequest mChangeTicketRequest = new MChangeTicketRequest();
        MChangeTicketNewResponse mChangeTicketNewResponse = null;
        try {
            OutChannelApplyChangeNewVo result = new OutChannelApplyChangeNewVo();

            //买入出票订单号
            mChangeTicketRequest.setOutOrderId(inChannelChangeParamVo.getOrder().getOutChannelOrderId());
            //改签订单号
            mChangeTicketRequest.setChangeOrderId(inChannelChangeParamVo.getOrder().getOrderId());
            //航班号,仓位，起飞时间
            BuyChangeVoyageInfoBo newChangeVoyage = null;
            if (inChannelChangeParamVo.getVoyages() != null && inChannelChangeParamVo.getVoyages().size() > 0) {
                for (int i = 0;i < inChannelChangeParamVo.getVoyages().size(); i++) {
                    if (inChannelChangeParamVo.getVoyages().get(i) != null && 1 == inChannelChangeParamVo.getVoyages().get(i).getVoyageType()) {
                        newChangeVoyage = inChannelChangeParamVo.getVoyages().get(i);
                        break;
                    }
                }
            }

            if (newChangeVoyage == null) {
                return null;
            }

            mChangeTicketRequest.setNewFlightNo(newChangeVoyage.getFlightNo());
            mChangeTicketRequest.setNewTakeOffTime(dateToXmlDate(newChangeVoyage.getDeptTime()));
            mChangeTicketRequest.setNewCarbin(newChangeVoyage.getCabin());

            List<String> stringList = new ArrayList<>();
            for (BuyChangeTicketInfoBo buyChangeTicketInfoBo : inChannelChangeParamVo.getTickets()) {
                String passagerName = buyChangeTicketInfoBo.getUserName();
                stringList.add(passagerName);
            }
            if (stringList.size() != 0) {
                ArrayOfString arrayOfString = new ArrayOfString();
                arrayOfString.string = stringList;
                mChangeTicketRequest.setPassagerNames(arrayOfString);
            }
            //账号密码
            mChangeTicketRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 0));
            mChangeTicketRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            mChangeTicketRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 1));
            mChangeTicketRequest.setCarrier("3UVIP");
            mChangeTicketRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mChangeTicketNewResponse = create.changeTicket(mChangeTicketRequest);
            if (mChangeTicketNewResponse.getResult().value() == 'Success') {
                //改签成功 构造返参(申请改签，会返回改签订单号，最后返回值赋值ChangeAirOrderId=航司正向订单号+"|"+返回的航司改签订单号)
                result.setChangeAirOrderId(mChangeTicketNewResponse.getAirChangeOrderId());
                result.setChangeOrderId(inChannelChangeParamVo.getOrder().getOrderId());
                result.setPnr(mChangeTicketNewResponse.getNewPnr());
            } else {
                result.setChangeFailReason(mChangeTicketNewResponse.getResultMsg());
            }
            response = result;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G改签申请出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MChangeTicketRequest newrequest = mChangeTicketRequest;
                final MChangeTicketNewResponse newresponse = mChangeTicketNewResponse;
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G改签订单接口交互');
                interactionParam.setKey1("applyChange");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }

    /**
     * 改签支付
     * @param inChannelChangeParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelChangePayNewVo channelChangePay(InChannelChangeParamVo inChannelChangeParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelChangePayNewVo response = null;
        MChangePayRequest mChangePayRequest = new MChangePayRequest();
        MPayOrderResponse mPayOrderResponse = null;
//        1.1 调用航司B2C集成服务接口改签支付方法获取改签支付链接，这里入参传航司改签订单号
//        1.2 调清算支付，调收银台地址，业务ID，PID，秘钥按之前的参数可配置，钱包账号用payInfo的第一位
        try {
            OutChannelChangePayNewVo result = new OutChannelChangePayNewVo();

            //构造入参
            mChangePayRequest.setChangeOrderId(inChannelChangeParamVo.getOrder().getChannelOrderId());
            mChangePayRequest.setPayMoney(inChannelChangeParamVo.getOrder().getChangeTickFee());
            //账号密码
            mChangePayRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 0));
            mChangePayRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            mChangePayRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 1));
            mChangePayRequest.setCarrier("3UVIP");
            mChangePayRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mPayOrderResponse = create.changePay(mChangePayRequest);
            //先判定成功
            if (mPayOrderResponse.getResult() == MResultStatusCode.SUCCESS) {
                //再判断extion
                if (mPayOrderResponse.getExtension() != null && mPayOrderResponse.getExtension() != '') {
                    MNoPassPayArgs args = new MNoPassPayArgs();
                    args.setPid(paramBusiness.getSysParam("GNJP_GQ_ChangePayPid"));
                    //args.setBuyerID(paramBusiness.getSysParam("GWCP_CP_GYQSACCOUNT"));
                    //args.setPid("1506251002227642000004");
                    args.setBuyerID(supplySystemInfo.getPayInfo().split("\\|")[0]);
                    args.setBalanceType(Integer.parseInt(supplySystemInfo.getPayInfo().split("\\|")[1]));
                    args.setAutoExecute("88");
                    args.setClientType(5);
                    args.setOrderID(inChannelChangeParamVo.getOrder().getOrderId() + "G");
                    args.setPayFee(inChannelChangeParamVo.getOrder().getChangeTickFee());
                    args.setPayTypeID(PayInterfacePayType.QsPay_NoPswExternal);
                    args.setSubBusinessType(PayInterfaceSubBusinessType.AirTicket);
                    args.setSubject(inChannelChangeParamVo.getOrder().getOrderId());
                    List<String> passagerNames = new ArrayList<>();
                    for (BuyChangeTicketInfoBo to : inChannelChangeParamVo.getTickets()) {
                        passagerNames.add(to.getUserName());
                    }
                    args.setRemark(";~~~" + "3UB2G" + "~" + "~");
                    //支付宝代付成功收通知地址，这里是出票接口收通知网站地址
                    args.setNotifyUrl(paramBusiness.getSysParam("CPPT_CP_ALIPAYNOTIFYURL"));
                    args.setPayInterfaceUrl(paramBusiness.getSysParam("GWCP_CP_QSZDCPURL"));
                    args.setSecurityCode(paramBusiness.getSysParam("GNJP_GQ_ChangePaySecurityCode"));
                    //args.setNotifyUrl("http://tz.cp.517na.com/CPPTAliPayNotify.aspx");
                    //args.setPayInterfaceUrl("http://zf.jk.517na.com/PubPayService.ashx");
                    //args.setSecurityCode("b0e3674a1b7a439bbc53dd441a2b74f0");
                    args.setDutParam(mPayOrderResponse.getExtension().replace("\\u003d", "=").replace("\\", ""));
                    PayExchange bpay = new PayExchange();
                    MNoPassPayResult payResult = bpay.NoPassPayNew(args);
                    if (payResult == null) {
                        result.setPayFailResult("调清算支付失败");
                        result.setIsPaySuccess(false);
                        result.setOutsideOrderId(inChannelChangeParamVo.getOrder().getOutOrderId());
                    } else if ('TRUE'.equalsIgnoreCase(payResult.getD().getIsSuccess())) {
                        result.setPayFailResult(payResult.getErrMsg());
                        result.setIsPaySuccess(true);
                        result.setOutsideOrderId(inChannelChangeParamVo.getOrder().getOutOrderId());
                    } else {
                        result.setIsPaySuccess(false);
                        result.setOutsideOrderId(inChannelChangeParamVo.getOrder().getOutOrderId());
                    }
                } else {
                    result.setIsPaySuccess(true);
                    result.setOutsideOrderId(inChannelChangeParamVo.getOrder().getChannelOrderId());
                }
            } else {
                result.setPayFailResult(mPayOrderResponse.getResultMsg());
                result.setIsPaySuccess(false);
                result.setOutsideOrderId(inChannelChangeParamVo.getOrder().getOutOrderId());
            }
            response = result;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G改签支付出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MChangePayRequest newrequest = mChangePayRequest;
                final MPayOrderResponse newresponse = mPayOrderResponse;
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G改签订单接口交互');
                interactionParam.setKey1("changePay");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }

    /**
     * 查询改签详情
     * @param inChannelChangeParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelQueryChangeInfoNewVo channelQueryChangeInfo(InChannelChangeParamVo inChannelChangeParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelQueryChangeInfoNewVo response = null;
        MQueryChangeRequest mQueryChangeRequest = new MQueryChangeRequest();
        MQueryChangeNewResponse mQueryChangeNewResponse = null;
        try {
            OutChannelQueryChangeInfoNewVo result = new OutChannelQueryChangeInfoNewVo();
            //构造入参 "airChangeOrderId", "changeOrderId", "passagerNames"

            //机票改签订单号
            mQueryChangeRequest.setAirChangeOrderId(inChannelChangeParamVo.getOrder().getChannelOrderId());
            List<String> stringList = new ArrayList<>();
            for (BuyChangeTicketInfoBo buyChangeTicketInfoBo : inChannelChangeParamVo.getTickets()) {
                String passagerName = buyChangeTicketInfoBo.getUserName();
                stringList.add(passagerName);
            }
            if (stringList.size() != 0) {
                ArrayOfString arrayOfString = new ArrayOfString();
                arrayOfString.string = stringList;
                mQueryChangeRequest.setPassagerNames(arrayOfString);
            }
            //账号密码
            mQueryChangeRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 0));
            mQueryChangeRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            mQueryChangeRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(), 1));
            mQueryChangeRequest.setCarrier("3UVIP");
            mQueryChangeRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mQueryChangeNewResponse = create.queryChange(mQueryChangeRequest);
            if (mQueryChangeNewResponse.getResult().value() == 'Success') {
                //"pasList", "newPnr", "status" 返回票号乘机人
                // 改签成功人数
                int changeSuccessCount = 0;
                List<BuyChangeTicketInfoBo> boList = new ArrayList<>();
                for (ArrayOfMChangePasModel array : mQueryChangeNewResponse.getPasList()) {
                    for (MChangePasModel pasModel : array.getMChangePasModel()) {
                        BuyChangeTicketInfoBo bo = new BuyChangeTicketInfoBo();
                        bo.setUserName(pasModel.getPassName());
                        bo.setNewTicketNo(pasModel.getTicketNo());
                        bo.setTotelFee(pasModel.getTotalPoundage());
                        bo.setNewTickPrice(pasModel.getNewTicketPrice());
                        bo.setCardNo(pasModel.getCardNo());
                        boList.add(bo);
                        // 如果获取到新票号，则该乘机人改签成功
                        if (!pasModel.getTicketNo().isEmpty()) {
                            changeSuccessCount++;
                        }
                    }
                }
                // 所有乘机人都改签成功，订单状态为改签成功
                if (changeSuccessCount == inChannelChangeParamVo.getTickets().size()) {
                    inChannelChangeParamVo.getOrder().setOrderStatus(4);
                    inChannelChangeParamVo.getOrder().setOrderStatusName("改签成功，交易结束");
                }

                result.setOrder(inChannelChangeParamVo.getOrder());
                result.setTickets(boList);
                result.setVoyages(inChannelChangeParamVo.getVoyages());
            }
            response = result;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G查询改签详情出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MQueryChangeRequest newrequest = mQueryChangeRequest;
                final MQueryChangeNewResponse newresponse = mQueryChangeNewResponse;
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G改签订单接口交互');
                interactionParam.setKey1("queryChangeInfo");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }

    private void writeLog(InChannelChangeParamVo newrequest, Object newresponse) {
        try {
            // 使用异步方式记日志
            new Thread() {
                public void run() {
                    OutputStream requestXml = new ByteArrayOutputStream();
                    OutputStream responsetXml = new ByteArrayOutputStream();
                    JAXB.marshal(newrequest, requestXml);
                    if (null != newresponse) {
                        JAXB.marshal(newresponse, responsetXml);
                    }
                    MLogInteraction interactionParam = new MLogInteraction();
                    interactionParam.setModule('3UB2G改签订单接口交互');
                    interactionParam.setKey1('3UB2G');
                    interactionParam.setReceiveContent(responsetXml.toString());
                    interactionParam.setSendContent(requestXml.toString());
                    logBusiness.writeInteractionLog(interactionParam);
                }
            }.start();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("日志记录时异常");
        }
    }

    private static String getBigCustomerAndUserName(String s, Integer p) {
        try {
            String[] result = s.split("\\|");
            return result[p];
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static XMLGregorianCalendar dateToXmlDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        DatatypeFactory dtf = null;
        XMLGregorianCalendar dateType = null;
        try {
            dtf = DatatypeFactory.newInstance();
            dateType = dtf.newXMLGregorianCalendar();
            dateType.setYear(cal.get(Calendar.YEAR));
            //由于Calendar.MONTH取值范围为0~11,需要加1
            dateType.setMonth(cal.get(Calendar.MONTH) + 1);
            dateType.setDay(cal.get(Calendar.DAY_OF_MONTH));
            dateType.setHour(cal.get(Calendar.HOUR_OF_DAY));
            dateType.setMinute(cal.get(Calendar.MINUTE));
            dateType.setSecond(cal.get(Calendar.SECOND));
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }
        return dateType;
    }

}
