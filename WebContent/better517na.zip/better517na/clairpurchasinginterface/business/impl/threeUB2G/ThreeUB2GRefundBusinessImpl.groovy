package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.threeUB2G

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.threeb2gService.ArrayOfMPassenger
import com.better517na.threeb2gService.MPassenger
import com.better517na.threeb2gService.MQueryRefundFeeResponse
import com.better517na.threeb2gService.MQueryRefundInfoRequest
import com.better517na.threeb2gService.MQueryRefundInfoResponse
import com.better517na.threeb2gService.MRefundPasModel
import com.better517na.threeb2gService.MRefundTicketRequest
import com.better517na.threeb2gService.MRefundTicketResponse
import com.better517na.threeb2gService.WebService1
import com.better517na.threeb2gService.WebService1Soap
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.threeUB2G.IThreeUB2GRefundBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.BuyReverseOrderInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.BuyReverseTicketInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.TicketRefundPoundageInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelRefundParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelApplyRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelQueryRefundInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelQueryRefundRateVo
import org.apache.cxf.frontend.ClientProxy
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean
import org.apache.cxf.jaxws.binding.soap.SOAPBindingImpl
import org.apache.cxf.transport.Conduit
import org.apache.cxf.transport.http.HTTPConduit
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.xml.bind.JAXB
import javax.xml.ws.Service

@Component
class ThreeUB2GRefundBusinessImpl implements IThreeUB2GRefundBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;
    /**
     * 3UB2G申请退票
     * @param inChannelRefundParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelApplyRefundVo returnTicket(InChannelRefundParamVo inChannelRefundParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelApplyRefundVo response = null;
        MRefundTicketRequest mRefundTicketRequest = new MRefundTicketRequest();
        MRefundTicketResponse mRefundTicketResponse = null;
        try {
            OutChannelApplyRefundVo result = new OutChannelApplyRefundVo();
            //这里需要构造入参 mRefundTicketRequest = inChannelRefundParamVo
            //传入订单号
            mRefundTicketRequest.setOrderId(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo().getChanelOrderId());
            //传入乘机人
            List<MPassenger> mPassengerList = new ArrayList<>();
            for (BuyReverseTicketInfo buyReverseTicketInfo : inChannelRefundParamVo.getArgDto().getBuyReverseTicketInfos()) {
                MPassenger mPassenger = new MPassenger();
                mPassenger.setPName(buyReverseTicketInfo.getUserName());
                mPassengerList.add(mPassenger);
            }
            if (mPassengerList.size() != 0) {
                ArrayOfMPassenger arrayOfMPassenger = new ArrayOfMPassenger();
                arrayOfMPassenger.mPassenger = mPassengerList;
                mRefundTicketRequest.setRefundPsgs(arrayOfMPassenger);
            }
            //传入账号密码
            mRefundTicketRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(),0));
            mRefundTicketRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            mRefundTicketRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(),1));
            //航司
            mRefundTicketRequest.setCarrier("3UVIP");
            mRefundTicketRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mRefundTicketResponse = create.refundTicket(mRefundTicketRequest);
            // 这里需要构造出参 response = mRefundTicketResponse
            if (mRefundTicketResponse != null && mRefundTicketResponse.getResult().value() == 'Success') {
                result.setQueryResult(true);
                result.setTicketOrderNo(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo().getChanelOrderId());
            } else {
                result.setQueryResult(false);
            }
            response = result;
        }  catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G申请退票出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MRefundTicketRequest newrequest = mRefundTicketRequest;
                final MRefundTicketResponse newresponse = mRefundTicketResponse;
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G退票订单接口交互');
                interactionParam.setKey1("applyRefund");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }
    /**
     * 3UB2G查询退票订单详情
     * @param inChannelRefundParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelQueryRefundInfoVo getRefundOrderDetail(InChannelRefundParamVo inChannelRefundParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelQueryRefundInfoVo response = null;
        MQueryRefundInfoRequest mQueryRefundInfoRequest = new MQueryRefundInfoRequest();
        MQueryRefundInfoResponse mQueryRefundInfoResponse = null;
        try {
            OutChannelQueryRefundInfoVo result = new OutChannelQueryRefundInfoVo();
            //构造入参"orderId", "serviceId", "ticketNo", "bigPnr"
            //订单号
            mQueryRefundInfoRequest.setOrderId(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo().getChanelOrderId());
            //票号，目前只拿第一个
            mQueryRefundInfoRequest.setTicketNo(inChannelRefundParamVo.getArgDto().getBuyReverseTicketInfos().get(0).getTicketNo());
            //传入用户密码
            mQueryRefundInfoRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(),0));
            mQueryRefundInfoRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(),1));
            mQueryRefundInfoRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            //航司
            mQueryRefundInfoRequest.setCarrier("3UVIP");
            mQueryRefundInfoRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mQueryRefundInfoResponse = create.queryRefundInfo(mQueryRefundInfoRequest);
            if (mQueryRefundInfoResponse != null && mQueryRefundInfoResponse.getResult().value() == 'Success') {

                //直接把入参赋值给出参
                result.setBuyReverseOrderInfo(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo());
                result.setBuyReverseInsuranceInfos(inChannelRefundParamVo.getArgDto().getBuyReverseInsuranceInfos());
                result.setBuyReverseTicketInfos(inChannelRefundParamVo.getArgDto().getBuyReverseTicketInfos());
                result.setBuyReverseVoyageInfos(inChannelRefundParamVo.getArgDto().getBuyReverseVoyageInfos());
                //将查询到的状态更新
                BuyReverseOrderInfo buyReverseOrderInfo = new BuyReverseOrderInfo();
                buyReverseOrderInfo.setChannelRefundOrderStatus(mQueryRefundInfoResponse.getStatus().value());
                result.setBuyReverseOrderInfo(buyReverseOrderInfo);
            }
            response = result;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G查询退票订单详情出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MQueryRefundInfoRequest newrequest = mQueryRefundInfoRequest;
                final MQueryRefundInfoResponse newresponse = mQueryRefundInfoResponse;

                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G退票订单接口交互');
                interactionParam.setKey1("queryRefundInfo");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }
    /**
     * 3UB2G查询退票手续费
     * @param inChannelRefundParamVo
     * @param url
     * @return
     */
    @Override
    OutChannelQueryRefundRateVo queryReturnTicketRate(InChannelRefundParamVo inChannelRefundParamVo, SupplySystemInfo supplySystemInfo) {
        OutChannelQueryRefundRateVo response = null;
        MRefundTicketRequest mRefundTicketRequest = new MRefundTicketRequest();
        MQueryRefundFeeResponse mQueryRefundFeeResponse = null;
        try {
            OutChannelQueryRefundRateVo result = new OutChannelQueryRefundRateVo();
            //构造入参"orderId", "refundPsgs", "refundType", "refundTicketType", "reasonDetails", "remark"
            //订单号
            mRefundTicketRequest.setOrderId(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo().getChanelOrderId());
            List<MPassenger> mPassengerList = new ArrayList<>();
            for (BuyReverseTicketInfo buyReverseTicketInfo : inChannelRefundParamVo.getArgDto().getBuyReverseTicketInfos()) {

                MPassenger mPassenger = new MPassenger();
                mPassenger.setTicketNo(buyReverseTicketInfo.getTicketNo())
                mPassenger.setPName(buyReverseTicketInfo.getUserName());
                mPassengerList.add(mPassenger);
            }
            if (mPassengerList.size() != 0) {
                ArrayOfMPassenger arrayOfMPassenger = new ArrayOfMPassenger();
                arrayOfMPassenger.mPassenger = mPassengerList;
                mRefundTicketRequest.setRefundPsgs(arrayOfMPassenger);
            }
            //用户密码
            mRefundTicketRequest.setUserName(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(),0));
            mRefundTicketRequest.setPassword(supplySystemInfo.getInterfacePassWord());
            mRefundTicketRequest.setBigCustomer(getBigCustomerAndUserName(supplySystemInfo.getInterfaceAccount(),1));
            //航司
            mRefundTicketRequest.setCarrier("3UVIP");
            mRefundTicketRequest.setChannel("0");
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass( WebService1Soap.class);
            factoryBean.setAddress(supplySystemInfo.getInterfaceUrl());
            WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit)conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            mQueryRefundFeeResponse = create.queryReturnTicketRate(mRefundTicketRequest);
            if (mQueryRefundFeeResponse != null && mQueryRefundFeeResponse.getResult().value() == 'Success') {
                List<TicketRefundPoundageInfoVo> ticketRefundPoundageInfoVoList = new ArrayList<>();
                for (MPassenger mPassenger : mPassengerList) {
                    for (MRefundPasModel mRefundPasModel : mQueryRefundFeeResponse.getPasList().getMRefundPasModel()) {
                        if (mPassenger.getTicketNo().replace('-', '').equalsIgnoreCase(mRefundPasModel.getTicketNo().replace('-', ''))
                                || mPassenger.getPName().replace('-', '').equalsIgnoreCase(mRefundPasModel.getPassName().replace('-', ''))) {
                            TicketRefundPoundageInfoVo ticketRefundPoundageInfoVo = new TicketRefundPoundageInfoVo();
                            ticketRefundPoundageInfoVo.setPoundage(mRefundPasModel.getPoundage());//手续费
                            ticketRefundPoundageInfoVo.setDeductionTotal(mRefundPasModel.getPoundage())
                            ticketRefundPoundageInfoVo.setTicketNo(mRefundPasModel.getTicketNo());
                            ticketRefundPoundageInfoVoList.add(ticketRefundPoundageInfoVo);
                        }
                    }
                }
                result.setTicketRefundPoundageList(ticketRefundPoundageInfoVoList);
                result.setRefundReason(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo().getApplyRefundReasonText());
                result.setRefundReasonId(inChannelRefundParamVo.getArgDto().getBuyReverseOrderInfo().getApplyRefundReasonID());
            }
            response = result;
        }catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '川航B2G查询退票手续费出错', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                final MRefundTicketRequest newrequest = mRefundTicketRequest;
                final MQueryRefundFeeResponse newresponse = mQueryRefundFeeResponse;

                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('3UB2G退票订单接口交互');
                interactionParam.setKey1("queryRefundRate");
                interactionParam.setSendAddress(supplySystemInfo.getInterfaceUrl());
                interactionParam.setReceiveContent(newresponse == null ? null : new Gson().toJson(newresponse));
                interactionParam.setSendContent(new Gson().toJson(newrequest));
                logBusiness.writeInteractionLog(interactionParam);

            } catch (Exception e) {
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return response;
    }

    private static String getBigCustomerAndUserName(String s, Integer p) {
        try {
            String[] result = s.split("\\|");
            return result[p];
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
