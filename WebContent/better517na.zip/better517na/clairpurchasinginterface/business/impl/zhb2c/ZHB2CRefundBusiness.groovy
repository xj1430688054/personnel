package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2c

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.zhb2cService.IOtaApiService
import com.better517na.zhb2cService.ReturnTicketInfoRequest
import com.better517na.zhb2cService.ReturnTicketInfoResponse
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2c.IZHB2CRefundBusiness
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class ZHB2CRefundBusiness implements IZHB2CRefundBusiness{

    @Autowired
    private LogBusiness logBusiness;

    @Override
    ReturnTicketInfoResponse returnTicket(ReturnTicketInfoRequest request, String url) {
        ReturnTicketInfoResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(IOtaApiService.class);
            factoryBean.setAddress(url);
            IOtaApiService create = factoryBean.create()
            response = create.returnTicket(request)
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '深航B2C提交退票异常', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('深航B2C接口交互');
                            interactionParam.setKey1('returnTicket');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }
}
