package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.zhb2c

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.payInteractionService.MYeepayPayOutParam
import com.better517na.payInteractionService.MYeepayPayParam
import com.better517na.zhb2cService.GetAvInfoRequest
import com.better517na.zhb2cService.GetAvInfoResponse
import com.better517na.zhb2cService.IOtaApiService
import com.better517na.zhb2cService.OrderInfoDetailRequest
import com.better517na.zhb2cService.OrderInfoDetailResponse
import com.better517na.zhb2cService.OutTicketInfoRequest
import com.better517na.zhb2cService.OutTicketInfoResponse
import com.better517na.zhb2cService.SubmitOrderInfoRequest
import com.better517na.zhb2cService.OrderPayInfoRequest
import com.better517na.zhb2cService.OrderPayInfoResponse
import com.better517na.zhb2cService.SubmitOrderInfoResponse
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.zhb2c.IZHB2CBusiness
import org.apache.cxf.frontend.ClientProxy
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean
import org.apache.cxf.transport.Conduit
import org.apache.cxf.transport.http.HTTPConduit
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class ZHB2CBusiness implements IZHB2CBusiness{

    @Autowired
    private LogBusiness logBusiness;
    @Override
    GetAvInfoResponse queryPrice(GetAvInfoRequest request, String url) {
        GetAvInfoResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(IOtaApiService.class);
            factoryBean.setAddress(url);
            IOtaApiService create = factoryBean.create()
            response = create.getAv(request)
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '深航B2C询价异常', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('深航B2C接口交互');
                            interactionParam.setKey1('getAV');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    public SubmitOrderInfoResponse createOrder(SubmitOrderInfoRequest request, String url){
        SubmitOrderInfoResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(IOtaApiService.class);
            factoryBean.setAddress(url);
            IOtaApiService create = factoryBean.create()
            response = create.submitOrder(request)
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '深航B2C创单异常', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('深航B2C接口交互');
                            interactionParam.setKey1('submitOrder');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    public OutTicketInfoResponse outTicket(OutTicketInfoRequest request, String url){
        OutTicketInfoResponse response = null;
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(IOtaApiService.class);
            factoryBean.setAddress(url);
            IOtaApiService create = factoryBean.create()
            response = create.outTicket(request)
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '深航B2C出票异常', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread() {
                    public void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('深航B2C接口交互');
                            interactionParam.setKey1('outTicket');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }.start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    @Override
    public OrderInfoDetailResponse queryOrderDetail(OrderInfoDetailRequest requestVo, String url) throws Exception {

        OrderInfoDetailResponse response = new OrderInfoDetailResponse();
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(IOtaApiService.class);
            factoryBean.setAddress(url);
            IOtaApiService create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit) conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.getOrderDetail(requestVo);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '深航B2C订单查询失败', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread(new Runnable() {
                    @Override
                    void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('深航B2C接口交互');
                            interactionParam.setKey1('getOrderDetail');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(requestVo));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }).start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    @Override
    public OrderPayInfoResponse orderPay(OrderPayInfoRequest request, String url) throws Exception {
        OrderPayInfoResponse response = new OrderPayInfoResponse();
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(IOtaApiService.class);
            factoryBean.setAddress(url);
            IOtaApiService create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit) conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.orderPay(request);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '深航B2C支付失败', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread(new Runnable() {
                    @Override
                    void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('深航B2C接口交互');
                            interactionParam.setKey1('orderPay');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }).start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }

    @Override
   public MYeepayPayOutParam yeepayPay(MYeepayPayParam request,String pidUniqueKey, String pid, String url) throws Exception {
        MYeepayPayOutParam response = new MYeepayPayOutParam();
        try {
            JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
            factoryBean.setServiceClass(com.better517na.payInteractionService.WebService1Soap.class);
            factoryBean.setAddress(url);
            com.better517na.payInteractionService.WebService1Soap create = factoryBean.create();
            Conduit conduit = ClientProxy.getClient(create).getConduit();
            HTTPConduit hc = (HTTPConduit) conduit;
            HTTPClientPolicy client = new HTTPClientPolicy();
            client.setConnectionTimeout(1000000);
            client.setReceiveTimeout(1000000);
            hc.setClient(client);
            response = create.yeepayExternalPay(request, pidUniqueKey, pid);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '公共支付服务支付失败', e));
            throw e;
        } finally {
            try {
                // 使用异步方式记日志
                new Thread(new Runnable() {
                    @Override
                    void run() {
                        try {
                            MLogInteraction interactionParam = new MLogInteraction();
                            interactionParam.setModule('公共支付服务交互');
                            interactionParam.setKey1('yeepayExternalPay');
                            interactionParam.setSendAddress(url);
                            interactionParam.setSendContent(new Gson().toJson(request));
                            interactionParam.setReceiveContent(response == null ? "" : new Gson().toJson(response));
                            logBusiness.writeInteractionLog(interactionParam);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
                        }
                    }
                }).start();
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
    }
}
