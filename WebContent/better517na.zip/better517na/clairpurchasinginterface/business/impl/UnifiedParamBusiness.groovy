package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.unifiedParameters.business.ParamBusiness
import com.better517na.unifiedParameters.entity.MDictionary
import com.better517na.unifiedParameters.entity.MDictionaryList
import com.better517na.unifiedParameters.entity.MUserParam
import com.better517na.unifiedParameters.entity.MUserParamList
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IUnifiedParamBusiness
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.annotation.Resource

@Component
public class UnifiedParamBusinessImpl implements IUnifiedParamBusiness {

    /**
     * 系统参数获取对象.
     */
    @Autowired
    private ParamBusiness paramBusiness;

    /**
     * 获取系统参数.
     *
     * @param id .
     * @return .
     * @throws Exception .
     */
    @Override
    public String getSysParam(String id) throws Exception {
        return paramBusiness.getSysParam(id);
    }

    /**
     * 获取字典参数.
     *
     * @param id .
     * @return .
     * @throws Exception .
     */
    @Override
    public List<String> getDictionaryParamList(String id) throws Exception {
        List<String> list = new ArrayList<String>();
        MDictionaryList dictionaryList = paramBusiness.getDictionaryParamList(id);
        if (null != dictionaryList) {
            List<MDictionary> entNoList = dictionaryList.getDictionary();
            if (null != entNoList && entNoList.size() > 0) {
                for (MDictionary cell : entNoList) {
                    list.add(cell.getParaValue());
                }
            }
        }

        return list;
    }

    /**
     * 获取字典参数.
     *
     * @param id .
     * @return .
     * @throws Exception .
     */
    @Override
    public MDictionaryList getSrcDictionaryParamList(String id) throws Exception {
        return paramBusiness.getDictionaryParamList(id);
    }

    /**
     * 获取部门参数.
     *
     * @param deptId  部门ID
     * @param paramId 参数id
     * @return 部门参数
     * @throws Exception .
     */
    @Override
    public String getDeptParam(String deptId, String paramId) throws Exception {
        MUserParamList param = paramBusiness.getUserParamList(paramId, deptId);
        List<MUserParam> plst = param.getUserParam();
        return plst.get(0).getParaValue();
    }
}

