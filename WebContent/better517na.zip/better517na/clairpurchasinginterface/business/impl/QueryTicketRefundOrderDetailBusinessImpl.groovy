package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IQueryTicketRefundOrderDetailBusiness
import org.springframework.stereotype.Component

@Component
public class QueryTicketRefundOrderDetailBusinessImpl implements IQueryTicketRefundOrderDetailBusiness {

}
