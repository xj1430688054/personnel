package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.CLEtermInteractionRouteHelper.helper.ThriftRouteHelper
import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.TicketStatus
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.DeterTicketNoIn
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.DeterTicketNoOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusArgs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusRes
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * 配置方式提取票号 bsp em
 */
@Component
public class TicketNoEMBusiness {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     *
     * @param args
     * @param interfaceInfo
     * @return
     */
    public ExtractTicketNoStatusRes extractTicketNoStatus(ExtractTicketNoStatusArgs args) {
        ExtractTicketNoStatusRes response = new ExtractTicketNoStatusRes();
        response.setTicketNo(args.getTicketNo());
        DeterTicketNoOut outResult = this.deterTicketNo(args);
        if (outResult == null) {
            response.setSuccess(false);
            return response;
        } else {
            if (!outResult.getAnalysisResult()) { //提取票号不成功
                response.setSuccess(false);
            } else {
                response.setSuccess(true);
                String ticketNoStatus = "";
                for (Integer stat : outResult.getTicketInfo().getTicketStatus()) {
                    for (TicketStatus status : TicketStatus.values()) {
                        if (stat == status.getId())
                            ticketNoStatus = ticketNoStatus + "/" + status.getName();
                    }
                }
                response.setTicketNoStatus(ticketNoStatus.substring(1, ticketNoStatus.length()));
                response.setTicketInfo(outResult.getTicketInfo());
                response.setSellAirrax(outResult.getTicketInfo().getPriceInfo().getAirportBuildFee())
                response.setSellOilrax(outResult.getTicketInfo().getPriceInfo().getFuelFee())
                response.setTicketPrice(outResult.getTicketInfo().getPriceInfo().getFare())
            }
            return response;
        }
    }

    /**
     * 构造参数 em提取票号
     * @param args
     * @return
     * @throws Exception
     */
    private DeterTicketNoOut deterTicketNo(ExtractTicketNoStatusArgs args) throws Exception {
        DeterTicketNoIn paramIn = new DeterTicketNoIn();
        paramIn.setSmallPnr(args.getPnr());
        paramIn.setTmcID(args.getTmcId());
        paramIn.setProviderID(args.getProviderID());
        paramIn.setCorpID(args.getCorpID());
        paramIn.setOffice(args.getOffice());
        paramIn.setOrderID(args.getOrderId());
        paramIn.setTicketNo(args.getTicketNo());
        paramIn.setAction('DetrTicketNo');
        try {
            String queryDate = GsonUtil.getGson().toJson(paramIn);
            String re = ThriftRouteHelper.getInstance().routeServiceInvoke(queryDate);
            DeterTicketNoOut getPriceOutBo = GsonUtil.getGson().fromJson(StringUtil.upperConvertToLower(re), DeterTicketNoOut.class);
            return getPriceOutBo;
        } catch (Exception e) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'deterTicketNo异常', e.toString(), e));
            e.printStackTrace();
            return null;
        }
    }
}
