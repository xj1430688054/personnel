package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.config.RabbitMQClientHelper
import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogAcc
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IValidPriceDataQueueBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyTicketInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.PriceValidateBaseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.PriceValidateDataVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.QunarSearchPriceVendorPriceVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.QunarSearchPriceVendorPriceVoListWrapper
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.FlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutQueryOrderInfoVo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.annotation.Resource
import java.nio.charset.Charset

@Component
public class ValidPriceDataQueueBusinessImpl implements IValidPriceDataQueueBusiness {

    /**
     * 消息队列操作类.
     */
    @Resource(name = "clairticket")
    private RabbitMQClientHelper mqClientHelper;

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    private boolean publishQueue(PriceValidateBaseVo priceValidateInfo) {
        boolean res = false;
        String exchangeName = "cl.airticket";
        // String routingKey = "cl.airticket.price.updatequeue";
        String routingKey = "cl.airticket.updateprice";
        try {
            this.mqClientHelper.basicPublish(exchangeName, routingKey, GsonUtil.gson.toJson(priceValidateInfo).getBytes((Charset.forName("utf-8"))));
            res = true;
        } catch (Exception ex) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "入消息队列异常", ex.toString(), ex));
        } finally {
            MLogAcc logAcc = new MLogAcc();
            logAcc.setAppName("CLAirPurchasingInterface");
            logAcc.setKey1("updateprice");
            logAcc.setKey2(GsonUtil.gson.toJson(res));
            logAcc.setKey3(routingKey);
            logAcc.setDescription(exchangeName);
            logAcc.setMethod("publishPriceValidateQueue");
            logAcc.setParas(GsonUtil.gson.toJson(priceValidateInfo));
            logAcc.setReturnValue(GsonUtil.gson.toJson(res));
            this.logBusiness.writeAccLog(logAcc);
        }
        return res;
    }


    @Override
    void qunarPayValidateDataPublishQueue(ResponseVo<OutQueryOrderInfoVo> queryOrderInfoRes, OrderDetailResponse qunarOriResponse) {
        try {
            Thread thread = new Thread() {
                public void run() {
                    try {
                        if (queryOrderInfoRes != null
                                && queryOrderInfoRes.getSuccess()
                                && queryOrderInfoRes.getResult() != null
                                && queryOrderInfoRes.getResult().getTicketInfoList() != null
                                && queryOrderInfoRes.getResult().getTicketInfoList().size() > 0
                                && qunarOriResponse != null
                                && qunarOriResponse.getCode()
                                && qunarOriResponse.getFlightInfo() != null
                                && qunarOriResponse.getFlightInfo().size() == 1) {
                            // 成功并且只要单程的
                            // 支付前验价；异步操作；将OutQueryOrderInfoVo对象转化成ReversePriceVo；
                            OutQueryOrderInfoVo outQueryOrderInfoVo = queryOrderInfoRes.getResult();
                            BuyTicketInfoBo ticketInfoBo = null;
                            List<BuyTicketInfoBo> ticketInfoList = outQueryOrderInfoVo.getTicketInfoList();
                            for (BuyTicketInfoBo buyTicketInfoBo : ticketInfoList) {
                                //乘客类型:0:成人 / 1:儿童 / 2:婴儿 取成人的第一张票；
                                if (0 == buyTicketInfoBo.getPassengerType()) {
                                    ticketInfoBo = buyTicketInfoBo;
                                    break;
                                }
                            }

                            FlightInfo flightInfo = qunarOriResponse.getFlightInfo().get(0);
                            if (null != ticketInfoBo
                                    && ticketInfoBo.getSalesPrice() != null
                                    && ticketInfoBo.getSalesPrice().compareTo(BigDecimal.ZERO) > 0
                                    && ticketInfoBo.getTicketPrice() != null
                                    && ticketInfoBo.getTicketPrice().compareTo(BigDecimal.ZERO) > 0) {
                                PriceValidateDataVo data = new PriceValidateDataVo();

                                //机票销售价;
                                data.setSalesPrice(ticketInfoBo.getSalesPrice());
                                //燃油费;
                                data.setOilrax(ticketInfoBo.getOilrax());
                                //机建费
                                data.setAirrax(ticketInfoBo.getAirrax());
                                //总金额
                                data.setTotalMoney(ticketInfoBo.getTotalMoney());
                                //票面价
                                data.setTicketPrice(ticketInfoBo.getTicketPrice());
                                //出发城市，到达城市；
                                data.setDptCity(flightInfo.getDptAirportCode());
                                data.setArrCity(flightInfo.getArrAirportCode());
                                data.setCabin(flightInfo.getCabin());
                                data.setFlightNum(flightInfo.getFlightNum());

                                //起飞时间；
                                data.setDeptTime(outQueryOrderInfoVo.getOrderInfo().getTakeOffTime());
                                //构造推队列入参；
                                String priceValidatejson = GsonUtil.getGson().toJson(data);

                                PriceValidateBaseVo baseInfo = new PriceValidateBaseVo();
                                baseInfo.setPriceValidatejson(priceValidatejson);
                                baseInfo.setJsontype(1);
                                baseInfo.setDesc("qunar支付校验");
                                baseInfo.setTime(new Date());
                                //调用推队列函数；
                                publishQueue(baseInfo);
                            }
                        }
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                        logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "qunar支付校验反向更新数据推队列异常", new Exception(ex)));
                    }
                }
            };
            thread.setDaemon(true);
            thread.start();
        } catch (Exception ex) {
            ex.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "qunar支付校验反向更新数据推队列外层异常", ex));
        }
    }

    @Override
    void qunarCreateOrderDataPublishQueue(List<QunarSearchPriceVendorPriceVo> reverseVendorPriceVoArrayList) {
        try {
            Thread thread = new Thread() {
                public void run() {
                    try {
                        if (reverseVendorPriceVoArrayList != null && reverseVendorPriceVoArrayList.size() > 0) {

                            QunarSearchPriceVendorPriceVoListWrapper reverseVendorPriceVoList = new QunarSearchPriceVendorPriceVoListWrapper();
                            reverseVendorPriceVoList.setReverseVendorPriceVoArrayList(reverseVendorPriceVoArrayList);
                            String json = GsonUtil.gson.toJson(reverseVendorPriceVoList);

                            PriceValidateBaseVo baseInfo = new PriceValidateBaseVo();
                            baseInfo.setPriceValidatejson(json);
                            baseInfo.setJsontype(0);
                            baseInfo.setDesc("qunar创单校验");
                            baseInfo.setTime(new Date());
                            publishQueue(baseInfo);
                        }
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                        logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "qunar创单校验反向更新数据推队列异常", new Exception(ex)));
                    }
                }
            };
            thread.setDaemon(true)
            thread.start();
        } catch (Exception ex) {
            ex.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "qunar创单校验反向更新数据推队列外层异常"), ex);
        }
    }

    @Override
    void qunarSearchPriceDataPublishQueue(List<QunarSearchPriceVendorPriceVo> reverseVendorPriceVoArrayList) {
        try {
            Thread thread = new Thread() {
                public void run() {
                    try {
                        if (reverseVendorPriceVoArrayList != null && reverseVendorPriceVoArrayList.size() > 0) {

                            QunarSearchPriceVendorPriceVoListWrapper reverseVendorPriceVoList = new QunarSearchPriceVendorPriceVoListWrapper();
                            reverseVendorPriceVoList.setReverseVendorPriceVoArrayList(reverseVendorPriceVoArrayList);
                            String json = GsonUtil.gson.toJson(reverseVendorPriceVoList);

                            PriceValidateBaseVo baseInfo = new PriceValidateBaseVo();
                            baseInfo.setPriceValidatejson(json);
                            baseInfo.setJsontype(3);
                            baseInfo.setDesc("qunar询价");
                            baseInfo.setTime(new Date());
                            publishQueue(baseInfo);
                        }
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                        logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "qunar询价反向更新数据推队列异常", new Exception(ex)));
                    }
                }
            };
            thread.setDaemon(true)
            thread.start();
        } catch (Exception ex) {
            ex.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, "qunar询价反向更新数据推队列外层异常"), ex);
        }
    }
}
