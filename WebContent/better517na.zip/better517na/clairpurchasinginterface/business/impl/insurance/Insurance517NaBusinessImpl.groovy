package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.insurance

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.javaloghelper.util.LogUtil
import com.better517na.logcompontent.model.MLogUiacc
import com.better517na.model.entity.InsuranceAgentInfo;
import com.better517na.model.request.CreateInsuranceOrderParam;
import com.better517na.model.request.InsuranceCancleOrderData;
import com.better517na.model.request.InsuranceOrderQueryData;
import com.better517na.model.request.NotifyInsuranceInsureParam;
import com.better517na.model.request.NotifyInsurancePayParam;
import com.better517na.model.response.CreateInsuranceOrderResponse;
import com.better517na.model.response.InsuranceCancleOrderResponse;
import com.better517na.model.response.InsuranceOrderQueryResponse;
import com.better517na.model.response.NotifyInsuraceInsureResponse;
import com.better517na.model.response.NotifyInsurancePayResponse;
import com.better517na.model.response.ResponseData;
import com.better517na.trade.IInsuranceTradeOperation;
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IInsurance517NaBusiness
import org.springframework.stereotype.Component

import javax.annotation.Resource
import java.util.concurrent.ExecutionException

/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 *
 * <pre>
 * </pre>
 *
 * @author qiyue
 */
@Component
public class Insurance517NaBusinessImpl implements IInsurance517NaBusiness {

    /**
     * 保险业务接口.
     */
    @Resource(name = "insuranceTradeOperation")
    private IInsuranceTradeOperation operation;

    /**
     * 查询保险订单信息,用于回填卖出保险订单
     *
     * @param request
     * @return
     */
    @Override
    public ResponseData<InsuranceOrderQueryResponse> queryInsuranceOrder(InsuranceOrderQueryData request,
                                                                         InsuranceAgentInfo agentInfo) {
        return operation.insuranceOrderQuery(request, agentInfo);
    }

    /**
     * 接口保险创单
     *
     * @param request
     * @return
     */
    @Override
    public ResponseData<CreateInsuranceOrderResponse> insuranceCreateOrder(CreateInsuranceOrderParam request,
                                                                           InsuranceAgentInfo agent) {
        ResponseData<CreateInsuranceOrderResponse> insuranceResponseData=null;
        StringBuilder sblog = new StringBuilder("Insurance【采购调用接口创单】----Start\n");
        try {
            //调用接口创单
           insuranceResponseData = operation.insuranceCreateOrder(request, agent);
            if(insuranceResponseData==null||insuranceResponseData.result.equals("False")||insuranceResponseData.getResultData()==null||insuranceResponseData==false) {
                //记录详细日志
                String winRequest = GsonUtil.gson.toJson(request);
                String winAgent = GsonUtil.gson.toJson(agent);
                String winResponse = GsonUtil.gson.toJson(insuranceResponseData);
                sblog.append("【请求入参：】 request:" + winRequest + "  ;agent:" + winAgent + "  【返回参数】:" + winResponse);
                // 记录Uiacc日志
                MLogUiacc log = new MLogUiacc();
                log.setBusiKey("InsuranceInsure");
                log.setKeyMessage(sblog.toString());
                log.setModule("insurance_CLAirPurchasingInterface");
                log.setModuleKey("insurance_CLAirPurchasingInterface");
                log.setOperation("insurance_insuranceCreateOrder");
                log.setOrderID(request == null ? "" : request.getInsuredInfos().get(0).getOutOrderId());
                LogUtil.writeUiAccLog(log);
            }
        }catch (Exception e)
        {
            System.out.println(sblog.toString());
            e.printStackTrace();
        }
        return insuranceResponseData;
    }

    /**
     * 通知接口支付
     *
     * @param request
     * @return
     */
    @Override
    public ResponseData<NotifyInsurancePayResponse> notifyInsurancePayOrder(NotifyInsurancePayParam request,
                                                                            InsuranceAgentInfo agent) {
        return operation.notifyInsurancePayOrder(request, agent);
    }

    /**
     * 通知接口投保
     *
     * @param request
     * @return
     */
    @Override
    public ResponseData<NotifyInsuraceInsureResponse> notifyInsuranceInSure(NotifyInsuranceInsureParam request,
                                                                            InsuranceAgentInfo agent) {
        return operation.notifyInsuranceInSure(request, agent);
    }

    /**
     * 通知接口撤保
     *
     * @param request
     * @return
     */
    @Override
    public ResponseData<InsuranceCancleOrderResponse> notifyInsuranceCancel(InsuranceCancleOrderData request,
                                                                            InsuranceAgentInfo agent) {
        return operation.insuranceCancleOrder(request, agent);
    }
}

