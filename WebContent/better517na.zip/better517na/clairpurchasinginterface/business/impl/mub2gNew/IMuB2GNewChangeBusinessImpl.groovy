package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2gNew

import com.ceair.b2g.client.DTicketShp
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeAVReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeCheckReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeOrderReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeTaxReq
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeAVRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeCheckRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeOrderRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeTaxRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew.IMuB2GNewChangeBusiness
import org.springframework.stereotype.Component

@Component
class IMuB2GNewChangeBusinessImpl implements IMuB2GNewChangeBusiness{
    @Override
    PostUpgradeAVRes postUpgradeAV(PostUpgradeAVReq req) {
        DTicketShp client = new DTicketShp();
        PostUpgradeAVRes  res = client.postUpgradeAV(req);
        return res;
    }

    @Override
    PostUpgradeOrderRes postUpgradeOrder(PostUpgradeOrderReq req) {
        DTicketShp client = new DTicketShp();
        PostUpgradeOrderRes  res =  client.postUpgradeOrder(req);
        return res;
    }

    @Override
    PostUpgradeCheckRes postUpgradeCheck(PostUpgradeCheckReq req) {
        DTicketShp client = new DTicketShp();
        PostUpgradeCheckRes  res = client.postUpgradeCheck(req);
        return res;
    }

    @Override
    PostUpgradeTaxRes postUpgradeTax(PostUpgradeTaxReq req) {
        DTicketShp client = new DTicketShp();
        PostUpgradeTaxRes res = client.postUpgradeTax(req);
        return res;
    }
}
