package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2gNew

import com.alibaba.dubbo.common.json.JSONObject
import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.muB2gService.EcfareInfoInput
import com.better517na.muB2gService.OrderInfo
import com.better517na.muB2gService.RtnEcfareInfo
import com.better517na.muB2gService.RtnOrderInfo
import com.better517na.muB2gService.RtnOrderStatusInfo
import com.better517na.muB2gService.SearchInfo
import com.better517na.muB2gService.SearchResponse
import com.better517na.muB2gService.StatusQueryInfo
import com.ceair.b2g.client.DTicketShp
import com.ceair.b2g.client.vo.TaxInfo
import com.ceair.b2g.client.vo.TaxInfoDetail
import com.ceair.b2g.client.vo.order.input.AirItineraryInfo
import com.ceair.b2g.client.vo.order.input.AirOrderDocaInfo
import com.ceair.b2g.client.vo.order.input.AirOrderMain
import com.ceair.b2g.client.vo.order.input.AirOrderPaxInfo
import com.ceair.b2g.client.vo.order.input.AirOrderPriceInfo
import com.ceair.b2g.client.vo.order.input.AirOrderReq
import com.ceair.b2g.client.vo.order.input.AirSegInfo
import com.ceair.b2g.client.vo.order.output.AirOrderRes
import com.ceair.b2g.client.vo.shopping.input.AirOriDest
import com.ceair.b2g.client.vo.shopping.input.AirShoppingReq
import com.ceair.b2g.client.vo.shopping.output.AirShoppingRes
import com.ceair.b2g.client.vo.shopping.output.AirShoppingUnit
import com.ceair.b2g.client.vo.shopping.output.CabinInfo
import com.ceair.b2g.dto.pricing.FareInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IFlightPriceBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IMuB2GBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CBookingFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew.IMuB2GNewBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyTicketInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyVoyageInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.AirShoppingRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.CreateOrderRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.TicketBuyOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.AirportCityInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.FlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.ProductInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightSegIDParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightsBatchParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.ShareFlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.StopOverInfo
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import com.alibaba.dubbo.common.json.JSONObject
import com.better517na.muB2gService.EcfareInfoInput
import com.better517na.muB2gService.OrderInfo
import com.better517na.muB2gService.RtnEcfareInfo
import com.better517na.muB2gService.RtnOrderInfo
import com.better517na.muB2gService.RtnOrderStatusInfo
import com.better517na.muB2gService.SearchInfo
import com.better517na.muB2gService.SearchResponse
import com.better517na.muB2gService.StatusQueryInfo
import com.ceair.b2g.client.DTicketShp
import com.ceair.b2g.client.vo.TaxInfo
import com.ceair.b2g.client.vo.TaxInfoDetail
import com.ceair.b2g.client.vo.order.cancel.input.CancelOrderReq
import com.ceair.b2g.client.vo.order.cancel.output.CancelOrderRes
import com.ceair.b2g.client.vo.order.input.AirItineraryInfo
import com.ceair.b2g.client.vo.order.input.AirOrderDocaInfo
import com.ceair.b2g.client.vo.order.input.AirOrderMain
import com.ceair.b2g.client.vo.order.input.AirOrderPaxInfo
import com.ceair.b2g.client.vo.order.input.AirOrderPriceInfo
import com.ceair.b2g.client.vo.order.input.AirOrderReq
import com.ceair.b2g.client.vo.order.input.AirSegInfo
import com.ceair.b2g.client.vo.order.output.AirOrderRes
import com.ceair.b2g.client.vo.pricing.input.EcQueryReq
import com.ceair.b2g.client.vo.pricing.output.EcQueryRes
import com.ceair.b2g.client.vo.order.status.input.OrderStatusReq
import com.ceair.b2g.client.vo.order.status.output.OrderStatusRes
import com.ceair.b2g.client.vo.order.status.output.TktPax
import com.ceair.b2g.client.vo.pay.input.PayInfo
import com.ceair.b2g.client.vo.pay.output.PayResult
import com.ceair.b2g.client.vo.shopping.input.AirOriDest
import com.ceair.b2g.client.vo.shopping.input.AirShoppingReq
import com.ceair.b2g.client.vo.shopping.output.AirShoppingRes
import com.ceair.b2g.client.vo.shopping.output.AirShoppingUnit
import com.ceair.b2g.client.vo.shopping.output.CabinInfo
import com.ceair.b2g.client.vo.tax.input.OrderTaxReq
import com.ceair.b2g.client.vo.tax.output.OrderTaxRes
import com.ceair.b2g.dto.pricing.FareInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IFlightPriceBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CBookingFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew.IMuB2GNewBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyTicketInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo.BuyVoyageInfoBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.AirShoppingRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.CreateOrderRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutTicketingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.TicketBuyOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.AirportCityInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.FlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.ProductInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightSegIDParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightsBatchParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.ShareFlightInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.StopOverInfo

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import java.text.SimpleDateFormat
import org.springframework.stereotype.Component

import java.text.SimpleDateFormat

@Component('IMuB2GNewFlightPrice')
public class IMuB2GNewBusinessImpl implements IFlightPriceBusiness, IMuB2GNewBusiness{
    @Override
    QueryFlightResult searchFlightsBatch(QueryFlightRequest<QueryFlightsBatchParam> param, String url) {
        return null
    }

    @Override
    QueryFlightResult searchFlightsBySegId2(QueryFlightRequest<QueryFlightSegIDParam> request, String url) {
        return null
    }

    @Override
    QueryFlightResult searchFlightsOtaDay(QueryFlightRequest<QueryFlightParam> param, String url) {
        //参数转换；
        QueryFlightParam queryFlightParam = param.getQueryFlightParam();
        AirShoppingReq airShoppingReq = new AirShoppingReq();
        //大客户编号
        airShoppingReq.setKamno("9968940");
        //运价种类
        airShoppingReq.setFareType("D");
        //促销代码
        airShoppingReq.setPromoCode("");
        //航程种类
        airShoppingReq.setRouteType("OW");
        //航段信息
        AirOriDest airOriDest = new AirOriDest();
        //出发机场或城市三字码
        airOriDest.setDepartureCode(queryFlightParam.getDepAirport());
        //到达机场或城市三字码
        airOriDest.setArrivalCode(queryFlightParam.getArrAirport());
        //航班日期
        airOriDest.setDepartDate(queryFlightParam.getDepDate());
        //三字码类型（0:机场码 1:城市码）
        airOriDest.setCodeType("1");
        //航程序号
        airOriDest.setSegSq(1);
        //航程类型
        airOriDest.setSegTp("G");
        List<AirOriDest> list = new ArrayList<>();
        list.add(airOriDest);
        airShoppingReq.setAirOriDestList(list);

        DTicketShp dTicketShp = new DTicketShp();
        AirShoppingRes airShoppingRes = dTicketShp.shopping(airShoppingReq);
        //参数转换；
        QueryFlightResult queryFlightResult = new QueryFlightResult();

        if(!"".equals(airShoppingRes.getRtnErrMsg()) &&  !"".equals(airShoppingRes.getRtnErrId()) && null != airShoppingRes.getRtnErrMsg() && null != airShoppingRes.getRtnErrId()){
            queryFlightResult.setErrMsg("与东航交互错误代码为:"+airShoppingRes.getRtnErrId()+";错误信息为:"+airShoppingRes.getRtnErrMsg);
            return queryFlightResult;
        }
        List<FlightInfo> flightInfoList = new ArrayList<>();
        SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for(AirShoppingUnit airShoppingUnit: airShoppingRes.getAirShoppingUnitList()) {
            //不是直飞
            if(!airShoppingUnit.getIsDirect()){
                continue;
            }
            for (com.ceair.b2g.client.vo.shopping.output.FlightInfo flightInfo1 : airShoppingUnit.getFlightInfoList()) {
                FlightInfo flightInfo = new FlightInfo();
                //航段ID
                flightInfo.setSegmentID(flightInfo1.getSegSq().toString());
                //航司二字码
                flightInfo.setAirCode(flightInfo1.getFlightNo().substring(0, 2));
                //flightInfo.setAirCodeDesc("东方航空公司");
                //航班号
                flightInfo.setFlightNo(flightInfo1.getFlightNo());
                //起飞时间
                flightInfo.setTakeOffTime(sf2.format(sf1.parse(flightInfo1.getFltDateTime())));
                //到达时间
                flightInfo.setArriveTime(sf2.format(sf1.parse(flightInfo1.getArriDateTime())));
               /* //基建费
                flightInfo.setBuildFee("100");
                //燃油费
                flightInfo.setFuelFee("150");*/
                //飞机大小
                flightInfo.setAirPlaneSize("大飞机");
                //飞机型号
                flightInfo.setAirPlaneType(flightInfo1.getPlanetype());
                ShareFlightInfo shareFlightInfo = new ShareFlightInfo();
                if(flightInfo1.isCodeShare()){
                //共享航班实际航班号
                shareFlightInfo.setActureFlightNo(flightInfo1.carrFlightNo);
                }
                flightInfo.setShareFlightInfo(shareFlightInfo);
                AirportCityInfo depAirportCityInfo = new AirportCityInfo();
                //出发航站楼
                depAirportCityInfo.setTerminal(flightInfo1.getDepTerm());
                //出发机场三字码
                depAirportCityInfo.setAirportCode(flightInfo1.getOrgCode());
                flightInfo.setDepAirportCityInfo(depAirportCityInfo);
                AirportCityInfo arrAirportCityInfo = new AirportCityInfo();
                //到达航站楼
                arrAirportCityInfo.setTerminal(flightInfo1.getArriTerm());
                //到达机场三字码
                arrAirportCityInfo.setAirportCode(flightInfo1.getDestCode());
                StopOverInfo stopOverInfo = new StopOverInfo();
                List<StopOverInfo> stopOverInfoList = new ArrayList<>();
                for (int i=0;i<flightInfo1.getStop();i++){
                    stopOverInfo.setSegID(Integer.valueOf(i+1));
                    stopOverInfoList.add(stopOverInfo);
                }
                flightInfo.setStopOverInfos(stopOverInfoList);
                flightInfo.setArrAirportCityInfo(arrAirportCityInfo);
                List<config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.CabinInfo> cabinfoList = new ArrayList<>();
                for (CabinInfo cabinInfo : flightInfo1.getCabins()) {
                    config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.CabinInfo cabinInfo1 = new config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.CabinInfo();
                    //舱位代码
                    cabinInfo1.setCabinCode(cabinInfo.getCabinCode());
                    //舱位类型(0经济舱，1公务舱，2头等舱)
                    if("F".equals(cabinInfo.getBasecabinCode())){
                        cabinInfo1.setCabinType(2);
                        cabinInfo1.setCabinName("头等舱");
                    }else if ("J".equals(cabinInfo.getBasecabinCode())){
                        cabinInfo1.setCabinType(1);
                        cabinInfo1.setCabinName("公务舱");
                    }else{
                        cabinInfo1.setCabinType(0);
                        cabinInfo1.setCabinName("经济舱");
                    }
                    //cabinInfo1.setCabinType(Integer.valueOf(cabinInfo.getBasecabinCode()));
                    //剩余座位数

                    if(!"A".equals(cabinInfo.getCount())){
                        cabinInfo1.setRemSeatNum(Integer.valueOf(cabinInfo.getCount()));
                    }else{
                        cabinInfo1.setRemSeatNum(9);
                    }

                    for (com.ceair.b2g.client.vo.shopping.output.FareInfo fareInfo : airShoppingUnit.getFareInfoList()) {
                        if (fareInfo.getCabinCode().equals(cabinInfo.getCabinCode()) && fareInfo.getFlightNos().equals(flightInfo1.getFlightNo())) {
                            if (0.equals(Integer.parseInt(fareInfo.getPrice()))|| null == fareInfo.getPrice() || 0.equals(Integer.parseInt(fareInfo.getFdPrice()))
                                    || null == fareInfo.getFdPrice()) {
                                //航司折扣
                                cabinInfo1.setCarrierDiscount(0);
                            } else {
                                Integer Price = Integer.parseInt(fareInfo.getPrice());
                                Integer FdPrice = Integer.parseInt(fareInfo.getFdPrice());
                                int CarrierDiscount = (Price.intValue() * 100 / FdPrice.intValue()).intValue();
                                //航司折扣
                                cabinInfo1.setCarrierDiscount(Integer.valueOf(CarrierDiscount));
                            }
                            if("ADT".equals(fareInfo.getPaxTp())){
                                //舱位价格
                                cabinInfo1.setCabinPrice(new BigDecimal(fareInfo.getPrice()));
                                //折前票价
                                cabinInfo1.setFdPrice(new BigDecimal(fareInfo.getFdPrice()));
                                //促销价
                                cabinInfo1.setFareDescription(fareInfo.getFareDescription());
                                //行李额
                                cabinInfo1.setBaggageWeight(fareInfo.getBaggageWeight());
                                //TC 项
                                cabinInfo1.setTourCode(fareInfo.getTourCode());
                                //退改规定
                                cabinInfo1.setComment(fareInfo.getComment());
                                //EI 项
                                cabinInfo1.setEi(fareInfo.getEi());
                                //rule 规则 ID
                                cabinInfo1.setRuleId(fareInfo.getRuleId());
                                cabinInfo1.setFareBasis(fareInfo.getFareBasis());
                                for(TaxInfo taxInfo : fareInfo.getTaxInfoList())
                                    for(TaxInfoDetail taxInfoDetail : taxInfo.getTaxInfoDetailList()){
                                        if("CN".equals(taxInfoDetail.getTaxCode())){
                                            //基建费
                                            flightInfo.setBuildFee(taxInfoDetail.getTaxAmout().toString());
                                            flightInfo.setFuelFee("0");
                                        }else if("YQ".equals(taxInfoDetail.getTaxCode())){
                                            //燃油费
                                            flightInfo.setFuelFee(taxInfoDetail.getTaxAmout().toString());
                                            flightInfo.setBuildFee("0");
                                        }
                                    }
                            }
                            List<ProductInfo> productInfoList = new ArrayList<>();
                            ProductInfo productInfo = new ProductInfo();
                            //产品类型
                            productInfo.setProductType(1);
                            //产品销售价
                            productInfo.setProductSalePrice(new BigDecimal(fareInfo.getPrice()));
                            productInfoList.add(productInfo);
                            cabinInfo1.setProductInfos(productInfoList);
                        }
                    }

                    cabinfoList.add(cabinInfo1);
                }
                flightInfo.setCabinInfos(cabinfoList);
                flightInfoList.add(flightInfo)
            }
        }
        queryFlightResult.setFlightInfos(flightInfoList);
        return queryFlightResult;

    }



    @Override
    public AirOrderRes creatOrder(AirOrderReq airOrderReq) {
        DTicketShp dTicketShp = new DTicketShp();
        AirOrderRes airOrderRes = dTicketShp.createOrder(airOrderReq);
        return airOrderRes;
    }


    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;


    @Override
    OrderTaxRes orderTax(OrderTaxReq req) {
        DTicketShp client = new DTicketShp();
        OrderTaxRes res = client.orderTax(req);
        return res;
    }

    @Override
    EcQueryRes ecFareQuery(EcQueryReq req) {
        DTicketShp client = new DTicketShp();
        EcQueryRes res = client.ecFareQuery(req);
        return res;

    }


    @Override
    ResponseVo<CreateOrderRes> creatOrder(RequestVo<TicketBuyOrderInfoVo> requestVo) {
        return null
    }

    /**
     * 支付并出票
     * @param requestVo
     * @return
     */
    @Override
    PayResult ticketing(PayInfo  info ) {
        PayResult pay = new PayResult();
        DTicketShp shp = new DTicketShp();
        if('11'.equals(info.getPaytype())||'12'.equals(info.getPaytype())||'42'.equals(info.getPaytype())||
                '28'.equals(info.getPaytype())||'36'.equals(info.getPaytype())
        ){
            //网关支付
            String payurl = shp.gateWayPay(info);
        }else if('31'.equals(info.getPaytype())||'43'.equals(info.getPaytype())){
            //代扣支付
            pay = shp.daikouPay(info);;
            if(StringUtil.isNullOrEmpty(pay.getRtnErrMsg())){
                pay.setRtnErrId('0000');//代扣支付成功
            }
        }else if('40'.equals(info.getPaytype())){
            //商务卡支付
            pay = shp.swkPay(info);
            if(StringUtil.isNullOrEmpty(pay.getRtnErrMsg())) {
                pay.setRtnErrId('333333');//商务卡支付成功
            }
        }
        return pay;
    }

/**
 * 查询订单信息
 * @param info
 * @return
 */
    @Override
    public OrderStatusRes queryOrderDetail(OrderStatusReq info){
        DTicketShp client = new DTicketShp();
        OrderStatusRes result = client.getOrderStatus(info);
        return result;
    }

    /**
     * 取消订单
     * @param requestVo
     * @return
     */
    @Override
    public CancelOrderRes cancelOrder(CancelOrderReq req) {
        DTicketShp shp = new DTicketShp();
        CancelOrderRes res = shp.cancelOrder(req);
        return res;
    }
}
