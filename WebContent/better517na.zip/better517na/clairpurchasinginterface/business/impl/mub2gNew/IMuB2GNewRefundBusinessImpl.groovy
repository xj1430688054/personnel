package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2gNew

import com.ceair.b2g.client.DTicketShp
import com.ceair.b2g.client.vo.refund.apply.input.RefundApplyTicketReq
import com.ceair.b2g.client.vo.refund.apply.output.RefundApplyTicketRes
import com.ceair.b2g.client.vo.refund.input.RefundApplyInfoSearchReq
import com.ceair.b2g.client.vo.refund.input.RefundTicketReq
import com.ceair.b2g.client.vo.refund.output.RefundApplyInfoSearchRes
import com.ceair.b2g.client.vo.refund.output.RefundTicketRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.mub2gNew.IMuB2GNewRefundBusiness
import org.springframework.stereotype.Component

@Component
public class IMuB2GNewRefundBusinessImpl implements IMuB2GNewRefundBusiness{

    @Override
    RefundTicketRes ticketRefundCheck(RefundTicketReq refundTicketReq) {
        DTicketShp client = new DTicketShp();
        RefundTicketRes res = client.ticketRefundCheck(refundTicketReq);
        return res;
    }

    @Override
    RefundApplyTicketRes ticketRefundApply(RefundApplyTicketReq refundApplyTicketReq) {
        DTicketShp client = new DTicketShp();
        RefundApplyTicketRes res = client.ticketRefundApply(refundApplyTicketReq);
        return res;
    }

    @Override
    RefundApplyInfoSearchRes searchRefundApplyInfo(RefundApplyInfoSearchReq req) {
        DTicketShp client = new DTicketShp();
        RefundApplyInfoSearchRes  res = client.searchRefundApplyInfo(req);
        return res;
    }
}
