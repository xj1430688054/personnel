package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.niney

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney.INineYuanBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.NineYRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.create.CreateParamOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.orderdetail.OrderDetailOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.pay.PayParamOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InQueryOrderInfoVo
import org.apache.commons.lang.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class NineYuanBusinessImpl extends NineYuanBaseBusiness implements INineYuanBusiness{
    @Autowired
    private LogBusiness logBusiness

    @Override
    OrderDetailOut queryOrderDetail(NineYRequest request) {
        String url = this.dealUrl(request.getUrl())
        url +='getOrder/'
        //RESTful调用
        url += request.getData()
        this.setToken(request.getToken())
        this.setAccount(request.getAccount())
        String result = this.execute(url,'','aqAir','queryOrderDetail',logBusiness)
        ResponseVo<OrderDetailOut> orderDetailResponse = GsonUtil.getGson().fromJson(result, new TypeToken<ResponseVo<OrderDetailOut>>() {}.getType())
        if (orderDetailResponse != null && orderDetailResponse.getStatus() == 200 && orderDetailResponse.getData() != null) {
            //构造返回参数
            return orderDetailResponse.getData()
        }else {
            throw new Exception("查询订单异常")
        }
    }

    @Override
    CreateParamOut createOrder(NineYRequest request) {
        String url = this.dealUrl(request.getUrl())
        url += 'commitOrder'
        this.setToken(request.getToken())
        this.setAccount(request.getAccount())
        String result = this.execute(url, request.getData(), 'aqAir', 'createOrder', logBusiness)
        ResponseVo<CreateParamOut> responseVo = GsonUtil.getGson().fromJson(result, new TypeToken<ResponseVo<CreateParamOut>>() {}.getType())
        if (responseVo != null && responseVo.getStatus() == 200 && responseVo.getData() != null) {
            return responseVo.getData()
        }else {
            throw new Exception((responseVo != null && StringUtils.isNotEmpty(responseVo.getMsg())) ? responseVo.getMsg() : "创单异常")
        }
    }

    @Override
    PayParamOut payOrder(NineYRequest request) {
        String url = this.dealUrl(request.getUrl())
        url += 'yeepay-withhold-apply'
        this.setToken(request.getToken())
        this.setAccount(request.getAccount())
        String result = this.execute(url, request.getData(), 'aqAir', 'payOrder', logBusiness)
        ResponseVo<PayParamOut> responseVo = GsonUtil.getGson().fromJson(result, new TypeToken<ResponseVo<PayParamOut>>() {}.getType())
        if (responseVo != null && responseVo.getStatus() == 200 && responseVo.getData() != null) {
            return responseVo.getData()
        }else {
            throw new Exception((responseVo!= null && StringUtils.isNotEmpty(responseVo.getMsg()))?responseVo.getMsg():'支付失败')
        }
    }
}
