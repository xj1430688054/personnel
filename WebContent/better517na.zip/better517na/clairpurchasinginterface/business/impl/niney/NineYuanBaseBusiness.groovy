package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.niney

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.NineYRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.ResponseVo
import org.apache.commons.lang.StringUtils

class NineYuanBaseBusiness extends NineYuanHttpBaseBusiness{
    /**
     * doPost方法
     * @param url
     * @param request
     * @param module
     * @param subModule
     * @param logBusiness
     * @return
     */
    String execute(String url, String request, String module, String subModule,LogBusiness logBusiness){
        this.setLogBusiness(logBusiness);
        this.doPost(url,request,module,subModule)
    }

    protected String dealUrl(String url) {
        if (StringUtils.isNotBlank(url)) {
            if (!url.endsWith('/')) {
                url += '/'
            }
        }
        return url
    }


}
