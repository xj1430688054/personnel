package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.niney

import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney.INineYuanRefundBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.ApplyRefundInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.ApplyRefundResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.CalRefundRateInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.CalRefundResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.ApplyRefundOutVo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class NineYuanRefundBusinessImpl extends NineYuanBaseBusiness implements INineYuanRefundBusiness{
    @Autowired
    private LogBusiness logBusiness

    /**
     * 计算退票手续费
     * @param calRefundRateInVo 参数
     * @return 结果
     */
    @Override
    CalRefundResultVo calRefundTicketRate(CalRefundRateInVo calRefundRateInVo, String url, String account, String token) {
        CalRefundResultVo resultVo = null;
        String params = GsonUtil.getGson().toJson(calRefundRateInVo);
        this.setAccount(account);
        this.setToken(token);
        String result = this.execute(url,params,"aqAir","calRefundTicketRate",logBusiness)
        if (!StringUtil.isStringParamNotLegal(result)) {
            TypeToken<ResponseVo<CalRefundResultVo>> typeToken = new TypeToken<ResponseVo<CalRefundResultVo>>() {
            };
            ResponseVo<CalRefundResultVo> responseVo =  GsonUtil.getGson().fromJson(result, typeToken.getType());
            if (responseVo!= null && responseVo.getMsg().contains('result.ok') && responseVo.getData()!= null) {
                resultVo = responseVo.getData();
            }
        }
        return resultVo
    }

    /**
     * 申请退票.
     * @param applyRefundInVo 参数.
     * @return 结果.
     */
    @Override
    ApplyRefundResultVo applyTicketRefund(ApplyRefundInVo applyRefundInVo, String url, String account, String token) {
        ApplyRefundResultVo resultVo = null
        String params = GsonUtil.getGson().toJson(applyRefundInVo);
        this.setAccount(account);
        this.setToken(token);

        String result = this.execute(url,params,"aqAir","applyTicketRefund", logBusiness)
        if (!StringUtil.isStringParamNotLegal(result)) {
            TypeToken<ResponseVo<ApplyRefundResultVo>> typeToken = new TypeToken<ResponseVo<ApplyRefundResultVo>>() {
            };
            ResponseVo<ApplyRefundResultVo> responseVo =  GsonUtil.getGson().fromJson(result, typeToken.getType());
            if (responseVo!= null && responseVo.getMsg().contains('result.ok') && responseVo.getData()!= null) {
                resultVo = responseVo.getData();
            }
        }
        return resultVo
    }
}
