package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.niney

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney.INineYuanBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney.INineYuanChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.NineYRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.change.ChangeApplyOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.change.ChangeQueryOut
import org.apache.commons.lang.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class NineYuanChangeBusinessImpl extends NineYuanBaseBusiness implements INineYuanChangeBusiness {

    @Autowired
    private LogBusiness logBusiness


    @Override
    ChangeQueryOut queryChangeFlight(NineYRequest request) {
        String url = this.dealUrl(request.getUrl())
        url +='reschedualFlightQuery'
        url += request.getData()
        this.setToken(request.getToken())
        this.setAccount(request.getAccount())
        String result = this.execute(url,request.getData(),'aqAir','queryChangeFlight',logBusiness)
        ResponseVo<ChangeQueryOut> responseVo = GsonUtil.getGson().fromJson(result, new TypeToken<ResponseVo<ChangeQueryOut>>(){}.getType())
        if (responseVo != null && responseVo.getStatus() == 200 && responseVo.getData() != null) {
            return responseVo.getData()
        }else {
            throw new Exception((responseVo!= null && StringUtils.isNotEmpty(responseVo.getMsg()))?responseVo.getMsg():'九元航空改签航班查询异常')
        }
    }

    @Override
    ChangeApplyOut changeApply(NineYRequest request) {
        String url = this.dealUrl(request.getUrl())
        url +='commitReschedual?language=zh_CN'
        this.setToken(request.getToken())
        this.setAccount(request.getAccount())
        String result = this.execute(url,request.getData(),'aqAir','changeApply',logBusiness)
        ResponseVo<ChangeApplyOut> responseVo = GsonUtil.getGson().fromJson(result, new TypeToken<ResponseVo<ChangeApplyOut>>(){}.getType())
        if (responseVo != null && responseVo.getStatus() == 200 && responseVo.getData() != null && StringUtils.isNotEmpty(responseVo.getData().getOrderNo())) {
            return responseVo.getData()
        }else {
            throw new Exception((responseVo!= null && StringUtils.isNotEmpty(responseVo.getMsg()))?responseVo.getMsg():'九元航空改签申请异常')
        }
    }
}
