package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.niney

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.HttpBaseBusiness
import org.apache.commons.lang.StringUtils
import org.apache.http.HttpEntity
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.impl.client.HttpClientBuilder
import org.apache.http.util.EntityUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

class NineYuanHttpBaseBusiness extends HttpBaseBusiness{

    private String account;
    private String token;String getAccount() {
        return account
    }

    void setAccount(String account) {
        this.account = account
    }

    String getToken() {
        return token
    }

    void setToken(String token) {
        this.token = token
    }

    String doPost(String url, String params, String contentType, String module, String subModule){
        long totalTime = 0;
        String result = '';
        if (StringUtils.isBlank(url)) {
            return result;
        }
        CloseableHttpResponse httpResponse = null;
        try {
            System.out.print("请求地址：");
            System.out.println(url);
            System.out.print("请求参数：");
            System.out.println(params);
            StringEntity se = new StringEntity(params, 'UTF-8');
            if (params != null && params.length() > 0) {
                se.setContentEncoding('UTF-8');
                se.setContentType(contentType);
            }

            long begin = System.currentTimeMillis();

            HttpPost httpPost = new HttpPost(url);
            httpPost.setHeader('Content-Type', contentType + ';charset=UTF-8');
            httpPost.setHeader('Agent-Account', this.getAccount());
            httpPost.setHeader('TOKEN', this.getToken());
            httpPost.setHeader('Accept-Language', 'zh-CN');
            if (se != null && se.getContentLength() > 0) {
                httpPost.setEntity(se);
            }
            httpResponse = HTTP_CLIENT.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, 'utf-8');
            }
            if (statusCode != 200) {
                httpPost.abort();
                throw new RuntimeException('HttpClient,error status code :' + statusCode +' ErrorMessage:'+ result);
            }
            EntityUtils.consume(entity);
            httpResponse.close();
            totalTime = System.currentTimeMillis() - begin;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'HTTP请求异常', e.getMessage(), e));
        } finally {
            writeInteractionLog(module, subModule, url, params, result, String.valueOf(totalTime));
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }
}
