package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.guangfa

import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IGuangFaBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.HttpBaseBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.GuangFaShoppingVo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component(value = "guangFaBusiness")
public class GuangFaBusinessImpl extends HttpBaseBusiness implements IGuangFaBusiness {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusinessLocal;

    /**
     * 运价（广发）
     * @param requestVo
     * @return
     */
    @Override
    String guangfaQueryFlight(GuangFaShoppingVo guangFaShoppingVo) {
        this.setLogBusiness(this.logBusinessLocal);
        String params = String.format("fromcity=%s&tocity=%s&date=%s&avNeed=%s&psnNeed=%s&psAvBind=%s&isPsDateBindsNeeded=%s&faresNeed=%s&isRefundReissueRuleNeeded=%s&isRefundReissueTextRuleNeeded=%s&NotOpenedClassNeeded=%s&IsSpecificClassAllPriceZvalueNeeded=%s&isCompressedResultNeeded=%s&RuleTypeNeeded=%s&Format=%s&LowestOrAll=%s&FareSource=%s&isZKeyNeeded=%s&isJourneyModel=%s&JourneyType=%s", guangFaShoppingVo.getFromcity(), guangFaShoppingVo.getTocity(),
                guangFaShoppingVo.getDate(), guangFaShoppingVo.getAvNeed(), guangFaShoppingVo.getPsnNeed(), guangFaShoppingVo.getPsAvBind(), guangFaShoppingVo.getIsPsDateBindsNeeded(), guangFaShoppingVo.getFaresNeed(), guangFaShoppingVo.getIsRefundReissueRuleNeeded(), guangFaShoppingVo.getIsRefundReissueTextRuleNeeded(), guangFaShoppingVo.getNotOpenedClassNeeded(), guangFaShoppingVo.getIsSpecificClassAllPriceZvalueNeeded(), guangFaShoppingVo.getIsCompressedResultNeeded(),
                guangFaShoppingVo.getRuleTypeNeeded(), guangFaShoppingVo.getFormat(), guangFaShoppingVo.getLowestOrAll(), guangFaShoppingVo.getFareSource(), guangFaShoppingVo.getIsZKeyNeeded(), guangFaShoppingVo.getIsJourneyModel(), guangFaShoppingVo.getJourneyType());
        return this.doGet(guangFaShoppingVo.getUrl(), params, "广发接口", "运价查询", "gb2312");

    }
}
