package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.model.InterfaceInfo
import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.TicketStatus
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusArgs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusRes
import org.apache.commons.lang.StringUtils
import org.apache.commons.lang3.EnumUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import java.util.regex.Matcher
import java.util.regex.Pattern

/**
 * 接口方式提取票号  https
 */
@Component
public class TicketNoECBusiness extends HttpBaseBusiness {


    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusinessLocal;

    public ExtractTicketNoStatusRes extractTicketNoStatus(ExtractTicketNoStatusArgs args, InterfaceInfo interfaceInfo) {
        ExtractTicketNoStatusRes response = new ExtractTicketNoStatusRes();
        response.setTicketNo(args.getTicketNo());
        // 格式如下：
        // http://api.fly517.com:889/PidServiceDetr.asmx/Detr?UserAct=517NA&UserPwd=12345a&UserKey=12345a&InstructionType=TN&InstructionValue=784-2936691847
        String param = "UserAct=" + interfaceInfo.getAccount() + "&UserPwd=" + StringUtils.split(interfaceInfo.getPassword(), "|")[0] +
                "&UserKey=" + StringUtils.split(interfaceInfo.getPassword(), "|")[1] + "&InstructionType=TN&InstructionValue=" + args.getTicketNo();
        this.setLogBusiness(this.logBusinessLocal);
        String ticketNoStatusOriginStr = super.doGet(interfaceInfo.getInterfaceUrl(), param, "提取票号状态", "EC接口提取票号状态", "gb2312");
        if (StringUtils.isEmpty(ticketNoStatusOriginStr)) {
            response.setSuccess(false);
        } else {
            String ticketNoStatusStr = this.getTicketNoStatusStr(ticketNoStatusOriginStr);
            if (StringUtils.isEmpty(ticketNoStatusStr)) {
                response.setSuccess(false);
            } else {
                String ticketNoStatus = this.getTicketNoStatus(ticketNoStatusOriginStr);
                if (StringUtils.isEmpty(ticketNoStatus)) {
                    response.setSuccess(false);
                } else {
                    response.setSuccess(true);
                    response.setOriginInfo(ticketNoStatusStr);
                    response.setTicketNoStatus(ticketNoStatus);
                    //做价格
                    this.fullPrice(response);
                }
            }
        }
        return response;
    }

    /**
     * 解析字符串中三个价格
     * @param no
     */
    private static void fullPrice(ExtractTicketNoStatusRes no) {
        Pattern pattern1 = Pattern.compile("(TAX).*?CNY\\s+(?<Value>\\d{1,8}\\.\\d{2})CN");
        Matcher matcher1 = pattern1.matcher(no.getOriginInfo());
        Pattern pattern2 = Pattern.compile("(TAX).*?CNY\\s+(?<Value>\\d{1,8}\\.\\d{2})YQ");
        Matcher matcher2 = pattern2.matcher(no.getOriginInfo());
        Pattern pattern3 = Pattern.compile("(票价|FARE).*?CNY.*?(?<Value>\\d{1,8}\\.\\d{2})");
        Matcher matcher3 = pattern3.matcher(no.getOriginInfo());
        String buildPrice = "";
        String oilPrice = "";
        String facePrice = "";
        if (matcher1.find()) {
            buildPrice = matcher1.group("Value");
        }
        if (matcher2.find()) {
            oilPrice = matcher2.group("Value");
        }
        if (matcher3.find()) {
            facePrice = matcher3.group("Value");
        }
        no.setSellAirrax(new BigDecimal(StringUtils.isEmpty(buildPrice) ? "0" : buildPrice));
        no.setSellOilrax(new BigDecimal(StringUtils.isEmpty(oilPrice) ? "0" : oilPrice));
        no.setTicketPrice(new BigDecimal(StringUtils.isEmpty(facePrice) ? "0" : facePrice));
    }

    /**
     * 匹配出价格
     * @param reg 正则表达式
     * @param str 匹配字符串
     * @return
     */
    private BigDecimal getPrice(String reg, String str) {
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(str);
        String statePrice = "";
        if (matcher.find()) {
            statePrice = matcher.group("Value");
        }
        return new BigDecimal(StringUtils.isEmpty(statePrice) ? "0" : statePrice);
    }

    /**
     * 票号提取出来的原始字符串
     * @param str
     * @return
     */
    private String getTicketNoStatusStr(String str) {
        String regex = "<string.*?>(?<info>(.|\\s)*?)</string>";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            return matcher.group("info")
        } else {
            return "";
        }
    }

    /**
     * 票号状态  返回如：UNKNOWN/OPEN_FOR_USE,  CHECKED_IN
     * @param str
     * @return
     */
    private String getTicketNoStatus(String str) {
        List<String> stateList = new ArrayList<>();
        String regex = "[^\\r\\n]+\\s+(?:\\w{1,2}L|\\d+KG?|\\d+PC)\\s+(?<state>[A-Z_/ ]+?)(?=\\r|\\n|\\\\|(\\s{2,}))";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        String stateStr = "";
        while (matcher.find()) {
            stateStr = matcher.group("state");
            if (StringUtils.isNotEmpty(stateStr))
                stateList.add(formatTicketNoStatus(stateStr));
        }
        // 有可能没有公斤数，前面的正则就定位不到票号状态，这里来遍历所有状态获取一次。
        if (stateList.isEmpty()) {
            String regMU = "(FM:(?<FROM>[A-Z]{3})\\s+TO:?\\s+(?<TO>[A-Z]{3})\\s+(?<AIR>[A-Z]\\d|\\d[A-Z]|[A-Z]{2})\\s*(?<HB>(\\d{2,5}\\w?)|OPEN)\\s+(?<CW>\\w{1,2})\\s+(?:((?<OFFDAY>\\d{2}[A-Z]{3})\\s*(?<OFFTIME>\\d{4}))|OPEN))+";
            String regEU = "((?<=\\d(?<FROM>[A-Z]{3})\\s+)(?<SHARE>[A-Z]\\d|\\d[A-Z]|[A-Z]{2})?\\s*(?<AIR>[A-Z]\\d|\\d[A-Z]|[A-Z]{2})\\s*(?<HB>\\d{2,5}\\w?|OPEN)\\s+(?<CW>\\w{1,2})\\s+(?:((?<OFFDAY>\\d{2}[A-Z]{3})\\s*(?<OFFTIME>\\d{4}))|OPEN)(.|\\n)*?TO:?\\d?\\s*(?<TO>[A-Z]{3})\\s)+";
            Pattern patternMu = Pattern.compile(regMU);
            Pattern patternEu = Pattern.compile(regEU);
            Matcher matcherMat = patternMu.matcher(str);
            if (!matcherMat.find()) {
                matcherMat = patternEu.matcher(str);
            }
            if (matcherMat.find()) {
                String regState = "OPEN FOR USE|VOID|REFUNDED|USED FLOWN|SUSPENDED|CHECKED IN|LIFT BOARDED|EXCHANGED|FIM EXCH|CPN NOTE";
                Pattern patternState = Pattern.compile(regState);
                Matcher matcherState = patternState.matcher(matcherMat.group());
                while (matcherState.find()) {
                    stateStr = matcherState.group();
                    if (StringUtils.isNotEmpty(stateStr))
                        stateList.add(formatTicketNoStatus(stateStr));
                }
            }
        }
        if (stateList.isEmpty()) {
            return "";
        } else {
            String status = "";
            for (String stat : stateList) {
                status = status + stat + "/";
            }
            return StringUtils.substring(status, 0, status.length() - 1);
        }
    }

    /**
     * 格式化票号
     * @param statusStr
     * @return
     */
    private String formatTicketNoStatus(String statusStr) {
        statusStr = statusStr.replace(" ", "_").replace("/", "_").toUpperCase();
        if (EnumUtils.isValidEnum(TicketStatus.class, statusStr)) {
            return statusStr;
        } else {
            switch (statusStr) {
                case "OPEN":
                    statusStr = "OPEN_FOR_USE";
                    break;
                case "FLOW":
                    statusStr = "USED_FLOWN";
                    break;
                case "CHEK":
                    statusStr = "CHECKED_IN";
                    break;
                default:
                    statusStr = "None";
                    break;
            }
            return statusStr;
        }
    }
}
