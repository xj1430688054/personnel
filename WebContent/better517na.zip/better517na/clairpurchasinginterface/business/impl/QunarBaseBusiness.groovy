package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.utils.SignUtils
import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request
import org.apache.http.HttpResponse
import org.apache.http.NameValuePair
import org.apache.http.client.HttpClient
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.HttpPost
import org.apache.http.impl.client.HttpClients
import org.apache.http.message.BasicNameValuePair
import org.apache.http.util.EntityUtils
import org.springframework.beans.factory.annotation.Autowired

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/22
 * Time: 17:42
 */
public class QunarBaseBusiness extends HttpBaseBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusinessLocal;

    /**
     * 请求.
     *
     * @param request request.
     * @param key key.
     * @param url url.
     * @return 响应.
     */
    public String execute(Request<?> request, String key, String url) {
        this.setLogBusiness(this.logBusinessLocal);
        String res = '';
        request.setSign(signRequest(request, key));
        String params = GsonUtil.getGson().toJson(request);
        res = this.doPost(url, request, '去哪儿机票接口', request.getTag());
        return res;
    }

    public String doPost(String url, Request<?> request, String module, String subModule) {
        this.setLogBusiness(this.logBusinessLocal);
        HttpPost httpPost = null;
        String resultJson = null;
        HttpResponse httpResponse = null;
        long totalTime = 0;
        List<NameValuePair> postData = new ArrayList<>();
        try {
            postData.add(new BasicNameValuePair('sign', request.getSign()));
            postData.add(new BasicNameValuePair('tag', request.getTag()));
            postData.add(new BasicNameValuePair('token', request.getToken()));
            postData.add(new BasicNameValuePair('createTime', String.valueOf(request.getCreateTime())));
            postData.add(new BasicNameValuePair('params', GsonUtil.getGson().toJson(request.getParams())));
            UrlEncodedFormEntity uefEntity = new UrlEncodedFormEntity(postData, 'UTF-8');
            httpPost = new HttpPost(url);
            httpPost.setEntity(uefEntity);

            long begin = System.currentTimeMillis();
            HttpClient httpsClient = HttpClients.createDefault();
            httpResponse = httpsClient.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode != 200) {
                httpPost.abort();
                throw new RuntimeException('HttpClient,error status code :' + statusCode);
            }
            //httpResponse = new Worker(ret, httpsClient).call();
            resultJson = EntityUtils.toString(httpResponse.getEntity());
            EntityUtils.consume(uefEntity);
            httpResponse.close();
            totalTime = System.currentTimeMillis() - begin;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'HTTP请求异常', e.getMessage(), e));
        } finally {
            writeInteractionLog(module, subModule, url, GsonUtil.getGson().toJson(postData), resultJson, String.valueOf(totalTime));
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return resultJson;
    }

    /**
     * 签名.
     *
     * @param request 请求对象.
     * @param key key.
     * @return 验签结果.
     */
    public String signRequest(Request<?> request, String key) {
        String sign = '';
        try {
            String params = null;
            if (request.getParams() != null) {
                params = GsonUtil.getGson().toJson(request.getParams());
            }

            Map<String, String> map = new HashMap<>();
            map.put('createTime', String.valueOf(request.getCreateTime()));
            map.put('key', key);
            map.put('params', params);
            map.put('tag', request.getTag());
            map.put('token', request.getToken());
            sign = SignUtils.signQunar(map);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '生成签名异常', e.getMessage(), e));
        }

        return sign;
    }
}
