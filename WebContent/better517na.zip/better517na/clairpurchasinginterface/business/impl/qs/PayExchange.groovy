package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.qs

import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qs.MNoPassPayArgs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qs.MNoPassPayResult
import org.apache.commons.codec.binary.Base64
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets
import java.security.MessageDigest

@Component
public class PayExchange {
    private String urlStr = "";

    public String getUrlStr() {
        return this.urlStr;
    }

    public void setUrlStr(String urlStr) {
        this.urlStr = urlStr;
    }

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    public MNoPassPayResult NoPassPayNew(MNoPassPayArgs args) {
        MNoPassPayResult noPassResult = new MNoPassPayResult();
        String requestPara = GetNoPassPayJsonNew(args);
        String strResponse = this.doPost(args.getPayInterfaceUrl(), requestPara, "收银台交互", "川航B2G支付");
        if (!StringUtil.isStringParamNotLegal(strResponse)) {
            byte[] buffer = Base64.decodeBase64(strResponse);
            strResponse = new String(buffer, StandardCharsets.UTF_8);
            noPassResult = new Gson().fromJson(strResponse, MNoPassPayResult.class);
        }

        return noPassResult;
    }

    private String doPost(String url, String postData, String module, String subModule) {
//        this.setLogBusiness(this.logBusinessLocal);
        HttpPost httpPost = null;
        String resultJson = null;
        HttpResponse httpResponse = null;
        long totalTime = 0;
        try {
//            UrlEncodedFormEntity uefEntity = new UrlEncodedFormEntity(postData, 'UTF-8');
            StringEntity stringEntity = new StringEntity(postData);
            httpPost = new HttpPost(url);
            httpPost.setEntity(stringEntity);

            long begin = System.currentTimeMillis();
            HttpClient httpsClient = HttpClients.createDefault();
            httpResponse = httpsClient.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode != 200) {
                httpPost.abort();
                throw new RuntimeException('HttpClient,error status code :' + statusCode);
            }

            resultJson = EntityUtils.toString(httpResponse.getEntity());
            EntityUtils.consume(stringEntity);
            httpResponse.close();
            totalTime = System.currentTimeMillis() - begin;
        } catch (Exception e) {
            e.printStackTrace();
            //logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'HTTP请求异常', e.getMessage(), e));
        } finally {
            writeInteractionLog(module, subModule, url, GsonUtil.getGson().toJson(postData), resultJson, String.valueOf(totalTime));
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return resultJson;
    }

/**
 * 设置logBusiness.
 *
 * @param logBusiness 赋值logBusiness
 */
    private void setLogBusiness(LogBusiness logBusiness) {
        this.logBusiness = logBusiness;
    }

    private String GetNoPassPayJsonNew(MNoPassPayArgs args) {
        List<String> busiData = new ArrayList<>();

        busiData.add(String.format("business_id=%s", args.getPid()));
        busiData.add(String.format("pay_type_id=%s", args.getPayTypeID()));
        busiData.add(String.format("sub_business_type=%s", args.getSubBusinessType()));
        busiData.add(String.format("buyer_id=%s", args.getBuyerID()));
        busiData.add(String.format("notify_url=%s", args.getNotifyUrl()));
        busiData.add(String.format("out_trade_no=%s", args.getOrderID()));
        busiData.add(String.format("subject=%s", args.getSubject()));
        busiData.add(String.format("remark=%s", args.getRemark()));
        busiData.add(String.format("total_fee=%s", args.getPayFee()));
        busiData.add(String.format("auto_excute=%s", args.getAutoExecute()));
        busiData.add(String.format("third_pay_account=%s", args.getThirdPayAccount()));
        if (args.getThirdPayInterface() != 0) {
            busiData.add(String.format("third_pay_interface=%s", args.getThirdPayInterface()));
        }

        busiData.add(String.format("balance_type=%s", args.getBalanceType()));
        busiData.add(String.format("receive_id=%s", args.getReceiveID()));
        busiData.add(String.format("dut_param=%s", args.getDutParam()));
        return GetCommonJson("no_pass_pay", args.getClientType(), args.getSecurityCode(), busiData, args.getDutParam());
    }

    private String GetCommonJson(String action, int clientType, String securityCode, List<String> busiData, String dutParam) {
        StringBuilder strJson = new StringBuilder();
        strJson.append("{\"v\":\"1.0\",");
        strJson.append("\"a\":\"" + action + "\",");
        strJson.append("\"at\":\"" + clientType + "\",");
        strJson.append("\"d\":{");
        for (int i = 0; i < busiData.size(); i++) {
            String[] strData = busiData[i].split('=');
            if (strData.size() < 2) {
                if (strData[0] == "dut_param") {
                    strJson.append("\"" + strData[0] + "\":\"" + dutParam + "\"");
                } else {
                    if (i < busiData.size() - 1) {
                        strJson.append("\"" + strData[0] + "\":\"" + "\",");
                    } else {
                        strJson.append("\"" + strData[0] + "\":\"" + "\"");
                    }
                }
            } else {
                if (strData[0] == "dut_param") {
                    strJson.append("\"" + strData[0] + "\":\"" + dutParam + "\"");
                } else {
                    if (i < busiData.size() - 1) {
                        strJson.append("\"" + strData[0] + "\":\"" + strData[1] + "\",");
                    } else {
                        strJson.append("\"" + strData[0] + "\":\"" + strData[1] + "\"");
                    }
                }
            }
        }

        strJson.append("},");

        //strJson.append("\"sign\":\"%s\",",GetSign(securityCode, busiData, dutParam));
        strJson.append("\"sign\":\"" + GetSign(securityCode, busiData, dutParam) + "\",");
        strJson.append("\"sign_type\":\"MD5\"}");

        byte[] buffer = strJson.toString().getBytes(StandardCharsets.UTF_8);
        this.urlStr = strJson.toString();

        return Base64.encodeBase64String(buffer);
    }

    private String GetSign(String securityCode, List<String> busiData, String dutParam) {
        ////先转成字典
        Map<String, Object> data = new HashMap<>();
        for (int i = 0; i < busiData.size(); i++) {
            String value = "";
            String key = busiData.get(i).split('=')[0];
            if (key == "dut_param") {
                value = dutParam;
            } else {
                if (busiData.get(i).split('=').size() > 1) {
                    value = busiData.get(i).split('=')[1];
                }
            }
            data.put(key, value);
        }

        Set<String> keySet = data.keySet();
        List<String> keys = new ArrayList<>(keySet);
        keys.sort();
        StringBuilder str = new StringBuilder();
        for (String key : keys) {
            str.append(key + "=" + data[key] + "&");
        }

        if (str.length() != 0) {
            str.deleteCharAt(str.length() - 1);
        }

        String sign = this.GetMD5(str.toString() + securityCode);
        return sign;
    }

    private String GetMD5(String inputString) {
        try {
            // 得到一个信息摘要器
            MessageDigest digest = MessageDigest.getInstance("md5");
            byte[] result = digest.digest(inputString.getBytes());
            StringBuffer buffer = new StringBuffer();
            // 把每一个byte 做一个与运算 0xff;
            for (byte b : result) {
                // 与运算
                int number = b & 0xff;// 加盐
                String str = Integer.toHexString(number);
                if (str.length() == 1) {
                    buffer.append("0");
                }
                buffer.append(str);
            }

            // 标准的md5加密后的结果
            return buffer.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

/**
 * 记录交互日志.
 *
 * @param module module.
 * @param subModule subModule.
 * @param url url.
 * @param request request.
 * @param response response.
 * @param totalTime totalTime.
 */
    protected void writeInteractionLog(String module, String subModule, String url, String request, String response, String totalTime) {
        try {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule(module);
            interactionParam.setKey1(subModule);
            interactionParam.setKey2(totalTime);
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(request);
            interactionParam.setReceiveContent(response);
            logBusiness.writeInteractionLog(interactionParam);
        } catch (Exception ex) {
            //logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '记录交互日志失败', ex.getMessage(), ex));
        }
    }

}
