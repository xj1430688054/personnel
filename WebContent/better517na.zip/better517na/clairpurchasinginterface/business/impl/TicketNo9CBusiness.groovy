package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.model.InterfaceInfo
import com.better517na.springAirSalesService.FlightBgAppHeadInfo
import com.better517na.springAirSalesService.GetOrderDetailInfoQueryBean
import com.better517na.springAirSalesService.GetOrderDetailInfoResultBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoInputBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoResultBean
import com.better517na.springAirSalesService.TicketInfo
import com.better517na.springAirSalesService.UsernameToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ISpringAirBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ISpringAirChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusArgs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InQueryOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutQueryOrderInfoVo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * 春秋航空没有票号，只能根据机票状态来返回.
 * Author: biluo
 * Date: 2018/10/24
 * Time: 17:01
 */
@Component
class TicketNo9CBusiness {
    /**
     * 春秋航空接口业务.
     */
    @Autowired
    ISpringAirBusiness springAirBusiness;

    /**
     * 春秋航空接口改签业务.
     */
    @Autowired
    ISpringAirChangeBusiness springAirChangeBusiness;

    /**
     * 获取票号状态.
     *
     * @param requestVo 请求参数.
     * @return 返回结果.
     */
    ExtractTicketNoStatusRes extractTicketNoStatus(ExtractTicketNoStatusArgs args, InterfaceInfo interfaceInfo) {
        ExtractTicketNoStatusRes response = new ExtractTicketNoStatusRes();
        response.setTicketNo(args.getTicketNo());

        // 查询订单明细
        GetOrderDetailInfoResultBean getOrderDetailInfoResult = this.getOrderDetailInfo(args, interfaceInfo);
        if (null != getOrderDetailInfoResult && getOrderDetailInfoResult.getTicketList() != null && getOrderDetailInfoResult.getTicketList().size() > 0) {
            boolean isExChanged = false; // EXCHANGED
            TicketInfo ticketInfo = null; // 机票订单明细
            FlightBgAppHeadInfo flightBgAppHeadInfo = null; // 航班变更申请明细

            // 若是出票的票号，即是机票订单明细ID；若是改签后的新票号，即是航班变更申请明细ID；若是改签后的原票号，即是机票订单明细ID
            String ticketNo = args.getTicketNo().replaceAll('-', '');

            // 先根据票号找机票订单明细，能找到说明是正向的，找不到说明是改签后的新票号或者是正向票号不准确
            for (TicketInfo item : getOrderDetailInfoResult.getTicketList()) {
                if (ticketNo.contains(String.valueOf(item.getTicketBasicInfo().getOrderHeadId()))) {
                    ticketInfo = item;
                    break;
                }
            }

            // 查询航班变更申请信息
            QueryFlightBgAppInfoResultBean queryFlightBgAppInfoResult = this.queryFlightBgAppInfo(args, interfaceInfo);
            if (queryFlightBgAppInfoResult != null && queryFlightBgAppInfoResult.getFlightBgApps() != null && queryFlightBgAppInfoResult.getFlightBgApps().size() > 0 &&
                    queryFlightBgAppInfoResult.getFlightBgApps().get(0).getBasicInfo() != null && queryFlightBgAppInfoResult.getFlightBgApps().get(0).getBasicInfo().getAppFlag() == 5) {
                isExChanged = true; // 完成改签，默认该EXCHANGED，若是改签后新票号则不是EXCHANGED
                // 根据票号找航班变更申请明细，找到了说明是改签后的新票号，找不到说明改签后的新票号不准确或者是改签原票号（即正向票号）不准确
                for (FlightBgAppHeadInfo item : queryFlightBgAppInfoResult.getFlightBgApps().get(0).getFlightBgAppHeads()) {
                    if (ticketNo.contains(String.valueOf(item.getFlightBgAppHeadId()))) {
                        flightBgAppHeadInfo = item;
                        isExChanged = false; // 是改签后新票号则不是EXCHANGED
                        break;
                    }
                }

                // 是改签后的新票号，则用订单明细ID找到对应的机票
                if (flightBgAppHeadInfo != null) {
                    for (TicketInfo item : getOrderDetailInfoResult.getTicketList()) {
                        if (item.getTicketBasicInfo().getOrderHeadId() == flightBgAppHeadInfo.getOrderHeadId()) {
                            ticketInfo = item;
                            break;
                        }
                    }
                }
            }

            // 如果还没找到机票订单明细，说明正向票号不准确或者改签后的新票号不准确，这里先只认为是正向票号不准确吧，若是单人的则直接用当前的机票订单明细
            if (ticketInfo == null && getOrderDetailInfoResult.getTicketList().size() == 1) {
                ticketInfo = getOrderDetailInfoResult.getTicketList().get(0);
            }

            // 转换票号
            this.getTicketNoStatus(ticketInfo, isExChanged, response);
            response.setSuccess(true);
        } else {
            response.setSuccess(false);
        }
        return response;
    }

    /**
     * 转换票号状态.
     * @param ticketInfo
     * @param isExChanged
     * @param response
     * @return
     */
    String getTicketNoStatus(TicketInfo ticketInfo, boolean isExChanged, ExtractTicketNoStatusRes response) {
        String ticketNoStatus = '';
        if (ticketInfo != null) {
            if (isExChanged) {
                ticketNoStatus = 'EXCHANGED'; // 已换开
            } else {
                // 机票状态：2-已预定，3-已出票，5-已售票，7-已退票，8-超时取消，10-旅客主动取消，11-申请退票，13-航班变更取消，40-已乘机
                // 票号状态：OPEN_FOR_USE=未使用,VOID=已废票,REFUNDED=已退票,USED_FLOWN=已使用,SUSPENDED=挂起,CHECKED_IN=已办理值机,LIFT_BOARDED=已离港,EXCHANGED=已换开,FIM_EXCH=被换开中断仓单,None=未知,CPN_NOTE=等效于未使用
                Integer tktFlag = ticketInfo.getTicketBasicInfo().getTktFlag();
                switch (tktFlag) {
                    case 3:
                    case 5:
                        ticketNoStatus = 'OPEN_FOR_USE'; // 未使用
                        break;
                    case 7:
                        ticketNoStatus = 'REFUNDED'; // 已退票
                        break;
                    case 40:
                        ticketNoStatus = 'USED_FLOWN'; // 已使用
                        break;
                    default:
                        ticketNoStatus = 'None'; // 未知
                        break;
                }
            }

            response.setTicketNoStatus(ticketNoStatus);
            response.setTicketPrice(new BigDecimal(ticketInfo.getTicketBasicInfo().getTktPrice()));
            response.setSellAirrax(new BigDecimal(ticketInfo.getTicketBasicInfo().getPortPay()));
            response.setSellOilrax(new BigDecimal(ticketInfo.getTicketBasicInfo().getFuelPrice()));
        }

        return ticketNoStatus;
    }

    /**
     * 查询订单明细.
     * @param args
     * @param interfaceInfo
     * @return
     */
    GetOrderDetailInfoResultBean getOrderDetailInfo(ExtractTicketNoStatusArgs args, InterfaceInfo interfaceInfo) {
        GetOrderDetailInfoQueryBean getOrderDetailInfoQueryBean = new GetOrderDetailInfoQueryBean();
        UsernameToken usernameToken = new UsernameToken();
        usernameToken.setUsername(interfaceInfo.getAccount());
        usernameToken.setPassword(interfaceInfo.getPassword());
        getOrderDetailInfoQueryBean.setUsernameToken(usernameToken);
        getOrderDetailInfoQueryBean.setLang('zh_cn'); // 语言（NN）-中文(中华人民共和国);
        getOrderDetailInfoQueryBean.setOrderNo(args.getPnr());
        GetOrderDetailInfoResultBean getOrderDetailInfoResult = springAirBusiness.getOrderDetailInfo(getOrderDetailInfoQueryBean, interfaceInfo.getInterfaceUrl());
        return getOrderDetailInfoResult;
    }

    /**
     * 查询航班变更申请信息.
     * @param args
     * @param interfaceInfo
     * @return
     */
    QueryFlightBgAppInfoResultBean queryFlightBgAppInfo(ExtractTicketNoStatusArgs args, InterfaceInfo interfaceInfo) {
        QueryFlightBgAppInfoInputBean queryFlightBgAppInfoInput = new QueryFlightBgAppInfoInputBean();
        UsernameToken usernameToken = new UsernameToken();
        usernameToken.setUsername(interfaceInfo.getAccount());
        usernameToken.setPassword(interfaceInfo.getPassword());
        queryFlightBgAppInfoInput.setUsernameToken(usernameToken);
        queryFlightBgAppInfoInput.setLang('zh_cn');
        queryFlightBgAppInfoInput.setQueryFlag(args.getPnr());
        queryFlightBgAppInfoInput.setQueryFlagId(1);
        queryFlightBgAppInfoInput.setAppFlags('1111');
        QueryFlightBgAppInfoResultBean queryFlightBgAppInfoResult = springAirChangeBusiness.queryFlightBgAppInfo(queryFlightBgAppInfoInput, interfaceInfo.getInterfaceUrl());
        return queryFlightBgAppInfoResult;
    }
}
