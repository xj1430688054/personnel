package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.CLEtermInteractionRouteHelper.helper.ThriftRouteHelper
import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.CommonParamInBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.DeterTicketNoIn
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.DeterTicketNoOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.GetPnrIn
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.GetPnrOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.GetPriceInBo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.GetPriceOutBo
import org.springframework.beans.factory.annotation.Autowired

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/19
 * Time: 20:10
 */
public class BspBaseBusinessImpl {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    public GetPnrOut RT(GetPnrIn paramIn) throws Exception {
        try {
            paramIn.setAction('RT');
            String re = this.clEtermInteraction(paramIn);
            GetPnrOut rtOutBo = GsonUtil.getGson().fromJson(StringUtil.upperConvertToLower(re), GetPnrOut.class);
            return rtOutBo;
        } catch (Exception e) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'RT异常', e.toString(), e));
            throw new Exception('BSP RT异常' + e.getMessage());
        }
    }

    public GetPriceOutBo getPrice(GetPriceInBo paramIn) throws Exception {
        try {
            paramIn.setAction('GetPrice');
            String re = this.clEtermInteraction(paramIn);
            GetPriceOutBo getPriceOutBo = GsonUtil.getGson().fromJson(StringUtil.upperConvertToLower(re), GetPriceOutBo.class);
            return getPriceOutBo;
        } catch (Exception e) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'getPrice异常', e.toString(), e));
            throw new Exception('获取价格异常'+ e.getMessage());
        }
    }

    public DeterTicketNoOut deterTicketNo(DeterTicketNoIn paramIn)throws Exception {
        try {
            paramIn.setAction('DetrTicketNo');
            String re = this.clEtermInteraction(paramIn);
            DeterTicketNoOut getPriceOutBo = GsonUtil.getGson().fromJson(StringUtil.upperConvertToLower(re), DeterTicketNoOut.class);
            return getPriceOutBo;
        } catch (Exception e) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'deterTicketNo异常', e.toString(), e));
            throw new Exception('提票号异常'+ e.getMessage());
        }
    }

    private String clEtermInteraction(CommonParamInBo paramIn) {
        String queryDate = GsonUtil.getGson().toJson(paramIn);
//        AdditionalParam addtion = new AdditionalParam();
//        addtion.setLogKey1(paramIn.getAction());
//        String re = ThriftServiceRouteHelper.getInstance().invokes4csharp("Better517na.CLEtermInteractionService.IService.IBSPAutoService", "ServiceInvoke", queryDate);
        String re = ThriftRouteHelper.getInstance().routeServiceInvoke(queryDate);
        return re;
    }
}
