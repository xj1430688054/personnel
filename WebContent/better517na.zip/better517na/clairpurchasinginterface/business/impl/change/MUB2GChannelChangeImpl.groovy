package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.change

import com.better517na.clairpurchasinginterface.commons.ParamBusinessHelper
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.muB2gService.ArrayOfFlightSegVO
import com.better517na.muB2gService.ArrayOfTransferVO
import com.better517na.muB2gService.CaresIbeCabinInfo
import com.better517na.muB2gService.CaresIbeFlightInfoVO
import com.better517na.muB2gService.FareInfo2
import com.better517na.muB2gService.FlightSegVO
import com.better517na.muB2gService.RtnOrderStatusInfo
import com.better517na.muB2gService.SearchInfo
import com.better517na.muB2gService.SearchResponse
import com.better517na.muB2gService.StatusQueryInfo
import com.better517na.muB2gService.TransferVO
import com.better517na.mub2gPayService.MessageBean
import com.better517na.mub2gReturnTicket.ArrayOfPostUpgradeSegInfo
import com.better517na.mub2gReturnTicket.ArrayOfRpuAmountTktDto
import com.better517na.mub2gReturnTicket.ArrayOfRpuCheckTktVO
import com.better517na.mub2gReturnTicket.ArrayOfRpuTktDto
import com.better517na.mub2gReturnTicket.ObjectFactory
import com.better517na.mub2gReturnTicket.PostUpgradeAmountInfo
import com.better517na.mub2gReturnTicket.PostUpgradeCheckInfo
import com.better517na.mub2gReturnTicket.PostUpgradeOperateInfo
import com.better517na.mub2gReturnTicket.PostUpgradeSegInfo
import com.better517na.mub2gReturnTicket.RPUFacadeService
import com.better517na.mub2gReturnTicket.RPUFacadeServicePortType
import com.better517na.mub2gReturnTicket.RpuAmountTktDto
import com.better517na.mub2gReturnTicket.RpuCheckTktVO
import com.better517na.mub2gReturnTicket.RpuTktDto
import com.better517na.mub2gReturnTicket.RtnPostUpgradeAmount
import com.better517na.mub2gReturnTicket.RtnPostUpgradeCheck
import com.better517na.mub2gReturnTicket.RtnPostUpgradeOperate
import com.better517na.mub2gReturnTicket.RtnTktPostUpgradeAmount
import com.better517na.mub2gReturnTicket.SegInfo
import com.better517na.mub2gReturnTicket.TktInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IChannelChange
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ObjToObj
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.MuB2GBusinessImpl
import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.BuyOrderStatusEnum
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.UserInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.MD5Util
import com.better517na.clairpurchasinginterface.utils.DateUtil
import org.apache.commons.lang.StringUtils
import org.apache.cxf.jaxws.binding.soap.SOAPBindingImpl
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.annotation.Resource
import javax.xml.bind.JAXB
import java.text.DateFormat
import java.text.DecimalFormat
import java.text.SimpleDateFormat

/**
 * MUB2G渠道改签
 */
@Service('mUB2GChannelChangeImpl')
public class MUB2GChannelChangeImpl implements IChannelChange {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;
    /**
     * 统一参数帮助类.
     */
    @Autowired
    private ParamBusinessHelper paramHelper;

    /**
     * iMuB2GBusiness.
     */
    @Autowired
    private MuB2GBusinessImpl iMuB2GBusiness;
    /**
     * FORMAT2.
     */
    private static final DateFormat FORMAT2 = new SimpleDateFormat('yyyy/MM/dd HHmm');

    /**
     * FORMAT1.
     */
    private static final DateFormat FORMAT1 = new SimpleDateFormat('yyyy/MM/dd');

    /**
     * @param inChannelApplyChangeVo 申请改签入参.
     * @return
     */
    @Override
    public OutChannelApplyChangeVo channelApplyChange(InChannelApplyChangeVo inChannelApplyChangeVo) throws Exception {
        OutChannelApplyChangeVo outChannelApplyChangeVo = null;
        Long totalTime = null;
        try {
            RequestVo<InChangeTicketVo> requestVo = new RequestVo<>();

            //对象转换
            // 取大客户号
            List<BuyChangeVoyageInfoBo> buyBos = inChannelApplyChangeVo.getVoyages();
            List<BuyChangeVoyageInfoBo> orgVoyage = new ArrayList<>();
            for (int i = 0; i < buyBos.size(); i++) {
                if (buyBos.get(i).getVoyageType() != null && buyBos.get(i).getVoyageType().intValue() == 0) {
                    orgVoyage.add(buyBos.get(i));
                }
            }
            requestVo.setUser(ObjToObj.supplyInfoToUserInfo(inChannelApplyChangeVo.getSupplySystemInfo(), orgVoyage.get(0).getLargeCustomerNum()));

            requestVo.setBody(ObjToObj.applyChangeVoToChangeTicket(inChannelApplyChangeVo));

            PostUpgradeOperateInfo request = this.changeTicketRequest(requestVo);

            RtnPostUpgradeOperate response = this.postUpgrade(request, requestVo.getUser().getInterfaceUrl());
            long startTime = System.currentTimeMillis();
            OutChangeTicketVo outChangeTicketVo = this.changeTicketResponse(response, requestVo.getBody(), requestVo.getUser());
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
            if (outChangeTicketVo != null) {
                outChannelApplyChangeVo = new OutChannelApplyChangeVo();
                outChannelApplyChangeVo.setChangeAirOrderId(outChangeTicketVo.getChangeAirOrderId());
                outChannelApplyChangeVo.setChangeOrderId(outChangeTicketVo.getChangeOrderId());
                outChannelApplyChangeVo.setPnr(outChangeTicketVo.getPnr());
                outChannelApplyChangeVo.setChangeFailReason(outChangeTicketVo.getChangeFailReason());
            }
        } finally {
            // 使用异步方式记日志
            OutChannelApplyChangeVo newOutChannelApplyChangeVo = outChannelApplyChangeVo;
            Long newTotalTime = totalTime;
            try {
                OutputStream requestXml = new ByteArrayOutputStream();
                OutputStream responsetXml = new ByteArrayOutputStream();
                if (newOutChannelApplyChangeVo != null) {
                    JAXB.marshal(newOutChannelApplyChangeVo, responsetXml);
                }
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('B2G改签申请交互');
                interactionParam.setKey1('channelApplyChange');
                interactionParam.setKey2(newTotalTime.toString());
                interactionParam.setSendContent(requestXml.toString());
                interactionParam.setReceiveContent(responsetXml.toString());
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return outChannelApplyChangeVo;

    }

    /**
     * @param inChannelChangePayVo 改签支付入参.
     * @return
     */
    @Override
    public OutChannelChangePayVo channelChangePay(InChannelChangePayVo inChannelChangePayVo) {
        OutChannelChangePayVo outChannelChangePayVo = new OutChannelChangePayVo();
        boolean isPaySuccess = false;
        com.better517na.mub2gPayService.MessageBean resultBean = null;
        Long totalTime = null;
        MPayParamIn buildPayInParam = null;
        UserInfoVo userInfoVo;
        try {
            long startTime = System.currentTimeMillis();
            userInfoVo = ObjToObj.supplyInfoToUserInfo(inChannelChangePayVo.getSupplySystemInfo(), inChannelChangePayVo.getBigCustomer());
            if (inChannelChangePayVo.getPayAmount() != null) {
                // 这里按支付方式来区分走哪种方式支付
                String[] payInfo = inChannelChangePayVo.getPayInfo().split('\\|');
                if (payInfo.length < 4) {
                    outChannelChangePayVo.setPayFailResult('支付信息长度小于4，构建支付信息失败');
                    return outChannelChangePayVo;
                }

                if (payInfo.length == 4 || (payInfo.length > 4 && payInfo[4].equals('6'))) {
                    // 易宝代付
                    buildPayInParam = this.buildPayInParam(userInfoVo, inChannelChangePayVo.getChangeAirOrderId(), inChannelChangePayVo.getPayAmount(), inChannelChangePayVo.getPayInfo());
                    resultBean = iMuB2GBusiness.payOrder(buildPayInParam);
                } else if (payInfo[4].equals('8')) {
                    // 商旅卡支付
                    buildPayInParam = this.buildPayInParamByBusCard(userInfoVo, inChannelChangePayVo.getChangeAirOrderId(), inChannelChangePayVo.getPayAmount(), inChannelChangePayVo.getPayInfo());
                    resultBean = iMuB2GBusiness.payOrderBusCard(buildPayInParam);
                } else {
                    // 不支持这种支付方式
                    outChannelChangePayVo.setPayFailResult('暂不支持该支付方式：PayType=' + payInfo[4]);
                    return outChannelChangePayVo;
                }

                if ('0000'.equalsIgnoreCase(resultBean.getErrCode().getValue()) || (payInfo[4].equals('8') && '333333'.equalsIgnoreCase(resultBean.getErrCode().getValue()))) {
                    isPaySuccess = true;
                }
            } else {
                isPaySuccess = true;
            }

            // 成功
            if (isPaySuccess) {
                outChannelChangePayVo.setIsPaySuccess(true);
                outChannelChangePayVo.setOutsideOrderId(resultBean.getExternalOrderId().getValue());
            } else {
                outChannelChangePayVo.setPayFailResult(resultBean != null ? resultBean.getErrMsg().getValue() : '支付失败');
            }
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
        } finally {
            // 使用异步方式记日志
            OutChannelChangePayVo newOutChannelChangePayVo = outChannelChangePayVo;
            Long newTotalTime = totalTime;
            try {
                OutputStream requestXml = new ByteArrayOutputStream();
                OutputStream responsetXml = new ByteArrayOutputStream();
                if (newOutChannelChangePayVo != null) {
                    JAXB.marshal(newOutChannelChangePayVo, responsetXml);
                }
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('B2G改签支付交互');
                interactionParam.setKey1('channelChangePay');
                interactionParam.setKey2(newTotalTime.toString());
                interactionParam.setSendContent(requestXml.toString());
                interactionParam.setReceiveContent(responsetXml.toString());
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return outChannelChangePayVo;
    }

    /**
     * @param inChannelQueryChangeFeeVo 查询改签手续费入参.
     * @return
     */
    @Override
    public OutChannelQueryChangeFeeVo channelQueryChangeFee(InChannelQueryChangeFeeVo inChannelQueryChangeFeeVo) throws Exception {
        OutChannelQueryChangeFeeVo outChannelApplyChangeVo = null;
        Long totalTime = null;
        try {
            long startTime = System.currentTimeMillis();
            RequestVo<InChangeCalculateFeeVo> requestVo = new RequestVo<>();
            // 取大客户号
            List<BuyChangeVoyageInfoBo> buyBos = inChannelQueryChangeFeeVo.getVoyages();
            List<BuyChangeVoyageInfoBo> orgVoyage = new ArrayList<>();
            for (int i = 0; i < buyBos.size(); i++) {
                if (buyBos.get(i).getVoyageType() != null && buyBos.get(i).getVoyageType().intValue() == 0) {
                    orgVoyage.add(buyBos.get(i));
                }
            }
            requestVo.setUser(ObjToObj.supplyInfoToUserInfo(inChannelQueryChangeFeeVo.getSupplySystemInfo(), orgVoyage.get(0).getLargeCustomerNum()));
            requestVo.setBody(ObjToObj.channelQueryToCalculateFee(inChannelQueryChangeFeeVo));

            //改签费计算之检查传入的参数
            this.checkTicketParam(requestVo);
            //查询机票状态及改期升舱政策查询
            PostUpgradeAmountInfo request = this.strutCalculateFee(requestVo.getUser(), requestVo.getBody());
            //改期升舱费率计算
            RtnPostUpgradeAmount response = this.upgradeAmount(request, requestVo.getUser().getInterfaceUrl());

            outChannelApplyChangeVo = ObjToObj.calculateFeeToQueryChange(this.changeCalculateFeeResponse(response, requestVo.getBody(), request));
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
        } finally {
            // 使用异步方式记日志
            OutChannelQueryChangeFeeVo newOutChannelQueryChangeFeeVo = outChannelApplyChangeVo;
            Long newTotalTime = totalTime;
            try {
                OutputStream requestXml = new ByteArrayOutputStream();
                OutputStream responsetXml = new ByteArrayOutputStream();
                if (newOutChannelQueryChangeFeeVo != null) {
                    JAXB.marshal(newOutChannelQueryChangeFeeVo, responsetXml);
                }
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('B2G查询改签手续费交互');
                interactionParam.setKey1('channelQueryChangeFee');
                interactionParam.setKey2(newTotalTime.toString());
                interactionParam.setSendContent(requestXml.toString());
                interactionParam.setReceiveContent(responsetXml.toString());
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return outChannelApplyChangeVo;
    }

    /**
     * @param inChannelQueryChangeInfoVo 查询改签信息入参.
     * @return
     */
    @Override
    public OutChannelQueryChangeInfoVo channelQueryChangeInfo(InChannelQueryChangeInfoVo inChannelQueryChangeInfoVo) {
        OutChannelQueryChangeInfoVo outChannelQueryChangeInfoVo = new OutChannelQueryChangeInfoVo();
        Long totalTime = null;
        try {
            long startTime = System.currentTimeMillis();
            InChangeOrderInfoVo inChangeCalculateFeeVo = new InChangeOrderInfoVo();
            inChangeCalculateFeeVo.setChangeOrderId(inChannelQueryChangeInfoVo.getChangeOrderId());
            inChangeCalculateFeeVo.setChangeAirOrderId(inChannelQueryChangeInfoVo.getChangeAirOrderId());
            List<ChangeTicketInfoVo> cVos = new ArrayList<>();
            for (int i = 0; i < inChannelQueryChangeInfoVo.getTickets().size(); i++) {
                cVos.add(ObjToObj.changeTicketInfoBoToVo(inChannelQueryChangeInfoVo.getTickets().get(i)));
            }
            inChangeCalculateFeeVo.setChangeTicketInfoVos(cVos);
            //用户信息
            UserInfoVo userInfoVo = ObjToObj.supplyInfoToUserInfo(inChannelQueryChangeInfoVo.getSupplySystemInfo(), inChannelQueryChangeInfoVo.getBigCustomer());
            userInfoVo.setInterfaceUrl(userInfoVo.getInterfaceUrl() + 'CeaEcFacadeService');
            //requestVo.getChannel() 传入的null
            //机票信息
            RtnOrderStatusInfo response = this.getOrderStatus(userInfoVo, inChannelQueryChangeInfoVo.getChangeAirOrderId(), null);

            OutChangeOrderInfoVo outChangeOrderInfoVo = this.changeOrderInfoResponse(response, inChangeCalculateFeeVo);
            //订单信息
            BuyChangeOrderInfoBo changeOrderInfoBo = new BuyChangeOrderInfoBo();
            changeOrderInfoBo.setOrderId(outChangeOrderInfoVo.getChangeOrderId());
            //表示查询成功
            if (outChangeOrderInfoVo.getIsGetNewTicketNo()) {
                changeOrderInfoBo.setOrderStatus(BuyOrderStatusEnum.SUCCESSD.getId());
            }
            if (outChangeOrderInfoVo.getChangeOrderFail()) {
                changeOrderInfoBo.setOrderStatus(BuyOrderStatusEnum.FAILURE.getId());
            }
            outChannelQueryChangeInfoVo.setOrder(changeOrderInfoBo);
            //机票信息
            List<ChangeTicketInfoVo> changeTicketInfoVos = outChangeOrderInfoVo.getChangeTicketInfoVos();
            List<BuyChangeTicketInfoBo> changeTicketInfoBos = new ArrayList<>();
            for (int i = 0; i < changeTicketInfoVos.size(); i++) {
                changeTicketInfoBos.add(ObjToObj.changeTicketInfoVoToBo(changeTicketInfoVos.get(i)));
            }
            outChannelQueryChangeInfoVo.setTickets(changeTicketInfoBos);
            //outChannelQueryChangeInfoVo.setVoyages();
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
        } catch (Exception e) {

            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '调用东航接口查询改签信息', e));
        } finally {
            // 使用异步方式记日志
            OutChannelQueryChangeInfoVo newOutChannelQueryChangeInfoVo = outChannelQueryChangeInfoVo;
            Long newTotalTime = totalTime;
            try {
                OutputStream requestXml = new ByteArrayOutputStream();
                OutputStream responsetXml = new ByteArrayOutputStream();
                if (newOutChannelQueryChangeInfoVo != null) {
                    JAXB.marshal(newOutChannelQueryChangeInfoVo, responsetXml);
                }
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('B2G查询改签信息交互');
                interactionParam.setKey1('channelQueryChangeInfo');
                interactionParam.setKey2(newTotalTime.toString());
                interactionParam.setSendContent(requestXml.toString());
                interactionParam.setReceiveContent(responsetXml.toString());
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }
        return outChannelQueryChangeInfoVo;
    }

    /**
     *
     * @param infoVo 查询航班信息入参.
     * @return
     */
    @Override
    public OutChannelQueryFlightVo queryFlightInfo(InChannelFlightInfoVo infoVo) {
        OutChannelQueryFlightVo outChannelQueryFlightVo = null;
        RequestVo<InQueryFlightVo> requestVo = new RequestVo<>();
        Long totalTime = null;
        try {
            long startTime = System.currentTimeMillis();
            requestVo.setUser(ObjToObj.supplyInfoToUserInfo(infoVo.getSupplySystemInfo(), infoVo.getBigCustomer()));

            requestVo.setBody(ObjToObj.changeFloghtInfoVoToin(infoVo));

            SearchInfo request = this.createFlightQueryRequest(requestVo);
            SearchResponse response = iMuB2GBusiness.queryFlight(request);
            //ArrayOfTransferVO是空的
            ArrayOfTransferVO arrayOfTransferVO = response.getTransferVOList().getValue();
            boolean isGetShere = (requestVo.getBody().getS1() != null && requestVo.getBody().getS1().equalsIgnoreCase('1')) ? true : false;
            OutQueryFlightVo outQueryFlightVo = this.createFlightQueryResponse(arrayOfTransferVO, requestVo.getBody().getFromCity(), requestVo.getBody().getToCity(), requestVo.getBody().getTakeOffDate(), isGetShere);
            outChannelQueryFlightVo = ObjToObj.outQueryFlightVoTochannel(outQueryFlightVo);
            long endTime = System.currentTimeMillis();
            totalTime = endTime - startTime;
        } catch (Exception e) {

            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '渠道查询航班信息异常', e));
        } finally {
            // 使用异步方式记日志
            OutChannelQueryFlightVo newOutChannelQueryFlightVo = outChannelQueryFlightVo;
            Long newTotalTime = totalTime;
            try {
                OutputStream requestXml = new ByteArrayOutputStream();
                OutputStream responsetXml = new ByteArrayOutputStream();
                if (newOutChannelQueryFlightVo != null) {
                    JAXB.marshal(newOutChannelQueryFlightVo, responsetXml);
                }
                MLogInteraction interactionParam = new MLogInteraction();
                interactionParam.setModule('B2G查询航班信息交互');
                interactionParam.setKey1('queryFlightInfo');
                interactionParam.setKey2(newTotalTime.toString());
                interactionParam.setSendContent(requestXml.toString());
                interactionParam.setReceiveContent(responsetXml.toString());
                logBusiness.writeInteractionLog(interactionParam);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '异常', e));
            }
        }

        return outChannelQueryFlightVo;
    }

    /**
     * TODO 对机票进行改期升舱.
     *
     * @param operateInfo operateInfo.
     * @return RtnPostUpgradeOperate
     */
    private RtnPostUpgradeOperate postUpgrade(PostUpgradeOperateInfo operateInfo, String url) {

        RtnPostUpgradeOperate result = null;
        /*String urlString;
        if ('60'.equals(channel)) {
            urlString = paramHelper.getSysParam(SysParamID.CPPT_CP.name(), 'http://ecapitb.ceair.com:7012/CEAEC/services/RPUFacadeService');
        } else {
            urlString = paramHelper.getSysParam(SysParamID.CPPT_HSJH.name(), 'http://ecapitb.ceair.com:7012/CEAEC/services/RPUFacadeService');
        }*/
        try {
            javax.xml.ws.Service service = javax.xml.ws.Service.create(RPUFacadeService.SERVICE);
            service.addPort(RPUFacadeService.RPUFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url + 'RPUFacadeService');
            RPUFacadeServicePortType searchService = service.getPort(RPUFacadeService.RPUFacadeServiceHttpPort, RPUFacadeServicePortType.class);
            result = searchService.tktDoPostUpgrade(operateInfo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '对机票进行改期升舱操作异常', e));
        } finally {
            OutputStream requestXml = new ByteArrayOutputStream();
            JAXB.marshal(operateInfo, requestXml);
            String requestStr = requestXml.toString();
            String responseStr = '';
            if (result != null) {
                OutputStream responseXml = new ByteArrayOutputStream();
                JAXB.marshal(result, responseXml);
                responseStr = responseXml.toString();
            }

            logBusiness.writeInteractionLog(new MLogInteraction('gwCommunicateJavaService', 'postUpgrade', null, null, requestStr, responseStr));
        }

        return result;
    }

    /**
     * 改签机票请求.
     *
     * @param requestVo requestVo.
     * @return PostUpgradeOperateInfo
     * @throws Exception Exception.
     */
    private PostUpgradeOperateInfo changeTicketRequest(RequestVo<InChangeTicketVo> requestVo) throws Exception {
        if (null == requestVo.getUser()) {
            throw new Exception('用户信息为空');
        }

        if (requestVo.getBody() == null) {
            throw new Exception('请求体为空');
        }

        if (requestVo.getBody().getChangeTicketInfoVos() == null || requestVo.getBody().getChangeTicketInfoVos().size() <= 0) {
            throw new Exception('机票信息为空');
        }

        if (requestVo.getBody().getOrgChangeVoyage() == null || requestVo.getBody().getOrgChangeVoyage().size() <= 0) {
            throw new Exception('改签前航段信息为空');
        }

        if (requestVo.getBody().getNewChangeVoyage() == null || requestVo.getBody().getNewChangeVoyage().size() <= 0) {
            throw new Exception('改签后航段信息为空');
        }

        return this.structChangeTicket(requestVo.getUser(), requestVo.getBody(), requestVo.getChannel());
    }

    /**
     * 构造改签请求.
     *
     * @param userInfoVo userInfoVo.
     * @param inChangeTicketVo inChangeTicketVo.
     * @param channel channel.
     * @return PostUpgradeOperateInfo
     * @throws Exception Exception.
     */
    private PostUpgradeOperateInfo structChangeTicket(UserInfoVo userInfoVo, InChangeTicketVo inChangeTicketVo, String channel) throws Exception {
        ObjectFactory objectFactory = new ObjectFactory();
        RtnPostUpgradeCheck rtnPostUpgradeCheck = this.getRtnPostUpgradeCheck(userInfoVo, inChangeTicketVo.getChangeTicketInfoVos(), inChangeTicketVo.getChangeType(), inChangeTicketVo.getOrgChangeVoyage().get(0));
        com.better517na.muB2gService.CaresIbeFlightInfoVO caresIbeFlightInfoVO = this.getSearchResponse(userInfoVo, inChangeTicketVo.getNewChangeVoyage().get(0), -1);
        if (rtnPostUpgradeCheck == null || caresIbeFlightInfoVO == null) {
            throw new Exception('未匹配到航段');
        }

        PostUpgradeOperateInfo postUpgradeOperateInfo = objectFactory.createPostUpgradeOperateInfo();

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        postUpgradeOperateInfo.setUSRDESC(objectFactory.createPostUpgradeOperateInfoUSRDESC(userInfoVo.getUserDesc()));

        // 用户账号
        postUpgradeOperateInfo.setUSRID(objectFactory.createPostUpgradeOperateInfoUSRID(userInfoVo.getUserName()));

        // 用户密码
        postUpgradeOperateInfo.setUSRPWD(objectFactory.createPostUpgradeOperateInfoUSRPWD(userInfoVo.getPassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        postUpgradeOperateInfo.setUSRSQ(objectFactory.createPostUpgradeOperateInfoUSRSQ(userInfoVo.getUserSegment()));

        ArrayOfPostUpgradeSegInfo orgSegInfo = this.getOrgSegInfo(rtnPostUpgradeCheck, inChangeTicketVo.getChangeTicketInfoVos().get(0), inChangeTicketVo.getOrgChangeVoyage().get(0),
                inChangeTicketVo.getChangeType());
        if (orgSegInfo == null) {
            throw new Exception('未匹配到原航段信息');
        }

        ArrayOfPostUpgradeSegInfo newSegInfo = this.getNewSegInfo(caresIbeFlightInfoVO, inChangeTicketVo.getNewChangeVoyage().get(0), inChangeTicketVo.getChangeType());
        newSegInfo.getPostUpgradeSegInfo().get(0).setOLDDEPDT(objectFactory.createPostUpgradeSegInfoOLDDEPDT(orgSegInfo.getPostUpgradeSegInfo().get(0).getDEPDT().getValue()));
        newSegInfo.getPostUpgradeSegInfo().get(0).setOLDDEPTM(objectFactory.createPostUpgradeSegInfoOLDDEPTM(orgSegInfo.getPostUpgradeSegInfo().get(0).getDEPTM().getValue()));

        postUpgradeOperateInfo.setOLDSEGLIST(objectFactory.createPostUpgradeOperateInfoOLDSEGLIST(orgSegInfo));
        postUpgradeOperateInfo.setREADYSEGLIST(objectFactory.createPostUpgradeOperateInfoREADYSEGLIST(newSegInfo));
        postUpgradeOperateInfo.setTOTALPOSTUPAMOUNT(objectFactory.createPostUpgradeOperateInfoTOTALPOSTUPAMOUNT((int) inChangeTicketVo.getTotalUpgradeFee()));
        postUpgradeOperateInfo.setTOTALDIFFAMOUNT(objectFactory.createPostUpgradeOperateInfoTOTALDIFFAMOUNT((int) inChangeTicketVo.getTotalChangeDateFee()));
        postUpgradeOperateInfo.setTKTCHKTP(objectFactory.createPostUpgradeOperateInfoTKTCHKTP(this.convertChangeType(inChangeTicketVo.getChangeType())));
        postUpgradeOperateInfo.setROUTETYPE(objectFactory.createPostUpgradeOperateInfoROUTETYPE('OW'));
        ArrayOfRpuTktDto arrayOfRpuTktDto = objectFactory.createArrayOfRpuTktDto();
        for (ChangeTicketInfoVo changeTicketInfoVo : inChangeTicketVo.getChangeTicketInfoVos()) {
            RpuTktDto rpuTktDto = objectFactory.createRpuTktDto();
            rpuTktDto.setPAXNM(objectFactory.createRpuTktDtoPAXNM(changeTicketInfoVo.getPassangerName()));
            rpuTktDto.setTKTNO(objectFactory.createRpuTktDtoTKTNO(this.convertTicketNo(changeTicketInfoVo.getOrgTicketNo())));
            rpuTktDto.setTKTPOSTUPAMOUNT(objectFactory.createRpuTktDtoTKTPOSTUPAMOUNT(changeTicketInfoVo.getUpgradeFee().intValue()));
            rpuTktDto.setTKTDIFFAMOUNT(objectFactory.createRpuTktDtoTKTDIFFAMOUNT(changeTicketInfoVo.getChangeDateFee().intValue()));
            arrayOfRpuTktDto.getRpuTktDto().add(rpuTktDto);
        }

        postUpgradeOperateInfo.setOperateTktList(objectFactory.createPostUpgradeOperateInfoOperateTktList(arrayOfRpuTktDto));
        return postUpgradeOperateInfo;
    }

    /**
     * 改签检查.
     *
     * @param userInfoVo userInfoVo.
     * @param changeTicketInfoVos changeTicketInfoVos.
     * @param changeType changeType.
     * @param orgChangeVoayge orgChangeVoayge.
     * @return RtnPostUpgradeCheck
     * @throws Exception Exception.
     */
    private RtnPostUpgradeCheck getRtnPostUpgradeCheck(UserInfoVo userInfoVo, List<ChangeTicketInfoVo> changeTicketInfoVos, int changeType, ChangeVoyageInfoVo orgChangeVoayge) throws Exception {
        // 构造检查信息
        PostUpgradeCheckInfo postUpgradeCheckInfo = this.structCheckInfo(userInfoVo, changeTicketInfoVos, changeType);
        // 1、查询是否可以改签
        RtnPostUpgradeCheck rtnPostUpgradeCheck = this.upgradeCheck(postUpgradeCheckInfo, userInfoVo.getInterfaceUrl());
        if (rtnPostUpgradeCheck == null) {
            throw new Exception('机票状态及改期升舱政策查询返回值为空');
        }

        if (!''.equalsIgnoreCase(rtnPostUpgradeCheck.getRTNERRID().getValue())) {
            throw new Exception(rtnPostUpgradeCheck.getRTNERRID().getValue() + rtnPostUpgradeCheck.getRTNERRMSG().getValue());
        }

        if (rtnPostUpgradeCheck.getTKTLIST() == null || rtnPostUpgradeCheck.getTKTLIST().getValue() == null || rtnPostUpgradeCheck.getTKTLIST().getValue().getTktInfo() == null
                || rtnPostUpgradeCheck.getTKTLIST().getValue().getTktInfo().size() <= 0) {
            throw new Exception('未获取到判断机票信息');
        }

        for (ChangeTicketInfoVo changeTicketInfoVo : changeTicketInfoVos) {
            boolean isFound = false;
            for (TktInfo tktInfo : rtnPostUpgradeCheck.getTKTLIST().getValue().getTktInfo()) {
                if (StringUtils.isNotEmpty(tktInfo.getTKTEXCEPTIONINFO().getValue())) {
                    throw new Exception(tktInfo.getTKTEXCEPTIONINFO().getValue());
                }

                if (this.convertTicketNo(changeTicketInfoVo.getOrgTicketNo()).equalsIgnoreCase(tktInfo.getTKTNO().getValue())) {
                    isFound = true;
                    if (tktInfo.getSEGLIST() == null || tktInfo.getSEGLIST().getValue() == null || tktInfo.getSEGLIST().getValue().getSegInfo() == null
                            || tktInfo.getSEGLIST().getValue().getSegInfo().size() < 0) {
                        throw new Exception('未获取到对应航程信息');
                    }

                    for (SegInfo segInfo : tktInfo.getSEGLIST().getValue().getSegInfo()) {
                        if (segInfo.getFLTNO().getValue().equalsIgnoreCase(orgChangeVoayge.getFlightNO())) {
                            if (segInfo.isSEGCANUPGRADE() != null && 'false'.equalsIgnoreCase(segInfo.isSEGCANUPGRADE().toString())) {
                                throw new Exception('乘机人' + changeTicketInfoVo.getPassangerName() + '不允许改签');
                            }
                        }
                    }
                }
            }

            if (!isFound) {
                throw new Exception('未找到乘机人' + changeTicketInfoVo.getPassangerName());
            }
        }

        return rtnPostUpgradeCheck;
    }

    /**
     * 获取航班查询信息.
     *
     * @param userInfoVo userInfoVo.
     * @param newChangeVoyageInfoVo newChangeVoyageInfoVo.
     * @param passagerCount passagerCount.
     * @return CaresIbeFlightInfoVO
     * @throws Exception Exception.
     */
    private com.better517na.muB2gService.CaresIbeFlightInfoVO getSearchResponse(UserInfoVo userInfoVo, ChangeVoyageInfoVo newChangeVoyageInfoVo, int passagerCount) throws Exception {
        com.better517na.muB2gService.SearchInfo request = this.createFlightQueryRequest(userInfoVo, newChangeVoyageInfoVo);
        com.better517na.muB2gService.SearchResponse response = iMuB2GBusiness.queryFlight(request);
        if (response == null) {
            throw new Exception('改签后航班查询返回值为空');
        }

        if (!''.equalsIgnoreCase(response.getRTNERRID().getValue())) {
            throw new Exception(response.getRTNERRID().getValue() + response.getRTNERRMSG().getValue());
        }

        if (response.getTransferVOList() == null || response.getTransferVOList().getValue() == null || response.getTransferVOList().getValue().getTransferVO() == null
                || response.getTransferVOList().getValue().getTransferVO().size() <= 0) {
            throw new Exception('未获取到改签后机票信息');
        }

        com.better517na.muB2gService.CaresIbeFlightInfoVO caresIbeFlightInfo = null;

        for (com.better517na.muB2gService.TransferVO transferVO : response.getTransferVOList().getValue().getTransferVO()) {
            if (transferVO.getFlightInfoList() == null || transferVO.getFlightInfoList().getValue() == null || transferVO.getFlightInfoList().getValue().getCaresIbeFlightInfoVO() == null
                    || transferVO.getFlightInfoList().getValue().getCaresIbeFlightInfoVO().size() <= 0) {
                continue;
            }

            for (com.better517na.muB2gService.CaresIbeFlightInfoVO caresIbeFlightInfoVO : transferVO.getFlightInfoList().getValue().getCaresIbeFlightInfoVO()) {
                if (caresIbeFlightInfoVO.getFlightNo().getValue().equalsIgnoreCase(newChangeVoyageInfoVo.getFlightNO())) {
                    if (caresIbeFlightInfoVO.getCabins() == null || caresIbeFlightInfoVO.getCabins().getValue() == null || caresIbeFlightInfoVO.getCabins().getValue().getCaresIbeCabinInfo() == null
                            || caresIbeFlightInfoVO.getCabins().getValue().getCaresIbeCabinInfo().size() <= 0) {
                        continue;
                    }

                    for (com.better517na.muB2gService.CaresIbeCabinInfo carbin : caresIbeFlightInfoVO.getCabins().getValue().getCaresIbeCabinInfo()) {
                        if (carbin.getCabinCode().getValue().equalsIgnoreCase(newChangeVoyageInfoVo.getSeatClass())) {
                            caresIbeFlightInfo = caresIbeFlightInfoVO;
                            break;
                        }
                    }
                }
            }
        }

        return caresIbeFlightInfo;
    }

    /**
     * 获取改签前航段信息.
     *
     * @param rtnPostUpgradeCheck rtnPostUpgradeCheck.
     * @param changeTicketInfoVo changeTicketInfoVo.
     * @param orgChangeVoyageInfoVo orgChangeVoyageInfoVo.
     * @param changeType changeType.
     * @return ArrayOfPostUpgradeSegInfo
     * @throws Exception Exception.
     */
    private ArrayOfPostUpgradeSegInfo getOrgSegInfo(RtnPostUpgradeCheck rtnPostUpgradeCheck, ChangeTicketInfoVo changeTicketInfoVo, ChangeVoyageInfoVo orgChangeVoyageInfoVo, int changeType)
            throws Exception {
        ArrayOfPostUpgradeSegInfo arrayOfPostUpgradeSegInfo = null;

        for (TktInfo tktInfo : rtnPostUpgradeCheck.getTKTLIST().getValue().getTktInfo()) {
            if (this.convertTicketNo(changeTicketInfoVo.getOrgTicketNo()).equalsIgnoreCase(tktInfo.getTKTNO().getValue())) {
                if (tktInfo.getSEGLIST().getValue() == null || tktInfo.getSEGLIST().getValue().getSegInfo() == null || tktInfo.getSEGLIST().getValue().getSegInfo().size() <= 0) {
                    throw new Exception('机票航段信息为空');
                }

                for (SegInfo segInfo : tktInfo.getSEGLIST().getValue().getSegInfo()) {
                    if (segInfo.getFLTNO().getValue().equalsIgnoreCase(orgChangeVoyageInfoVo.getFlightNO())) {
                        ObjectFactory objectFactory = new ObjectFactory();
                        PostUpgradeSegInfo postUpgradeSegInfo = objectFactory.createPostUpgradeSegInfo();
                        postUpgradeSegInfo.setSEGSQ(objectFactory.createPostUpgradeSegInfoSEGSQ('1'));
                        postUpgradeSegInfo.setSEGTP(objectFactory.createPostUpgradeSegInfoSEGTP('G'));
                        postUpgradeSegInfo.setFLTNO(objectFactory.createPostUpgradeSegInfoFLTNO(segInfo.getFLTNO().getValue()));
                        postUpgradeSegInfo.setFLTTP(objectFactory.createPostUpgradeSegInfoFLTTP(segInfo.getFLTTP().getValue()));
                        postUpgradeSegInfo.setCLASTP(objectFactory.createPostUpgradeSegInfoCLASTP(segInfo.getCLASTP().getValue()));
                        postUpgradeSegInfo.setDEPARPCD(objectFactory.createPostUpgradeSegInfoDEPARPCD(segInfo.getDEPARPCD().getValue()));
                        postUpgradeSegInfo.setARRARPCD(objectFactory.createPostUpgradeSegInfoARRARPCD(segInfo.getARRARPCD().getValue()));
                        postUpgradeSegInfo.setDEPDT(objectFactory.createPostUpgradeSegInfoDEPDT(segInfo.getDEPDT().getValue().replace('-', '/')));
                        postUpgradeSegInfo.setDEPTM(objectFactory.createPostUpgradeSegInfoDEPTM(segInfo.getDEPTM().getValue()));
                        postUpgradeSegInfo.setARRDT(objectFactory.createPostUpgradeSegInfoARRDT(segInfo.getARRDT().getValue().replace('-', '/')));
                        postUpgradeSegInfo.setARRTM(objectFactory.createPostUpgradeSegInfoARRTM(segInfo.getARRTM().getValue()));
                        postUpgradeSegInfo.setTKTAMOUNT(objectFactory.createPostUpgradeSegInfoTKTAMOUNT(segInfo.getTKTAMOUNT().getValue()));
                        postUpgradeSegInfo.setARPTAX(objectFactory.createPostUpgradeSegInfoARPTAX(segInfo.getARPTAX().getValue()));
                        postUpgradeSegInfo.setFUELTAX(objectFactory.createPostUpgradeSegInfoFUELTAX(segInfo.getFUELTAX().getValue()));
                        postUpgradeSegInfo.setTKTCHKTP(objectFactory.createPostUpgradeSegInfoTKTCHKTP(this.convertChangeType(changeType)));
                        postUpgradeSegInfo.setFAREBASIS(objectFactory.createPostUpgradeSegInfoFAREBASIS(segInfo.getFAREBASIS().getValue()));
                        postUpgradeSegInfo.setRULEID(objectFactory.createPostUpgradeSegInfoRULEID(segInfo.getRULEID().getValue() == null ? 0 : segInfo.getRULEID().getValue()));

                        // postUpgradeSegInfo.setCHDARPTAX(objectFactory.createPostUpgradeSegInfoCHDARPTAX(0));
                        // postUpgradeSegInfo.setCHDFUELTAX(objectFactory.createPostUpgradeSegInfoCHDFUELTAX(0));
                        // postUpgradeSegInfo.setCHDTKTAMOUNT(objectFactory.createPostUpgradeSegInfoCHDTKTAMOUNT(0));
                        // postUpgradeSegInfo.setCHDFAREBASIS(objectFactory.createPostUpgradeSegInfoCHDFAREBASIS(''));
                        // postUpgradeSegInfo.setINFARPTAX(objectFactory.createPostUpgradeSegInfoINFARPTAX(0));
                        // postUpgradeSegInfo.setINFFUELTAX(objectFactory.createPostUpgradeSegInfoINFFUELTAX(0));
                        // postUpgradeSegInfo.setINFTKTAMOUNT(objectFactory.createPostUpgradeSegInfoINFTKTAMOUNT(0));
                        // postUpgradeSegInfo.setINFFAREBASIS(objectFactory.createPostUpgradeSegInfoINFFAREBASIS(''));
                        // postUpgradeSegInfo.setCARRCD(objectFactory.createPostUpgradeSegInfoCARRCD(segInfo.getCARRCD().getValue()
                        // ==null?segInfo.getFLTNO().getValue().substring(0,2):segInfo.getCARRCD().getValue()));
                        // postUpgradeSegInfo.setCarrNo(objectFactory.createPostUpgradeSegInfoCarrNo(segInfo.getFLTNO().getValue()));
                        // postUpgradeSegInfo.setOLDDEPTM(objectFactory.createPostUpgradeSegInfoOLDDEPTM(segInfo.getDEPTM().getValue()));
                        // postUpgradeSegInfo.setOLDDEPDT(objectFactory.createPostUpgradeSegInfoOLDDEPDT(segInfo.getDEPDT().getValue().replace('-', '/')));

                        if (arrayOfPostUpgradeSegInfo == null) {
                            arrayOfPostUpgradeSegInfo = objectFactory.createArrayOfPostUpgradeSegInfo();
                        }

                        arrayOfPostUpgradeSegInfo.getPostUpgradeSegInfo().add(postUpgradeSegInfo);
                    }
                }
            }
        }

        return arrayOfPostUpgradeSegInfo;
    }

    /**
     * 获取新的航段.
     *
     * @param caresIbeFlightInfoVO caresIbeFlightInfoVO.
     * @param newChangeVoyageInfoVo newChangeVoyageInfoVo.
     * @param changeType changeType.
     * @return ArrayOfPostUpgradeSegInfo
     * @throws Exception Exception.
     */
    private ArrayOfPostUpgradeSegInfo getNewSegInfo(com.better517na.muB2gService.CaresIbeFlightInfoVO caresIbeFlightInfoVO, ChangeVoyageInfoVo newChangeVoyageInfoVo, int changeType) throws Exception {
        ObjectFactory objectFactory = new ObjectFactory();
        PostUpgradeSegInfo postUpgradeSegInfo = objectFactory.createPostUpgradeSegInfo();
        postUpgradeSegInfo.setSEGSQ(objectFactory.createPostUpgradeSegInfoSEGSQ('1'));
        postUpgradeSegInfo.setSEGTP(objectFactory.createPostUpgradeSegInfoSEGTP('G'));
        postUpgradeSegInfo.setFLTNO(objectFactory.createPostUpgradeSegInfoFLTNO(caresIbeFlightInfoVO.getFlightNo().getValue()));
        postUpgradeSegInfo.setFLTTP(objectFactory.createPostUpgradeSegInfoFLTTP(caresIbeFlightInfoVO.getPlanetype().getValue()));
        postUpgradeSegInfo.setDEPARPCD(objectFactory.createPostUpgradeSegInfoDEPARPCD(caresIbeFlightInfoVO.getOrgCode().getValue()));
        postUpgradeSegInfo.setARRARPCD(objectFactory.createPostUpgradeSegInfoARRARPCD(caresIbeFlightInfoVO.getDestCode().getValue()));
        String depDt = caresIbeFlightInfoVO.getFltDate().getYear() + '/' + (caresIbeFlightInfoVO.getFltDate().getMonth() > 9 ? caresIbeFlightInfoVO.getFltDate().getMonth() : '0' + caresIbeFlightInfoVO.getFltDate().getMonth()) + '/' + (caresIbeFlightInfoVO.getFltDate().getDay() > 9 ? caresIbeFlightInfoVO.getFltDate().getDay() : '0' + caresIbeFlightInfoVO.getFltDate().getDay());
        postUpgradeSegInfo.setDEPDT(objectFactory.createPostUpgradeSegInfoDEPDT(depDt));
        String depTime = new StringBuffer(caresIbeFlightInfoVO.getOrgTime().getValue()).insert(2, ':').toString();
        postUpgradeSegInfo.setDEPTM(objectFactory.createPostUpgradeSegInfoDEPTM(depTime));
        String arrDt = caresIbeFlightInfoVO.getArriDate().getYear() + '/' + (caresIbeFlightInfoVO.getArriDate().getMonth() > 9 ? caresIbeFlightInfoVO.getArriDate().getMonth() : '0' + caresIbeFlightInfoVO.getArriDate().getMonth()) + '/' + (caresIbeFlightInfoVO.getArriDate().getDay() > 9 ? caresIbeFlightInfoVO.getArriDate().getDay() : '0' + caresIbeFlightInfoVO.getArriDate().getDay());
        postUpgradeSegInfo.setARRDT(objectFactory.createPostUpgradeSegInfoARRDT(arrDt));
        String arrTime = new StringBuffer(caresIbeFlightInfoVO.getDestTime().getValue()).insert(2, ':').toString();
        postUpgradeSegInfo.setARRTM(objectFactory.createPostUpgradeSegInfoARRTM(arrTime));

        // postUpgradeSegInfo.setCHDARPTAX(objectFactory.createPostUpgradeSegInfoCHDARPTAX(0));
        // postUpgradeSegInfo.setCHDFUELTAX(objectFactory.createPostUpgradeSegInfoCHDFUELTAX(0));
        // postUpgradeSegInfo.setCHDTKTAMOUNT(objectFactory.createPostUpgradeSegInfoCHDTKTAMOUNT(0));
        // postUpgradeSegInfo.setCHDFAREBASIS(objectFactory.createPostUpgradeSegInfoCHDFAREBASIS(''));
        // postUpgradeSegInfo.setINFARPTAX(objectFactory.createPostUpgradeSegInfoINFARPTAX(0));
        // postUpgradeSegInfo.setINFFUELTAX(objectFactory.createPostUpgradeSegInfoINFFUELTAX(0));
        // postUpgradeSegInfo.setINFTKTAMOUNT(objectFactory.createPostUpgradeSegInfoINFTKTAMOUNT(0));
        // postUpgradeSegInfo.setINFFAREBASIS(objectFactory.createPostUpgradeSegInfoINFFAREBASIS(''));
        postUpgradeSegInfo.setCARRCD(objectFactory.createPostUpgradeSegInfoCARRCD(caresIbeFlightInfoVO.getCarrCd().getValue()));
        // postUpgradeSegInfo.setCarrNo(objectFactory.createPostUpgradeSegInfoCarrNo(caresIbeFlightInfoVO.getCarrFlightNo().getValue()));
        // postUpgradeSegInfo.setArrTerm(objectFactory.createPostUpgradeSegInfoArrTerm(caresIbeFlightInfoVO.getArriTerm().getValue()));
        // postUpgradeSegInfo.setDepTerm(objectFactory.createPostUpgradeSegInfoDepTerm(caresIbeFlightInfoVO.getDepTerm().getValue()));

        if (caresIbeFlightInfoVO.getCabins() == null || caresIbeFlightInfoVO.getCabins().getValue() == null || caresIbeFlightInfoVO.getCabins().getValue().getCaresIbeCabinInfo() == null
                || caresIbeFlightInfoVO.getCabins().getValue().getCaresIbeCabinInfo().size() < 0) {
            throw new Exception('改签后机票航段舱位信息为空');
        }

        boolean isFoundCarbin = false;
        for (com.better517na.muB2gService.CaresIbeCabinInfo cabinInfo : caresIbeFlightInfoVO.getCabins().getValue().getCaresIbeCabinInfo()) {
            if (cabinInfo.getCabinCode().getValue().equalsIgnoreCase(newChangeVoyageInfoVo.getSeatClass())) {
                if (cabinInfo.getFareInfo() == null || cabinInfo.getFareInfo().getValue() == null || cabinInfo.getFareInfo().getValue().getFareInfo() == null
                        || cabinInfo.getFareInfo().getValue().getFareInfo().size() <= 0) {
                    throw new Exception('未获取到改签后机票舱位' + newChangeVoyageInfoVo.getSeatClass() + '价格信息');
                }

                for (FareInfo2 fareInfo2 : cabinInfo.getFareInfo().getValue().getFareInfo()) {
                    if ('ADT'.equalsIgnoreCase(fareInfo2.getPaxTp().getValue())) {
                        if ('4'.equalsIgnoreCase(fareInfo2.getFareInfoTp().getValue())) {
                            postUpgradeSegInfo.setCLASTP(objectFactory.createPostUpgradeSegInfoCLASTP(cabinInfo.getCabinCode().getValue()));
                            postUpgradeSegInfo.setTKTAMOUNT(objectFactory.createPostUpgradeSegInfoTKTAMOUNT((int) Double.parseDouble(fareInfo2.getPrice().getValue())));
                            postUpgradeSegInfo.setARPTAX(objectFactory.createPostUpgradeSegInfoARPTAX((int) Double.parseDouble(fareInfo2.getAirportTax().getValue())));
                            postUpgradeSegInfo.setFUELTAX(objectFactory.createPostUpgradeSegInfoFUELTAX((int) Double.parseDouble(fareInfo2.getFuelTax().getValue())));
                            postUpgradeSegInfo.setTKTCHKTP(objectFactory.createPostUpgradeSegInfoTKTCHKTP(this.convertChangeType(changeType)));
                            postUpgradeSegInfo.setFAREBASIS(objectFactory.createPostUpgradeSegInfoFAREBASIS(fareInfo2.getFareBasis().getValue()));
                            postUpgradeSegInfo.setRULEID(objectFactory.createPostUpgradeSegInfoRULEID(fareInfo2.getRuleID().getValue()));
                            break;
                        } else if ('1'.equalsIgnoreCase(fareInfo2.getFareInfoTp().getValue())) {
                            postUpgradeSegInfo.setCLASTP(objectFactory.createPostUpgradeSegInfoCLASTP(cabinInfo.getCabinCode().getValue()));
                            postUpgradeSegInfo.setTKTAMOUNT(objectFactory.createPostUpgradeSegInfoTKTAMOUNT((int) Double.parseDouble(fareInfo2.getPrice().getValue())));
                            postUpgradeSegInfo.setARPTAX(objectFactory.createPostUpgradeSegInfoARPTAX((int) Double.parseDouble(fareInfo2.getAirportTax().getValue())));
                            postUpgradeSegInfo.setFUELTAX(objectFactory.createPostUpgradeSegInfoFUELTAX((int) Double.parseDouble(fareInfo2.getFuelTax().getValue())));
                            postUpgradeSegInfo.setTKTCHKTP(objectFactory.createPostUpgradeSegInfoTKTCHKTP(this.convertChangeType(changeType)));
                            postUpgradeSegInfo.setFAREBASIS(objectFactory.createPostUpgradeSegInfoFAREBASIS(fareInfo2.getFareBasis().getValue()));
                            postUpgradeSegInfo.setRULEID(objectFactory.createPostUpgradeSegInfoRULEID(fareInfo2.getRuleID().getValue()));
                        }
                    }
                }

                isFoundCarbin = true;
                break;
            }
        }

        if (!isFoundCarbin) {
            throw new Exception('未找到改签后机票航段舱位');
        }

        ArrayOfPostUpgradeSegInfo arrayOfPostUpgradeSegInfo = objectFactory.createArrayOfPostUpgradeSegInfo();
        arrayOfPostUpgradeSegInfo.getPostUpgradeSegInfo().add(postUpgradeSegInfo);

        return arrayOfPostUpgradeSegInfo;
    }

    /**
     * 创建改签航班查询参数.
     *
     * @param userInfoVo userInfoVo.
     * @param voyage voyage.
     * @return SearchInfo
     * @throws Exception Exception
     */
    private com.better517na.muB2gService.SearchInfo createFlightQueryRequest(UserInfoVo userInfoVo, ChangeVoyageInfoVo voyage) throws Exception {
        com.better517na.muB2gService.ObjectFactory objectFactory = new com.better517na.muB2gService.ObjectFactory();
        com.better517na.muB2gService.SearchInfo searchInfo = objectFactory.createSearchInfo();
        com.better517na.muB2gService.ArrayOfFlightSegVO flightInfo = objectFactory.createArrayOfFlightSegVO();
        com.better517na.muB2gService.FlightSegVO flightSegVo = objectFactory.createFlightSegVO();
        flightInfo.getFlightSegVO().add(flightSegVo);
        searchInfo.setSegItemList(objectFactory.createSearchInfoSegItemList(flightInfo));

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        searchInfo.setUSRDESC(objectFactory.createSearchInfoUSRDESC(userInfoVo.getUserDesc()));

        // 用户账号
        searchInfo.setUSRID(objectFactory.createSearchInfoUSRID(userInfoVo.getUserName()));

        // 用户密码
        searchInfo.setUSRPWD(objectFactory.createSearchInfoUSRPWD(userInfoVo.getPassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        searchInfo.setUSRSQ(objectFactory.createSearchInfoUSRSQ(userInfoVo.getUserSegment()));

        // 运价种类（ I国际 /D国内）
        searchInfo.setFareType(objectFactory.createSearchInfoFareType('D'));

        // 不知道干嘛的，接口文档上面附的null
        searchInfo.setPaxTp(objectFactory.createSearchInfoPaxTp(null));
        searchInfo.setPromoCode(objectFactory.createSearchInfoPromoCode(null));

        // 航程种类（ 1单程 /2往返）
        searchInfo.setRouteType(objectFactory.createSearchInfoRouteType('1'));

        // 到达机场
        flightSegVo.setARRAIRPCD(objectFactory.createFlightSegVOARRAIRPCD(voyage.getToCityCode()));

        // 航司
        flightSegVo.setCARRIER(objectFactory.createFlightSegVOCARRIER(voyage.getFlightNO().substring(0, 2)));

        // 舱位限制('': 不限， EC: 经济舱， BC: 商务舱， FC: 头等舱) 可填具体舱位
        flightSegVo.setCLASTP(objectFactory.createFlightSegVOCLASTP(voyage.getSeatClass()));

        // 出发机场
        flightSegVo.setDEPAIRPCD(objectFactory.createFlightSegVODEPAIRPCD(voyage.getFromCityCode()));

        // 限制起始时间
        flightSegVo.setLIMITBTM(objectFactory.createFlightSegVOLIMITBTM('00:00'));

        // 限制结束时间
        flightSegVo.setLIMITETM(objectFactory.createFlightSegVOLIMITETM('23:59'));

        // 查询日期(yyyy/MM/dd exp:2009/08/10)
        flightSegVo.setSEARCHDATE(objectFactory.createFlightSegVOSEARCHDATE(FORMAT1.format(voyage.getTakeOffTime())));

        // 航段序号
        flightSegVo.setSEGSQ(objectFactory.createFlightSegVOSEGSQ(1));

        // 航段类别G-去程， R-回程
        flightSegVo.setSEGTP(objectFactory.createFlightSegVOSEGTP('G'));
        return searchInfo;
    }

    /**
     * 改签响应解析.
     *
     * @param postUpgradeOperate postUpgradeOperate.
     * @param inChangeTicketVo inChangeTicketVo.
     * @param userInfoVo userInfoVo.
     * @return OutChangeTicketVo
     * @throws Exception Exception.
     */
    private OutChangeTicketVo changeTicketResponse(RtnPostUpgradeOperate postUpgradeOperate, InChangeTicketVo inChangeTicketVo, UserInfoVo userInfoVo) throws Exception {
        OutChangeTicketVo outChangeTicketVo = new OutChangeTicketVo();

        if (!''.equalsIgnoreCase(postUpgradeOperate.getRTNERRID().getValue())) {
            throw new Exception(postUpgradeOperate.getRTNERRID().getValue() + postUpgradeOperate.getRTNERRMSG().getValue());
        }

        if (postUpgradeOperate.getORDEROPSQ().getValue().isEmpty() || postUpgradeOperate.getPNROPCODE().getValue().isEmpty()) {
            outChangeTicketVo.setChangeFailReason(postUpgradeOperate.getRTNERRMSG().getValue());
            throw new Exception('未获取到改签后订单号');
        }

        outChangeTicketVo.setChangeAirOrderId(postUpgradeOperate.getORDEROPSQ().getValue());
        outChangeTicketVo.setPnr(postUpgradeOperate.getPNROPCODE().getValue());
        outChangeTicketVo.setChangeTicketInfoVos(inChangeTicketVo.getChangeTicketInfoVos());
        return outChangeTicketVo;
    }

    /**
     * TODO 构造检查信息.
     *
     * @param userInfoVo userInfoVo.
     * @param changeTicketInfoVos changeTicketInfoVos.
     * @param changeType changeType.
     * @return PostUpgradeCheckInfo.
     */
    private PostUpgradeCheckInfo structCheckInfo(UserInfoVo userInfoVo, List<ChangeTicketInfoVo> changeTicketInfoVos, int changeType) {
        ObjectFactory objectFactory = new ObjectFactory();
        PostUpgradeCheckInfo postUpgradeCheckInfo = objectFactory.createPostUpgradeCheckInfo();

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        postUpgradeCheckInfo.setUSRDESC(objectFactory.createPostUpgradeCheckInfoUSRDESC(userInfoVo.getUserDesc()));

        // 用户账号
        postUpgradeCheckInfo.setUSRID(objectFactory.createPostUpgradeCheckInfoUSRID(userInfoVo.getUserName()));

        // 用户密码
        postUpgradeCheckInfo.setUSRPWD(objectFactory.createPostUpgradeCheckInfoUSRPWD(userInfoVo.getPassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        postUpgradeCheckInfo.setUSRSQ(objectFactory.createPostUpgradeCheckInfoUSRSQ(userInfoVo.getUserSegment()));

        // 查询客票信息
        ArrayOfRpuCheckTktVO arrayOfRpuCheckTktVO = objectFactory.createArrayOfRpuCheckTktVO();
        List<RpuCheckTktVO> rpuCheckTktVOS = new ArrayList<>();
        for (ChangeTicketInfoVo changeTicketInfoVo : changeTicketInfoVos) {
            RpuCheckTktVO rpuCheckTktVO = new RpuCheckTktVO();
            rpuCheckTktVO.setTKTNO(objectFactory.createRpuCheckTktVOTKTNO(this.convertTicketNo(changeTicketInfoVo.getOrgTicketNo())));
            rpuCheckTktVO.setPAXNM(objectFactory.createRpuCheckTktVOPAXNM(changeTicketInfoVo.getPassangerName()));
            rpuCheckTktVO.setPAXCERTCD(objectFactory.createRpuCheckTktVOPAXCERTCD(changeTicketInfoVo.getiDNo()));
            rpuCheckTktVO.setTKTCHKTP(objectFactory.createRpuCheckTktVOTKTCHKTP(this.convertChangeType(changeType)));
            rpuCheckTktVOS.add(rpuCheckTktVO);

        }
        arrayOfRpuCheckTktVO.getRpuCheckTktVO().addAll(rpuCheckTktVOS);
        postUpgradeCheckInfo.setCheckTktVOList(objectFactory.createPostUpgradeCheckInfoCheckTktVOList(arrayOfRpuCheckTktVO));
        return postUpgradeCheckInfo;
    }

    /**
     * 机票改升查询
     *
     * @param checkInfo checkInfo.
     * @return RtnPostUpgradeCheck.
     */
    private RtnPostUpgradeCheck upgradeCheck(PostUpgradeCheckInfo checkInfo, String url) {
        RtnPostUpgradeCheck result = null;
        // String urlString = paramHelper.getSysParam(SysParamID.CPPT_HSJH.name(), 'http://ecapitb.ceair.com:7012/CEAEC/services/RPUFacadeService');
        try {
            javax.xml.ws.Service service = javax.xml.ws.Service.create(RPUFacadeService.SERVICE);
            service.addPort(RPUFacadeService.RPUFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url + 'RPUFacadeService');
            RPUFacadeServicePortType searchService = service.getPort(RPUFacadeService.RPUFacadeServiceHttpPort, RPUFacadeServicePortType.class);
            result = searchService.newTktPostUpgradeCheck(checkInfo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '机票改升查询异常', e));
        } finally {
            OutputStream requestXml = new ByteArrayOutputStream();
            JAXB.marshal(checkInfo, requestXml);
            String requestStr = requestXml.toString();
            String responseStr = '';
            if (result != null) {
                OutputStream responseXml = new ByteArrayOutputStream();
                JAXB.marshal(result, responseXml);
                responseStr = responseXml.toString();
            }

            logBusiness.writeInteractionLog(new MLogInteraction('gwCommunicateJavaService', 'upgradeCheck', null, null, requestStr, responseStr));
        }

        return result;
    }

    /**
     * 检查传入的参数
     * @param requestVo
     * @return
     * @throws Exception
     */
    private void checkTicketParam(RequestVo<InChangeCalculateFeeVo> requestVo) throws Exception {
        if (null == requestVo.getUser()) {
            throw new Exception('用户信息为空');
        }

        if (requestVo.getBody() == null) {
            throw new Exception('请求体为空');
        }

        if (requestVo.getBody().getChangeTicketInfoVos() == null || requestVo.getBody().getChangeTicketInfoVos().size() <= 0) {
            throw new Exception('机票信息为空');
        }

        if (requestVo.getBody().getOrgChangeVoyage() == null || requestVo.getBody().getOrgChangeVoyage().size() <= 0) {
            throw new Exception('改签前航段信息为空');
        }

        if (requestVo.getBody().getNewChangeVoyage() == null || requestVo.getBody().getNewChangeVoyage().size() <= 0) {
            throw new Exception('改签后航段信息为空');
        }

    }

    /**
     * 构造计算费用.
     *
     * @param userInfoVo
     * @param inChangeCalculateFeeVo
     * @return
     * @throws Exception
     */
    private PostUpgradeAmountInfo strutCalculateFee(UserInfoVo userInfoVo, InChangeCalculateFeeVo inChangeCalculateFeeVo) throws Exception {

        ObjectFactory objectFactory = new ObjectFactory();
        RtnPostUpgradeCheck rtnPostUpgradeCheck = this.getRtnPostUpgradeCheck(userInfoVo, inChangeCalculateFeeVo.getChangeTicketInfoVos(), inChangeCalculateFeeVo.getChangeType(),
                inChangeCalculateFeeVo.getOrgChangeVoyage().get(0));
        com.better517na.muB2gService.CaresIbeFlightInfoVO caresIbeFlightInfoVO = this.getSearchResponse(userInfoVo, inChangeCalculateFeeVo.getNewChangeVoyage().get(0), inChangeCalculateFeeVo.getPassagerCount());
        if (rtnPostUpgradeCheck == null || caresIbeFlightInfoVO == null) {
            throw new Exception('未匹配到航段');
        }

        PostUpgradeAmountInfo postUpgradeAmountInfo = objectFactory.createPostUpgradeAmountInfo();

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        postUpgradeAmountInfo.setUSRDESC(objectFactory.createPostUpgradeAmountInfoUSRDESC(userInfoVo.getUserDesc()));

        // 用户账号
        postUpgradeAmountInfo.setUSRID(objectFactory.createPostUpgradeAmountInfoUSRID(userInfoVo.getUserName()));

        // 用户密码
        postUpgradeAmountInfo.setUSRPWD(objectFactory.createPostUpgradeAmountInfoUSRPWD(userInfoVo.getPassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        postUpgradeAmountInfo.setUSRSQ(objectFactory.createPostUpgradeAmountInfoUSRSQ(userInfoVo.getUserSegment()));

        ArrayOfPostUpgradeSegInfo orgSegInfo = this.getOrgSegInfo(rtnPostUpgradeCheck, inChangeCalculateFeeVo.getChangeTicketInfoVos().get(0), inChangeCalculateFeeVo.getOrgChangeVoyage().get(0),
                inChangeCalculateFeeVo.getChangeType());
        if (orgSegInfo == null) {
            throw new Exception('未匹配到原航段信息');
        }

        ArrayOfPostUpgradeSegInfo newSegInfo = this.getNewSegInfo(caresIbeFlightInfoVO, inChangeCalculateFeeVo.getNewChangeVoyage().get(0), inChangeCalculateFeeVo.getChangeType());
        newSegInfo.getPostUpgradeSegInfo().get(0).setOLDDEPDT(objectFactory.createPostUpgradeSegInfoOLDDEPDT(orgSegInfo.getPostUpgradeSegInfo().get(0).getDEPDT().getValue()));
        newSegInfo.getPostUpgradeSegInfo().get(0).setOLDDEPTM(objectFactory.createPostUpgradeSegInfoOLDDEPTM(orgSegInfo.getPostUpgradeSegInfo().get(0).getDEPTM().getValue()));

        ArrayOfRpuAmountTktDto arrayOfRpuAmountTktDto = objectFactory.createArrayOfRpuAmountTktDto();
        for (ChangeTicketInfoVo changeTicketInfoVo : inChangeCalculateFeeVo.getChangeTicketInfoVos()) {
            RpuAmountTktDto rpuAmountTktDto = objectFactory.createRpuAmountTktDto();
            rpuAmountTktDto.setTKTNO(objectFactory.createRpuAmountTktDtoTKTNO(this.convertTicketNo(changeTicketInfoVo.getOrgTicketNo())));
            rpuAmountTktDto.setOLDSEGLIST(objectFactory.createRpuAmountTktDtoOLDSEGLIST(orgSegInfo));
            rpuAmountTktDto.setREADYSEGLIST(objectFactory.createRpuAmountTktDtoREADYSEGLIST(newSegInfo));
            arrayOfRpuAmountTktDto.getRpuAmountTktDto().add(rpuAmountTktDto);
        }

        postUpgradeAmountInfo.setAmountTktVOList(objectFactory.createPostUpgradeAmountInfoAmountTktVOList(arrayOfRpuAmountTktDto));
        return postUpgradeAmountInfo;
    }

    /**
     * 改期升舱费率计算.
     *
     * @param amountInfo
     * @return
     */
    private RtnPostUpgradeAmount upgradeAmount(PostUpgradeAmountInfo amountInfo, String url) {
        RtnPostUpgradeAmount result = null;
        // String urlString = paramHelper.getSysParam(SysParamID.CPPT_HSJH.name(), 'http://ecapitb.ceair.com:7012/CEAEC/services/RPUFacadeService');
        try {
            javax.xml.ws.Service service = javax.xml.ws.Service.create(RPUFacadeService.SERVICE);
            service.addPort(RPUFacadeService.RPUFacadeServiceHttpPort, SOAPBindingImpl.SOAP11HTTP_BINDING, url + 'RPUFacadeService');
            RPUFacadeServicePortType searchService = service.getPort(RPUFacadeService.RPUFacadeServiceHttpPort, RPUFacadeServicePortType.class);
            result = searchService.tktPostUpgradeAmount(amountInfo);
            return result;
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '改签查询费用查询异常', e));
        } finally {
            OutputStream requestXml = new ByteArrayOutputStream();
            JAXB.marshal(amountInfo, requestXml);
            String requestStr = requestXml.toString();
            String responseStr = '';
            if (result != null) {
                OutputStream responseXml = new ByteArrayOutputStream();
                JAXB.marshal(result, responseXml);
                responseStr = responseXml.toString();
            }

            logBusiness.writeInteractionLog(new MLogInteraction('gwCommunicateJavaService', 'upgradeAmount', null, null, requestStr, responseStr));
        }

        return result;
    }

    /**
     * 解析计算改签费响应.
     *
     * @param postUpgradeAmount postUpgradeAmount.
     * @param inChangeCalculateFeeVo inChangeCalculateFeeVo.
     * @param upgradeAmountInfo upgradeAmountInfo.
     * @return OutChangeCalculateFeeVo
     * @throws Exception Exception.
     */
    private OutChangeCalculateFeeVo changeCalculateFeeResponse(RtnPostUpgradeAmount postUpgradeAmount, InChangeCalculateFeeVo inChangeCalculateFeeVo, PostUpgradeAmountInfo upgradeAmountInfo)
            throws Exception {
        if (postUpgradeAmount.getRtnTktPostUpgradeAmountList() == null || postUpgradeAmount.getRtnTktPostUpgradeAmountList().getValue() == null
                || postUpgradeAmount.getRtnTktPostUpgradeAmountList().getValue().getRtnTktPostUpgradeAmount() == null
                || postUpgradeAmount.getRtnTktPostUpgradeAmountList().getValue().getRtnTktPostUpgradeAmount().size() <= 0) {
            throw new Exception('不能改签，未获取到费用信息');
        }

        OutChangeCalculateFeeVo outChangeCalculateFeeVo = new OutChangeCalculateFeeVo();
        outChangeCalculateFeeVo.setChangeTicketInfoVos(inChangeCalculateFeeVo.getChangeTicketInfoVos());
        outChangeCalculateFeeVo.setTotalChangeDateFee(postUpgradeAmount.getTOTALDIFFAMOUNT().getValue());
        outChangeCalculateFeeVo.setTotalUpgradeFee(postUpgradeAmount.getTOTALPOSTUPAMOUNT().getValue());
        outChangeCalculateFeeVo.setChangeOrderId(inChangeCalculateFeeVo.getChangeOrderId());
        for (ChangeTicketInfoVo changeTicketInfoVo : outChangeCalculateFeeVo.getChangeTicketInfoVos()) {
            RpuAmountTktDto rpuAmountTktDto = upgradeAmountInfo.getAmountTktVOList().getValue().getRpuAmountTktDto().get(0);
            changeTicketInfoVo.setTickPrice((double) rpuAmountTktDto.getREADYSEGLIST().getValue().getPostUpgradeSegInfo().get(0).getTKTAMOUNT().getValue());
            for (RtnTktPostUpgradeAmount upgradeAmount : postUpgradeAmount.getRtnTktPostUpgradeAmountList().getValue().getRtnTktPostUpgradeAmount()) {
                if (this.convertTicketNo(changeTicketInfoVo.getOrgTicketNo()).equalsIgnoreCase(upgradeAmount.getTKTNO().getValue())) {
                    changeTicketInfoVo.setChangeDateFee((double) upgradeAmount.getTKTDIFFAMOUNT().getValue());
                    changeTicketInfoVo.setUpgradeFee((double) upgradeAmount.getTKTPOSTUPAMOUNT().getValue());
                }
            }
        }

        return outChangeCalculateFeeVo;
    }

    /**
     * 构建支付请求入参.
     *
     * @param userInfo userInfo.
     * @param changeOrderId changeOrderId.
     * @param payAmount payAmount.
     * @return MPayParamIn
     */
    private MPayParamIn buildPayInParam(UserInfoVo userInfo, String changeOrderId, String payAmount, String payInfoStr) {
        String[] payInfo = payInfoStr.split('\\|');
        MPayParamIn payInParam = new MPayParamIn();
        String customerName = userInfo.getBigCustomer();
        String orderId = changeOrderId;
        String cardNo = payInfo[0]; // 'chenfuming2@test.com';
        String signKey = payInfo[1]; // '1794941b-c15d-491a-9a8d-16d71cc2a607';
        String userNameString = userInfo.getUserName();
        String password = userInfo.getPassWord();
        String sign = MD5Util.md5Hex((customerName + orderId + cardNo + signKey).getBytes()).toUpperCase();
        String encrypt = 'customerName=' + customerName + '&orderId=' + orderId + '&cardNo=' + cardNo + '&signMsg=' + sign + '&userId=' + userNameString + '&password=' + password;
        BigInteger e = new BigInteger('65537');

        BigInteger n = new BigInteger('19088884874345537868197456139999183195584621814137005' + '709517008924265378761074128004769930595545052' + '4284144975170623710456573144454170656337707433'
                + '41669147122887594204420544425331025195283965770' + '15023502735042564678681062962824706950878663730' + '40815048275798304875024255366782116655907180184'
                + '18027077172986537508764414819485429305431448645' + '90122288392440347193562165043148371310560931610' + '70071547119869393423515186164308315548820022972'
                + '14477828256683830764847804234342898655578096580' + '76429677728383731480606039191566442587188099975' + '01838786572095047231501225037523282208069369949'
                + '83848348919610405719539262015200707475346107381623');
        String cs = '';

        try {
            BigInteger m = new BigInteger(encrypt.getBytes('utf-8'));
            BigInteger c = m.modPow(e, n);
            cs = c.toString();
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        payInParam.setOrderId(changeOrderId);
        payInParam.setAmt(payAmount);
        payInParam.setEncrypt(cs);
        payInParam.setPushurl(payInfo[2]);
        payInParam.setServiceUrl(payInfo[3]);
        return payInParam;
    }

    /**
     * TODO 构建支付请求入参(商旅卡支付).
     *
     * @param requestVo 请求
     * @return 结果
     */
    private MPayParamIn buildPayInParamByBusCard(UserInfoVo userInfo, String changeOrderId, String payAmount, String payInfoStr) {
        String[] payInfo = payInfoStr.split('\\|');
        if (payInfo.length < 6) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '未获取到支付信息', new Exception('未获取到支付信息')));
            return null;
        }

        MPayParamIn payInParam = new MPayParamIn();
        String customerName = userInfo.getBigCustomer();
        String orderId = changeOrderId;
        String cardNo = payInfo[0]; // 'chenfuming2@test.com';
        String signKey = payInfo[1]; // '1794941b-c15d-491a-9a8d-16d71cc2a607';
        //这里拿到的是年月日这种，2018-07-15，要处理成0718
        String expiredDate = DateUtil.dateToString(DateUtil.stringToDate(payInfo[5], 'yyyy-MM-dd'), 'MMyy');
        String userNameString = userInfo.getUserName();
        String password = userInfo.getPassWord();
        String sign = MD5Util.md5Hex((customerName + orderId + cardNo + expiredDate + signKey).getBytes()).toUpperCase();
        String encrypt = 'customerName=' + customerName + '&orderId=' + orderId + '&cardNo=' + cardNo + '&expiredDate=' + expiredDate + '&signMsg=' + sign + '&userId=' + userNameString + '&password=' + password;
        BigInteger e = new BigInteger('65537');

        BigInteger n = new BigInteger('19088884874345537868197456139999183195584621814137005' + '709517008924265378761074128004769930595545052' + '4284144975170623710456573144454170656337707433'
                + '41669147122887594204420544425331025195283965770' + '15023502735042564678681062962824706950878663730' + '40815048275798304875024255366782116655907180184'
                + '18027077172986537508764414819485429305431448645' + '90122288392440347193562165043148371310560931610' + '70071547119869393423515186164308315548820022972'
                + '14477828256683830764847804234342898655578096580' + '76429677728383731480606039191566442587188099975' + '01838786572095047231501225037523282208069369949'
                + '83848348919610405719539262015200707475346107381623');
        String cs = '';
        try {
            BigInteger m = new BigInteger(encrypt.getBytes('utf-8'));
            BigInteger c = m.modPow(e, n);
            cs = c.toString();
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        payInParam.setOrderId(changeOrderId);
        payInParam.setAmt(payAmount);
        payInParam.setEncrypt(cs);
        payInParam.setPushurl(payInfo[2]);
        payInParam.setServiceUrl(payInfo[3]);
        return payInParam;
    }

    /**
     * 获取订单状态.
     *
     * @param userInfoVo userInfoVo.
     * @param changeOrderId changeOrderId.
     * @param channel channel.
     * @return RtnOrderStatusInfo
     * @throws Exception Exception.
     */
    private RtnOrderStatusInfo getOrderStatus(UserInfoVo userInfoVo, String changeOrderId, String channel) throws Exception {
        com.better517na.muB2gService.ObjectFactory objectFactory = new com.better517na.muB2gService.ObjectFactory();
        StatusQueryInfo statusQueryInfo = objectFactory.createStatusQueryInfo();

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        statusQueryInfo.setUSRDESC(objectFactory.createStatusQueryInfoUSRDESC(userInfoVo.getUserDesc()));

        // 用户账号
        statusQueryInfo.setUSRID(objectFactory.createStatusQueryInfoUSRID(userInfoVo.getUserName()));

        // 用户密码
        statusQueryInfo.setUSRPWD(objectFactory.createStatusQueryInfoUSRPWD(userInfoVo.getPassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        statusQueryInfo.setUSRSQ(objectFactory.createStatusQueryInfoUSRSQ(userInfoVo.getUserSegment()));

        // 要支付订单的订单编号
        statusQueryInfo.setOPSQ(objectFactory.createStatusQueryInfoOPSQ(changeOrderId));

        return iMuB2GBusiness.queryChangeOrderStatus(statusQueryInfo, userInfoVo.getInterfaceUrl());
    }

    /**
     * 改签信息获取解析.
     *
     * @param orderStatusInfo
     *            orderStatusInfo.
     * @param inChangeOrderInfoVo
     *            inChangeOrderInfoVo.
     * @return OutChangeOrderInfoVo
     */
    private OutChangeOrderInfoVo changeOrderInfoResponse(RtnOrderStatusInfo orderStatusInfo, InChangeOrderInfoVo inChangeOrderInfoVo) {
        OutChangeOrderInfoVo outChangeOrderInfoVo = new OutChangeOrderInfoVo();
        if ('Y'.equalsIgnoreCase(orderStatusInfo.getTKTSTATUS().getValue())) {
            if (orderStatusInfo.getTktItemList() == null || orderStatusInfo.getTktItemList().getValue() == null || orderStatusInfo.getTktItemList().getValue().getTktItem() == null
                    || orderStatusInfo.getTktItemList().getValue().getTktItem().size() <= 0) {
                return outChangeOrderInfoVo;
            }

            outChangeOrderInfoVo.setChangeTicketInfoVos(inChangeOrderInfoVo.getChangeTicketInfoVos());
            outChangeOrderInfoVo.setChangeAirOrderId(inChangeOrderInfoVo.getChangeAirOrderId());
            outChangeOrderInfoVo.setChangeOrderId(inChangeOrderInfoVo.getChangeOrderId());
            int passagerCount = 0;
            for (com.better517na.muB2gService.TktItem tktItem : orderStatusInfo.getTktItemList().getValue().getTktItem()) {
                for (ChangeTicketInfoVo changeTicketInfoVo : outChangeOrderInfoVo.getChangeTicketInfoVos()) {
                    if (tktItem.getPAXCNM().getValue().replace(' ', '').equalsIgnoreCase(changeTicketInfoVo.getPassangerName().replace(' ', ''))) {
                        changeTicketInfoVo.setTicketNo(tktItem.getTKTNO().getValue());
                        passagerCount++;
                    }
                }
            }

            if (passagerCount == outChangeOrderInfoVo.getChangeTicketInfoVos().size()) {
                outChangeOrderInfoVo.setIsGetNewTicketNo(true);
            }
        } else if ('X'.equalsIgnoreCase(orderStatusInfo.getORDERSTATUS().getValue())) {
            outChangeOrderInfoVo.setChangeOrderFail(true);
        }

        return outChangeOrderInfoVo;
    }

    /**
     *
     * TODO 创建航班 的查询参数
     *
     * @param requestVo
     *            入参
     * @return 结果
     * @throws Exception
     *             异常
     */
    private SearchInfo createFlightQueryRequest(RequestVo<InQueryFlightVo> requestVo) throws Exception {
        InQueryFlightVo inQueryFlightVo = requestVo.getBody();
        UserInfoVo userInfoVo = requestVo.getUser();
        if (null == userInfoVo) {
            throw new Exception('用户信息为空');
        }
        com.better517na.muB2gService.ObjectFactory objectFactory = new com.better517na.muB2gService.ObjectFactory();
        SearchInfo searchInfo = objectFactory.createSearchInfo();
        ArrayOfFlightSegVO flightInfo = objectFactory.createArrayOfFlightSegVO();
        FlightSegVO flightSegVo = objectFactory.createFlightSegVO();
        flightInfo.getFlightSegVO().add(flightSegVo);
        searchInfo.setSegItemList(objectFactory.createSearchInfoSegItemList(flightInfo));

        // 使用WS的用户的描述信息格式如下：3/KA/9960011/NULL/NULL
        searchInfo.setUSRDESC(objectFactory.createSearchInfoUSRDESC(userInfoVo.getUserDesc()));

        // 用户账号
        searchInfo.setUSRID(objectFactory.createSearchInfoUSRID(userInfoVo.getUserName()));

        // 用户密码
        searchInfo.setUSRPWD(objectFactory.createSearchInfoUSRPWD(userInfoVo.getPassWord()));

        // 用户的序号，用来解决一个账号下不同用户通过不同系统进行访问系统的问题 格式是四位数字，默认值是0001
        searchInfo.setUSRSQ(objectFactory.createSearchInfoUSRSQ(userInfoVo.getUserSegment()));

        // 运价种类（ I国际 /D国内）
        searchInfo.setFareType(objectFactory.createSearchInfoFareType('D'));

        // 不知道干嘛的，接口文档上面附的null
        searchInfo.setPaxTp(objectFactory.createSearchInfoPaxTp(null));
        searchInfo.setPromoCode(objectFactory.createSearchInfoPromoCode(null));

        // 航程种类（ 1单程 /2往返）
        searchInfo.setRouteType(objectFactory.createSearchInfoRouteType('1'));

        // 到达机场
        flightSegVo.setARRAIRPCD(objectFactory.createFlightSegVOARRAIRPCD(inQueryFlightVo.getToCity()));

        // 到达城市
        if (null != inQueryFlightVo.getArrCity() && !inQueryFlightVo.getArrCity().equalsIgnoreCase('')) {
            flightSegVo.setARRCITYCD(objectFactory.createFlightSegVOARRCITYCD(inQueryFlightVo.getArrCity()));
        }

        // 航司
        flightSegVo.setCARRIER(objectFactory.createFlightSegVOCARRIER(inQueryFlightVo.getCarrier()));

        // 舱位限制('': 不限， EC: 经济舱， BC: 商务舱， FC: 头等舱) 可填具体舱位
        flightSegVo.setCLASTP(objectFactory.createFlightSegVOCLASTP(inQueryFlightVo.getCabin()));

        // 出发机场
        flightSegVo.setDEPAIRPCD(objectFactory.createFlightSegVODEPAIRPCD(inQueryFlightVo.getFromCity()));

        // 出发城市
        if (null != inQueryFlightVo.getDepCity() && !inQueryFlightVo.getDepCity().equalsIgnoreCase('')) {
            flightSegVo.setDEPCITYCD(objectFactory.createFlightSegVODEPCITYCD(inQueryFlightVo.getDepCity()));
        }

        // 限制起始时间
        flightSegVo.setLIMITBTM(objectFactory.createFlightSegVOLIMITBTM('00:00'));

        // 限制结束时间
        flightSegVo.setLIMITETM(objectFactory.createFlightSegVOLIMITETM('23:59'));

        // 查询日期(yyyy/MM/dd exp:2009/08/10)
        flightSegVo.setSEARCHDATE(objectFactory.createFlightSegVOSEARCHDATE(FORMAT1.format(inQueryFlightVo.getTakeOffDate())));

        // 航段序号
        flightSegVo.setSEGSQ(objectFactory.createFlightSegVOSEGSQ(1));

        // 航段类别G-去程， R-回程
        flightSegVo.setSEGTP(objectFactory.createFlightSegVOSEGTP('G'));
        return searchInfo;
    }

    /**
     *
     * 构造航班查询返回内容.
     *
     * @param arrayOfTransferVO
     *            如参一
     * @param fromCity
     *            如参二
     * @param toCity
     *            到达城市
     * @param takeOffDate
     *            起飞时间
     * @param isGetShere
     *            是否获取共享航班
     * @return outQueryFlightVo 航班信息
     * @throws Exception
     *             异常
     */
    private OutQueryFlightVo createFlightQueryResponse(ArrayOfTransferVO arrayOfTransferVO, String fromCity, String toCity, Date takeOffDate, boolean isGetShere) throws Exception {
        OutQueryFlightVo outQueryFlightVo = new OutQueryFlightVo();
        outQueryFlightVo.setFromCity(fromCity);
        outQueryFlightVo.setToCity(toCity);
        outQueryFlightVo.setTakeOffDate(takeOffDate);
        if (arrayOfTransferVO != null && arrayOfTransferVO.getTransferVO().size() > 0) {

            List<FlightInfoVo> flightInfoList = new ArrayList<FlightInfoVo>();
            outQueryFlightVo.setFlightInfoList(flightInfoList);
            for (TransferVO transferVO : arrayOfTransferVO.getTransferVO()) {
                for (CaresIbeFlightInfoVO flightInfoVO : transferVO.getFlightInfoList().getValue().getCaresIbeFlightInfoVO()) {
                    // 过滤掉共享航班
                    if (!isGetShere && flightInfoVO.isCodeShare()) {
                        continue;
                    }

                    FlightInfoVo flightInfo = new FlightInfoVo();
                    List<CabinInfoVo> cabinInfoList = new ArrayList<CabinInfoVo>();

                    flightInfo.setArrAir(flightInfoVO.getDestCode().getValue());
                    int year = flightInfoVO.getArriDate().getYear();
                    int month = flightInfoVO.getArriDate().getMonth();
                    int day = flightInfoVO.getArriDate().getDay();
                    flightInfo.setArriveTime(FORMAT2.parse(String.format('%d/%d/%d %s', year, month, day, flightInfoVO.getDestTime().getValue())));
                    flightInfo.setCabinInfoList(cabinInfoList);
                    flightInfo.setCarrier(flightInfoVO.getAirlineCode().getValue());
                    flightInfo.setDepAir(flightInfoVO.getOrgCode().getValue());
                    flightInfo.setFlightNO(flightInfoVO.getFlightNo().getValue());
                    flightInfo.setFromCity(fromCity);
                    flightInfo.setPlaneType(flightInfoVO.getPlanetype().getValue());
                    flightInfo.setToTerminal(flightInfoVO.getArriTerm().getValue());
                    flightInfo.setFromTerminal(flightInfoVO.getDepTerm().getValue());
                    year = flightInfoVO.getFltDate().getYear();
                    month = flightInfoVO.getFltDate().getMonth();
                    day = flightInfoVO.getFltDate().getDay();
                    flightInfo.setTakeOffTime(FORMAT2.parse(String.format('%d/%d/%d %s', year, month, day, flightInfoVO.getOrgTime().getValue())));
                    flightInfo.setToCity(toCity);
                    flightInfoList.add(flightInfo);
                    for (CaresIbeCabinInfo cabinInfoVO : flightInfoVO.getCabins().getValue().getCaresIbeCabinInfo()) {
                        for (FareInfo2 fareInfo : cabinInfoVO.getFareInfo().getValue().getFareInfo()) {
                            // 接口会返回儿童价，所以只要成人的价格
                            if (!'ADT'.equalsIgnoreCase(fareInfo.getPaxTp().getValue())) {
                                continue;
                            }

                            CabinInfoVo cabinInfo = new CabinInfoVo();
                            cabinInfo.setCabin(cabinInfoVO.getCabinCode().getValue());
                            cabinInfo.setFacePrice(fareInfo.getPrice().getValue());
                            cabinInfo.setFlightLimitType(1);
                            cabinInfo.setFlightNum(flightInfo.getFlightNO());
                            cabinInfo.setItineraryPrice(Double.valueOf(fareInfo.getPrice().getValue()));

                            // 这个字段要往下传，创单要用。。。
                            // 这里需要区别产品类型：标准价、协议价、促销价
                            // fareInfoTP:1 标准价，4 协议价（包含促销价）
                            // ruleID:0:协议价，其他：促销价

                            int productType = 0; // 0:标准价，1：协议价，2:促销价
                            if ('1'.equalsIgnoreCase(fareInfo.getFareInfoTp().getValue())) {
                                productType = 0;
                            } else if ('4'.equalsIgnoreCase(fareInfo.getFareInfoTp().getValue())) {
                                if (fareInfo.getRuleID().getValue() == 0) {
                                    productType = 1;
                                } else {
                                    productType = 2;
                                }
                            }
                            cabinInfo.setPricesource(fareInfo.getRuleID().getValue().toString() + '^' + productType);
                            int seatCount = 0;
                            if ('A'.equalsIgnoreCase(cabinInfoVO.getCount().getValue())) {
                                seatCount = 9;
                            } else {
                                seatCount = Integer.parseInt(cabinInfoVO.getCount().getValue());
                            }
                            cabinInfo.setLastSeats(seatCount);
                            cabinInfo.setSalePrice(Double.valueOf(fareInfo.getPrice().getValue()));
                            DecimalFormat df = new DecimalFormat('######0'); // 四色五入转换成整数
                            String disCount = df.format(Double.valueOf(fareInfo.getPrice().getValue()) / Double.valueOf(fareInfo.getBaseClassPrice().getValue()) * 100);
                            cabinInfo.setS5(disCount);
                            cabinInfoList.add(cabinInfo);

                            flightInfo.setAirrax(Double.valueOf(fareInfo.getAirportTax().getValue()));
                            flightInfo.setOilrax(Double.valueOf(fareInfo.getFuelTax().getValue()));
                        }
                    }
                }
            }
        }
        return outQueryFlightVo;
    }

    /**
     * 改签类型转化.
     *
     * @param changeType changeType.
     * @return String.
     */
    private String convertChangeType(int changeType) {
        switch (changeType) {
            case 0:
                return 'U';
            case 1:
                return 'P';
            case 2:
                return 'UP';
            default:
                return '';
        }
    }

    /**
     * 票号转化.
     *
     * @param ticketNo ticketNo.
     * @return String
     */
    private String convertTicketNo(String ticketNo) {
        String ticketNoString = ticketNo;
        if (ticketNoString.contains('-')) {
            ticketNoString = ticketNoString.replace('-', '');
        }

        return ticketNoString;
    }


}
