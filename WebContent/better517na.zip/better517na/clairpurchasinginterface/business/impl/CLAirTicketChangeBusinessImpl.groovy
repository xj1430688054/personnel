package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import com.better517na.clairticketapi.model.vo.CancelChangeInVo
import com.better517na.clairticketapi.model.vo.CancelChangeOutVo
import com.better517na.clairticketapi.model.vo.refund.ApplyChangeInVo
import com.better517na.clairticketapi.model.vo.refund.ApplyChangeOutVo
import com.better517na.clairticketapi.model.vo.refund.ChangeOrderSearchInVo
import com.better517na.clairticketapi.model.vo.refund.ChangeOrderSearchOutVo
import com.better517na.clairticketapi.model.vo.refund.ChangePayInVo
import com.better517na.clairticketapi.model.vo.refund.ChangePayOutVo
import com.better517na.clairticketapi.model.vo.refund.ChangeSearchInVo
import com.better517na.clairticketapi.model.vo.refund.ChangeSearchOutVo
import com.better517na.logcompontent.business.LogBusiness
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ICLAirTicketChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.ResponseVo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.annotation.Resource

@Component
class CLAirTicketChangeBusinessImpl extends CLAirTicketAPIBaseBusiness implements ICLAirTicketChangeBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    ResponseVo<ApplyChangeOutVo> applyChange(RequestVo<ApplyChangeInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/applyChange');
        TypeToken<ResponseVo<ApplyChangeOutVo>> typeToken = new TypeToken<ResponseVo<ApplyChangeOutVo>>() {
        };
        ResponseVo<ApplyChangeOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    ResponseVo<ChangeSearchOutVo> changeSearch(RequestVo<ChangeSearchInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/changeSearch');
        TypeToken<ResponseVo<ChangeSearchOutVo>> typeToken = new TypeToken<ResponseVo<ChangeSearchOutVo>>() {
        };
        ResponseVo<ChangeSearchOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    ResponseVo<ChangeOrderSearchOutVo> changeOrderSearch(RequestVo<ChangeOrderSearchInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/changeOrderSearch');
        TypeToken<ResponseVo<ChangeOrderSearchOutVo>> typeToken = new TypeToken<ResponseVo<ChangeOrderSearchOutVo>>() {
        };
        ResponseVo<ChangeOrderSearchOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    ResponseVo<ChangePayOutVo> changePay(RequestVo<ChangePayInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/changePay');
        TypeToken<ResponseVo<ChangePayOutVo>> typeToken = new TypeToken<ResponseVo<ChangePayOutVo>>() {
        };
        ResponseVo<ChangePayOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    ResponseVo<CancelChangeOutVo> cancelChange(RequestVo<CancelChangeInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/cancelChange');
        TypeToken<ResponseVo<CancelChangeOutVo>> typeToken = new TypeToken<ResponseVo<CancelChangeOutVo>>() {
        };
        ResponseVo<CancelChangeOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }
}
