package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.utils.Constants;
import com.better517na.clairpurchasinginterface.utils.SignUtils;
import com.better517na.javaloghelper.util.GsonUtil;
import com.better517na.logcompontent.model.MLogException;
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.RequestVo

import java.text.SimpleDateFormat;


/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/22
 * Time: 14:57
 */
public class CLAirTicketAPIBaseBusiness extends HttpBaseBusiness {

    /**
     * 请求.
     *
     * @param request request.
     * @param secret secret.
     * @param domain 域名.
     * @param subModule subModule.
     * @return 响应.
     */
    public String execute(RequestVo<?> request, String secret, String domain, String subModule) {
        String res = '';
        basicParam(request); // 构建基础参数.
        request.setSign(signRequest(request, secret));
        String params = GsonUtil.getGson().toJson(request);
        res = this.doPost(domain + subModule, params, '差旅机票接口', subModule);
        return res;
    }

    /**
     * 构建基础参数.
     *
     * @param request .
     */
    private void basicParam(RequestVo<?> request) {
        request.setRequestId(String.valueOf(System.currentTimeMillis()));
        request.setTimestamp(new SimpleDateFormat(Constants.DATE_TIME_FORMAT).format(new Date()));
        request.setVersion('1.0');
    }

    /**
     * 签名.
     *
     * @param request 请求对象.
     * @return 验签结果.
     */
    public String signRequest(RequestVo<?> request, String secret) {
        String sign = '';
        try {
            String data = null;
            if (request.getData() != null) {
                data = GsonUtil.getGson().toJson(request.getData());
            }

            Map<String, String> map = new HashMap<>();
            map.put('data', data);
            map.put('pid', request.getPid());
            map.put('requestId', request.getRequestId());
            map.put('timestamp', request.getTimestamp());
            map.put('version', request.getVersion());
            sign = SignUtils.sign(map, secret);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '生成签名异常', e.getMessage(), e));
        }

        return sign;
    }
}
