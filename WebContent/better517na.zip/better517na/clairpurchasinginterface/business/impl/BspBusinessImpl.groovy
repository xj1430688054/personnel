package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairpurchasinginterface.feignClient.ClAirTicketBuyDataServiceFeignClient
import com.better517na.clairpurchasinginterface.utils.DateUtil
import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.clairticketbuytradeintegration.model.vo.TicketBuyOrderInfoVo
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IBspBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.DeterTicketNoIn
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.DeterTicketNoOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.GetPnrIn
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.GetPnrOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp.VoyageInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InPayValidateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InTicketNoCheckVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutPayValidateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutTicketNoCheckVo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component


/**
 * TODO 添加类的一句话简单描述.
 * Author: sanzang
 * Date: 2018/6/19
 * Time: 20:10
 */
@Component
class BspBusinessImpl extends BspBaseBusinessImpl implements IBspBusiness {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness

    /**
     * 添加字段注释.
     */
    @Autowired
    private ClAirTicketBuyDataServiceFeignClient airTicketBuyDataServiceFeignClient

    @Override
    ResponseVo<OutPayValidateVo> payValidate(RequestVo<InPayValidateVo> requestVo) {
        ResponseVo<OutPayValidateVo> responseVo = new ResponseVo<OutPayValidateVo>();
        OutPayValidateVo payValidateVo = new OutPayValidateVo();
        payValidateVo.setChangePrice(false);
        responseVo.setResult(payValidateVo);

        try {
            TicketBuyOrderInfoVo buyOrderInfo = this.getBuyOrderInfo(requestVo.getBody().getPtOrderId());
            if (buyOrderInfo != null) {
                GetPnrIn getPnrIn = new GetPnrIn();
                // 构造入参
                getPnrIn.setBigPnr(buyOrderInfo.getBuyOrderInfoBo().getBigPNR());
                getPnrIn.setSmallPnr(buyOrderInfo.getBuyOrderInfoBo().getPNR());
                getPnrIn.setTmcID(buyOrderInfo.getBuyOrderInfoBo().getTMCNo());
                getPnrIn.setProviderID(buyOrderInfo.getBuyOrderInfoBo().getServiceProviderID());
                getPnrIn.setCorpID(buyOrderInfo.getBuyOrderInfoBo().getSupplyId());
                getPnrIn.setOffice(buyOrderInfo.getBuyOrderExtendBo().getBookOffice());
                getPnrIn.setOrderID(buyOrderInfo.getBuyOrderExtendBo().getSellOrderId());
                GetPnrOut pnrOut = this.RT(getPnrIn);
                if (pnrOut.getSuccess() && pnrOut.getPnrInfo() != null && pnrOut.getPnrInfo().getStatus() == 2 && pnrOut.getPnrInfo().getVoyages().size() > 0) {
                    for (VoyageInfo voyageInfo : pnrOut.getPnrInfo().getVoyages()) {
                        if (!'HK/KK/DK/KL/TK'.contains(voyageInfo.getSeatStatus().toString().toUpperCase())) {
                            responseVo.setMsg('航段状态为' + voyageInfo.getSeatStatus().toString() + ',不能支付');
                            responseVo.setSuccess(false);
                            return responseVo;
                        }
                    }
                }
            } else {
                responseVo.setMsg('BSP支付前校验失败：通过卖出订单号未获取到买入订单：' + requestVo.getBody().getPtOrderId());
                responseVo.setSuccess(false);
            }
        } catch (Exception e) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'BSP支付前校验失败', e.toString(), e));
            responseVo.setMsg('BSP支付前校验失败：' + e.getMessage());
            responseVo.setSuccess(false);
            return responseVo;
        }

        responseVo.setSuccess(true);
        return responseVo;
    }

    /**
     * 票号校验.
     *
     * @param requestVo 请求参数.
     * @return 返回结果.
     */
    @Override
    ResponseVo<OutTicketNoCheckVo> ticketNoCheck(RequestVo<InTicketNoCheckVo> requestVo) {
        OutTicketNoCheckVo outTicketNoCheckVo=new OutTicketNoCheckVo();
        ResponseVo<OutTicketNoCheckVo> responseVo = new ResponseVo<>();

        try {
            DeterTicketNoIn paramIn = new DeterTicketNoIn();
            paramIn.setSmallPnr(requestVo.getBody().getPnr());
            paramIn.setTmcID(requestVo.getSupplySystemInfo().getTmcID());
            paramIn.setProviderID(requestVo.getBody().getProviderId());
            paramIn.setCorpID(requestVo.getBody().getCorpId());
            paramIn.setOffice(requestVo.getBody().getOffice());
            paramIn.setOrderID(requestVo.getBody().getOrderId());
            paramIn.setTicketNo(requestVo.getBody().getTicketNo());

            DeterTicketNoOut outResult = this.deterTicketNo(paramIn);
            if (outResult.getSuccess()) {
                // 获取成功了则比较乘机人信息
                if (outResult.getAnalysisResult() && outResult.getTicketInfo() != null) {
                    String takeOffTimeStr = '';
                    if (!StringUtil.isStringParamNotLegal(outResult.getTicketInfo().getVoyages().get(0).getTakeoffTime())) {
                        takeOffTimeStr = outResult.getTicketInfo().getVoyages().get(0).getTakeoffTime().substring(0, 10);
                    }

                    String flightNo = '';
                    if (!StringUtil.isStringParamNotLegal(outResult.getTicketInfo().getVoyages().get(0).getScheduledFlight().getScheduledFlightNo())) {
                        flightNo = outResult.getTicketInfo().getVoyages().get(0).getScheduledFlight().getScheduledFlightNo();
                    }

                    // 获取到票号，验证信息是否正确
                    if (!StringUtil.isStringParamNotLegal(outResult.getTicketInfo().getPassengerName()) && !StringUtil.isStringParamNotLegal(requestVo.getBody().getUserName()) && !requestVo.getBody().getUserName().equals(outResult.getTicketInfo().getPassengerName())) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg(String.format('票号:%s校验不通过，订单乘机人:%s与票号乘机人:%s不匹配;', paramIn.getTicketNo(), requestVo.getBody().getUserName(), outResult.getTicketInfo().getPassengerName()));
                    } else if (!StringUtil.isStringParamNotLegal(outResult.getTicketInfo().getVoyages().get(0).getFromCity()) && !requestVo.getBody().getFromCity().equals(outResult.getTicketInfo().getVoyages().get(0).getFromCity())) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg(String.format('票号:%s校验不通过，订单出发城市:%s与票号出发城市:%s不匹配;', paramIn.getTicketNo(), requestVo.getBody().getFromCity(), outResult.getTicketInfo().getVoyages().get(0).getFromCity()));
                    } else if (!StringUtil.isStringParamNotLegal(outResult.getTicketInfo().getVoyages().get(0).getToCity()) && !requestVo.getBody().getToCity().equals(outResult.getTicketInfo().getVoyages().get(0).getToCity())) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg(String.format('票号:%s校验不通过，订单到达城市:%s与票号到达城市:%s不匹配;', paramIn.getTicketNo(), requestVo.getBody().getToCity(), outResult.getTicketInfo().getVoyages().get(0).getToCity()));
                    } else if (!takeOffTimeStr.equals('') && !takeOffTimeStr.equals('0001-01-01') && !takeOffTimeStr.equals('1900-01-01') && !takeOffTimeStr.equals(DateUtil.dateToString(requestVo.getBody().getTakeOffTime(), 'yyyy-MM-dd'))) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg(String.format('票号:%s校验不通过，订单起飞日期:%s与票号起飞日期:%s不匹配;', paramIn.getTicketNo(), DateUtil.dateToString(requestVo.getBody().getTakeOffTime(), 'yyyy-MM-dd'), takeOffTimeStr));
                    } else if (!StringUtil.isStringParamNotLegal(flightNo) && !flightNo.equals(requestVo.getBody().getFlightNo())) {
                        responseVo.setSuccess(false);
                        responseVo.setMsg(String.format('票号:%s校验不通过，订单航班号:%s与票号航班号:%s不匹配;', paramIn.getTicketNo(), requestVo.getBody().getFlightNo(), flightNo));
                    } else {
                        // 走到这里就验证通过了
                        responseVo.setSuccess(true);
                    }
                    return responseVo;
                } else if (outResult.getErrMessage().contains('[AUTHORITY')) {
                    // 没有权限
                    responseVo.setSuccess(false);
                    responseVo.setMsg(String.format('没有提取票号:%s内容的权限，请输入正确的票号，或联系管理员维护正确的Office号;', paramIn.getTicketNo()));
                } else if (outResult.getErrMessage().contains('ET TICKET NUMBER IS NOT EXIST ')) {
                    // 票号不存在
                    responseVo.setSuccess(false);
                    responseVo.setMsg(String.format('票号:%s不存在,请输入正确的票号;', paramIn.getTicketNo()));
                } else {
                    // 未获取到票号，票号不存在
                    responseVo.setSuccess(false);
                    responseVo.setMsg(String.format('票号:%s校验不通过:%s;', paramIn.getTicketNo(), outResult.getErrMessage()));
                }
            } else {
                // 系统异常这种先按照成功处理，后面有需求改成失败处理再改
                responseVo.setSuccess(true);
            }
            responseVo.setResult(outTicketNoCheckVo);
        }
        catch (Exception ex) {
            this.logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'BSP票号校验异常', ex.toString(), ex));
            responseVo.setMsg('BSP票号校验异常，请重试：' + ex.getMessage());
            responseVo.setSuccess(false);
            return responseVo;
        }

        return responseVo;
    }

    private TicketBuyOrderInfoVo getBuyOrderInfo(String sellOrderId) {
        TicketBuyOrderInfoVo buyOrderInfo = null
//        com.better517na.clairticketbuytradeintegration.model.vo.TicketBuyOrderInfoVo temp =
        List<TicketBuyOrderInfoVo> buyOrderInfoVoList = airTicketBuyDataServiceFeignClient.getOrderInfoBySellOrderId(sellOrderId)
        if (buyOrderInfoVoList != null && buyOrderInfoVoList.size() > 0) {
            return buyOrderInfoVoList.get(0);
//            // 买入订单为空，则根据订单状态判断哪一个应该支付
//            for (TicketBuyOrderInfoVo buyOrderInfoVo : buyOrderInfoVoList) {
//                // 1 新订单，等待支付 2 取消交易，交易结束 3 已经出票，交易结束 4 取消出票，等待退款 5 已经付款，等待出票 6 已经退款，交易结束 7 暂不能出票，等待处理 99 创单失败
//                if (buyOrderInfo == null && buyOrderInfoVo.getBuyOrderInfoBo().getOrderDisplayID() == 99) {
//                    buyOrderInfo = buyOrderInfoVo;
//                }
//                if (buyOrderInfoVo.getBuyOrderInfoBo().getOrderDisplayID() >= 2 && buyOrderInfoVo.getBuyOrderInfoBo().getOrderDisplayID() <= 7) {
//                    buyOrderInfo = buyOrderInfoVo;
//                } else if ((buyOrderInfo == null || buyOrderInfo.getBuyOrderInfoBo().getOrderDisplayID() == 99) && buyOrderInfoVo.getBuyOrderInfoBo().getOrderDisplayID() == 1) {
//                    buyOrderInfo = buyOrderInfoVo;
//                }
//            }
        }
        return buyOrderInfo
    }
}
