package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.czb2g

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.czb2g.ICZB2GChangeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.CancelChangeInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.ChangeOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.ChangeShowReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.ChangeShowResp
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange.DoBookRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange.DoBookRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.RQPassenger
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue.ReissueRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue.ReissueRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.ReshopReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.ReshopResp
import org.apache.commons.lang.StringUtils
import org.springframework.stereotype.Component
import com.google.common.reflect.TypeToken;

@Component
class CZB2GChangeBusinessImpl extends CZB2GBaseBusiness implements ICZB2GChangeBusiness {

    /**
     * 查询准备改升行程信息
     * @param request
     * @param url
     * @return
     */
    @Override
    ChangeShowResp changeShow(ChangeShowReq request, String url) {
        String params = String.format('<OrderRetrieveRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '\t<Document/>\n' +
                '\t<Party/>\n' +
                '\t<Query>\n' +
                '\t\t<Filters>\n' +
                '\t\t\t<!--航司二字码  订单编号-->\n' +
                '\t\t\t<OrderID Owner="%s">%s</OrderID>\n' +
                '\t\t\t<BookingReferences>\n' +
                '\t\t\t\t<BookingReference>\n' +
                '\t\t\t\t\t<!--PNR-->\n' +
                '\t\t\t\t\t<ID>%s</ID>\n' +
                '\t\t\t\t\t<!--EbrNO-->\n' +
                '\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t</BookingReference>\n' +
                '\t\t\t</BookingReferences>\n' +
                '\t\t</Filters>\n' +
                '\t</Query>\n' +
                '</OrderRetrieveRQ>', request.getCarrier(), request.getOrderNo(), request.getPnr(), request.getEbrNo());
        String res = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/changepre/flightinfo')
        return GsonUtil.getGson().fromJson(res, ChangeShowResp.class);
    }

    /**
     * 查询改升航班
     * @param request
     * @param url
     * @return
     */
    @Override
    ReshopResp reshop(ReshopReq request, String url) {
        StringBuilder params = new StringBuilder(String.format('<ItinReshopRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '\t<Document>\n' +
                '\t\t<!--版本 必填-->\n' +
                '\t\t<Name>zh_CN</Name>\n' +
                '\t</Document>\n' +
                '\t<Party>\n' +
                '\t\t<Sender>\n' +
                '\t\t\t<TravelAgencySender>\n' +
                '\t\t\t\t<OtherIDs>\n' +
                '\t\t\t\t\t<!--国际 国内标志 D国内 I 国际 必填-->\n' +
                '\t\t\t\t\t<OtherID Description="IsInter">D</OtherID>\n' +
                '\t\t\t\t</OtherIDs>\n' +
                '\t\t\t</TravelAgencySender>\n' +
                '\t\t</Sender>\n' +
                '\t</Party>\n' +
                '\t<Query>\n' +
                '\t\t<Reshop>\n' +
                '\t\t\t<Actions>\n' +
                '\t\t\t\t<BookingReferences>\n' +
                '\t\t\t\t\t<BookingReference>\n' +
                '\t\t\t\t\t\t<!--PNR-->\n' +
                '\t\t\t\t\t\t<ID>%s</ID>\n' +
                '\t\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t\t</BookingReference>\n' +
                '\t\t\t\t</BookingReferences>\n' +
                '\t\t\t\t<!--订单号-->\n' +
                '\t\t\t\t<OrderID Owner="%s">%s</OrderID>\n' +
                '\t\t\t\t<OrderItems>\n' +
                '\t\t\t\t\t<!--选择改期的航段信息-->\n' +
                '\t\t\t\t\t<OrderItem>\n' +
                '\t\t\t\t\t<!--ShortDate：重新选择的改期日期 必填-->\n' +
                '\t\t\t\t\t<FlightItem ShortDate="%s">\n' +
                '\t\t\t\t\t\t<OriginDestination>\n' +
                '\t\t\t\t\t\t\t<Flight>\n' +
                '\t\t\t\t\t\t\t\t<Departure>\n' +
                '\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t</Departure>\n' +
                '\t\t\t\t\t\t\t\t\t<Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t</Arrival>\n' +
                '\t\t\t\t\t\t\t\t<MarketingCarrier>\n' +
                '\t\t\t\t\t\t\t\t\t<!--飞机航班 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t\t\t\t\t\t<FlightNumber>%s</FlightNumber>\n' +
                '\t\t\t\t\t\t\t\t</MarketingCarrier>\n' +
                '\t\t\t\t\t\t\t\t<CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t<!--飞机舱位 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<Code>%s</Code>\n' +
                '\t\t\t\t\t\t\t\t</CabinType>\n' +
                '\t\t\t\t\t\t\t</Flight>\n' +
                '\t\t\t\t\t\t</OriginDestination>\n' +
                '\t\t\t\t\t</FlightItem>\n' +
                '\t\t\t\t\t</OrderItem>\n' +
                '\t\t\t\t</OrderItems>\n' +
                '\t\t\t\t<!--选择改升乘客信息-->\n' +
                '\t\t\t\t<Passengers>\n', request.getPnr(), request.getCarrier(), request.getCarrier(), request.getOrderNo(), request.getChangeDate(),
                request.getDepAirportCode(), request.getDepDate(), request.getDepTime(), request.getArrAirportCode(), request.getArrDate(), request.getArrTime(),
                request.getCarrier(), request.getFlightNo(), request.getCabinCode()));
        for (RQPassenger pa : request.getPassengers()) {
            String passenger = String.format('\t\t\t\t<Passenger>\n' +
                    '\t\t\t\t\t<Name>\n' +
                    '\t\t\t\t\t\t<!--乘客姓名 必填-->\n' +
                    '\t\t\t\t\t\t<Surname>%s</Surname>\n' +
                    '\t\t\t\t\t</Name>\n' +
                    '\t\t\t\t\t<Remarks>\n' +
                    '\t\t\t\t\t\t<!--票号 多个票号以逗号分隔 必填 -->\n' +
                    '\t\t\t\t\t\t<Remark>%s</Remark>\n' +
                    '\t\t\t\t\t\t<!---->\n' +
                    '\t\t\t\t\t</Remarks>\n' +
                    '\t\t\t\t\t<PassengerIDInfo>\n' +
                    '\t\t\t\t\t\t<FOID>\n' +
                    '\t\t\t\t\t\t\t<!--证件类型 HZ护照 JRZ军人证 TWZ台胞证  SZ身份证 HXZ回乡证 GATXZ港澳通行证 GJHY国际海员证 YJJZ外国人永久居住证 LXZ旅行证 HKB户口簿 CSZ 出生证明 必填-->\n' +
                    '\t\t\t\t\t\t\t<Type>%s</Type>\n' +
                    '\t\t\t\t\t\t\t<ID>%s</ID>\n' +
                    '\t\t\t\t\t\t</FOID>\n' +
                    '\t\t\t\t\t</PassengerIDInfo>\n' +
                    '\t\t\t\t\t<Contacts>\n' +
                    '\t\t\t\t\t\t<Contact>\n' +
                    '\t\t\t\t\t\t\t<!--联系电话 必填-->\n' +
                    '\t\t\t\t\t\t\t<PhoneContact>\n' +
                    '\t\t\t\t\t\t\t\t<Number>%s</Number>\n' +
                    '\t\t\t\t\t\t\t</PhoneContact>\n' +
                    '\t\t\t\t\t\t</Contact>\n' +
                    '\t\t\t\t\t</Contacts>\n' +
                    '\t\t\t\t</Passenger>\n', pa.getPassengerName(), pa.getTicketNo(), pa.getCardType(), pa.getCardNo(), pa.getContactPhoneNo());
            params.append(passenger);
        }
        params.append(String.format('\t\t\t\t</Passengers>\n' +
                '\t\t\t</Actions>\n' +
                '\t\t</Reshop>\n' +
                '\t</Query>\n' +
                '</ItinReshopRQ>'));

        String res = this.execute(params.toString(), request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/changereshop')
        return GsonUtil.getGson().fromJson(res, ReshopResp.class);
    }

    /**
     * 改升航班询价
     * @param request
     * @param url
     * @return
     */
    @Override
    ReissueRS reissue(ReissueRQ request, String url) {
        StringBuilder params = new StringBuilder(String.format('<ItinReshopRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '\t<Query>\n' +
                '\t\t<Reshop>\n' +
                '\t\t\t<Actions>\n' +
                '\t\t\t\t<BookingReferences>\n' +
                '\t\t\t\t\t<BookingReference>\n' +
                '\t\t\t\t\t\t<!--订单号 必填-->\n' +
                '\t\t\t\t\t\t<ID>%s</ID>\n' +
                '\t\t\t\t\t\t<!--PNR号 必填-->\n' +
                '\t\t\t\t\t\t<OtherID>%s</OtherID>\n' +
                '\t\t\t\t\t</BookingReference>\n' +
                '\t\t\t\t</BookingReferences>\n' +
                '\t\t\t\t<!--改升旅客-->\n' +
                '\t\t\t\t<Passengers>\n' +
                '\t\t\t\t\t<!--ObjectKey 旅客编号 必填-->\n', request.getOrderNo(), request.getPnr()));
        for (RQPassenger pa : request.getPassengers()) {
            String passenger = String.format('<Passenger ObjectKey="%s">\n' +
                    '\t\t\t\t\t\t<!--旅客类型 必须是ADT不能是0 必填 -->\n' +
                    '\t\t\t\t\t\t<PTC>ADT</PTC>\n' +
                    '\t\t\t\t\t\t<Name>\n' +
                    '\t\t\t\t\t\t\t<!--旅客名 必填-->\n' +
                    '\t\t\t\t\t\t\t<Surname>%s</Surname>\n' +
                    '\t\t\t\t\t\t</Name>\n' +
                    '\t\t\t\t\t\t<Contacts>\n' +
                    '\t\t\t\t\t\t\t<Contact>\n' +
                    '\t\t\t\t\t\t\t\t<!--电话 非必填-->\n' +
                    '\t\t\t\t\t\t\t\t<PhoneContact>\n' +
                    '\t\t\t\t\t\t\t\t\t<Number>%s</Number>\n' +
                    '\t\t\t\t\t\t\t\t</PhoneContact>\n' +
                    '\t\t\t\t\t\t\t</Contact>\n' +
                    '\t\t\t\t\t\t</Contacts>\n' +
                    '\t\t\t\t\t\t<Remarks>\n' +
                    '\t\t\t\t\t\t\t<!--旅客票号,如有多个，号分开  必填-->\n' +
                    '\t\t\t\t\t\t\t<Remark>%s</Remark>\n' +
                    '\t\t\t\t\t\t</Remarks>\n' +
                    '\t\t\t\t\t\t<PassengerIDInfo>\n' +
                    '\t\t\t\t\t\t\t<FOID>\n' +
                    '\t\t\t\t\t\t\t\t<!--证件类型-->\n' +
                    '\t\t\t\t\t\t\t\t<!--SFZ身份证/HZ护照/JRZ军人证/TWZ台胞证/HXZ回乡证/GATXZ港澳通行证-->\n' +
                    '\t\t\t\t\t\t\t\t<!--GJHY国际海员/YJJZ外国人永久居住证/LXZ旅行证/HKB户口薄/CSZ出生证明/QT其他-->\n' +
                    '\t\t\t\t\t\t\t\t<Type>%s</Type>\n' +
                    '\t\t\t\t\t\t\t\t<!--证件号 必填-->\n' +
                    '\t\t\t\t\t\t\t\t<ID>%s</ID>\n' +
                    '\t\t\t\t\t\t\t</FOID>\n' +
                    '\t\t\t\t\t\t</PassengerIDInfo>\n' +
                    '\t\t\t\t\t</Passenger>\n', pa.getPassengerNo(), pa.getPassengerName(), pa.getContactPhoneNo(), pa.getTicketNo(), pa.getCardType(), pa.getCardNo());
            params.append(passenger);
        }
        params.append(String.format('</Passengers>\n' +
                '\t\t\t\t<OrderItems>\n' +
                '\t\t\t\t\t<!--航段信息标识ObjectKey 必填 原航段用OLD标识，新选择航段用NEW标识-->\n' +
                '\t\t\t\t\t<OrderItem ObjectKey="OLD">\n' +
                '\t\t\t\t\t\t<!--原航段信息 必填-->\n' +
                '\t\t\t\t\t\t<FlightItem>\n' +
                '\t\t\t\t\t\t\t<OriginDestination>\n' +
                '\t\t\t\t\t\t\t\t<!--多段改期会有多个此节点-->\n' +
                '\t\t\t\t\t\t\t\t<Flight>\n' +
                '\t\t\t\t\t\t\t\t\t<!--航段RPH-->\n' +
                '\t\t\t\t\t\t\t\t\t<SegmentKey>1</SegmentKey>\n' +
                '\t\t\t\t\t\t\t\t\t<!--出发信息 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<Departure>\n' +
                '\t\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t</Departure>\n' +
                '\t\t\t\t\t\t\t\t\t<Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t</Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t<MarketingCarrier>\n' +
                '\t\t\t\t\t\t\t\t\t\t<!--航空公司二字码 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t\t\t\t\t\t\t<!--航班号 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t\t<FlightNumber>%s</FlightNumber>\n' +
                '\t\t\t\t\t\t\t\t\t</MarketingCarrier>\n', request.getOldDepAirportCode(), request.getOldDepDate(), request.getOldDepTime(), request.getOldArrAirportCode(),
                request.getOldArrDate(), request.getOldArrTime(), request.getOldCarrier(), request.getOldFlightNo()));
        if (StringUtils.isNotEmpty(request.getOldShareFlightNo())) {
            params.append('<!--如是共享航班才有此节点-->\n' +
                    '\t\t\t\t\t\t\t\t\t<OperatingCarrier>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<!--实际承运航司-->\n' +
                    '\t\t\t\t\t\t\t\t\t\t<AirlineID>' + request.getOldShareFlightNo().substring(0, 2) + '</AirlineID>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<!--航班号-->\n' +
                    '\t\t\t\t\t\t\t\t\t\t<FlightNumber>' + request.getOldShareFlightNo().substring(2, request.getOldShareFlightNo().length() + 1) + '</FlightNumber>\n' +
                    '\t\t\t\t\t\t\t\t\t</OperatingCarrier>\n');
        }
        params.append(String.format('\t\t\t\t\t\t\t\t\t<CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t\t<!--舱位 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t\t<Code>%s</Code>\n' +
                '\t\t\t\t\t\t\t\t\t</CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t<Equipment>\n' +
                '\t\t\t\t\t\t\t\t\t\t<!--机型 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t\t<AircraftCode>%s</AircraftCode>\n' +
                '\t\t\t\t\t\t\t\t\t</Equipment>\n' +
                '\t\t\t\t\t\t\t\t</Flight>\n' +
                '\t\t\t\t\t\t\t</OriginDestination>\n' +
                '\t\t\t\t\t\t</FlightItem>\n' +
                '\t\t\t\t\t</OrderItem>\n' +
                '\t\t\t\t\t<!--改升航段信息，由改升航段标识NEW+航段RPH组成-->\n' +
                '\t\t\t\t\t<OrderItem ObjectKey="NEW">\n' +
                '\t\t\t\t\t\t<FlightItem>\n' +
                '\t\t\t\t\t\t\t<OriginDestination>\n' +
                '\t\t\t\t\t\t\t\t<Flight>\n' +
                '\t\t\t\t\t\t\t\t\t<SegmentKey>1</SegmentKey>\n' +
                '\t\t\t\t\t\t\t\t\t<Departure>\n' +
                '\t\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Terminal/>\n' +
                '\t\t\t\t\t\t\t\t\t</Departure>\n' +
                '\t\t\t\t\t\t\t\t\t<Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Terminal/>\n' +
                '\t\t\t\t\t\t\t\t\t</Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t<MarketingCarrier>\n' +
                '\t\t\t\t\t\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t\t\t\t\t\t\t<FlightNumber>%s</FlightNumber>\n' +
                '\t\t\t\t\t\t\t\t\t</MarketingCarrier>\n', request.getOldCabinCode(), request.getOldFlightType(), request.getNewDepAirportCode(), request.getNewDepDate(),
                request.getNewDepTime(), request.getNewArrAirportCode(), request.getNewArrDate(), request.getNewArrTime(), request.getNewCarrier(), request.getNewFlightNo()));
        if (StringUtils.isNotEmpty(request.getNewShareFlightNo())) {
            params.append('\t\t\t\t\t\t\t\t\t<OperatingCarrier>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<AirlineID>' + request.getNewShareFlightNo().substring(0, 2) + '</AirlineID>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<FlightNumber>' + request.getOldShareFlightNo().substring(2, request.getNewShareFlightNo().length() + 1) + '</FlightNumber>\n' +
                    '\t\t\t\t\t\t\t\t\t</OperatingCarrier>\n');
        };
        params.append(String.format('\t\t\t\t\t\t\t\t\t<CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t\t<Code>%s</Code>\n' +
                '\t\t\t\t\t\t\t\t\t</CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t<Equipment>\n' +
                '\t\t\t\t\t\t\t\t\t\t<AircraftCode>%s</AircraftCode>\n' +
                '\t\t\t\t\t\t\t\t\t</Equipment>\n' +
                '\t\t\t\t\t\t\t\t</Flight>\n' +
                '\t\t\t\t\t\t\t</OriginDestination>\n' +
                '\t\t\t\t\t\t</FlightItem>\n' +
                '\t\t\t\t\t</OrderItem>\n' +
                '\t\t\t\t</OrderItems>\n' +
                '\t\t\t</Actions>\n' +
                '\t\t</Reshop>\n' +
                '\t</Query>\n' +
                '</ItinReshopRQ>', request.getNewCabinCode(), request.getNewFlightType()));
        String res = this.execute(params.toString(), request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/reissue');
        return GsonUtil.getGson().fromJson(res, ReissueRS.class);
    }

    /**
     * 改期升舱
     * @param request
     * @param url
     * @return
     */
    @Override
    DoBookRS dochange(DoBookRQ request, String url) {
        StringBuilder params = new StringBuilder(String.format('<OrderChangeRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '\t<Query>\n' +
                '\t\t<BookingReferences>\n' +
                '\t\t\t<BookingReference>\n' +
                '\t\t\t\t<!--订单号 必填-->\n' +
                '\t\t\t\t<ID>%s</ID>\n' +
                '\t\t\t\t<!--PNR号 必填-->\n' +
                '\t\t\t\t<OtherID>%s</OtherID>\n' +
                '\t\t\t</BookingReference>\n' +
                '\t\t</BookingReferences>\n' +
                '\t\t<!--改升旅客-->\n' +
                '\t\t<Passengers>\n', request.getOrderNo(), request.getPnr()));
        for (RQPassenger pa : request.getPassengers()) {
            String passenger = String.format('<!--ObjectKey 旅客编号 必填-->\n' +
                    '\t\t\t<Passenger ObjectKey="%s">\n' +
                    '\t\t\t\t<!--旅客类型 必填-->\n' +
                    '\t\t\t\t<PTC>ADT</PTC>\n' +
                    '\t\t\t\t<Name>\n' +
                    '\t\t\t\t\t<!--旅客名 必填-->\n' +
                    '\t\t\t\t\t<Surname>%s</Surname>\n' +
                    '\t\t\t\t</Name>\n' +
                    '\t\t\t\t<Contacts>\n' +
                    '\t\t\t\t\t<Contact>\n' +
                    '\t\t\t\t\t\t<!--电话 非必填-->\n' +
                    '\t\t\t\t\t\t<PhoneContact>\n' +
                    '\t\t\t\t\t\t\t<Number>%s</Number>\n' +
                    '\t\t\t\t\t\t</PhoneContact>\n' +
                    '\t\t\t\t\t</Contact>\n' +
                    '\t\t\t\t</Contacts>\n' +
                    '\t\t\t\t<Remarks>\n' +
                    '\t\t\t\t\t<!--旅客票号,如有多个，号分开 必填-->\n' +
                    '\t\t\t\t\t<Remark>%s</Remark>\n' +
                    '\t\t\t\t</Remarks>\n' +
                    '\t\t\t\t<PassengerIDInfo>\n' +
                    '\t\t\t\t\t<FOID>\n' +
                    '\t\t\t\t\t\t<!--证件类型-->\n' +
                    '\t\t\t\t\t\t<!--SFZ身份证/HZ护照/JRZ军人证/TWZ台胞证/HXZ回乡证/GATXZ港澳通行证-->\n' +
                    '\t\t\t\t\t\t<!--GJHY国际海员/YJJZ外国人永久居住证/LXZ旅行证/HKB户口薄/CSZ出生证明/QT其他-->\n' +
                    '\t\t\t\t\t\t<Type>%s</Type>\n' +
                    '\t\t\t\t\t\t<!--证件号 必填-->\n' +
                    '\t\t\t\t\t\t<ID>%s</ID>\n' +
                    '\t\t\t\t\t</FOID>\n' +
                    '\t\t\t\t</PassengerIDInfo>\n' +
                    '\t\t\t</Passenger>\n', pa.getPassengerNo(), pa.getPassengerName(), pa.getContactPhoneNo(), pa.getTicketNo(), pa.getCardType(), pa.getCardNo());
            params.append(passenger);
        }
        params.append(String.format('\t\t</Passengers>\n' +
                '\t\t<Order>\n' +
                '\t\t\t<OrderItems>\n' +
                '\t\t\t\t<!--航段信息标识ObjectKey 必填 原航段用OLD标识，新航段用NEW标识-->\n' +
                '\t\t\t\t<OrderItem ObjectKey="OLD">\n' +
                '\t\t\t\t\t<FlightItem>\n' +
                '\t\t\t\t\t\t<OriginDestination>\n' +
                '\t\t\t\t\t\t\t<Flight>\n' +
                '\t\t\t\t\t\t\t\t<!--航段RPH 必填-->\n' +
                '\t\t\t\t\t\t\t\t<SegmentKey>1</SegmentKey>\n' +
                '\t\t\t\t\t\t\t\t<!--出发信息 必填-->\n' +
                '\t\t\t\t\t\t\t\t<Departure>\n' +
                '\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t</Departure>\n' +
                '\t\t\t\t\t\t\t\t<!--到达信息 必填-->\n' +
                '\t\t\t\t\t\t\t\t<Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t</Arrival>\n' +
                '\t\t\t\t\t\t\t\t<MarketingCarrier>\n' +
                '\t\t\t\t\t\t\t\t\t<!--航空公司二字码 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t\t\t\t\t\t<!--航班号 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<FlightNumber>%s</FlightNumber>\n' +
                '\t\t\t\t\t\t\t\t</MarketingCarrier>\n', request.getOldDepAirportCode(), request.getOldDepDate(), request.getOldDepTime(),
                request.getOldArrAirportCode(), request.getOldArrDate(), request.getOldArrTime(), request.getOldCarrier(), request.getOldFlightNo()));
        if (StringUtils.isNotEmpty(request.getOldShareFlightNo())) {
            params.append('<!--如是共享航班才有此节点-->\n' +
                    '\t\t\t\t\t\t\t\t\t<OperatingCarrier>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<!--实际承运航司-->\n' +
                    '\t\t\t\t\t\t\t\t\t\t<AirlineID>' + request.getOldShareFlightNo().substring(0, 2) + '</AirlineID>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<!--航班号-->\n' +
                    '\t\t\t\t\t\t\t\t\t\t<FlightNumber>' + request.getOldShareFlightNo().substring(2, request.getOldShareFlightNo().length() + 1) + '</FlightNumber>\n' +
                    '\t\t\t\t\t\t\t\t\t</OperatingCarrier>\n');
        }
        params.append(String.format('\t\t\t\t\t\t\t\t<CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t<!--舱位 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<Code>%s</Code>\n' +
                '\t\t\t\t\t\t\t\t</CabinType>\n' +
                '\t\t\t\t\t\t\t\t<Equipment>\n' +
                '\t\t\t\t\t\t\t\t\t<!--机型 必填-->\n' +
                '\t\t\t\t\t\t\t\t\t<AircraftCode>%s</AircraftCode>\n' +
                '\t\t\t\t\t\t\t\t</Equipment>\n' +
                '\t\t\t\t\t\t\t</Flight>\n' +
                '\t\t\t\t\t\t</OriginDestination>\n' +
                '\t\t\t\t\t</FlightItem>\n' +
                '\t\t\t\t</OrderItem>\n' +
                '\t\t\t\t<!--改升航段信息，由改升航段标识NEW+航段RPH组成-->\n' +
                '\t\t\t\t<OrderItem ObjectKey="NEW">\n' +
                '\t\t\t\t\t<FlightItem>\n' +
                '\t\t\t\t\t\t<OriginDestination>\n' +
                '\t\t\t\t\t\t\t<Flight>\n' +
                '\t\t\t\t\t\t\t\t<SegmentKey>1</SegmentKey>\n' +
                '\t\t\t\t\t\t\t\t<Departure>\n' +
                '\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t<Terminal/>\n' +
                '\t\t\t\t\t\t\t\t</Departure>\n' +
                '\t\t\t\t\t\t\t\t<Arrival>\n' +
                '\t\t\t\t\t\t\t\t\t<AirportCode>%s</AirportCode>\n' +
                '\t\t\t\t\t\t\t\t\t<Date>%s</Date>\n' +
                '\t\t\t\t\t\t\t\t\t<Time>%s</Time>\n' +
                '\t\t\t\t\t\t\t\t\t<Terminal/>\n' +
                '\t\t\t\t\t\t\t\t</Arrival>\n' +
                '\t\t\t\t\t\t\t\t<MarketingCarrier>\n' +
                '\t\t\t\t\t\t\t\t\t<AirlineID>%s</AirlineID>\n' +
                '\t\t\t\t\t\t\t\t\t<FlightNumber>%s</FlightNumber>\n' +
                '\t\t\t\t\t\t\t\t</MarketingCarrier>\n', request.getOldCabinCode(), request.getOldFlightType(), request.getNewDepAirportCode(), request.getNewDepDate(),
                request.getNewDepTime(), request.getNewArrAirportCode(), request.getNewArrDate(), request.getNewArrTime(), request.getNewCarrier(), request.getNewFlightNo()));
        if (StringUtils.isNotEmpty(request.getNewShareFlightNo())) {
            params.append('\t\t\t\t\t\t\t\t\t<OperatingCarrier>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<AirlineID>' + request.getNewShareFlightNo().substring(0, 2) + '</AirlineID>\n' +
                    '\t\t\t\t\t\t\t\t\t\t<FlightNumber>' + request.getOldShareFlightNo().substring(2, request.getNewShareFlightNo().length() + 1) + '</FlightNumber>\n' +
                    '\t\t\t\t\t\t\t\t\t</OperatingCarrier>\n');
        }
        params.append(String.format('\t\t\t\t\t\t\t\t<CabinType>\n' +
                '\t\t\t\t\t\t\t\t\t<Code>%s</Code>\n' +
                '\t\t\t\t\t\t\t\t</CabinType>\n' +
                '\t\t\t\t\t\t\t\t<Equipment>\n' +
                '\t\t\t\t\t\t\t\t\t<AircraftCode>%s</AircraftCode>\n' +
                '\t\t\t\t\t\t\t\t</Equipment>\n' +
                '\t\t\t\t\t\t\t</Flight>\n' +
                '\t\t\t\t\t\t</OriginDestination>\n' +
                '\t\t\t\t\t</FlightItem>\n' +
                '\t\t\t\t</OrderItem>\n' +
                '\t\t\t</OrderItems>\n' +
                '\t\t</Order>\n' +
                '\t\t<Payments>\n' +
                '\t\t\t<Payment>\n' +
                '\t\t\t\t<Method/>\n' +
                '\t\t\t\t<!--改升需支付金额，若为免费，则可不填写-->\n' +
                '\t\t\t\t<Amount>%s</Amount>\n' +
                '\t\t\t</Payment>\n' +
                '\t\t</Payments>\n' +
                '\t</Query>\n' +
                '</OrderChangeRQ>', request.getNewCabinCode(), request.getNewFlightType(), request.getChangePayAmount()));
        String res = this.execute(params.toString(), request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/dochange');
        return GsonUtil.getGson().fromJson(res, DoBookRS.class);
    }
    /**
     * 取消改签
     * @param cancelChangeInVoRequestVo
     * @param url
     * @return
     */
    @Override
    ChangeOutVo cancelChange(CancelChangeInVo cancelChangeInVoRequestVo, String url) {
        String res = null;

        String params=String.format('<OrderCancelRQ xmlns="http://www.iata.org/IATA/EDIST" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '<Document>\n' +
                '<!-- 语种，默认中文 -->\n' +
                '<Name>zh_CN</Name>\n' +
                '</Document>\n' +
                '<Query>\n' +
                '<!-- 订单编号 必填 -->\n' +
                '<OrderID>%s</OrderID>\n' +
                '<BookingReferences>\n' +
                '<BookingReference>\n' +
                '<!-- PNR 必填 -->\n' +
                '<ID>%s</ID>\n' +
                '</BookingReference>\n' +
                '</BookingReferences>\n' +
                '</Query>\n' +
                '</OrderCancelRQ>',cancelChangeInVoRequestVo.getChangeOrderId(),cancelChangeInVoRequestVo.getPnr());
            res = this.execute(params, cancelChangeInVoRequestVo.getToken(),cancelChangeInVoRequestVo.getAccount(),cancelChangeInVoRequestVo.getPassword(), url, 'api/v1/cancelchange')
            ChangeOutVo cancelChangeOutVoResponseVo =  GsonUtil.getGson().fromJson( res, ChangeOutVo.class);
        return cancelChangeOutVoResponseVo;
    }

}
