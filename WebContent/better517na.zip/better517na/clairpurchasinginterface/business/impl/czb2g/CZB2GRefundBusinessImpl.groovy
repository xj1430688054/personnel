package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.czb2g


import com.better517na.javaloghelper.util.GsonUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.czb2g.ICZB2GRefundBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.AirDocDisplayRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.AirDocDisplayRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundApply.OrderViewRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundApply.RefundApplyReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.BookingReference
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.Description
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.OrderChangeRQ
import org.springframework.stereotype.Component

@Component
class CZB2GRefundBusinessImpl extends CZB2GBaseBusiness implements ICZB2GRefundBusiness {

    @Override
    AirDocDisplayRS getRefundOrderDetail(AirDocDisplayRQ airDocDisplayRQ, String url) {
        String params = String.format("<AirDocDisplayRQ xmlns=\"http://www.iata.org/IATA/EDIST\" Version=\"\">\n" +
                "\t<!--Version：版本 必填-->\n" +
                "  <Document>\n" +
                "    <Name>zh_CN</Name>\n" +
                "  </Document>\n" +
                "  <Query>\n" +
                "    <OrderID>\n" +
                "\t  <!--订单号-->\n" +
                "      <OrderID Owner=\"%s\">%s</OrderID>\n" +
                "    </OrderID>\n" +
                "  </Query>\n" +
                "</AirDocDisplayRQ>",airDocDisplayRQ.getOwner(),airDocDisplayRQ.getOrderID());
        String res = this.execute(params, airDocDisplayRQ.getToken(), airDocDisplayRQ.getAccount(), airDocDisplayRQ.getPassword(), url, 'api/v1/refund/detail');
        AirDocDisplayRS airDocDisplayRS = GsonUtil.getGson().fromJson(res,AirDocDisplayRS.class);
        return airDocDisplayRS;
    }

    @Override
    OrderViewRS applyRefund(RefundApplyReq refundApplyReq, String url) {
        String params = String.format("<OrderRetrieveRQ xmlns=\"http://www.iata.org/IATA/EDIST\" Version=\"15.2\">\n" +
                "  <!--Version：版本 必填-->\n" +
                "  <Document>\n" +
                "    <Name>zh_CN</Name>\n" +
                "  </Document>\n" +
                "  <Query>\n" +
                "    <Filters>\n" +
                "\t  <!--订单编号 必填-->\n" +
                "      <OrderID>%s</OrderID>\n" +
                "\t  <TicketDocument>\n" +
                "\t\t  <!--ebr从页面传来 -->\n" +
                "\t\t<TicketDocNbr>%s</TicketDocNbr>\n" +
                "\t  </TicketDocument>\n" +
                "      <BookingReferences>\n" +
                "        <BookingReference>\n" +
                "\t\t  <!--PNR 必填-->\n" +
                "          <ID>%s</ID>\n" +
                "        </BookingReference>\n" +
                "      </BookingReferences>\n" +
                "    </Filters>\n" +
                "  </Query>\n" +
                "</OrderRetrieveRQ>",refundApplyReq.getOrderID(),refundApplyReq.getTicketDocNbr(),refundApplyReq.getID());
        String res = this.execute(params, refundApplyReq.getToken(), refundApplyReq.getAccount(), refundApplyReq.getPassword(), url, 'api/v1/refund/apply');
        OrderViewRS orderViewRS = GsonUtil.getGson().fromJson(res,OrderViewRS.class);
        return orderViewRS;
    }

    @Override
    config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.OrderViewRS refundSubmit(OrderChangeRQ orderChangeRQ, String url) {
        String params = String.format("<OrderChangeRQ Version=\"15.2\" xmlns=\"http://www.iata.org/IATA/EDIST\">\n" +
                "  <!--Version：版本 必填-->\n" +
                "  <!--ID提交更改的字符串submitstr 必填  旅客编号*旅客类型/票号:航段,航段;@-->\n" +
                "  <!--多个航段已逗号(,)分隔，票号:航段多个已分号(;)分隔-->\n" +
                "  <!--例子:3*1/876-2326050878:1,2;876-2326050879:3;@-->\n" +
                "  <Document id=\""+orderChangeRQ.getDocumentId()+"\">\n" +
                "\t<!--ebrno 必填-->\n" +
                "\t<ReferenceVersion>"+orderChangeRQ.getReferenceVersion()+"</ReferenceVersion>\n" +
                "  </Document>\n" +
                "  <Party>\n" +
                "    <Sender>\n" +
                "      <TravelAgencySender>\n" +
                "        <Contacts>\n" +
                "          <Contact>\n" +
                "            <EmailContact>\n" +
                "\t\t\t  <!--联系Email 必填-->\n" +
                "              <Address>"+orderChangeRQ.getEmailAddress()+"</Address>\n" +
                "            </EmailContact>\n" +
                "            <PhoneContact>\n" +
                "\t\t\t  <!--联系电话 必填-->\n" +
                "              <Number>"+orderChangeRQ.getPhoneNumber()+"</Number>\n" +
                "            </PhoneContact>\n" +
                "          </Contact>\n" +
                "        </Contacts>\n" +
                "      </TravelAgencySender>\n" +
                "    </Sender>\n" +
                "  </Party>\n" +
                "  <Query>\n" +
                "    <Order>\n" +
                "\t  <!--订单号 必填-->\n" +
                "      <OrderID Owner=\""+orderChangeRQ.getOrderIDOwner()+"\">"+orderChangeRQ.getOderID()+"</OrderID>\n" +
                "      <OrderItems>\n" +
                "        <OrderItem>\n" +
                "\t\t  <!--PNR 必填-->\n" +
                "\t\t  <OrderItemID>"+orderChangeRQ.getOrderItemID()+"</OrderItemID>\n" +
                "\t\t  <!--上传附件，每个附件对应1个Description，最多五个 非必填-->\n" +
                "          <Disclosures>\n");
        if(orderChangeRQ.getDescriptions()!=null && orderChangeRQ.getDescriptions().size()>0){
            for(Description description : orderChangeRQ.getDescriptions()){
                params = params+"<Description>\n" +
                        "\t\t\t  <!--内容-->\n" +
                        "              <Text>"+description.getText()+"</Text>\n" +
                        "\t\t\t  <!--文件类型-->\n" +
                        "              <MarkupStyle>"+description.getMarkupStyle()+"</MarkupStyle>\n" +
                        "\t\t\t  <!--文件名-->\n" +
                        "              <Link>"+description.getLink()+"</Link>\n" +
                        "            </Description>\n";
            }

        }
        params = params+"</Disclosures>\n" +
                "        </OrderItem>\n" +
                "      </OrderItems>\n" +
                "    </Order>\n" +
                "    <BookingReferences>\n";
        if(orderChangeRQ.getBookingReferences().size()>0){
            for(BookingReference bookingReference : orderChangeRQ.getBookingReferences()){
                params = params + "       <BookingReference>\n" +
                        "        <Type>\n" +
                        "          <Code>"+bookingReference.getTypeCode()+"</Code>\n" +
                        "        </Type>\n" +
                        "        <ID>"+bookingReference.getID()+"</ID>\n" +
                        "        <AirlineID>"+bookingReference.getAirlineID()+"</AirlineID>\n" +
                        "      </BookingReference>\n";
            }
        }
        params = params + "    </BookingReferences>\n" +
                "  </Query>\n" +
                "</OrderChangeRQ>";
        String res = this.execute(params, orderChangeRQ.getToken(), orderChangeRQ.getAccount(), orderChangeRQ.getPassword(), url, 'api/v1/refund/submit');
        config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.OrderViewRS orderViewRS = GsonUtil.getGson().fromJson(res,config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.OrderViewRS.class);
        return orderViewRS;
    }
}
