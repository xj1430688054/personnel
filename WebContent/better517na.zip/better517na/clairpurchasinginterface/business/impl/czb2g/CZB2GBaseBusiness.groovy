package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.czb2g

import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.redis.helper.RedisHelper
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.HttpBaseBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.accessToken.CustomerInputRS
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

import javax.annotation.Resource

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/24
 * Time: 16:32
 */
@Component
class CZB2GBaseBusiness extends HttpBaseBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * redis路由组件.
     */
    @Resource(name = 'redisHelper')
    private RedisHelper redisHelper;

    /**
     * Redis保存的时效（单位：秒）.
     */
    @Value('${redis.czb2gTokenEffectTime:86400}')
    private int redisEffectTime;

    /**
     * 请求接口.
     * @param request 请求参数.
     * @param token token.
     * @param account 企业账号.
     * @param password 密码.
     * @param accept 可选application/xml或application/json.
     * @param domain 域名.
     * @param subModule 子模块.
     * @return 结果.
     */
    public String execute(String request, String token, String account, String password, String accept, String domain, String subModule) {
        return execute(request, token, account, password, 'application/xml', accept, domain, subModule);
    }

    /**
     * 请求接口.
     * @param request 请求参数.
     * @param token token.
     * @param account 企业账号.
     * @param password 密码.
     * @param domain 域名.
     * @param subModule 子模块.
     * @return 结果.
     */
    public String execute(String request, String token, String account, String password, String domain, String subModule) {
        return execute(request, token, account, password, 'application/xml', 'application/json', domain, subModule);
    }

    /**
     * 请求接口.
     * @param request 请求参数.
     * @param token token.
     * @param account 企业账号.
     * @param password 密码.
     * @param contentType 可选application/xml或application/json.
     * @param accept 可选application/xml或application/json.
     * @param domain 域名.
     * @param subModule 子模块.
     * @return 结果.
     */
    public String execute(String request, String token, String account, String password, String contentType, String accept, String domain, String subModule) {
        // 若token为空则从Redis取，若未取到则请求接口获取并存Redis
        if (StringUtil.isStringParamNotLegal(token)) {
            // 取redis  Key:CZB2G_TOKEN_账号
            try {
                token = this.redisHelper.getValue('CZB2G_TOKEN_' + account);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'key取Redis异常', e.getMessage(), e));
            }

            // 若未取到则请求接口获取并存Redis
            if (StringUtil.isStringParamNotLegal(token)) {
                token = this.getTokenAndSetRedis(account, password, domain);
            }
        }

        // 发起请求
        String res = this.doPost(request, token, contentType, accept, domain, subModule);

        // 若响应token已过期则调接口获取token并存Redis，然后重新请求一次 (南航B2G的人说的是token距上一次使用时间24小时则会过期)
        /* token过期的表现：shopping接口：<Error Code="0004">获取不到用户信息</Error>
         运价获取接口：<Error Code="">用户无权限</Error>
         预订接口：<Error ShortText="登录异常！" Code="">登录失效！</Error>
         支付接口：<Error ShortText="系统用户信息获取失败" Code="pay_001"/>
         出票接口：<Error ShortText="获取用户失败" Code="MESSAGE"/>
         订单详情查询接口：<Error ShortText="获取失败" Code="order_002">系统用户信息</Error> */
        if (res.contains('获取不到用户信息') || res.contains('用户无权限') || res.contains('登录失效') ||
                res.contains('系统用户信息获取失败') || res.contains('获取用户失败')) {
            token = this.getTokenAndSetRedis(account, password, domain);
            res = this.doPost(request, token, contentType, accept, domain, subModule);
        }
        return res;
    }

    /**
     * 用户认证.
     * @param account 企业账号.
     * @param password 密码.
     * @param url url.
     * @return 返回token.
     */
    String accessToken(String account, String password, String url) {
        String token = '';
        String params = String.format('<?xml version="1.0" encoding="UTF-8"?>\n' +
                '<CustomerInputRQ xmlns="http://www.iata.org/IATA/EDIST" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.iata.org/IATA/EDIST" Version="">\n' +
                '\t<Document/>\n' +
                '\t<Query>\n' +
                '\t\t<TravelerAuthentication>\n' +
                '\t\t\t<AuthRequest>\n' +
                '\t\t\t\t<AuthAccount>\n' +
                '\t\t\t\t\t<AccountID>%s</AccountID><!-- 登录密码 -->\n' +
                '\t\t\t\t\t<AccountName>%s</AccountName><!-- 用户名 -->\n' +
                '\t\t\t\t</AuthAccount>\n' +
                '\t\t\t</AuthRequest>\n' +
                '\t\t</TravelerAuthentication>\n' +
                '\t</Query>\n' +
                '</CustomerInputRQ>', password, account);

        // 响应json格式的
        String res = this.doPost(params, '', 'application/json', url, "api/v1/auth/accesstoken");
        CustomerInputRS customerInputRS = GsonUtil.getGson().fromJson(res, CustomerInputRS.class);
        if (customerInputRS != null && customerInputRS.getResponse() != null && customerInputRS.getResponse().getTravelerAuthentication() != null
                && customerInputRS.getResponse().getTravelerAuthentication().getAuthResponse() != null
                && customerInputRS.getResponse().getTravelerAuthentication().getAuthResponse().getAuthAccount() != null) {
            token = customerInputRS.getResponse().getTravelerAuthentication().getAuthResponse().getAuthAccount().getAccountID()
        }

        // 响应xml格式的 xml的反序列化有性能问题
//        res = this.doPost(params, '', 'application/xml', url, "api/v1/auth/accesstoken");
//
//        startTime = System.currentTimeMillis();
//        com.better517na.czb2gService.CustomerInputRS customerInput = JAXB.unmarshal(new StringReader(res), com.better517na.czb2gService.CustomerInputRS.class);
//        if (customerInput != null && customerInput.getResponse() != null && customerInput.getResponse().getTravelerAuthentication() != null
//                && customerInput.getResponse().getTravelerAuthentication().getAuthResponse() != null
//                && customerInput.getResponse().getTravelerAuthentication().getAuthResponse().getAuthAccount() != null) {
//            token = customerInput.getResponse().getTravelerAuthentication().getAuthResponse().getAuthAccount().getAccountID()
//        }
//        endTime = System.currentTimeMillis();
//        totalTime = endTime - startTime;
//        System.out.println("2:" + totalTime);
        return token;
    }

    /**
     * 获取token并存Redis.
     * @param account 企业账号.
     * @param password 密码.
     * @param url url.
     * @return 返回token.
     */
    String getTokenAndSetRedis(String account, String password, String url) {
        // 获取token
        String token = accessToken(account, password, url);

        // 存到Redis
        try {
            String key = 'CZB2G_TOKEN_' + account;
            this.redisHelper.setValue(key, token, redisEffectTime);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'key存Redis异常', e.getMessage(), e));
        }

        return token;
    }

    /**
     * post请求.
     * @param params 请求参数.
     * @param token token.
     * @param domain 域名.
     * @param subModule 子模块.
     * @return 结果.
     */
    String doPost(String params, String token, String domain, String subModule) {
        return doPost(params, token, 'application/xml', 'application/json', domain, subModule);
    }

    /**
     * post请求.
     * @param params 请求参数.
     * @param token token.
     * @param domain 域名.
     * @param subModule 子模块.
     * @return 结果.
     */
    String doPost(String params, String token, String accept, String domain, String subModule) {
        return doPost(params, token, 'application/xml', accept, domain, subModule);
    }

    /**
     * post请求.
     * @param params 请求参数.
     * @param token token.
     * @param contentType 可选application/xml或application/json.
     * @param accept 可选application/xml或application/json.
     * @param domain 域名.
     * @param subModule 子模块.
     * @return 结果.
     */
    String doPost(String params, String token, String contentType, String accept, String domain, String subModule) {
        String url = '';
        String result = null;
        HttpResponse httpResponse = null;
        long totalTime = 0;
        try {
            if (!domain.endsWith('/')) {
                domain = domain + '/';
            }
            url = domain + subModule;
            System.out.print("请求地址：");
            System.out.println(url);
            System.out.print("请求参数：");
            System.out.println(params);
            StringEntity se = new StringEntity(params, 'UTF-8');
            if (params != null && params.length() > 0) {
                se.setContentEncoding('UTF-8');
                se.setContentType(contentType);
            }

            long begin = System.currentTimeMillis();
            HttpPost httpPost = new HttpPost(url);
            httpPost.setHeader('Content-Type', contentType + ';charset=UTF-8');
            httpPost.setHeader('Accept', accept);
            httpPost.setHeader('Accept-Encoding', 'gzip, deflate');
            httpPost.setHeader('Accept-Language', 'zh-CN,zh;q=0.9');
            if (!StringUtil.isStringParamNotLegal(token)) {
                httpPost.setHeader('token', token);
            }
            if (se != null && se.getContentLength() > 0) {
                httpPost.setEntity(se);
            }
            HttpClient httpsClient = HttpClients.createDefault();
            httpResponse = httpsClient.execute(httpPost);
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, 'utf-8');
            }
            EntityUtils.consume(entity);
            httpPost.abort();
            totalTime = System.currentTimeMillis() - begin;
            if (StringUtil.isStringParamNotLegal(result)) {
                int statusCode = httpResponse.getStatusLine().getStatusCode();
                if (statusCode != 200) {
                    httpPost.abort();
                    throw new RuntimeException('HttpClient,error status code :' + statusCode);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'HTTP请求异常', e.getMessage(), e));
            throw e;
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            this.setLogBusiness(this.logBusiness);
            writeInteractionLog('南航B2G接口', subModule, url, params, result, String.valueOf(totalTime), token);
        }
        return result;
    }
}
