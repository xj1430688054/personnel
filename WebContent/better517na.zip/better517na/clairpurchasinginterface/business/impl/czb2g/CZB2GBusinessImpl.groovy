package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.czb2g

import com.better517na.clairpurchasinginterface.utils.DateUtil
import com.better517na.clairpurchasinginterface.utils.SignUtils
import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.better517na.javaloghelper.util.GsonUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.czb2g.ICZB2GBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book.BookReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book.OrderViewRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book.PassengerInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail.Czb2gOrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail.OrderDetailReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment.CZPayRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment.CZpayResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price.FlightPriceRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price.PriceFlight
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price.PriceOriginDestination
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price.PriceReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.AirShoppingRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.ShoppingReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.ticketIssue.CZticketIssueRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.ticketIssue.CZticketIssueResponse
import org.springframework.stereotype.Component

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/24
 * Time: 16:31
 */
@Component
class CZB2GBusinessImpl extends CZB2GBaseBusiness implements ICZB2GBusiness {
    /**
     * 用户认证.
     * @param account 企业账号.
     * @param password 密码.
     * @param url url.
     * @return 返回token.
     */
    @Override
    String accessToken(String account, String password, String url) {
        return super.accessToken(account, password, url);
    }

    /**
     * 航班查询.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    AirShoppingRS shopping(ShoppingReq request, String url) {
        // 根据出发到达起飞日志查询航班信息
        String params = String.format('<AirShoppingRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '  <Party>\n' +
                '    <Sender>\n' +
                '      <TravelAgencySender>\n' +
                '        <OtherIDs>\n' +
                '          <!--航程类型 0单程 1往返 2多段 必填-->\n' +
                '          <OtherID Description="FltType">0</OtherID>\n' +
                '          <!--是否返回价格日历 1：返回 0 不返回，不填写此参数，默认1返回-->\n' +
                '          <OtherID Description="showCalendar">0</OtherID>\n' +
                '        </OtherIDs>\n' +
                '      </TravelAgencySender>\n' +
                '    </Sender>\n' +
                '  </Party>\n' +
                '  <CoreQuery>\n' +
                '    <!--查询航班 若是多段则有多个OriginDestination-->\n' +
                '    <OriginDestinations>\n' +
                '      <!--单个航程-->\n' +
                '      <OriginDestination>\n' +
                '        <Departure>\n' +
                '          <!--起飞机场-->\n' +
                '          <AirportCode>%s</AirportCode>\n' +
                '          <!--起飞日期-->\n' +
                '          <Date>%s</Date>\n' +
                '        </Departure>\n' +
                '        <Arrival>\n' +
                '          <!--到达机场-->\n' +
                '          <AirportCode>%s</AirportCode>\n' +
                '        </Arrival>\n' +
                '      </OriginDestination>\n' +
                '    </OriginDestinations>\n' +
                '  </CoreQuery>\n' +
                '</AirShoppingRQ>', request.getDepAirportCode(), request.getDepDate(), request.getArrAirportCode());
        String res = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/shopping/domestic')

        // 反序列化成对象再返回
//        long startTime = System.currentTimeMillis();
        AirShoppingRS airShoppingRS = GsonUtil.getGson().fromJson(res, AirShoppingRS.class);
//        long endTime = System.currentTimeMillis();
//        Long totalTime = endTime - startTime;
//        System.out.println("airShoppingRS反序列化耗时:" + totalTime);
        return airShoppingRS;
    }

    /**
     * 运价查询.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    FlightPriceRS price(PriceReq request, String url) {
        String params = '<FlightPriceRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">  \n' +
                '  <Document> \n' +
                '    <Name>zh_CN</Name> \n' +
                '  </Document>  \n' +
                '  <Party> \n' +
                '    <Sender> \n' +
                '      <TravelAgencySender> \n' +
                '        <OtherIDs> \n' +
                '          <!--航程类型 0单程  1往返  2多段 必填-->  \n' +
                '          <OtherID Description="FltType">0</OtherID>  \n' +
                '          <!--国际国内 D国内 I国际 必填-->  \n' +
                '          <OtherID Description="IsInter">D</OtherID>  \n' +
                '          <!--人数 必填-->  \n' +
                '          <OtherID Description="PsgNum">' + request.getPsgNum() + '</OtherID> \n' +
                '        </OtherIDs>  \n' +
                '        <!--用户名-->  \n' +
                '        <AgencyID>' + request.getAccount() + '</AgencyID> \n' +
                '      </TravelAgencySender> \n' +
                '    </Sender> \n' +
                '  </Party>  \n' +
                '  <Query> \n' +
                '    <!--航段信息 单程则对应一个OriginDestination，若存在中转，则一个OriginDestination下包含两个Flight； 往返对应两个OriginDestination-->  \n';
        for (PriceOriginDestination item : request.getPriceOriginDestinations()) {
            params = params + '    <OriginDestination> \n' +
                    '      <OriginDestinationKey>' + item.getOriginDestinationKey() + '</OriginDestinationKey><!--航程RPH--> \n';
            for (PriceFlight priceFlight : item.getPriceFlights()) {
                String priceFlightXml = '      <Flight> \n' +
                        '        <!--出发地信息-->  \n' +
                        '        <Departure> \n' +
                        '          <AirportCode>' + priceFlight.getDepAirportCode() + '</AirportCode>  \n' +
                        '          <Date>' + DateUtil.dateToString(priceFlight.getDepDate(), 'yyyy-MM-dd') + '+08:00</Date>  \n' +
                        '          <Time>' + DateUtil.dateToString(priceFlight.getDepDate(), 'HH:mm') + '</Time> \n' +
                        '        </Departure>  \n' +
                        '        <!--到达地信息-->  \n' +
                        '        <Arrival> \n' +
                        '          <AirportCode>' + priceFlight.getArrAirportCode() + '</AirportCode>  \n' +
                        '          <Date>' + DateUtil.dateToString(priceFlight.getArrDate(), 'yyyy-MM-dd') + '+08:00</Date>  \n' +
                        '          <Time>' + DateUtil.dateToString(priceFlight.getArrDate(), 'HH:mm') + '</Time> \n' +
                        '        </Arrival>  \n';
                if (!StringUtil.isStringParamNotLegal(priceFlight.getShareFlightNo())) {
                    priceFlightXml = priceFlightXml +
                            '        <!--共享航班信息-->  \n' +
                            '        <MarketingCarrier> \n' +
                            '          <AirlineID>' + priceFlight.getShareFlightNo().substring(0, 2) + '</AirlineID>  \n' +
                            '          <FlightNumber>' + priceFlight.getShareFlightNo().substring(2, priceFlight.getShareFlightNo().length()) + '</FlightNumber> \n' +
                            '        </MarketingCarrier>  \n';
                }
                priceFlightXml = priceFlightXml +
                        '        <!--机型-->  \n' +
                        '        <Equipment> \n' +
                        '          <AircraftCode>' + priceFlight.getAircraftCode() + '</AircraftCode> \n' +
                        '        </Equipment>  \n' +
                        '        <!--国内票：seq、国际票：舱位代码-->  \n' +
                        '        <CabinType> \n' +
                        '          <Code>' + priceFlight.getCabinSeq() + '</Code> \n' +
                        '        </CabinType>  \n' +
                        '        <!--舱等 头等舱：F，商务舱：C，明珠经济舱：P，经济舱：Y-->  \n' +
                        '        <ClassOfService> \n' +
                        '          <Code>' + priceFlight.getCabinClass() + '</Code> \n' +
                        '        </ClassOfService> \n' +
                        '      </Flight> \n';
                params = params + priceFlightXml;
            }
            params = params + '    </OriginDestination> \n';
        }
        params = params + '  </Query> \n' +
                '</FlightPriceRQ>';
        String res = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/price');
        FlightPriceRS flightPriceRS = GsonUtil.getGson().fromJson(res, FlightPriceRS.class);
        return flightPriceRS;
    }

    /**
     * 预订.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    OrderViewRS book(BookReq request, String url) {
        String params = '<OrderCreateRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">  \n' +
                '  <Document> \n' +
                '    <Name>zh_CN</Name> \n' +
                '  </Document>  \n' +
                '  <Party> \n' +
                '    <Sender> \n' +
                '      <TravelAgencySender> \n' +
                '        <Contacts> \n' +
                '          <!--联系人信息-->  \n' +
                '          <Contact> \n' +
                '            <!--联系人手机-->  \n' +
                '            <PhoneContact> \n' +
                '              <Number>' + request.getContactPhone() + '</Number> \n' +
                '            </PhoneContact>  \n' +
                '            <!--联系人邮箱-->  \n' +
                '            <EmailContact> \n' +
                '              <Address>' + request.getContactEmail() + '</Address> \n' +
                '            </EmailContact>  \n' +
                '            <!--联系人名字-->  \n' +
                '            <Name> \n' +
                '              <Surname>' + request.getContactName() + '</Surname> \n' +
                '            </Name> \n' +
                '          </Contact> \n' +
                '        </Contacts>  \n' +
                '        <OtherIDs> \n' +
                '          <!-- OtherID需要按已下顺序填写：FltType、IsInter、isToUSAObj、fareType -->  \n' +
                '          <!--航程类型 0单程  1往返 必填-->  \n' +
                '          <OtherID Description="FltType">0</OtherID>  \n' +
                '          <!--国际国内 D国内 I国际 必填-->  \n' +
                '          <OtherID Description="IsInter">D</OtherID>  \n' +
                '          <!--是否赴美航班 必填-->  \n' +
                '          <OtherID Description="isToUSAObj">false</OtherID>  \n' +
                '          <!--成本中心id-->  \n' +
                '          <!--<OtherID Description="selectedCostCenterId">201812191416492721</OtherID>-->  \n' +
                '          <!-- 航段的seg_no/价格类型-->  \n' +
                '          <OtherID Description="fareType">' + request.getFareType() + '</OtherID> \n' +
                '        </OtherIDs> \n' +
                '      </TravelAgencySender> \n' +
                '    </Sender> \n' +
                '  </Party>  \n' +
                '  <Query> \n' +
                '    <!--旅客列表-->  \n' +
                '    <Passengers> \n';
        for (PassengerInfo item : request.getPassengers()) {
            String surname = ''; // 姓
            String given = ''; // 名
            // 判断是否有‘/’
            if (item.getPsgName().contains('/')) {
                String[] nameStrings = item.getPsgName().split('/');
                surname = nameStrings[0];
                given = nameStrings[1];
            } else {
                surname = item.getPsgName().substring(0, 1); // 旅客中文姓(第一个字)
                given = item.getPsgName().substring(1); // 旅客中文名
            }
            String passengerXml =
                    '      <Passenger ObjectKey="' + item.getPsgPhone() + '"> \n' +
                            '        <!--PTC乘机人选择方式，1：员工，2：常用乘机人，3：手动输入 固定值2-->  \n' +
                            '        <PTC>2</PTC>  \n' +
                            '        <Name> \n' +
                            '          <!--姓-->  \n' +
                            '          <Surname>' + surname + '</Surname>  \n' +
                            '          <!--名-->  \n' +
                            '          <Given>' + given + '</Given>  \n' +
                            '          <!--Middle名称类型zh_cn：中文/english :英文-->  \n' +
                            '          <Title>' + item.getPsgNameType() + '</Title> \n' +
                            '        </Name>  \n' +
                            '        <!--国际必填，性别 男M女F-->  \n' +
                            '        <Gender>' + item.getGender() + '</Gender>  \n' +
                            '        <PassengerIDInfo> \n' +
                            '          <!---证件-->  \n' +
                            '          <PassengerDocument> \n' +
                            '            <!--证件类型 SFZ :身份证,HZ  :护照,JRZ :军人证,TWZ :台胞证,HXZ :回乡证,GATX:港澳通行证,GJHY:国际海员证,YJJZ:外国人永久居住证,LXZ :旅行证,HKB :户口簿,CSZ :出生证明,QT  :其他-->  \n' +
                            '            <Type>' + item.getCardType() + '</Type>  \n' +
                            '            <!--证件ID-->  \n' +
                            '            <ID>' + item.getCardNo() + '</ID>  \n' +
                            '            <!--生日 (格式"YYYY-MM-DD")-->  \n' +
                            '            <BirthCountry>' + item.getBirthday() + '</BirthCountry> \n' +
                            '          </PassengerDocument> \n' +
                            '        </PassengerIDInfo> \n' +
                            '      </Passenger>  \n';
            params += passengerXml;
        }
        params += '    </Passengers> \n' +
                '  </Query> \n' +
                '</OrderCreateRQ>';
        String res = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/book');
        // String res = '{"party":{"sender":{"travelAgencySender":{"metadata":[],"refs":[],"contacts":{"contact":[{"emailContact":{"address":{"value":"287994374@qq.com","refs":[],"objectMetaReferences":[]},"refs":[]},"phoneContact":{"refs":[],"number":[{"value":"18382212520","refs":[]}]},"name":{"surname":{"value":"刘小婷","refs":[]},"given":[],"middle":[],"refs":[],"objectMetaReferences":[]}}]},"otherIDs":{"otherID":[{"value":"0","description":"FltType","refs":[]},{"value":"D","description":"IsInter","refs":[]},{"value":"false","description":"isToUSAObj","refs":[]},{"value":"0/0","description":"fareType","refs":[]}]}}}},"success":{},"response":{"passengers":{"passenger":[{"refs":[],"objectKey":"18382212520","ptc":{"value":"2"},"name":{"surname":{"value":"徐","refs":[]},"given":[{"value":"嘉俊","refs":[]}],"title":"zh_cn","middle":[],"refs":[],"objectMetaReferences":[]},"gender":{"refs":[]},"passengerIDInfo":{"passengerDocument":[{"type":"SFZ","id":"310108199003133811","birthCountry":"1990-03-13"}]}}]},"order":[{"metadataToken":"2019-01-30 17:16","refs":[],"orderID":{"value":"RN201901301631413158","owner":"CZB2B","refs":[],"objectMetaReferences":[]},"bookingReferences":{"bookingReference":[{"refs":[],"type":{"refs":[],"code":"OrderStatus"},"id":"1"},{"refs":[],"type":{"refs":[],"code":"PNR"},"id":"NEWWMH"}]},"totalOrderPrice":{"detailCurrencyPrice":{"refs":[],"total":{"value":5710.0,"taxable":true},"details":{"refs":[],"detail":[{"subTotal":{"value":5660.0,"taxable":true},"refs":[]}]},"taxes":{"refs":[],"total":{"value":0.0,"taxable":true}},"fees":{"refs":[],"total":{"value":50.0,"taxable":true}}}},"orderItems":{"orderItem":[{"refs":[],"flightItem":{"refs":[],"originDestination":[{"flight":[{"segmentKey":"5660.0","departure":{"refs":[],"airportCode":{"value":"CTU"},"date":1556064900000},"arrival":{"refs":[],"airportCode":{"value":"PEK"},"date":1556074500000},"marketingCarrier":{"refs":[],"airlineID":{"value":"CZ","refs":[],"objectMetaReferences":[]},"name":"33B","flightNumber":{"value":"6120"}},"cabinType":{"refs":[],"code":"C","name":"公务舱","originDestinationReferences":[]},"classOfService":{"code":{"value":"J"},"refs":[]},"details":{"refs":[],"stops":{"stopLocations":{"stopLocation":[{"refs":[],"airportCode":{"value":"CZ6120","refs":[]}},{"refs":[]}]}},"resDateTime":{"date":{}}},"refs":[]}],"refs":[]}]}}]}}]},"target":"Production"}'
        // String res = '{"party":{"sender":{"travelAgencySender":{"metadata":[],"refs":[],"contacts":{"contact":[{"emailContact":{"address":{"value":"287994374@qq.com","refs":[],"objectMetaReferences":[]},"refs":[]},"phoneContact":{"refs":[],"number":[{"value":"18382212520","refs":[]}]},"name":{"surname":{"value":"刘小婷","refs":[]},"given":[],"middle":[],"refs":[],"objectMetaReferences":[]}}]},"otherIDs":{"otherID":[{"value":"0","description":"FltType","refs":[]},{"value":"D","description":"IsInter","refs":[]},{"value":"false","description":"isToUSAObj","refs":[]},{"value":"0/0","description":"fareType","refs":[]}]}}}},"success":{},"response":{"passengers":{"passenger":[{"refs":[],"objectKey":"18382212520","ptc":{"value":"2"},"name":{"surname":{"value":"徐","refs":[]},"given":[{"value":"嘉俊","refs":[]}],"title":"zh_cn","middle":[],"refs":[],"objectMetaReferences":[]},"gender":{"refs":[]},"passengerIDInfo":{"passengerDocument":[{"type":"SFZ","id":"310108199003133811","birthCountry":"1990-03-13"}]}},{"refs":[],"objectKey":"18382212520","ptc":{"value":"2"},"name":{"surname":{"value":"孙","refs":[]},"given":[{"value":"晶","refs":[]}],"title":"zh_cn","middle":[],"refs":[],"objectMetaReferences":[]},"gender":{"refs":[]},"passengerIDInfo":{"passengerDocument":[{"type":"SFZ","id":"310101198703070525","birthCountry":"1987-03-07"}]}}]},"order":[{"metadataToken":"2019-01-31 11:35","refs":[],"orderID":{"value":"RN201901311050153175","owner":"CZB2B","refs":[],"objectMetaReferences":[]},"bookingReferences":{"bookingReference":[{"refs":[],"type":{"refs":[],"code":"OrderStatus"},"id":"1"},{"refs":[],"type":{"refs":[],"code":"PNR"},"id":"MC567Y"}]},"totalOrderPrice":{"detailCurrencyPrice":{"refs":[],"total":{"value":11420.0,"taxable":true},"details":{"refs":[],"detail":[{"subTotal":{"value":11320.0,"taxable":true},"refs":[]}]},"taxes":{"refs":[],"total":{"value":0.0,"taxable":true}},"fees":{"refs":[],"total":{"value":100.0,"taxable":true}}}},"orderItems":{"orderItem":[{"refs":[],"flightItem":{"refs":[],"originDestination":[{"flight":[{"segmentKey":"5660.0","departure":{"refs":[],"airportCode":{"value":"CTU"},"date":1556064900000},"arrival":{"refs":[],"airportCode":{"value":"PEK"},"date":1556074500000},"marketingCarrier":{"refs":[],"airlineID":{"value":"CZ","refs":[],"objectMetaReferences":[]},"name":"33B","flightNumber":{"value":"6120"}},"cabinType":{"refs":[],"code":"C","name":"公务舱","originDestinationReferences":[]},"classOfService":{"code":{"value":"J"},"refs":[]},"details":{"refs":[],"stops":{"stopLocations":{"stopLocation":[{"refs":[],"airportCode":{"value":"CZ6120","refs":[]}},{"refs":[]}]}},"resDateTime":{"date":{}}},"refs":[]}],"refs":[]}]}}]}}]},"target":"Production"}'
        OrderViewRS orderViewRS = GsonUtil.getGson().fromJson(res, OrderViewRS.class);
        return orderViewRS;
    }

    /**
     * 支付.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    CZpayResponse payment(CZPayRequest request, String url) {
        /**拼接 签名 :"订单号" + "&" +"PNR编号" + "&" +"订单用户ID" + "&" +"支付银行ID" + "&" +"合作方支付单号" + "&" +"合作方ID" + "&" +"合作方签名方式" + "&"
         + "合作方签名秘钥"+ "&" + "合作方签名秘钥"*/
        String sign = request.getOrderId() + '&' + request.getPnr() + '&' + request.getOrderUserId() + '&' + request.getPayBankId() + '&' + request.getPtOrderId() + '&' +
                request.getOrderUserId() + '&MD5&' + request.getSignSecretKey() + '&' + request.getSignSecretKey();
        //先将签名 MD5 加密
        //再 把二进制转化为小写的十六进制(32位小写字符串)
        String sign_MD5 = SignUtils.byte2hex(SignUtils.encryptMD5(sign)).toLowerCase();

        String params = '<?xml version="1.0" encoding="UTF-8"?>\n' +
                '<AirDocIssueRQ xmlns="http://www.iata.org/IATA/EDIST" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.iata.org/IATA/EDIST" Version="">\n' +
                '\t<Document>\n' +
                '\t\t<Name>zh_CN</Name>\n' +
                '\t</Document>\n' +
                '\t<!--合作方信息-->\n' +
                '\t<Party>\n' +
                '\t\t<Sender>\n' +
                '\t\t\t<TravelAgencySender>\n' +
                '\t\t\t\t<!-- 合作方ID 必填-->\n' +
                '\t\t\t\t<AgencyID>' + request.getOrderUserId() + '</AgencyID>\n' +
                '\t\t\t</TravelAgencySender>\n' +
                '\t\t</Sender>\n' +
                '\t</Party>\n' +
                '\t<!--支付信息-->\n' +
                '\t<Query>\n' +
                '\t\t<TicketDocInfo>\n' +
                '\t\t\t<TravelerInfo>\n' +
                '\t\t\t\t<Surname/>\n' +
                '\t\t\t\t<Given/>\n' +
                '\t\t    </TravelerInfo>\n' +
                '\t\t\t<OrderReference>\n' +
                '\t\t\t\t<!--订单编号 必填-->\n' +
                '\t\t\t\t<OrderID>' + request.getOrderId() + '</OrderID>\n' +
                '\t\t\t\t<!--PNR编号 必填-->\n' +
                '\t\t\t\t<OrderItemID>' + request.getPnr() + '</OrderItemID>\n' +
                '\t\t\t\t<!--订单用户ID 必填-->\n' +
                '\t\t\t\t<OfferItemID>' + request.getOrderUserId() + '</OfferItemID>\n' +
                '\t\t\t</OrderReference>\n' +
                '\t\t\t<BookingReference>\n' +
                '\t\t\t\t<!--合作方支付单号 必填-->\n' +
                '\t\t\t\t<ID>' + request.getPtOrderId() + '</ID>\n' +
                '\t\t\t\t<!--合作方签名方式、签名 必填-->\n' +
                '\t\t\t\t<OtherID Name="' + request.getSignType() + '">' + sign_MD5 + '</OtherID>\n' +
                '\t\t\t</BookingReference>\n' +
                '\t\t\t<Payments>\n' +
                '\t\t\t\t<Payment>\n' +
                '\t\t\t\t\t<Type>\n' +
                '\t\t\t\t\t\t<Code></Code>\n' +
                '\t\t\t\t\t</Type>\n' +
                '\t\t\t\t\t<!--货币、支付金额 必填-->\n' +
                '\t\t\t\t\t<Amount Code="CNY">' + request.getPayMoney() + '</Amount>\n' +
                '\t\t\t\t\t<BankAccount>\n' +
                '\t\t\t\t\t\t<!--支付银行ID、BankID:ALIPAYCHARGE 必填-->\n' +
                '\t\t\t\t\t\t<BankID>' + request.getPayBankId() + '</BankID>\n' +
                '\t\t\t\t\t</BankAccount>\n' +
                '\t\t\t\t</Payment>\n' +
                '\t\t\t</Payments>\n' +
                '\t\t</TicketDocInfo>\n' +
                '\t</Query>\n' +
                '</AirDocIssueRQ>';
        String str = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, request.getSubUrl());
        CZpayResponse cZpayResponse = GsonUtil.getGson().fromJson(str, CZpayResponse.class);
        return cZpayResponse;
    }

    /**
     * 出票.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    CZticketIssueResponse ticketIssue(CZticketIssueRes request, String url) {
        String params = String.format('<AirDocIssueRQ xmlns="http://www.iata.org/IATA/EDIST" Version="15.2">\n' +
                '    <!--Version：版本 必填-->\n' +
                '\t<Document>\n' +
                '\t\t<Name>zh_CN</Name>\n' +
                '    </Document>\n' +
                '\t<Query>\n' +
                '\t\t<TicketDocInfo>\n' +
                '\t\t\t<OrderReference>\n' +
                '\t\t\t\t<!--订单号 必填-->\n' +
                '\t\t\t\t<OrderID  Owner="SC">%s</OrderID>\n' +
                '\t\t\t\t<!-- PNR号 必填-->\n' +
                '\t\t\t\t<OfferItemID>%s</OfferItemID>\n' +
                '\t\t\t</OrderReference>\n' +
                '\t\t</TicketDocInfo>\n' +
                '\t</Query>\n' +
                '</AirDocIssueRQ>', request.getOrderId(), request.getPnrId());
        String res = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/ticketissue');
        CZticketIssueResponse cZticketIssueResponse = GsonUtil.getGson().fromJson(res, CZticketIssueResponse.class);
        return cZticketIssueResponse;
    }

    /**
     * 订单详情查询.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    @Override
    Czb2gOrderDetailResponse orderDetail(OrderDetailReq request, String url) {

        String params = String.format('\t<OrderRetrieveRQ Version="15.2" xmlns="http://www.iata.org/IATA/EDIST">\n' +
                '\t  <Query>\n' +
                '\t    <Filters>\n' +
                '\t\t\t<!--订单号 必填-->\n' +
                '\t      <OrderID>%s</OrderID>\n' +
                '\t    </Filters>\n' +
                '\t  </Query>\n' +
                '\t</OrderRetrieveRQ>', request.getOrderNum());
        String res = this.execute(params, request.getToken(), request.getAccount(), request.getPassword(), url, 'api/v1/order/detail');
        return GsonUtil.getGson().fromJson(res, Czb2gOrderDetailResponse.class);
    }
}
