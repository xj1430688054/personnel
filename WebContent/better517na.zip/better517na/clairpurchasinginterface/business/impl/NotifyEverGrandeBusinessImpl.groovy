package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.INotifyEverGrandeBusiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.notify.TicketNoRequestVo
import org.apache.http.NameValuePair
import org.apache.http.message.BasicNameValuePair
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component('notifyEverGrandeBusiness')
public class NotifyEverGrandeBusinessImpl extends HttpBaseBusiness implements INotifyEverGrandeBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    String notifyFillBackTicketNo(TicketNoRequestVo ticketNoRequest, String url) {
        this.setLogBusiness(logBusiness);
        String requestJson = GsonUtil.gson.toJson(ticketNoRequest);
        // **** list2 地址的请求方式 ****
        String res = this.doPost(url, requestJson, '恒大接口', '回填通知');

        // **** list 地址的请求方式 ****
//        List<NameValuePair> postData = new ArrayList<>();
//        postData.add(new BasicNameValuePair('orderDetailInfo', requestJson));
//        String res = this.doPost(url, postData, '恒大接口', '回填通知');
        // 下面这种方式请求也可以
        // String params = 'orderDetailInfo=' + requestJson;
        // res = this.doPost(url, params, 'application/x-www-form-urlencoded', '恒大接口', '回填通知');
        return res;
    }
}
