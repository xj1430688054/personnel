package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogAcc
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.Direction
import com.better517na.logcompontent.util.ExceptionLevel
import com.better517na.mub2cChangeTicket.IUniChangeLitersService
import com.better517na.mub2cChangeTicket.ReBookReq
import com.better517na.mub2cChangeTicket.ReBookRes
import com.better517na.mub2cChangeTicket.ReShoppingReq
import com.better517na.mub2cChangeTicket.ReShoppingRes
import com.better517na.mub2cFlightBook.BookingReq
import com.better517na.mub2cFlightBook.BookingRes
import com.better517na.mub2cFlightBook.FavorPassenger
import com.better517na.mub2cFlightBook.IUniSaleBookingService
import com.better517na.mub2cFlightQuery.IUniSaleShoppingService
import com.better517na.mub2cFlightQuery.ShoppingReq
import com.better517na.mub2cFlightQuery.ShoppingRes
import com.better517na.mub2cOrderPay.IUniPayDataService
import com.better517na.mub2cOrderPay.PayConfirmAndTicketOutReq
import com.better517na.mub2cOrderPay.PayConfirmAndTicketOutRes
import com.better517na.mub2cOrderQuery.IUniOtaOrderService
import com.better517na.mub2cOrderQuery.OrderSearchReq
import com.better517na.mub2cOrderQuery.OrderTicketNoReq
import com.better517na.mub2cOrderQuery.OrderTicketNoRes
import com.better517na.mub2cOrderQuery.OtaOrderSearchRes
import com.better517na.mub2cPriceQuery.IUniSalePricingService
import com.better517na.mub2cPriceQuery.PriceCalReq
import com.better517na.mub2cPriceQuery.PricingReq
import com.better517na.mub2cPriceQuery.PricingRes
import com.better517na.mub2cReturnTicket.CalcFeeRes
import com.better517na.mub2cReturnTicket.CalcFeeV2Req
import com.better517na.mub2cReturnTicket.IUniRefundDataService
import com.better517na.mub2cReturnTicket.ReApplyReq
import com.better517na.mub2cReturnTicket.ReCalcFeeReq
import com.better517na.mub2cReturnTicket.RefundApplyReq
import com.better517na.mub2cReturnTicket.RefundApplyRes
import com.better517na.mub2cReturnTicket.RefundDetailReq
import com.better517na.mub2cReturnTicket.RefundDetailRes
import com.better517na.mub2cReturnTicket.RefundRes
import com.better517na.mub2cReturnTicket.RefundV2Req
import com.better517na.unifiedParameters.business.IGetParamBusiness
import com.google.gson.Gson
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IMuB2CBussiness
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CBookingFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CChangeFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CPricingFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CUniOrderDataServiceFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CUniPayDataServiceFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CUniRefundDataServiceFactoryBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory.B2CUniSaleDataServiceFactoryBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import javax.annotation.Resource

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c
 * Author: gaoshun
 * DateTime: 2018/11/6 15:38
 * Desc: 说明类的作用
 */
@Component
public class MuB2CBussinessImpl implements IMuB2CBussiness {

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 添加字段注释.
     */
    @Resource(name = "ParamBusiness")
    private IGetParamBusiness paramBusiness;

    /**
     * {@inheritDoc}.
     */
    @Override
    public ShoppingRes shopping(ShoppingReq request, String url) throws Exception {
        B2CUniSaleDataServiceFactoryBean b2cUniSaleDataServiceFactoryBean = new B2CUniSaleDataServiceFactoryBean();
        url = url + 'UniSaleShoppingService?wsdl';
        b2cUniSaleDataServiceFactoryBean.setUrl(url);
        IUniSaleShoppingService flightQueryService = b2cUniSaleDataServiceFactoryBean.getObject();

        ShoppingRes shopping = null;
        try {
            shopping = flightQueryService.shopping(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('shopping');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(shopping));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return shopping;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public PricingRes pricing(PricingReq request, String url) throws Exception {
        B2CPricingFactoryBean pricingFactoryBean = new B2CPricingFactoryBean();
        url = url + 'UniSalePricingService?wsdl';
        pricingFactoryBean.setUrl(url);
        IUniSalePricingService priceService = pricingFactoryBean.getObject();

        PricingRes pricing = null;

        try {
            pricing = priceService.pricing(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('pricing');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(pricing));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return pricing;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public BookingRes booking(BookingReq request, String url) throws Exception {
        B2CBookingFactoryBean b2cUniSaleDataServiceFactoryBean = new B2CBookingFactoryBean();
        url = url + 'UniSaleBookingService?wsdl';
        b2cUniSaleDataServiceFactoryBean.setUrl(url);
        IUniSaleBookingService bookingService = b2cUniSaleDataServiceFactoryBean.getObject();

        BookingRes booking = null;
        try {
            booking = bookingService.booking(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('booking');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(booking));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return booking;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public PricingRes priceCal(PriceCalReq request, String url) throws Exception {
        B2CPricingFactoryBean pricingFactoryBean = new B2CPricingFactoryBean();
        url = url + 'UniSalePricingService?wsdl';
        pricingFactoryBean.setUrl(url);
        IUniSalePricingService priceService = pricingFactoryBean.getObject();

        PricingRes priceCal = null;
        try {
            priceCal = priceService.priceCal(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('priceCal');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(priceCal));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return priceCal;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public PayConfirmAndTicketOutRes payConfirmAndTicketOut(PayConfirmAndTicketOutReq request, String url) throws Exception {
        B2CUniPayDataServiceFactoryBean b2cUniPayDataServiceFactoryBean = new B2CUniPayDataServiceFactoryBean();
        url = url + 'UniPayDataService?wsdl';
        b2cUniPayDataServiceFactoryBean.setUrl(url);
        IUniPayDataService servicePay = b2cUniPayDataServiceFactoryBean.getObject();

        PayConfirmAndTicketOutRes ticketOut = null;
        try {
            ticketOut = servicePay.payConfirmAndTicketOut(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('payConfirmAndTicketOut');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(ticketOut));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return ticketOut;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public OtaOrderSearchRes detail(OrderSearchReq request, String url) throws Exception {
        B2CUniOrderDataServiceFactoryBean b2cUniOrderDataServiceFactoryBean = new B2CUniOrderDataServiceFactoryBean();
        url = url + 'UniOtaOrderService?wsdl';
        b2cUniOrderDataServiceFactoryBean.setUrl(url);
        IUniOtaOrderService orderQueryService = b2cUniOrderDataServiceFactoryBean.getObject();

        OtaOrderSearchRes detail = null;
        try {
            detail = orderQueryService.searchOrderDetail(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('searchOrderDetail');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(detail));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return detail;
    }

    /**
     * {@inheritDoc}.
     *
     * @throws Exception
     */
    @Override
    public RefundApplyRes refundApply(RefundApplyReq request, String url) throws Exception {
        B2CUniRefundDataServiceFactoryBean b2cUniRefundDataServiceFactoryBean = new B2CUniRefundDataServiceFactoryBean();
        url = url + 'UniRefundDataService?wsdl';
        b2cUniRefundDataServiceFactoryBean.setUrl(url);
        IUniRefundDataService serviceRefund = b2cUniRefundDataServiceFactoryBean.getObject();

        RefundApplyRes refundApply = null;
        try {
            refundApply = serviceRefund.refundApply(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('refundApply');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(refundApply));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return refundApply;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public RefundRes refundV2(RefundV2Req request, String url) throws Exception {
        B2CUniRefundDataServiceFactoryBean b2cUniRefundDataServiceFactoryBean = new B2CUniRefundDataServiceFactoryBean();
        url = url + 'UniRefundDataService?wsdl';
        b2cUniRefundDataServiceFactoryBean.setUrl(url);
        IUniRefundDataService serviceRefund = b2cUniRefundDataServiceFactoryBean.getObject();

        RefundRes refund = null;
        try {
            refund = serviceRefund.refundV2(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('refundV2');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(refund));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return refund;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public RefundDetailRes refundDetail(RefundDetailReq request, String url) throws Exception {
        B2CUniRefundDataServiceFactoryBean b2cUniRefundDataServiceFactoryBean = new B2CUniRefundDataServiceFactoryBean();
        url = url + 'UniRefundDataService?wsdl';
        b2cUniRefundDataServiceFactoryBean.setUrl(url);
        IUniRefundDataService serviceRefund = b2cUniRefundDataServiceFactoryBean.getObject();

        RefundDetailRes refundDetail = null;
        try {
            refundDetail = serviceRefund.refundDetail(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('refundDetail');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(refundDetail));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return refundDetail;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public CalcFeeRes calcFee2(CalcFeeV2Req request, String url) throws Exception {
        B2CUniRefundDataServiceFactoryBean b2cUniRefundDataServiceFactoryBean = new B2CUniRefundDataServiceFactoryBean();
        url = url + 'UniRefundDataService?wsdl';
        b2cUniRefundDataServiceFactoryBean.setUrl(url);
        IUniRefundDataService serviceRefund = b2cUniRefundDataServiceFactoryBean.getObject();

        CalcFeeRes calcFee = null;
        try {
            calcFee = serviceRefund.calcFeeV2(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('calcFeeV2');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(calcFee));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return calcFee;
    }

    /**
     *
     * TODO查询票号.
     *
     * @param request
     *            请求
     * @return 票号信息
     * @throws Exception
     *             异常
     */
    @Override
    public OrderTicketNoRes getTicketNo(OrderTicketNoReq request, String url) throws Exception {
        B2CUniOrderDataServiceFactoryBean b2cUniOrderDataServiceFactoryBean = new B2CUniOrderDataServiceFactoryBean();
        url = url + 'UniOtaOrderService?wsdl';
        b2cUniOrderDataServiceFactoryBean.setUrl(url);
        IUniOtaOrderService orderQueryService = b2cUniOrderDataServiceFactoryBean.getObject();

        OrderTicketNoRes res = null;
        try {
            res = orderQueryService.getTicketNo(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('getTicketNo');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(res));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return res;
    }

    /**
     *
     * TODO改签航班查询.
     *
     * @param request
     *            请求
     * @return 票号信息
     * @throws Exception
     *             异常
     */
    @Override
    public ReShoppingRes reShopping(ReShoppingReq request, String url) throws Exception {
        B2CChangeFactoryBean b2cChangeFactoryBean = new B2CChangeFactoryBean();
        url = url + 'UniChangeLitersService?wsdl';
        b2cChangeFactoryBean.setUrl(url);
        IUniChangeLitersService changeService = b2cChangeFactoryBean.getObject();

        ReShoppingRes res = null;
        try {
            res = changeService.reShopping(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('reShopping');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(res));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return res;
    }

    /**
     *
     * TODO改签航班查询.
     *
     * @param request
     *            请求
     * @return 票号信息
     * @throws Exception
     *             异常
     */
    @Override
    public ReBookRes reBooking(ReBookReq request, String url) throws Exception {
        B2CChangeFactoryBean b2cChangeFactoryBean = new B2CChangeFactoryBean();
        url = url + 'UniChangeLitersService?wsdl';
        b2cChangeFactoryBean.setUrl(url);
        IUniChangeLitersService changeService = b2cChangeFactoryBean.getObject();

        ReBookRes res = null;
        try {
            res = changeService.reBooking(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('reBooking');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(res));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return res;
    }

    /**
     * 重新提交退票申请
     * @param request 请求入参
     * @param url 地址
     * @return 返回值
     * @throws Exception 异常
     */
    @Override
    public RefundRes reApply(ReApplyReq request, String url) throws Exception {
        B2CUniRefundDataServiceFactoryBean b2cUniRefundDataServiceFactoryBean = new B2CUniRefundDataServiceFactoryBean();
        url = url + 'UniRefundDataService?wsdl';
        b2cUniRefundDataServiceFactoryBean.setUrl(url);
        IUniRefundDataService serviceRefund = b2cUniRefundDataServiceFactoryBean.getObject();

        RefundRes res = null;
        try {
            res = serviceRefund.reApply(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('reApply');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(res));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return res;
    }

    /**
     * 非自愿转自愿
     * @param request 请求入参
     * @param url 地址
     * @return 返回值
     * @throws Exception 异常
     */
    @Override
    public CalcFeeRes reCalcFee(ReCalcFeeReq request, String url) throws Exception {
        B2CUniRefundDataServiceFactoryBean b2cUniRefundDataServiceFactoryBean = new B2CUniRefundDataServiceFactoryBean();
        url = url + 'UniRefundDataService?wsdl';
        b2cUniRefundDataServiceFactoryBean.setUrl(url);
        IUniRefundDataService serviceRefund = b2cUniRefundDataServiceFactoryBean.getObject();

        CalcFeeRes res = null;
        try {
            res = serviceRefund.reCalcFee(request);
        } finally {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule('MUB2C接口交互');
            interactionParam.setKey1('reCalcFee');
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(new Gson().toJson(request));
            interactionParam.setReceiveContent(new Gson().toJson(res));
            logBusiness.writeInteractionLog(interactionParam);
        }

        return res;
    }
}