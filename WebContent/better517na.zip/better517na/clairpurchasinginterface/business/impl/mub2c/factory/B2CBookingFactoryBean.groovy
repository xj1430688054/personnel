package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory

import com.better517na.mub2cFlightBook.IUniSaleBookingService
import com.better517na.mub2cFlightBook.UniSaleBookingServiceService
import org.springframework.beans.factory.FactoryBean

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory
 * Author: gaoshun
 * DateTime: 2018/11/6 15:19
 * Desc: 说明类的作用
 */
public class B2CBookingFactoryBean implements FactoryBean<IUniSaleBookingService> {
    /**
     * 添加字段注释.
     */
    private String url;

    /**
     * 设置url.
     *
     * @return 返回url
     */
    public String getUrl() {
        return url;
    }

    /**
     * 获取url.
     *
     * @param url
     *            要设置的url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public IUniSaleBookingService getObject() throws Exception {
        if (null == url || url.length() == 0) {
            throw new RuntimeException('url is null');
        }

        if (ServiceMapCache.serviceMapCache.containsKey(url)) {
            return ServiceMapCache.serviceMapCache.get(url);
        }

        IUniSaleBookingService impl = new UniSaleBookingServiceService(new URL(url)).getUniSaleBookingServicePort();
        ServiceMapCache.serviceMapCache.put(url,impl);

        return impl;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public Class<?> getObjectType() {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public boolean isSingleton() {
        // TODO Auto-generated method stub
        return false;
    }
}
