package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c.factory
 * Author: gaoshun
 * DateTime: 2018/11/6 15:47
 * Desc: 说明类的作用
 */
public class ServiceMapCache {
    /**
     * 缓存
     */
    public  static Map<String,Object> serviceMapCache = new HashMap<>();
}
