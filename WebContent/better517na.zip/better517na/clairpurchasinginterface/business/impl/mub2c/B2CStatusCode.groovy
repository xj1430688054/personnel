package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl.mub2c
 * Author: gaoshun
 * DateTime: 2018/11/6 15:35
 * Desc: 说明类的作用
 */
public class B2CStatusCode  {
    /**
     * 等待入库.
     */
    public static final String WAIT_FOR_STORAGE = '30210';

    /**
     * 等待支付.
     */
    public static final String WAIT_FOR_PAY = '30211';

    /**
     * 等待出票.
     */
    public static final String WAIT_FOR_TICKETOUT = '30212';

    /**
     * 出票完成.
     */
    public static final String TICKETOUT_FINISHED = '30213';

    /**
     * 订单作废.
     */
    public static final String CANCEL_ORDER = '30214';

    /**
     * 差错退款.
     */
    public static final String ERROR_REFUND = '30215';

    /**
     * 出票完成(有退票).
     */
    public static final String TICKETOUT_FINISHED_WITHREFUND = '30216';

    /**
     * 出票完成(变更).
     */
    public static final String TICKETOUT_FINISHED_WITHCHANGE = '30217';

    /**
     * 出票失败.
     */
    public static final String TICKETOUT_FAILED = '30218';

    /**
     * 成功.
     */
    public static final String SUCCESS = '0';

    /**
     * 自愿退票.
     */
    public static final Long IS_VOLUNTARY_REFUND = 281L;

    /**
     * 非自愿退票.
     */
    public static final Long NOT_VOLUNTARY_REFUND = 282L;
}