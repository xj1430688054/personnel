package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl;

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.clairpurchasinginterface.utils.DateUtil;
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IQunarBusiness;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.ResponseVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Tag
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.bk.BKRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.bk.BKResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.pay.OrderPayRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.pay.OrderPayResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.payValidate.PayValidateRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Tag
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.QueryParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.order.CreateOrderRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.order.CreateOrderResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.searchprice.QuaryRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.searchprice.SearchPriceResult;
import com.better517na.clairpurchasinginterface.utils.GsonUtil;
import com.better517na.logcompontent.business.LogBusiness;
import com.google.gson.reflect.TypeToken
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InPayValidateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutPayValidateVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/19
 * Time: 20:06
 */
@Component
public class QunarBusinessImpl extends QunarBaseBusiness implements IQunarBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    public Response<SearchPriceResult> searchPrice(Request<QuaryRequest> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.SEARCHPRICE.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<SearchPriceResult>> typeToken = new TypeToken<Response<SearchPriceResult>>() {
        };
        Response<SearchPriceResult> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    public Response<BKResponse> bk(Request<BKRequest> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.BK.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<BKResponse>> typeToken = new TypeToken<Response<BKResponse>>() {
        };
        Response<BKResponse> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    public Response<CreateOrderResponse> createOrder(Request<CreateOrderRequest> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        Response<CreateOrderResponse> res = null;
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.CREATE.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<CreateOrderResponse>> typeToken = new TypeToken<Response<CreateOrderResponse>>() {
        };
        // 居然会返回这种：{"code":1404,"message":"""","createTime":1549963548764,"result":{}}
        if (!str.contains('"message":""""')) {
            res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        }
        return res;
    }

    @Override
    public Response<OrderPayResponse> payOrder(Request<OrderPayRequest> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.PAY.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<OrderPayResponse>> typeToken = new TypeToken<Response<OrderPayResponse>>() {
        };
        Response<OrderPayResponse> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    public config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo<OutPayValidateVo> payValidate(RequestVo<InPayValidateVo> requestVo) {
        // 构建入参
        Request<PayValidateRequest> payValidateRequest = new Request<PayValidateRequest>();

        // 公共参数
        payValidateRequest.setToken(requestVo.getSupplySystemInfo().getpID());
        payValidateRequest.setCreateTime(this.GetTimestamp());
        if (StringUtil.isNullOrEmpty(payValidateRequest.getTag())) {
            payValidateRequest.setTag(Tag.PAYVALIDATE.getValue());
        }

        // 业务参数
        PayValidateRequest param = new PayValidateRequest();

        // PayInfo=tb517nacom@163.com|ALIPAY|www.517na.com|OUTDAIKOU|2
        // (支付账号|BankCode|支付回调地址|PmCode|支付方式（2支付宝，6易宝））
        String[] payInfos = requestVo.getSupplySystemInfo().getPayInfo().split("\\|");
        param.setPmCode(payInfos[3]);
        param.setBankCode(payInfos[1]);

        // 订单ID|代理商域名
        String[] keys = requestVo.getBody().getS3().split("\\|");
        param.setOrderId(keys[0]);
        param.setClientSite(keys[1]);

        payValidateRequest.setParams(param);

        // 请求
        this.setLogBusiness(logBusiness);
        String str = this.execute(payValidateRequest, requestVo.getSupplySystemInfo().getSecurityCode(), requestVo.getSupplySystemInfo().getInterfaceUrl());
        TypeToken<Response<?>> typeToken = new TypeToken<Response<?>>() {};
        Response<?> res = GsonUtil.getGson().fromJson(str, typeToken.getType());

        config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo<OutPayValidateVo> responseVo = new config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo<OutPayValidateVo>();

        OutPayValidateVo payValidateOut = new OutPayValidateVo();
        if (res.getCode() == 0) {
            responseVo.setSuccess(true);
            payValidateOut.setChangePrice(false);
        } else if (res.getCode() == 1007) {
            responseVo.setSuccess(true);
            payValidateOut.setChangePrice(true);
        } else {
            responseVo.setSuccess(false);
            responseVo.setMsg(res.getMessage());
        }

        responseVo.setResult(payValidateOut)

        // 解析返回结果
        return responseVo;
    }

    @Override
    Response<OrderDetailResponse> queryOrder(Request<QueryParam> requestVo, String key, String url) {
        this.setLogBusiness(logBusiness);
        if (StringUtil.isNullOrEmpty(requestVo.getTag())) {
            requestVo.setTag(Tag.GETDETAIL.getValue());
        }
        String str = this.execute(requestVo, key, url);
        TypeToken<Response<OrderDetailResponse>> typeToken = new TypeToken<Response<OrderDetailResponse>>() {
        };
        Response<OrderDetailResponse> response = com.better517na.javaloghelper.util.GsonUtil.getGson().fromJson(str, typeToken.getType());
        return response;
    }

    /**
     * 获取时间戳
     * @return 时间戳
     */
    private long GetTimestamp() {
        return System.currentTimeMillis();
    }
}
