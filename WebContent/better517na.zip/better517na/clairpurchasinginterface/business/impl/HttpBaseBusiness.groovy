package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.javaloghelper.util.GsonUtil
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.model.MLogInteraction
import com.better517na.logcompontent.util.ExceptionLevel
import org.apache.commons.lang.StringUtils
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.NameValuePair
import org.apache.http.client.HttpClient
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.impl.client.HttpClientBuilder
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/22
 * Time: 13:47
 */
public class HttpBaseBusiness {
    /**
     * http客户端.
     */
    protected static final CloseableHttpClient HTTP_CLIENT;

    static {
        RequestConfig config = RequestConfig.custom().setConnectTimeout(300000).setSocketTimeout(300000).build();
        HTTP_CLIENT = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
    }

    /**
     * . 基类中的日子组件对象
     */
    protected LogBusiness logBusiness;

    /**
     * 获取logBusiness.
     *
     * @return 返回logBusiness
     */
    public LogBusiness getLogBusiness() {
        return logBusiness;
    }

    /**
     * 设置logBusiness.
     *
     * @param logBusiness 赋值logBusiness
     */
    public void setLogBusiness(LogBusiness logBusiness) {
        this.logBusiness = logBusiness;
    }

    /**
     * Post请求.
     *
     * @param url url.
     * @param params params.
     * @param module module(记日志用).
     * @param subModule subModule(记日志用).
     * @return
     */
    public String doPost(String url, String params, String module, String subModule) {
        return doPost(url, params, 'application/json', module, subModule);
    }

    /**
     * Post请求.
     *
     * @param url url.
     * @param params params.
     * @param contentType contentType:application/json  application/x-www-form-urlencoded ....
     * @param module module(记日志用).
     * @param subModule subModule(记日志用).
     * @return
     */
    public String doPost(String url, String params, String contentType, String module, String subModule) {
        long totalTime = 0;
        String result = '';
        if (StringUtils.isBlank(url)) {
            return result;
        }
        CloseableHttpResponse httpResponse = null;
        try {
            System.out.print("请求地址：");
            System.out.println(url);
            System.out.print("请求参数：");
            System.out.println(params);
            StringEntity se = new StringEntity(params, 'UTF-8');
            if (params != null && params.length() > 0) {
                se.setContentEncoding('UTF-8');
                se.setContentType(contentType);
            }

            long begin = System.currentTimeMillis();
            HttpPost httpPost = new HttpPost(url);
            httpPost.setHeader('Content-Type', contentType + ';charset=UTF-8');
            httpPost.setHeader('Accept', '*/*');
            httpPost.setHeader('Accept-Encoding', 'gzip, deflate');
            httpPost.setHeader('Accept-Language', 'zh-CN,zh;q=0.9');
            if (se != null && se.getContentLength() > 0) {
                httpPost.setEntity(se);
            }
            httpResponse = HTTP_CLIENT.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode != 200) {
                httpPost.abort();
                throw new RuntimeException('HttpClient,error status code :' + statusCode);
            }
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, 'utf-8');
            }
            EntityUtils.consume(entity);
            httpResponse.close();
            totalTime = System.currentTimeMillis() - begin;
        } catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'HTTP请求异常', e.getMessage(), e));
        } finally {
            writeInteractionLog(module, subModule, url, params, result, String.valueOf(totalTime));
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    /**
     * Post请求(键值对).
     * @param url url.
     * @param postData postData.
     * @param module module(记日志用).
     * @param subModule subModule(记日志用).
     * @return 结果.
     */
    public String doPost(String url, List<NameValuePair> postData, String module, String subModule) {
        long totalTime = 0; // 记录耗时
        String result = ''; // 响应结果
        if (StringUtils.isBlank(url)) {
            return result;
        }
        HttpResponse httpResponse = null;
        String params = GsonUtil.getGson().toJson(postData);
        try {
            System.out.print('请求地址：');
            System.out.println(url);
            System.out.print('请求参数：');
            System.out.println(params);

            UrlEncodedFormEntity uefEntity = new UrlEncodedFormEntity(postData, 'UTF-8');
            HttpPost httpPost = new HttpPost(url);
            httpPost.setEntity(uefEntity);

            long begin = System.currentTimeMillis();
            HttpClient httpsClient = HttpClients.createDefault();
            httpResponse = httpsClient.execute(httpPost);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode != 200) {
                httpPost.abort();
                throw new RuntimeException('HttpClient,error status code :' + statusCode);
            }

            result = EntityUtils.toString(httpResponse.getEntity());
            EntityUtils.consume(uefEntity);
            httpResponse.close();
            totalTime = System.currentTimeMillis() - begin;
        }
        catch (Exception e) {
            e.printStackTrace();
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, 'HTTP请求异常', e.getMessage(), e));
        } finally {
            writeInteractionLog(module, subModule, url, params, result, String.valueOf(totalTime));
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    /**
     * Get请求.
     *
     * @param url url.
     * @param params params.
     * @param module module(记日志用).
     * @param subModule subModule(记日志用).
     * @param mycharset 编码.
     * @return
     */
    public String doGet(String url, String params, String module, String subModule, String mycharset) {
        long totalTime = 0;
        if (url == null || "".equals(url.trim())) {
            return null;
        }

        if (StringUtils.isEmpty(params)) {
            return null;
        }
        url += "?" + params;
        String result = null;
        CloseableHttpResponse httpResponse = null;
        long begin = System.currentTimeMillis();
        HttpGet httpGet = new HttpGet(url);
        try {
            httpResponse = HTTP_CLIENT.execute(httpGet);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if (statusCode != 200) {
                // 这里获取一下信息
                StringBuilder errMessage = new StringBuilder();
                errMessage.append('HttpClient,error status code :');
                errMessage.append(statusCode);
                errMessage.append('\r\n');
                try {
                    HttpEntity entity = httpResponse.getEntity();
                    if (entity != null) {
                        errMessage.append(EntityUtils.toString(entity, mycharset));
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    totalTime = System.currentTimeMillis() - begin;
                    String strerrMessage = errMessage.toString();
                    writeInteractionLog(module, subModule, url, params, strerrMessage, String.valueOf(totalTime));
                }
                httpGet.abort();
                throw new RuntimeException(errMessage.toString());
            }
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, mycharset);
            }
            EntityUtils.consume(entity);
            httpResponse.close();
            totalTime = System.currentTimeMillis() - begin;
        } finally {
            writeInteractionLog(module, subModule, url, params, result, String.valueOf(totalTime));
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return result;
    }

    /**
     * 记录交互日志.
     *
     * @param module module.
     * @param subModule subModule.
     * @param url url.
     * @param request request.
     * @param response response.
     * @param totalTime totalTime.
     */
    protected void writeInteractionLog(String module, String subModule, String url, String request, String response, String totalTime) {
        writeInteractionLog(module, subModule, url, request, response, totalTime, '')
    }

    /**
     * 记录交互日志.
     *
     * @param module module.
     * @param subModule subModule.
     * @param url url.
     * @param request request.
     * @param response response.
     * @param totalTime totalTime.
     * @param message message.
     */
    protected void writeInteractionLog(String module, String subModule, String url, String request, String response, String totalTime, String message) {
        try {
            MLogInteraction interactionParam = new MLogInteraction();
            interactionParam.setModule(module);
            interactionParam.setKey1(subModule);
            interactionParam.setKey2(totalTime);
            interactionParam.setSendAddress(url);
            interactionParam.setSendContent(request);
            interactionParam.setReceiveContent(response);
            interactionParam.setMessage(message)
            logBusiness.writeInteractionLog(interactionParam);
        } catch (Exception ex) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '记录交互日志失败', ex.getMessage(), ex));
        }
    }
}
