package config.groovyFiles.com.better517na.clairpurchasinginterface.business.impl

import com.better517na.clairticketapi.model.vo.refund.ApplyRefundInVo
import com.better517na.clairticketapi.model.vo.refund.ApplyRefundOutVo
import com.better517na.clairticketapi.model.vo.refund.RefundOrderSearchInVo
import com.better517na.clairticketapi.model.vo.refund.RefundOrderSearchOutVo
import com.better517na.clairticketapi.model.vo.refund.RefundSearchOutVo;
import com.better517na.clairticketapi.model.vo.refund.RefundSearchInVo
import com.better517na.javaloghelper.util.GsonUtil
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.ICLAirTicketAPIBusiness;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.OrderCreateInVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.OrderCreateOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayOrderInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayOrderResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayValidateInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.PayValidateOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.QueryTicketOrderInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.QueryTicketOrderOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.RequestVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.ResponseVo;
import com.better517na.logcompontent.business.LogBusiness;
import com.google.gson.reflect.TypeToken
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/19
 * Time: 20:10
 */
@Component
public class CLAirTicketAPIBusinessImpl extends CLAirTicketAPIBaseBusiness implements ICLAirTicketAPIBusiness {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @Override
    public ResponseVo<OrderCreateOutVo> createOrder(RequestVo<OrderCreateInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/createOrder');
        TypeToken<ResponseVo<OrderCreateOutVo>> typeToken = new TypeToken<ResponseVo<OrderCreateOutVo>>() {
        };
        ResponseVo<OrderCreateOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    public ResponseVo<QueryTicketOrderOutVo> queryOrder(RequestVo<QueryTicketOrderInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/queryOrder');
        TypeToken<ResponseVo<QueryTicketOrderOutVo>> typeToken = new TypeToken<ResponseVo<QueryTicketOrderOutVo>>() {
        };
        ResponseVo<QueryTicketOrderOutVo> queryTicketOrderOutVoResponseVo = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return queryTicketOrderOutVoResponseVo;
    }


    /**
     * 支付前验价.
     * @param param 参数
     * @return 结果
     */
    @Override
    ResponseVo<PayValidateOutVo> payValidate(RequestVo<PayValidateInVo> param, String secret, String url) {
        this.setLogBusiness(logBusiness);
        if (!url.endsWith('/')) {
            url = url + '/';
        }
        String str = this.execute(param, secret, url, 'api/airticket/payValidate');
        TypeToken<ResponseVo<PayValidateOutVo>> typeToken = new TypeToken<ResponseVo<PayValidateOutVo>>() {
        };
        ResponseVo<PayValidateOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    @Override
    public ResponseVo<PayOrderResVo> payOrder(RequestVo<PayOrderInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/payOrder');
        TypeToken<ResponseVo<PayOrderResVo>> typeToken = new TypeToken<ResponseVo<PayOrderResVo>>() {
        };
        ResponseVo<PayOrderResVo> payOrderResVoResponseVo = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return payOrderResVoResponseVo;
    }

/**
     * @CLAirTicketAPI的退票订单查询
     * @param param 请求参数
     * @return 订单查询结果
     */
    @Override
    public ResponseVo<RefundOrderSearchOutVo> refundOrderSearch(RequestVo<RefundOrderSearchInVo> requestVo, String secret, String url) {
        this.setLogBusiness(logBusiness);
        String str = this.execute(requestVo, secret, url, 'api/airticket/refundOrderSearch');
        TypeToken<ResponseVo<RefundOrderSearchOutVo>> typeToken = new TypeToken<ResponseVo<RefundOrderSearchOutVo>>() {
        };
        ResponseVo<RefundOrderSearchOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }
    /**
     * 申请退票.
     * @param param 退票参数
     * @return 申请结果
     */
    @Override
    ResponseVo<ApplyRefundOutVo> applyRefund(RequestVo<ApplyRefundInVo> param, String secret, String url) {
        this.setLogBusiness(logBusiness);
        if (!url.endsWith('/')) {
            url = url + '/';
        }
        String str = this.execute(param, secret, url, 'api/airticket/applyRefund');
        TypeToken<ResponseVo<ApplyRefundOutVo>> typeToken = new TypeToken<ResponseVo<ApplyRefundOutVo>>() {
        };
        ResponseVo<ApplyRefundOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

    /**
     * 申请退票查询.
     * @param param 参数
     * @return 结果
     */
    @Override
    ResponseVo<RefundSearchOutVo> refundSearch(RequestVo<RefundSearchInVo> param, String secret, String url) {
        this.setLogBusiness(logBusiness);
        if (!url.endsWith('/')) {
            url = url + '/';
        }
        String str = this.execute(param, secret, url, 'api/airticket/refundSearch');
        TypeToken<ResponseVo<RefundSearchOutVo>> typeToken = new TypeToken<ResponseVo<RefundSearchOutVo>>() {
        };
        ResponseVo<RefundSearchOutVo> res = GsonUtil.getGson().fromJson(str, typeToken.getType());
        return res;
    }

}
