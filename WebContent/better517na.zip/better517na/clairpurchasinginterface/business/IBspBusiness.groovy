package config.groovyFiles.com.better517na.clairpurchasinginterface.business;

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InPayValidateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InTicketNoCheckVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutPayValidateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutTicketNoCheckVo

/**
 * TODO 添加类的一句话简单描述.
 * Author: sanzang
 * Date: 2018/8/14
 * Time: 20:05
 */
interface IBspBusiness {
    ResponseVo<OutPayValidateVo> payValidate(RequestVo<InPayValidateVo> requestVo)

    /**
     * 票号校验.
     *
     * @param requestVo 请求参数.
     * @return 返回结果.
     */
    ResponseVo<OutTicketNoCheckVo> ticketNoCheck(RequestVo<InTicketNoCheckVo> requestVo);
}
