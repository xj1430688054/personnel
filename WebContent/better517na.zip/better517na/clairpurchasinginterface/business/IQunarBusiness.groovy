package config.groovyFiles.com.better517na.clairpurchasinginterface.business;

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.bk.BKRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.bk.BKResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.QueryParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.order.CreateOrderRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.order.CreateOrderResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.pay.OrderPayRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.pay.OrderPayResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.searchprice.QuaryRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.searchprice.SearchPriceResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.InPayValidateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutPayValidateVo;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/19
 * Time: 20:05
 */
public interface IQunarBusiness {
    Response<SearchPriceResult> searchPrice(Request<QuaryRequest> requestVo, String key, String url);

    Response<BKResponse> bk(Request<BKRequest> requestVo, String key, String url);

    Response<CreateOrderResponse> createOrder(Request<CreateOrderRequest> requestVo, String key, String url);

    Response<OrderPayResponse> payOrder(Request<OrderPayRequest> requestVo, String key, String url);

    config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo<OutPayValidateVo> payValidate(RequestVo<InPayValidateVo> requestVo);

    Response<OrderDetailResponse> queryOrder(Request<QueryParam> requestVo, String key, String url);
}
