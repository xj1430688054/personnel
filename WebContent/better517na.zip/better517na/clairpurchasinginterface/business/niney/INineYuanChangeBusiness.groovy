package config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.NineYRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.change.ChangeApplyOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.change.ChangeQueryOut

interface INineYuanChangeBusiness {

    ChangeQueryOut queryChangeFlight(NineYRequest request)

    ChangeApplyOut changeApply(NineYRequest request)

}