package config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.NineYRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.create.CreateParamOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.orderdetail.OrderDetailOut
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.pay.PayParamOut

interface INineYuanBusiness{

    OrderDetailOut queryOrderDetail(NineYRequest request)

    CreateParamOut createOrder(NineYRequest nineYRequest)

    PayParamOut payOrder(NineYRequest nineYRequest)
}