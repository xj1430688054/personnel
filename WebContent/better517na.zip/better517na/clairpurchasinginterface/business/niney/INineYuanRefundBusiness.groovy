package config.groovyFiles.com.better517na.clairpurchasinginterface.business.niney

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.ApplyRefundInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.ApplyRefundResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.CalRefundRateInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.niney.refund.CalRefundResultVo

interface INineYuanRefundBusiness {
    /**
     * 计算退票手续费
     * @param calRefundRateInVo 参数
     * @return 结果
     */
    CalRefundResultVo calRefundTicketRate(CalRefundRateInVo calRefundRateInVo, String url, String account, String token);

    /**
     * 申请退票.
     * @param applyRefundInVo 参数.
     * @return 结果.
     */
    ApplyRefundResultVo applyTicketRefund(ApplyRefundInVo applyRefundInVo, String url, String account, String token);
}