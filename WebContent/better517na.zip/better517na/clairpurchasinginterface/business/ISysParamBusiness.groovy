package config.groovyFiles.com.better517na.clairpurchasinginterface.business

interface ISysParamBusiness {

    /**
     * 获取乘机人联系电话参数.
     *
     * @return .
     * @throws Exception .
     */
    List<String> getPassengerLinkPhoneParam() throws Exception;
}