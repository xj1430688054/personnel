package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.springAirSalesService.BookOrderBookBean
import com.better517na.springAirSalesService.BookOrderResultBean
import com.better517na.springAirSalesService.GetFlightBgAppInputBean
import com.better517na.springAirSalesService.GetFlightBgAppResultBean
import com.better517na.springAirSalesService.GetOrderDetailInfoQueryBean
import com.better517na.springAirSalesService.GetOrderDetailInfoResultBean
import com.better517na.springAirSalesService.GetSpecificPriceInputBean
import com.better517na.springAirSalesService.GetSpecificPriceResultBean
import com.better517na.springAirSalesService.SearchFlightsBatchResultBean
import com.better517na.springAirSalesService.SearchFlightsBatchResultBean2
import com.better517na.springAirSalesService.SearchFlightsBatchSearchBean
import com.better517na.springAirSalesService.SearchFlightsBySegIdBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.springAir.SpringAirPayIn

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/10/22
 * Time: 19:48
 */
interface ISpringAirBusiness {
    /**
     * 计算订单金额（售前）.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    GetSpecificPriceResultBean getSpecificPrice(GetSpecificPriceInputBean request, String url);

    /**
     * 预订订单.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    BookOrderResultBean bookOrder(BookOrderBookBean request, String url);

    /**
     * 提交支付.
     * @param request 请求.
     * @return 结果.
     */
    String pay(SpringAirPayIn request);

    /**
     * 查询订单明细信息.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    GetOrderDetailInfoResultBean getOrderDetailInfo(GetOrderDetailInfoQueryBean request, String url);

    /**
     * 查询改签手续费.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    GetFlightBgAppResultBean queryChangeFee(GetFlightBgAppInputBean request, String url);
}
