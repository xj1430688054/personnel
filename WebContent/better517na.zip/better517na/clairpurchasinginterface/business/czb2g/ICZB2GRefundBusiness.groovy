package config.groovyFiles.com.better517na.clairpurchasinginterface.business.czb2g


import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.AirDocDisplayRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.AirDocDisplayRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundApply.OrderViewRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundApply.RefundApplyReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.OrderChangeRQ


interface ICZB2GRefundBusiness {
    AirDocDisplayRS getRefundOrderDetail(AirDocDisplayRQ airDocDisplayRQ, String url);

    OrderViewRS applyRefund(RefundApplyReq refundApplyReq, String url);

    config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundSubmit.OrderViewRS refundSubmit(OrderChangeRQ orderChangeRQ, String url);

}