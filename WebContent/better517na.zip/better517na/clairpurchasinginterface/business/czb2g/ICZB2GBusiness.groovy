package config.groovyFiles.com.better517na.clairpurchasinginterface.business.czb2g

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book.BookReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book.OrderViewRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail.Czb2gOrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail.OrderDetailReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment.CZPayRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment.CZpayResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price.FlightPriceRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price.PriceReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.AirShoppingRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.ShoppingReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.ticketIssue.CZticketIssueRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.ticketIssue.CZticketIssueResponse

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/24
 * Time: 16:30
 */
interface ICZB2GBusiness {
    /**
     * 用户认证.
     * @param account 企业账号.
     * @param password 密码.
     * @param url url.
     * @return 返回token.
     */
    String accessToken(String account, String password, String url);

    /**
     * 航班查询.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    AirShoppingRS shopping(ShoppingReq request, String url);

    /**
     * 运价查询.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    FlightPriceRS price(PriceReq request, String url);

    /**
     * 预订.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    OrderViewRS book(BookReq request, String url);

    /**
     * 支付.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    CZpayResponse payment(CZPayRequest request, String url);

    /**
     * 出票.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    CZticketIssueResponse ticketIssue(CZticketIssueRes request, String url);

    /**
     * 订单详情查询.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    Czb2gOrderDetailResponse orderDetail(OrderDetailReq request, String url);
}