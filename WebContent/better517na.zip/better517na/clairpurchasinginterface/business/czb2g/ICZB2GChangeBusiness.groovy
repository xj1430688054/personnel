package config.groovyFiles.com.better517na.clairpurchasinginterface.business.czb2g

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.CancelChangeInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.ChangeOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.ChangeShowReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.ChangeShowResp
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange.DoBookRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange.DoBookRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue.ReissueRQ
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue.ReissueRS
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.ReshopReq
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.ReshopResp

interface ICZB2GChangeBusiness {

    /**
     * 查询准备改升行程信息
     * @param request
     * @param url
     * @return
     */
    ChangeShowResp changeShow(ChangeShowReq request, String url)

    /**
     * 查询改升航班
     * @param request
     * @param url
     * @return
     */
    ReshopResp reshop(ReshopReq request, String url)

    /**
     * 改升航班询价
     * @param request
     * @param url
     * @return
     */
    ReissueRS reissue(ReissueRQ request, String url)

    /**
     * 改期升舱
     * @param request
     * @param url
     * @return
     */
    DoBookRS dochange(DoBookRQ request, String url)
    /**
     * 取消改签
     * @param cancelChangeInVoRequestVo
     * @param url
     * @return
     */
    ChangeOutVo cancelChange(CancelChangeInVo cancelChangeInVoRequestVo, String url);
}