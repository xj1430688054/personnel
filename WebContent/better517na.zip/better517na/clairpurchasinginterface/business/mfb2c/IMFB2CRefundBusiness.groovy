package config.groovyFiles.com.better517na.clairpurchasinginterface.business.mfb2c

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundApplyInParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundApplyOutResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundQueryInParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFRefundQueryOutResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTARequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTAResponse

/**
 \* Created with IntelliJ IDEA.
 \* User: lulin
 \* Date: 2019-03-06
 \* Time: 11:38
 \* To change this template use File | Settings | File Templates.
 \* Description: 
 \*/
interface IMFB2CRefundBusiness {
    /**
     * mf提交退票
     * @param param 请求参数
     * @param url 地址
     * @return 处理结果
     */
    OTAResponse<MFRefundApplyOutResult> applyRefund(OTARequest<MFRefundApplyInParam> param, String url);

    /**
     * 查询手续费
     * @param param 参数
     * @param url 请求地址
     * @return 处理结果
     */
    OTAResponse<MFRefundQueryOutResult> queryReturnTicketRate(OTARequest<MFRefundQueryInParam> param,String url);

    /**
     * 查询详情
     * @param param 参数
     * @param url 请求地址
     * @return 处理结果
     */
    OTAResponse<MFRefundQueryOutResult> getRefundOrderDetail(OTARequest<MFRefundQueryInParam> param,String url);
}
