package config.groovyFiles.com.better517na.clairpurchasinginterface.business.mfb2c

import com.better517na.payInteractionService.MYeepayPayOutParam
import com.better517na.payInteractionService.MYeepayPayParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MFQueryOrderDetailOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.MfOrderQueryInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTARequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.OTAResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.createOrder.MFCreateOrderInParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.createOrder.MFCreateOrderOutResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentApplyReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentApplyResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentConfirmReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.pay.PaymentConfirmResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.queryFlight.MFQueryFlightInParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.mfb2c.queryFlight.MFQueryFlightOutResultVo

/**
 * @Auther: beitian
 * @Date: 2019/3/5 14:03
 * @Description:
 */
interface IMFB2CBusiness {


    OTAResponse<MFQueryFlightOutResultVo>queryFlight(OTARequest<MFQueryFlightInParamVo>requestVo, String url);

    OTAResponse<MFCreateOrderOutResultVo>createOrder(OTARequest<MFCreateOrderInParamVo>requestVo, String url);

    OTAResponse<MFQueryOrderDetailOutResultVo> orderDetail(OTARequest<MfOrderQueryInVo> requestVo, String url);

    OTAResponse<PaymentApplyResVo> paymentApply(OTARequest<PaymentApplyReqVo> requestVo, String url);

    OTAResponse<PaymentConfirmResVo> paymentConfirm(OTARequest<PaymentConfirmReqVo> requestVo, String url);

    MYeepayPayOutParam yeepayPay(MYeepayPayParam request, String pidUniqueKey, String pid, String url) throws Exception;
}