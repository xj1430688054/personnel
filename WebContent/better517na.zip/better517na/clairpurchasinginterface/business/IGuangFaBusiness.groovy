package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.GuangFaShoppingVo

public interface IGuangFaBusiness {

    /**
     * 查询运价（广发）
     * @param guangFaShoppingVo
     * @return
     */
    String guangfaQueryFlight(GuangFaShoppingVo guangFaShoppingVo);

}