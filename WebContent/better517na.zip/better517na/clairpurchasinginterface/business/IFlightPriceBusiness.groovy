package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.springAirSalesService.SearchFlightsBatchResultBean
import com.better517na.springAirSalesService.SearchFlightsBatchResultBean2
import com.better517na.springAirSalesService.SearchFlightsBatchSearchBean
import com.better517na.springAirSalesService.SearchFlightsBySegIdBean
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightSegIDParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightsBatchParam

interface IFlightPriceBusiness {

    /**
     * 批查询航班.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    QueryFlightResult searchFlightsBatch(QueryFlightRequest<QueryFlightsBatchParam> param, String url);

    /**
     * 根据航段ID查询航班信息2.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    QueryFlightResult searchFlightsBySegId2(QueryFlightRequest<QueryFlightSegIDParam> request, String url);

    /**
     * 根据航段ID查询航班信息2.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    QueryFlightResult searchFlightsOtaDay(QueryFlightRequest<QueryFlightParam> request, String url);
}