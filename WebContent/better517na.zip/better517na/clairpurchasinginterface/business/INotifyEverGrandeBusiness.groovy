package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.notify.TicketNoRequestVo

public interface INotifyEverGrandeBusiness {
    String notifyFillBackTicketNo(TicketNoRequestVo ticketNoRequest, String url);
}