package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.UserInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.InChannelFlightInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.InQueryFlightVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.OutChannelQueryFlightVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.OutQueryFlightVo

import java.text.SimpleDateFormat

/**
 * MUB2G渠道改签的对象转换
 */
public class ObjToObj {


    /**
     * 供应配置信息转换为用户信息.
     *
     * @param supplySystemInfo 供应配置信息.
     * @param bigCustomer      大客户号
     * @return 返回用户信息.
     */
    public static UserInfoVo supplyInfoToUserInfo(SupplySystemInfo supplySystemInfo, String bigCustomer) {
        UserInfoVo userInfoVo = new UserInfoVo();
        userInfoVo.setUserName(supplySystemInfo.getInterfaceAccount());
        userInfoVo.setPassWord(supplySystemInfo.getInterfacePassWord());
        userInfoVo.setUserSegment(supplySystemInfo.getpID());
        userInfoVo.setUserDesc(String.format('3/KA/%s/NULL/NULL', bigCustomer));
        userInfoVo.setInterfaceUrl(supplySystemInfo.getInterfaceUrl());
        userInfoVo.setBigCustomer(bigCustomer);

        return userInfoVo;
    }

    /**
     * ChangeTicketInfoBo 转换ChangeTicketInfoVo
     *
     * @param changeTicketInfoBo
     */
    public static ChangeTicketInfoVo changeTicketInfoBoToVo(BuyChangeTicketInfoBo changeTicketInfoBo) {

        ChangeTicketInfoVo changeTicketInfoVos = new ChangeTicketInfoVo();
        changeTicketInfoVos.setChangeDateFee(changeTicketInfoBo.getChangeDateFee() != null ? changeTicketInfoBo.getChangeDateFee().doubleValue() : 0);
        changeTicketInfoVos.setUpgradeFee(changeTicketInfoBo.getUpgradeFee() != null ? changeTicketInfoBo.getUpgradeFee().doubleValue() : 0);
        changeTicketInfoVos.setOrgTickPrice(changeTicketInfoBo.getAgentFee() != null ? changeTicketInfoBo.getAgentFee().doubleValue() : 0);
        changeTicketInfoVos.setiDNo(String.valueOf(changeTicketInfoBo.getCardNo()));
        changeTicketInfoVos.setiDType(changeTicketInfoBo.getCardType() + '');
        changeTicketInfoVos.setPassangerName(changeTicketInfoBo.getUserName());
        if (changeTicketInfoBo.getPassengerType() != null) {
            changeTicketInfoVos.setPassangerType(changeTicketInfoBo.getPassengerType());
        }
        changeTicketInfoVos.setOrgTicketNo(changeTicketInfoBo.getTicketNo());
        changeTicketInfoVos.setTickPrice(changeTicketInfoBo.getNewTickPrice() != null ? changeTicketInfoBo.getNewTickPrice().doubleValue() : 0);
        return changeTicketInfoVos;
    }


    /**
     * InChannelQueryChangeFeeVo 转换 InChangeCalculateFeeVo
     *
     * @param outChangeCalculateFeeVo
     * @return
     */
    public static OutChannelQueryChangeFeeVo calculateFeeToQueryChange(OutChangeCalculateFeeVo outChangeCalculateFeeVo) {
        OutChannelQueryChangeFeeVo outChannelQueryChangeFeeVo = new OutChannelQueryChangeFeeVo();
        if (outChangeCalculateFeeVo == null) {
            return null;
        }

        //乘机人集合
        List<ChangeTicketInfoVo> vo = outChangeCalculateFeeVo.getChangeTicketInfoVos();
        if (vo != null && vo.size() > 0) {
            List<BuyChangeTicketInfoBo> bo = new ArrayList<>();
            for (int i = 0; i < vo.size(); i++) {
                bo.add(changeTicketInfoVoToBo(vo.get(i)));
            }
            outChannelQueryChangeFeeVo.setTickets(bo);
        }

        outChannelQueryChangeFeeVo.setChangeOrderId(outChangeCalculateFeeVo.getChangeOrderId());
        outChannelQueryChangeFeeVo.setTotalChangeDateFee(outChangeCalculateFeeVo.getTotalChangeDateFee());
        outChannelQueryChangeFeeVo.setTotalUpgradeFee(outChangeCalculateFeeVo.getTotalUpgradeFee());

        return outChannelQueryChangeFeeVo;
    }


    public static InChangeCalculateFeeVo channelQueryToCalculateFee(InChannelQueryChangeFeeVo inChannelQueryChangeFeeVo) {
        InChangeCalculateFeeVo inChangeCalculateFeeVo = new InChangeCalculateFeeVo();
        if (inChannelQueryChangeFeeVo == null) {
            return null;
        }

        List<ChangeTicketInfoVo> changeTicketInfoVos = new ArrayList<>();
        if (inChannelQueryChangeFeeVo.getTickets() != null && inChannelQueryChangeFeeVo.getTickets().size() > 0) {
            for (int i = 0; i < inChannelQueryChangeFeeVo.getTickets().size(); i++) {
                changeTicketInfoVos.add(ObjToObj.changeTicketInfoBoToVo(inChannelQueryChangeFeeVo.getTickets().get(i)));
            }
            inChangeCalculateFeeVo.setChangeTicketInfoVos(changeTicketInfoVos);
        }

        if (inChannelQueryChangeFeeVo.getOrder() != null && inChannelQueryChangeFeeVo.getOrder().getOrderId() != null) {
            inChangeCalculateFeeVo.setChangeOrderId(inChannelQueryChangeFeeVo.getOrder().getOrderId());
        }

        List<BuyChangeVoyageInfoBo> buyBos = inChannelQueryChangeFeeVo.getVoyages();
        List<ChangeVoyageInfoVo> orgVoyage = new ArrayList<>();
        List<ChangeVoyageInfoVo> newVoyage = new ArrayList<>();
        if (buyBos != null && buyBos.size() > 0) {
            for (int i = 0; i < buyBos.size(); i++) {
                if (buyBos.get(i).getVoyageType() != null && buyBos.get(i).getVoyageType().intValue() == 0) {
                    orgVoyage.add(changeVoyageInfoBoToVo(buyBos.get(i)));
                } else if (buyBos.get(i).getVoyageType() != null && buyBos.get(i).getVoyageType().intValue() == 1) {
                    newVoyage.add(changeVoyageInfoBoToVo(buyBos.get(i)));
                }
            }
        }

        // 初始化改签类型(0:升舱,1:改期,2:升舱+改期).
        int changeType = 0;
        if (newVoyage.get(0).getSeatClass().equals(orgVoyage.get(0).getSeatClass())) {
            changeType = 1;
        }

        SimpleDateFormat sdf = new SimpleDateFormat('yyyy-MM-dd HH:mm');
        if (!sdf.format(newVoyage.get(0).getTakeOffTime()).equals(sdf.format(orgVoyage.get(0).getTakeOffTime()))) {
            changeType = 2;
        }

        inChangeCalculateFeeVo.setChangeType(changeType);
        inChangeCalculateFeeVo.setOrgChangeVoyage(orgVoyage);
        inChangeCalculateFeeVo.setNewChangeVoyage(newVoyage);

        return inChangeCalculateFeeVo;
    }


    /**
     * ChangeVoyageInfoBo 转换ChangeTicketInfoVo
     *
     * @param changeVoyageInfoBo
     */
    public static ChangeVoyageInfoVo changeVoyageInfoBoToVo(BuyChangeVoyageInfoBo changeVoyageInfoBo) {

        ChangeVoyageInfoVo changeTicketInfoVos = new ChangeVoyageInfoVo();
        changeTicketInfoVos.setArriveTime(changeVoyageInfoBo.getArrTime());
        changeTicketInfoVos.setFlightNO(changeVoyageInfoBo.getFlightNo());
        changeTicketInfoVos.setFromCity(changeVoyageInfoBo.getDeptCityCh());
        changeTicketInfoVos.setFromCityCode(changeVoyageInfoBo.getDeptCity());
        changeTicketInfoVos.setSeatClass(changeVoyageInfoBo.getCabin());
        changeTicketInfoVos.setTakeOffTime(changeVoyageInfoBo.getDeptTime());
        changeTicketInfoVos.setToCity(changeVoyageInfoBo.getArrCityCh());
        changeTicketInfoVos.setToCityCode(changeVoyageInfoBo.getArrCity());

        return changeTicketInfoVos;
    }


    /**
     * channelApplyChange
     * InChannelApplyChangeVo 转换成 InChangeTicketVo
     *
     * @param inChannelApplyChangeVo
     * @return
     */
    public static InChangeTicketVo applyChangeVoToChangeTicket(InChannelApplyChangeVo inChannelApplyChangeVo) {

        InChangeTicketVo inChangeTicketVo = new InChangeTicketVo();
        List<ChangeTicketInfoVo> changeTicketInfoVos = new ArrayList<>();
        if (inChannelApplyChangeVo == null) {
            return null;
        }
        //改签机票信息
        double totalUpgradeFee = 0;
        double totalChangeDateFee = 0;
        if (inChannelApplyChangeVo.getTickets() != null && inChannelApplyChangeVo.getTickets().size() > 0) {
            for (int i = 0; i < inChannelApplyChangeVo.getTickets().size(); i++) {
                ChangeTicketInfoVo ticketInfoVo = changeTicketInfoBoToVo(inChannelApplyChangeVo.getTickets().get(i));
                totalUpgradeFee += ticketInfoVo.getUpgradeFee();
                totalChangeDateFee += ticketInfoVo.getChangeDateFee();
                changeTicketInfoVos.add(ticketInfoVo);
            }
        }

        inChangeTicketVo.setTotalUpgradeFee(totalUpgradeFee);
        inChangeTicketVo.setTotalChangeDateFee(totalChangeDateFee);
        inChangeTicketVo.setChangeTicketInfoVos(changeTicketInfoVos);

        //改签的订单号
        if (inChannelApplyChangeVo.getOrder() != null && inChannelApplyChangeVo.getOrder().getChannelOrderId() != null) {
            inChangeTicketVo.setChangeOrderId(inChannelApplyChangeVo.getOrder().getChannelOrderId());
        }

        //  inChangeTicketVo.setAirOrderId();
        List<BuyChangeVoyageInfoBo> buyBos = inChannelApplyChangeVo.getVoyages();
        List<ChangeVoyageInfoVo> orgVoyage = new ArrayList<>();
        List<ChangeVoyageInfoVo> newVoyage = new ArrayList<>();
        if (buyBos != null && buyBos.size() > 0) {
            for (int i = 0; i < buyBos.size(); i++) {
                buyBos.get(i).getVoyageType();
                if (buyBos.get(i).getVoyageType() != null && buyBos.get(i).getVoyageType() == 0) {
                    orgVoyage.add(changeVoyageInfoBoToVo(buyBos.get(i)));
                } else if (buyBos.get(i).getVoyageType() != null && buyBos.get(i).getVoyageType() == 1) {
                    newVoyage.add(changeVoyageInfoBoToVo(buyBos.get(i)));
                }
            }
        }

        inChangeTicketVo.setOrgChangeVoyage(orgVoyage);
        inChangeTicketVo.setNewChangeVoyage(newVoyage);

        return inChangeTicketVo;
    }


    public static BuyChangeTicketInfoBo changeTicketInfoVoToBo(ChangeTicketInfoVo vo) {
        BuyChangeTicketInfoBo changeTicketInfoBo = new BuyChangeTicketInfoBo();
        changeTicketInfoBo.setUpgradeFee(vo.getUpgradeFee() != null ? new BigDecimal(vo.getUpgradeFee()) : null);
        //changeTicketInfoBo.setAgentFee(vo.getF);

        //changeTicketInfoBo.setCardNo(vo.getiDNo());
        //changeTicketInfoBo.setCardType(vo.getiDType() != null && !vo.getiDType().equals('null') ? Integer.valueOf(vo.getiDType()) : null);
        changeTicketInfoBo.setChangeDateFee(vo.getChangeDateFee() != null ? new BigDecimal(vo.getChangeDateFee()) : null);
        changeTicketInfoBo.setUpgradeFee(vo.getUpgradeFee() != null ? new BigDecimal(vo.getUpgradeFee()) : null);
        changeTicketInfoBo.setChangeTickFee(changeTicketInfoBo.getChangeDateFee().add(changeTicketInfoBo.getUpgradeFee()));
        changeTicketInfoBo.setNewTickPrice(BigDecimal.valueOf(vo.getTickPrice()));
        changeTicketInfoBo.setUserName(vo.getPassangerName());
        changeTicketInfoBo.setTicketNo(vo.getOrgTicketNo());
        // changeTicketInfoBo.setIdentity(vo.getiDNo() != null && !vo.getiDNo().equals('null') ? Integer.valueOf(vo.getiDNo()) : null);
        // changeTicketInfoBo.setInternational(vo.getOrgTicketNo());
        // changeTicketInfoBo.setSellSalesPrice(vo.getOrgTickPrice() != null ? new BigDecimal(vo.getOrgTickPrice()) : null);
        changeTicketInfoBo.setNewTicketNo(vo.getTicketNo());
        // changeTicketInfoBo.setUserName(vo.getPassangerName());
        // changeTicketInfoBo.setPassengerType(vo.getPassangerType());
        return changeTicketInfoBo;
    }


    /**
     * 航班查询入参
     *
     * @param vo
     * @return
     */
    public static InQueryFlightVo changeFloghtInfoVoToin(InChannelFlightInfoVo vo) {
        InQueryFlightVo inQueryFlightVo = new InQueryFlightVo();
        inQueryFlightVo.setArrCity(vo.getArrCity());
        inQueryFlightVo.setDepCity(vo.getDepCity());
        inQueryFlightVo.setCarrier(vo.getCarrier());
        inQueryFlightVo.setFlightNo(vo.getFlightNo());
        inQueryFlightVo.setTakeOffDate(vo.getTakeOffDate());
        inQueryFlightVo.setS1(vo.getS1());
        inQueryFlightVo.setVoyageType(vo.getVoyageType());
        inQueryFlightVo.setCabin(vo.getCabin());
        inQueryFlightVo.setFromCity(vo.getFromCity());
        inQueryFlightVo.setToCity(vo.getToCity());
        return inQueryFlightVo;
    }

    /**
     * 航班查询出参
     *
     * @param vo
     * @return
     */
    public static OutChannelQueryFlightVo outQueryFlightVoTochannel(OutQueryFlightVo vo) {
        OutChannelQueryFlightVo outChannelQueryFlightVo = new OutChannelQueryFlightVo();
        outChannelQueryFlightVo.setToCity(vo.getToCity());
        outChannelQueryFlightVo.setFromCity(vo.getFromCity());
        outChannelQueryFlightVo.setS1(vo.getS1());
        outChannelQueryFlightVo.setTakeOffDate(vo.getTakeOffDate());
        outChannelQueryFlightVo.setFlightInfoList(vo.getFlightInfoList());
        return outChannelQueryFlightVo;
    }
}
