package config.groovyFiles.com.better517na.clairpurchasinginterface.business.qunar

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.ApplyRefundInVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.ApplyRefundOutVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.QueryRefundRateParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.refund.RefundRateQueryResult

interface IQunarRefundBusiness {
    Response<ApplyRefundOutVo> returnTicket(Request<ApplyRefundInVo> requestVo, String key, String url);

    Response<List<RefundRateQueryResult>> queryReturnTicketRate(Request<QueryRefundRateParam> requestVo, String key, String url);

    Response<OrderDetailResponse> getRefundOrderDetail(Request<?> requestVo, String key, String url);
}
