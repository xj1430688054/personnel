package config.groovyFiles.com.better517na.clairpurchasinginterface.business.qunar

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Request
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeApplyParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeApplyResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeQueryParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.ChangeQueryResultVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.SearchFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.change.SearchFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.QueryParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.pay.ChangePayResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.InChannelChangePayNewVo

interface IQunarChangeBusiness {
    ChangeQueryResultVo changeSearch(Request<ChangeQueryParamVo> requestVo, String key, String url);

    Response<ChangePayResult> channelChangePay(Request<InChannelChangePayNewVo> inChannelChangePayVo, String key, String url)

    Response<SearchFlightResult> searchFlight(Request<SearchFlightRequest> searchFlightRequestRequest, String key, String url)

    ChangeApplyResultVo changeApply(Request<ChangeApplyParamVo> requestVo, String key, String url);

    Response<OrderDetailResponse> queryOrder(Request<QueryParam> requestVo, String key, String url)
}
