package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.springAirSalesService.GetFlightsCanBgInputBean
import com.better517na.springAirSalesService.GetFlightsCanBgResultBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoInputBean
import com.better517na.springAirSalesService.QueryFlightBgAppInfoResultBean
import com.better517na.springAirSalesService.SubmitFlightBgAppInputBean
import com.better517na.springAirSalesService.SubmitFlightBgAppResultBean

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/10/26
 * Time: 11:34
 */
interface ISpringAirChangeBusiness {

    GetFlightsCanBgResultBean getFlightsCanBg(GetFlightsCanBgInputBean getFlightsCanBgInputBean, String url)
    /**
     * 提交网上航班变更申请2.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    SubmitFlightBgAppResultBean submitFlightBgApp2(SubmitFlightBgAppInputBean request, String url)

    /**
     * 查询网上航班变更申请.
     * @param request 请求.
     * @param url url.
     * @return 结果.
     */
    QueryFlightBgAppInfoResultBean queryFlightBgAppInfo(QueryFlightBgAppInfoInputBean request, String url)
}