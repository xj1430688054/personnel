package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import com.better517na.springAirSalesService.ApplyReturnTicketInputBean
import com.better517na.springAirSalesService.ApplyReturnTicketResultBean2
import com.better517na.springAirSalesService.CalcRetTktFeeInputBean
import com.better517na.springAirSalesService.CalcRetTktFeeResultBean

interface ISpringAirRefundBusiness {

    CalcRetTktFeeResultBean calcRetTktFee(CalcRetTktFeeInputBean calcRetTktFeeInputBean, String url)

    ApplyReturnTicketResultBean2 applyReturnTicket2(ApplyReturnTicketInputBean applyReturnTicketInputBean, String url)
}