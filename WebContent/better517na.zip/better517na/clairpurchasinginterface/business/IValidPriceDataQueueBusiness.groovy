package config.groovyFiles.com.better517na.clairpurchasinginterface.business

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.QunarSearchPriceVendorPriceVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.detail.OrderDetailResponse
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.OutQueryOrderInfoVo

interface IValidPriceDataQueueBusiness {
    public void qunarPayValidateDataPublishQueue(ResponseVo<OutQueryOrderInfoVo> queryOrderInfoRes, OrderDetailResponse qunarOriResponse);

    public void qunarCreateOrderDataPublishQueue(List<QunarSearchPriceVendorPriceVo> reverseVendorPriceVoArrayList);

    void qunarSearchPriceDataPublishQueue(List<QunarSearchPriceVendorPriceVo> reverseVendorPriceVoArrayList);
}
