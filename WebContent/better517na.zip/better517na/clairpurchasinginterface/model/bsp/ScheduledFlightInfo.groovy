/*
 * 文件名：ScheduledFlightInfo.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： ScheduledFlightInfo.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * 航班对象.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public class ScheduledFlightInfo {

    /**
     * 航司二字码.
     */
    private String airways;

    /**
     * 航班号.
     */
    private String scheduledFlightNo;

    /**
     * 构造函数.
     * 
     * @param airways
     * airways
     * @param scheduledFlightNo
     * scheduledFlightNo
     */
    public ScheduledFlightInfo(String airways, String scheduledFlightNo) {
        this.airways = airways;
        this.scheduledFlightNo = scheduledFlightNo;
    }

    /**
     * 设置航司.
     * 
     * @return 返回airways
     */
    public String getAirways() {
        return airways;
    }

    /**
     * 获取航司.
     * 
     * @param airways
     *            要设置的airways
     */
    public void setAirways(String airways) {
        this.airways = airways;
    }

    /**
     * 设置航班号.
     * 
     * @return 返回scheduledFlightNo
     */
    public String getScheduledFlightNo() {
        return scheduledFlightNo;
    }

    /**
     * 获取航班号.
     * 
     * @param scheduledFlightNo
     *            要设置的scheduledFlightNo
     */
    public void setScheduledFlightNo(String scheduledFlightNo) {
        this.scheduledFlightNo = scheduledFlightNo;
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public String toString() {
        return airways + scheduledFlightNo;
    }
}
