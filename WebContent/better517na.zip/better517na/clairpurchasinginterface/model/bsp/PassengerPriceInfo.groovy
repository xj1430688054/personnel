package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp

/**
 * 乘机人价格对象.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public class PassengerPriceInfo {

    /**
     * 票面价.
     */
    private double fare;

    /**
     * 机建.
     */
    private double airportBuildFee;

    /**
     * 燃油.
     */
    private double fuelFee;

    /**
     * 是否匹配价格.
     */
    private boolean isMatch;

    /**
     * 税费.
     */
    private double tax;

    /**
     * 总价.
     */
    private double tatal;

    /**
     * 提前天数.
     */
    private int advanceDay;

    /**
     * 舱位.
     */
    private String seatClass;

    /**
     * 舱位信息.
     */
    private String seatInfo;

    /**
     * 设置票面价.
     * 
     * @return 返回fare
     */
    public double getFare() {
        return fare;
    }

    /**
     * 获取票面价.
     * 
     * @param fare
     *            要设置的fare
     */
    public void setFare(double fare) {
        this.fare = fare;
    }

    /**
     * 设置机建.
     * 
     * @return 返回airportBuildFee
     */
    public double getAirportBuildFee() {
        return airportBuildFee;
    }

    /**
     * 获取机建.
     * 
     * @param airportBuildFee
     *            要设置的airportBuildFee
     */
    public void setAirportBuildFee(double airportBuildFee) {
        this.airportBuildFee = airportBuildFee;
    }

    /**
     * 设置燃油.
     * 
     * @return 返回fuelFee
     */
    public double getFuelFee() {
        return fuelFee;
    }

    /**
     * 获取燃油.
     * 
     * @param fuelFee
     *            要设置的fuelFee
     */
    public void setFuelFee(double fuelFee) {
        this.fuelFee = fuelFee;
    }

    /**
     * 设置是否匹配价格.
     * 
     * @return 返回isMatch
     */
    public boolean isMatch() {
        return isMatch;
    }

    /**
     * 获取是否匹配价格.
     * 
     * @param isMatchs
     *            要设置的isMatch
     */
    public void setMatch(boolean isMatchs) {
        this.isMatch = isMatchs;
    }

    /**
     * 设置税费.
     * 
     * @return 返回tax
     */
    public double getTax() {
        return tax;
    }

    /**
     * 获取税费.
     * 
     * @param tax
     *            要设置的tax
     */
    public void setTax(double tax) {
        this.tax = tax;
    }

    /**
     * 设置总价.
     * 
     * @return 返回tatal
     */
    public double getTatal() {
        return tatal;
    }

    /**
     * 获取总价.
     * 
     * @param tatal
     *            要设置的tatal
     */
    public void setTatal(double tatal) {
        this.tatal = tatal;
    }

    /**
     * 设置提前天数.
     * 
     * @return 返回advanceDay
     */
    public int getAdvanceDay() {
        return advanceDay;
    }

    /**
     * 获取提前天数.
     * 
     * @param advanceDay
     *            要设置的advanceDay
     */
    public void setAdvanceDay(int advanceDay) {
        this.advanceDay = advanceDay;
    }

    /**
     * 设置舱位.
     * 
     * @return 返回seatClass
     */
    public String getSeatClass() {
        return seatClass;
    }

    /**
     * 获取舱位.
     * 
     * @param seatClass
     *            要设置的seatClass
     */
    public void setSeatClass(String seatClass) {
        this.seatClass = seatClass;
    }

    /**
     * 设置舱位信息.
     * 
     * @return 返回seatInfo
     */
    public String getSeatInfo() {
        return seatInfo;
    }

    /**
     * 获取舱位信息.
     * 
     * @param seatInfo
     *            要设置的seatInfo
     */
    public void setSeatInfo(String seatInfo) {
        this.seatInfo = seatInfo;
    }
}
