package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp

class PriceInfo {
    private Double discount;

    private BigDecimal fare;

    private BigDecimal airportBuildFee;

    private BigDecimal fuelFee;

    private BigDecimal FullPrice;

    private BigDecimal tax;

    private BigDecimal tatal;

    private BigDecimal otherTax;

    private String currency;

    Double getDiscount() {
        return discount
    }

    void setDiscount(Double discount) {
        this.discount = discount
    }

    BigDecimal getFare() {
        return fare
    }

    void setFare(BigDecimal fare) {
        this.fare = fare
    }

    BigDecimal getAirportBuildFee() {
        return airportBuildFee
    }

    void setAirportBuildFee(BigDecimal airportBuildFee) {
        this.airportBuildFee = airportBuildFee
    }

    BigDecimal getFuelFee() {
        return fuelFee
    }

    void setFuelFee(BigDecimal fuelFee) {
        this.fuelFee = fuelFee
    }

    BigDecimal getFullPrice() {
        return FullPrice
    }

    void setFullPrice(BigDecimal fullPrice) {
        FullPrice = fullPrice
    }

    BigDecimal getTax() {
        return tax
    }

    void setTax(BigDecimal tax) {
        this.tax = tax
    }

    BigDecimal getTatal() {
        return tatal
    }

    void setTatal(BigDecimal tatal) {
        this.tatal = tatal
    }

    BigDecimal getOtherTax() {
        return otherTax
    }

    void setOtherTax(BigDecimal otherTax) {
        this.otherTax = otherTax
    }

    String getCurrency() {
        return currency
    }

    void setCurrency(String currency) {
        this.currency = currency
    }
}
