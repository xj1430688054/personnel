/*
 * 文件名：PNRStatus.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： PNRStatus.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * PNR状态枚举.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public enum PNRStatus {

    /**
     * NoPNR.
     */
    NoPNR(0),

    /**
     * 已取消.
     */
    Cancelled(1),

    /**
     * 正常.
     */
    Normal(2),

    /**
     * 已出票.
     */
    Outed(3),

    /**
     * 已失效.
     */
    Invalid(4);

     /**
      * 构造函数.
      *
      * @param value
      *            值
      */
     private PNRStatus(Integer value) {
          this.value = value;
     }

     /**
      * 渠道值.
      */
     private Integer value;

     /**
      * {@inheritDoc}.
      */
     public String toString() {
          return value.toString();
     }

     /**
      * 设置value.
      *
      * @return 返回value
      */
     public Integer getValue() {
          return value;
     }

     /**
      * 获取value.
      *
      * @param value
      *            要设置的value
      */
     public void setValue(Integer value) {
          this.value = value;
     }

    // public static final int NoPNR = 0;
    //
    // public static final int Cancelled = 1;
    //
    // public static final int Normal = 2;
    //
    // public static final int Outed = 3;
    //
    // public static final int Invalid = 4;
}
