/*
 * 文件名：PNRContentInfo.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： PNRContentInfo.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;


/**
 * PNR对象.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public class PNRContentInfo implements Serializable {

    /**
     * 序列化版本号.
     */
    private static final long serialVersionUID = 1L;

    /**
     * 小编码.
     */
    private String pNRCode;

    /**
     * 大编码.
     */
    private String bigPNR;

    /**
     * 编码状态.
     */
    private Integer status;

    /**
     * Office号.
     */
    private String officeNo;

    /**
     * PNR内容.
     */
    private String pNRContent;

    /**
     * PAT内容.
     */
    private String patInfo;

    /**
     * 是否团队编码.
     */
    private boolean isTeam;

    /**
     * 是否包含婴儿.
     */
    private boolean isIncludedBaby;

    /**
     * 证件号项数.
     */
    private int sSRFOIDCount;

    /**
     * 是否PAT.
     */
    private boolean isPAT;

    /**
     * B2B价格.
     */
    private double b2BPrice;

    /**
     * BSP价格.
     */
    private double bSPPrice;

    /**
     * 行程.
     */
    private String travel;

    /**
     * 行程类型.
     */
    private TravelType travelType;

    /**
     * PNR来源.
     */
    private AnalisisAction action;

    /**
     * 备注信息.
     */
    private String remark;

    /**
     * 配置提供方ID.
     */
    private int configurationSupplierDeptId;

    /**
     * 是否特价.
     */
    private boolean isTeJia;

    /**
     * 备用.
     */
    private String tag;

    /**
     * 乘机人集合.
     */
    private List<PassengerInfo> passengers;

    /**
     * 乘机人数.
     */
    private int passengerCount;

    /**
     * 成人乘机人数.
     */
    private int adultPassengerCount;

    /**
     * 婴儿乘机人数.
     */
    private int babyPassengerCount;

    /**
     * 航段集合.
     */
    private List<VoyageInfo> voyages;

    /**
     * 航段数.
     */
    private int voyageCount;

    /**
     * 成人价格集合.
     */
    private List<PassengerPriceInfo> adultPassgersPrice;

    /**
     * 设置小编码.
     *
     * @return 返回pnrCode
     */
    public String getPNRCode() {
        return pNRCode;
    }

    /**
     * 获取小编码.
     *
     * @param pnrCode
     *            要设置的pnrCode
     */
    public void setPNRCode(String pnrCode) {
        this.pNRCode = pnrCode;
    }

    /**
     * 设置大编码.
     *
     * @return 返回bigPNR
     */
    public String getBigPNR() {
        return bigPNR;
    }

    /**
     * 获取大编码.
     *
     * @param bigPNR
     *            要设置的bigPNR
     */
    public void setBigPNR(String bigPNR) {
        this.bigPNR = bigPNR;
    }

    /**
     * 设置编码状态.
     * 
     * @return 返回status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 获取编码状态.
     * 
     * @param status
     *            要设置的status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 设置Office号.
     *
     * @return 返回officeNo
     */
    public String getOfficeNo() {
        return officeNo;
    }

    /**
     * 获取Office号.
     *
     * @param officeNo
     *            要设置的officeNo
     */
    public void setOfficeNo(String officeNo) {
        this.officeNo = officeNo;
    }

    /**
     * 设置PNR内容.
     *
     * @return 返回pnrContent
     */
    public String getPnrContent() {
        return pNRContent;
    }

    /**
     * 获取PNR内容.
     *
     * @param pnrContent
     *            要设置的pnrContent
     */
    public void setPnrContent(String pnrContent) {
        this.pNRContent = pnrContent;
    }

    /**
     * 设置PAT内容.
     *
     * @return 返回patInfo
     */
    public String getPatInfo() {
        return patInfo;
    }

    /**
     * 获取PAT内容.
     *
     * @param patInfo
     *            要设置的patInfo
     */
    public void setPatInfo(String patInfo) {
        this.patInfo = patInfo;
    }

    /**
     * 设置是否团队编码.
     *
     * @return 返回isTeam
     */
    public boolean isTeam() {
        return isTeam;
    }

    /**
     * 获取是否团队编码.
     *
     * @param isTeams
     *            要设置的isTeam
     */
    public void setTeam(boolean isTeams) {
        this.isTeam = isTeams;
    }

    /**
     * 设置是否包含婴儿.
     *
     * @return 返回isIncludedBaby
     */
    public boolean isIncludedBaby() {
        return isIncludedBaby;
    }

    /**
     * 获取是否包含婴儿.
     *
     * @param isIncludedBabys
     *            要设置的isIncludedBaby
     */
    public void setIncludedBaby(boolean isIncludedBabys) {
        this.isIncludedBaby = isIncludedBabys;
    }

    /**
     * 设置证件号项数.
     *
     * @return 返回sSRFOIDCount
     */
    public int getsSRFOIDCount() {
        return sSRFOIDCount;
    }

    /**
     * 获取证件号项数.
     *
     * @param sSRFOIDCount
     *            要设置的sSRFOIDCount
     */
    public void setsSRFOIDCount(int sSRFOIDCount) {
        this.sSRFOIDCount = sSRFOIDCount;
    }

    /**
     * 设置是否PAT.
     *
     * @return 返回isPAT
     */
    public boolean isPAT() {
        return isPAT;
    }

    /**
     * 获取是否PAT.
     *
     * @param isPATs
     *            要设置的isPAT
     */
    public void setPAT(boolean isPATs) {
        this.isPAT = isPATs;
    }

    /**
     * 设置B2B价格.
     *
     * @return 返回b2BPrice
     */
    public double getB2BPrice() {
        return b2BPrice;
    }

    /**
     * 获取B2B价格.
     *
     * @param b2bPrice
     *            要设置的b2BPrice
     */
    public void setB2BPrice(double b2bPrice) {
        b2BPrice = b2bPrice;
    }

    /**
     * 设置BSP价格.
     *
     * @return 返回bSPPrice
     */
    public double getbSPPrice() {
        return bSPPrice;
    }

    /**
     * 获取BSP价格.
     *
     * @param bSPPrice
     *            要设置的bSPPrice
     */
    public void setbSPPrice(double bSPPrice) {
        this.bSPPrice = bSPPrice;
    }

    /**
     * 设置行程.
     *
     * @return 返回travel
     */
    public String getTravel() {
        return travel;
    }

    /**
     * 获取行程.
     *
     * @param travel
     *            要设置的travel
     */
    public void setTravel(String travel) {
        this.travel = travel;
    }

    /**
     * 设置行程类型.
     *
     * @return 返回travelType
     */
    public TravelType getTravelType() {
        return travelType;
    }

    /**
     * 获取行程类型.
     *
     * @param travelType
     *            要设置的travelType
     */
    public void setTravelType(TravelType travelType) {
        this.travelType = travelType;
    }

    /**
     * 设置编码来源.
     *
     * @return 返回action
     */
    public AnalisisAction getAction() {
        return action;
    }

    /**
     * 获取编码来源.
     *
     * @param action
     *            要设置的action
     */
    public void setAction(AnalisisAction action) {
        this.action = action;
    }

    /**
     * 设置备注.
     *
     * @return 返回remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 获取备注.
     *
     * @param remark
     *            要设置的remark
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * 设置配置提供方ID.
     *
     * @return 返回configurationSupplierDeptId
     */
    public int getConfigurationSupplierDeptId() {
        return configurationSupplierDeptId;
    }

    /**
     * 获取配置提供方ID.
     *
     * @param configurationSupplierDeptId
     *            要设置的configurationSupplierDeptId
     */
    public void setConfigurationSupplierDeptId(int configurationSupplierDeptId) {
        this.configurationSupplierDeptId = configurationSupplierDeptId;
    }

    /**
     * 设置是否特价.
     *
     * @return 返回isTeJia
     */
    public boolean isTeJia() {
        return isTeJia;
    }

    /**
     * 获取是否特价.
     *
     * @param isTeJias
     *            要设置的isTeJia
     */
    public void setTeJia(boolean isTeJias) {
        this.isTeJia = isTeJias;
    }

    /**
     * 设置备用.
     *
     * @return 返回tag
     */
    public String getTag() {
        return tag;
    }

    /**
     * 获取备用.
     *
     * @param tag
     *            要设置的tag
     */
    public void setTag(String tag) {
        this.tag = tag;
    }

    /**
     * 设置乘机人集合.
     *
     * @return 返回passengers
     */
    public List<PassengerInfo> getPassengers() {
        return passengers;
    }

    /**
     * 获取乘机人集合.
     *
     * @param passengers
     *            要设置的passengers
     */
    public void setPassengers(List<PassengerInfo> passengers) {
        this.passengers = passengers;
    }

    /**
     * 设置乘机人数.
     *
     * @return 返回passengerCount
     */
    public int getPassengerCount() {
        return passengerCount;
    }

    /**
     * 获取乘机人数.
     *
     * @param passengerCount
     *            要设置的passengerCount
     */
    public void setPassengerCount(int passengerCount) {
        this.passengerCount = passengerCount;
    }

    /**
     * 设置成人乘机人数.
     *
     * @return 返回adultPassengerCount
     */
    public int getAdultPassengerCount() {
        return adultPassengerCount;
    }

    /**
     * 获取成人乘机人数.
     *
     * @param adultPassengerCount
     *            要设置的adultPassengerCount
     */
    public void setAdultPassengerCount(int adultPassengerCount) {
        this.adultPassengerCount = adultPassengerCount;
    }

    /**
     * 设置婴儿乘机人数.
     *
     * @return 返回babyPassengerCount
     */
    public int getBabyPassengerCount() {
        return babyPassengerCount;
    }

    /**
     * 获取婴儿乘机人数.
     *
     * @param babyPassengerCount
     *            要设置的babyPassengerCount
     */
    public void setBabyPassengerCount(int babyPassengerCount) {
        this.babyPassengerCount = babyPassengerCount;
    }

    /**
     * 设置航段集合.
     *
     * @return 返回voyages
     */
    public List<VoyageInfo> getVoyages() {
        return voyages;
    }

    /**
     * 获取航段集合.
     *
     * @param voyages
     *            要设置的voyages
     */
    public void setVoyages(List<VoyageInfo> voyages) {
        this.voyages = voyages;
    }

    /**
     * 设置航段数.
     *
     * @return 返回voyageCount
     */
    public int getVoyageCount() {
        return voyageCount;
    }

    /**
     * 获取航段数.
     *
     * @param voyageCount
     *            要设置的voyageCount
     */
    public void setVoyageCount(int voyageCount) {
        this.voyageCount = voyageCount;
    }

    /**
     * 设置成人价格集合.
     *
     * @return 返回adultPassgersPrice
     */
    public List<PassengerPriceInfo> getAdultPassgersPrice() {
        return adultPassgersPrice;
    }

    /**
     * 获取成人价格集合.
     *
     * @param adultPassgersPrice
     *            要设置的adultPassgersPrice
     */
    public void setAdultPassgersPrice(List<PassengerPriceInfo> adultPassgersPrice) {
        this.adultPassgersPrice = adultPassgersPrice;
    }
}
