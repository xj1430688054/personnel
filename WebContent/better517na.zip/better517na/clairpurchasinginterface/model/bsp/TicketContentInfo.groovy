
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp

import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.TicketStatus;

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp
 * Author: gaoshun
 * DateTime: 2018/8/29 15:52
 * Desc: 说明类的作用
 */
public class TicketContentInfo {
    /**
     * 大编码
     */
    private String bigPnr;

    /**
     * 凭据
     */
    private String credentialCode;

    /**
     * 信息
     */
    private String information;

    /**
     * 保单
     */
    private String insurance;

    /**
     * 是否是BSP出票
     */
    private Boolean isBSP;

    /**
     * 是否取消行程
     */
    private Boolean isCancelItinerary;

    /**
     * 是否取消位置
     */
    private Boolean isCancelSeat;

    /**
     * 乘机人姓名
     */
    private String passengerName;

    /**
     * 乘机人类型
     */
    private PassengerType passengerType;

    /**
     * 小编码
     */
    private String smallPnr;

    /**
     * ticketContent
     */
    private String ticketContent;

    /**
     * TicketEI
     */
    private String ticketEI;

    /**
     * 票号
     */
    private String ticketNo;

    /**
     * 票号状态
     */
    private List<Integer> ticketStatus;

    /**
     * 航程信息
     */
    private List<VoyageInfo> voyages;

    /**
     * 价格信息
     */
    private PriceInfo priceInfo;

    PriceInfo getPriceInfo() {
        return priceInfo
    }

    void setPriceInfo(PriceInfo priceInfo) {
        this.priceInfo = priceInfo
    }

    public String getBigPnr() {
        return bigPnr;
    }

    public void setBigPnr(String bigPnr) {
        this.bigPnr = bigPnr;
    }

    public String getCredentialCode() {
        return credentialCode;
    }

    public void setCredentialCode(String credentialCode) {
        this.credentialCode = credentialCode;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }

    public String getInsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }

    public Boolean getBSP() {
        return isBSP;
    }

    public void setBSP(Boolean BSP) {
        isBSP = BSP;
    }

    public Boolean getCancelItinerary() {
        return isCancelItinerary;
    }

    public void setCancelItinerary(Boolean cancelItinerary) {
        isCancelItinerary = cancelItinerary;
    }

    public Boolean getCancelSeat() {
        return isCancelSeat;
    }

    public void setCancelSeat(Boolean cancelSeat) {
        isCancelSeat = cancelSeat;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public PassengerType getPassengerType() {
        return passengerType;
    }

    public void setPassengerType(PassengerType passengerType) {
        this.passengerType = passengerType;
    }

    public String getSmallPnr() {
        return smallPnr;
    }

    public void setSmallPnr(String smallPnr) {
        this.smallPnr = smallPnr;
    }

    public String getTicketContent() {
        return ticketContent;
    }

    public void setTicketContent(String ticketContent) {
        this.ticketContent = ticketContent;
    }

    public String getTicketEI() {
        return ticketEI;
    }

    public void setTicketEI(String ticketEI) {
        this.ticketEI = ticketEI;
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    public List<VoyageInfo> getVoyages() {
        return voyages;
    }

    public void setVoyages(List<VoyageInfo> voyages) {
        this.voyages = voyages;
    }

    List<Integer> getTicketStatus() {
        return ticketStatus
    }

    void setTicketStatus(List<Integer> ticketStatus) {
        this.ticketStatus = ticketStatus
    }
}
