package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/4/12
 * Time: 22:00
 */
public class CommonParamOutBo {

    /**
     * 是否成功0：失败，1：成功
     */
    private Boolean isSuccess;

    /**
     * 错误消息
     */
    private String errMessage;

    /**
     * 配置账号
     */
    private String settingAccount;

    /**
     * 0：放大配置，1：原始配置
     */
    private Integer settingType;

    /**
     * 返回指令内容
     */
    private String pnrResult;

    public Boolean getSuccess() {
        return isSuccess;
    }

    public void setSuccess(Boolean success) {
        isSuccess = success;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public String getSettingAccount() {
        return settingAccount;
    }

    public void setSettingAccount(String settingAccount) {
        this.settingAccount = settingAccount;
    }

    public Integer getSettingType() {
        return settingType;
    }

    public void setSettingType(Integer settingType) {
        this.settingType = settingType;
    }

    public String getPnrResult() {
        return pnrResult;
    }

    public void setPnrResult(String pnrResult) {
        this.pnrResult = pnrResult;
    }
}
