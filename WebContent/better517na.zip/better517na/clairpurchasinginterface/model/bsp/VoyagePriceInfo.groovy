/*
 * 文件名：VoyagePriceInfo.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： VoyagePriceInfo.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * 航段价格.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public class VoyagePriceInfo {

    /**
     * 航司.
     */
    private String airways;

    /**
     * 出发机场三字码.
     */
    private String fromCity;

    /**
     * 到达机场三字码.
     */
    private String toCity;

    /**
     * 舱位.
     */
    private String seatClass;

    /**
     * 票面价.
     */
    private double fare;

    /**
     * 燃油费.
     */
    private double fullPrice;

    /**
     * 机型.
     */
    private String airplaneModel;

    /**
     * 折扣.
     */
    private int discount;

    public VoyagePriceInfo() {
    }

    public VoyagePriceInfo(String airplaneModel) {
        this.airplaneModel = airplaneModel;
    }

    /**
     * 设置航司.
     * 
     * @return 返回airways
     */
    public String getAirways() {
        return airways;
    }

    /**
     * 获取航司.
     * 
     * @param airways
     *            要设置的airways
     */
    public void setAirways(String airways) {
        this.airways = airways;
    }

    /**
     * 设置出发机场三字码.
     * 
     * @return 返回fromCity
     */
    public String getFromCity() {
        return fromCity;
    }

    /**
     * 获取出发机场三字码.
     * 
     * @param fromCity
     *            要设置的fromCity
     */
    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    /**
     * 设置到达机场三字码.
     * 
     * @return 返回toCity
     */
    public String getToCity() {
        return toCity;
    }

    /**
     * 获取到达机场三字码.
     * 
     * @param toCity
     *            要设置的toCity
     */
    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    /**
     * 设置舱位.
     * 
     * @return 返回seatClass
     */
    public String getSeatClass() {
        return seatClass;
    }

    /**
     * 获取舱位.
     * 
     * @param seatClass
     *            要设置的seatClass
     */
    public void setSeatClass(String seatClass) {
        this.seatClass = seatClass;
    }

    /**
     * 设置票面价.
     * 
     * @return 返回fare
     */
    public double getFare() {
        return fare;
    }

    /**
     * 获取票面价.
     * 
     * @param fare
     *            要设置的fare
     */
    public void setFare(double fare) {
        this.fare = fare;
    }

    /**
     * 设置燃油费.
     * 
     * @return 返回fullPrice
     */
    public double getFullPrice() {
        return fullPrice;
    }

    /**
     * 获取燃油费.
     * 
     * @param fullPrice
     *            要设置的fullPrice
     */
    public void setFullPrice(double fullPrice) {
        this.fullPrice = fullPrice;
    }

    /**
     * 设置机型.
     * 
     * @return 返回airplaneModel
     */
    public String getAirplaneModel() {
        return airplaneModel;
    }

    /**
     * 获取机型.
     * 
     * @param airplaneModel
     *            要设置的airplaneModel
     */
    public void setAirplaneModel(String airplaneModel) {
        this.airplaneModel = airplaneModel;
    }

    /**
     * 设置折扣.
     * 
     * @return 返回discount
     */
    public int getDiscount() {
        return discount;
    }

    /**
     * 获取折扣.
     * 
     * @param discount
     *            要设置的discount
     */
    public void setDiscount(int discount) {
        this.discount = discount;
    }
}
