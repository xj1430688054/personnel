/*
 * 文件名：PassengerType.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： PassengerType.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * 乘机人类型（国际国内通用）.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public enum PassengerType {

    /**
     * 成人.
     */
    Adult,

    /**
     * 儿童.
     */
    Child,

    /**
     * 婴儿.
     */
    Baby

    // public static final int Adult = 0;
    //
    // public static final int Child = 0;
    //
    // public static final int Baby = 0;

}
