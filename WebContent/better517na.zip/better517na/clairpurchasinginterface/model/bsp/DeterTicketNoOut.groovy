package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp
 * Author: gaoshun
 * DateTime: 2018/8/28 18:05
 * Desc: 说明类的作用
 */
public class DeterTicketNoOut extends CommonParamOutBo {
    /**
     * 票号信息
     */
    private TicketContentInfo ticketInfo;

    /**
     * 解析结果是否正确（业务上的票号提取成功标识）
     */
    private Boolean analysisResult;

    public TicketContentInfo getTicketInfo() {
        return ticketInfo;
    }

    public void setTicketInfo(TicketContentInfo ticketInfo) {
        this.ticketInfo = ticketInfo;
    }

    public Boolean getAnalysisResult() {
        return analysisResult;
    }

    public void setAnalysisResult(Boolean analysisResult) {
        this.analysisResult = analysisResult;
    }
}
