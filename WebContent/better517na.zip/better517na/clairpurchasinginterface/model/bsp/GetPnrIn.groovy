package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * Project: 差旅机票买入交易集成服务
 * Package: com.better517na.clairticketbuytradeintegration.model.bo.pnr
 * Author: gaoshun
 * DateTime: 2018/4/23 17:18
 * Desc: 说明类的作用
 */
public class GetPnrIn extends CommonParamInBo {

    /**
     * 小编码
     */
    private String smallPnr;

    /**
     * 大编码
     */
    private String bigPnr;

    /**
     * 小编码
     * @return 小编码
     */
    public String getSmallPnr() {
        return smallPnr;
    }

    /**
     * 小编码
     * @param smallPnr 小编码
     */
    public void setSmallPnr(String smallPnr) {
        this.smallPnr = smallPnr;
    }

    /**
     * 大编码
     * @return 大编码
     */
    public String getBigPnr() {
        return bigPnr;
    }

    /**
     * 大编码
     * @param bigPnr 大编码
     */
    public void setBigPnr(String bigPnr) {
        this.bigPnr = bigPnr;
    }
}
