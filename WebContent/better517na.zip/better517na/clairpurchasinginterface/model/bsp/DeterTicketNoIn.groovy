package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * Project: CLAirPurchasingInterface
 * Package: config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp
 * Author: gaoshun
 * DateTime: 2018/8/28 18:03
 * Desc: 说明类的作用
 */
public class DeterTicketNoIn extends CommonParamInBo {
    /**
     * 小编码
     */
    private String smallPnr;

    /**
     * 票号
     */
    private String ticketNo;

    public String getSmallPnr() {
        return smallPnr;
    }

    public void setSmallPnr(String smallPnr) {
        this.smallPnr = smallPnr;
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }
}
