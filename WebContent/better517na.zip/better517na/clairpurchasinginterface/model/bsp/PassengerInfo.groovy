/*
 * 文件名：PassengerInfo.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： PassengerInfo.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * 乘机人对象.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public class PassengerInfo {

    /**
     * 姓名.
     */
    private String name;

    /**
     * 乘机人类型.
     */
    private PassengerType passengerType;

    /**
     * 证件号.
     */
    private String credentialsCode;

    /**
     * 证件类型.
     */
    private String credentialsType;

    /**
     * 手机号.
     */
    private String mobileNo;

    /**
     * 结算码.
     */
    private String settleCode;

    /**
     * 票号.
     */
    private String ticketCode;

    /**
     * 乘机人序号.
     */
    private int index;

    /**
     * 常旅客卡号.
     */
    private String regularPassengerCard;

    /**
     * 价格对象.
     */
    private PassengerPriceInfo price;

    /**
     * 设置姓名.
     * 
     * @return 返回name
     */
    public String getName() {
        return name;
    }

    /**
     * 获取姓名.
     * 
     * @param name
     *            要设置的name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 设置乘机人类型.
     * 
     * @return 返回passengerType
     */
    public PassengerType getPassengerType() {
        return passengerType;
    }

    /**
     * 获取乘机人类型.
     * 
     * @param passengerType
     *            要设置的passengerType
     */
    public void setPassengerType(PassengerType passengerType) {
        this.passengerType = passengerType;
    }

    /**
     * 设置证件号.
     * 
     * @return 返回credentialsCode
     */
    public String getCredentialsCode() {
        return credentialsCode;
    }

    /**
     * 获取证件号.
     * 
     * @param credentialsCode
     *            要设置的credentialsCode
     */
    public void setCredentialsCode(String credentialsCode) {
        this.credentialsCode = credentialsCode;
    }

    /**
     * 设置证件类型.
     * 
     * @return 返回credentialsType
     */
    public String getCredentialsType() {
        return credentialsType;
    }

    /**
     * 获取证件类型.
     * 
     * @param credentialsType
     *            要设置的credentialsType
     */
    public void setCredentialsType(String credentialsType) {
        this.credentialsType = credentialsType;
    }

    /**
     * 设置手机号.
     * 
     * @return 返回mobileNo
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * 获取手机号.
     * 
     * @param mobileNo
     *            要设置的mobileNo
     */
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    /**
     * 设置结算码.
     * 
     * @return 返回settleCode
     */
    public String getSettleCode() {
        return settleCode;
    }

    /**
     * 获取结算码.
     * 
     * @param settleCode
     *            要设置的settleCode
     */
    public void setSettleCode(String settleCode) {
        this.settleCode = settleCode;
    }

    /**
     * 设置票号.
     * 
     * @return 返回ticketCode
     */
    public String getTicketCode() {
        return ticketCode;
    }

    /**
     * 获取票号.
     * 
     * @param ticketCode
     *            要设置的ticketCode
     */
    public void setTicketCode(String ticketCode) {
        this.ticketCode = ticketCode;
    }

    /**
     * 设置乘机人序号.
     * 
     * @return 返回index
     */
    public int getIndex() {
        return index;
    }

    /**
     * 获取乘机人序号.
     * 
     * @param index
     *            要设置的index
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * 设置常旅客卡号.
     * 
     * @return 返回regularPassengerCard
     */
    public String getRegularPassengerCard() {
        return regularPassengerCard;
    }

    /**
     * 获取常旅客卡号.
     * 
     * @param regularPassengerCard
     *            要设置的regularPassengerCard
     */
    public void setRegularPassengerCard(String regularPassengerCard) {
        this.regularPassengerCard = regularPassengerCard;
    }

    /**
     * 设置价格.
     * 
     * @return 返回price
     */
    public PassengerPriceInfo getPrice() {
        return price;
    }

    /**
     * 获取价格.
     * 
     * @param price
     *            要设置的price
     */
    public void setPrice(PassengerPriceInfo price) {
        this.price = price;
    }
}
