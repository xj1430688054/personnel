/*
 * 文件名：SeatStatus.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： SeatStatus.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * 座位状态枚举.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
/**
 * @author caozhenwei
 *
 */
/**
 * @author caozhenwei
 *
 */
/**
 * @author caozhenwei
 *
 */
public enum SeatStatus {
    /**
     * 预订状态，可以生成订单.
     */
    HK,

    /**
     * 不能生成订单.
     */
    HL,

    /**
     * 不能生成订单.
     */
    HN,

    /**
     * 不能生成订单.
     */
    NN,

    /**
     * 确定订位，可以生成订单.
     */
    RR,

    /**
     * 座位被NO，不能生成订单.
     */
    NO,

    /**
     * 已被取消，不能生成订单.
     */
    XX,

    /**
     * 航空公司X编码，不能生成订单.
     */
    HX,

    /**
     * 航班已变更，不能生成订单.
     */
    UN,

    /**
     * 已K到位置，可以生成订单.
     */
    KK,

    /**
     * 预订状态，可以生成订单.
     */
    DK,

    /**
     * 申请状态，不能生成订单.
     */
    DL,

    /**
     * 可以生成订单.
     */
    KL,

    /**
     * 其它未知状态.
     */
    OTHER,

    /**
     * 航班变动.
     */
    TK,

    /**
     * UU.
     */
    UU,

    /**
     * UC.
     */
    UC

    // public static final int HK = 0;
    //
    // public static final int HL = 1;
    //
    // public static final int HN = 2;
    //
    // public static final int NN = 3;
    //
    // public static final int RR = 4;
    //
    // public static final int NO = 5;
    //
    // public static final int XX = 6;
    //
    // public static final int HX = 7;
    //
    // public static final int UN = 8;
    //
    // public static final int KK = 9;
    //
    // public static final int DK = 10;
    //
    // public static final int DL = 11;
    //
    // public static final int KL = 12;
    //
    // public static final int OTHER = 13;
    //
    // public static final int TK = 14;
    //
    // public static final int UU = 15;
    //
    // public static final int UC = 16;
}
