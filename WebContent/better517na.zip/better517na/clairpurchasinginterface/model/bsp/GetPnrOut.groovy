package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp


/**
 * Project: 差旅机票买入交易集成服务
 * Package: com.better517na.clairticketbuytradeintegration.model.bo.pnr
 * Author: gaoshun
 * DateTime: 2018/4/23 17:26
 * Desc: 说明类的作用
 */
public class GetPnrOut extends CommonParamOutBo {
    /**
     * PNR对象
     */
    private PNRContentInfo pnrInfo;

    /**
     * PNR对象
     * @return PNR对象
     */
    public PNRContentInfo getPnrInfo() {
        return this.pnrInfo;
    }

    /**
     * PNR对象
     * @param pnrInfo PNR对象
     */
    public void setPnrInfo(PNRContentInfo pnrInfo) {
        pnrInfo = this.pnrInfo;
    }
}
