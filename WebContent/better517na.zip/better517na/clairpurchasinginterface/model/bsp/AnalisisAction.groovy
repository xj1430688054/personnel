/*
 * 文件名：AnalisisAction.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： AnalisisAction.java
 * 修改人：caozhenwei
 * 修改时间：2015年6月2日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * PNR对象来源.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public enum AnalisisAction {

    /**
     * B系统编码导入.
     */
    BImportPNR,

    /**
     * C系统编码导入.
     */
    CImportPNR,

    /**
     * B系统内容导入.
     */
    BImportContent,

    /**
     * C系统内容导入.
     */
    CImportContent,

    /**
     * B2B预订.
     */
    B2BBooking,

    /**
     * EM预订.
     */
    EMBooking
}
