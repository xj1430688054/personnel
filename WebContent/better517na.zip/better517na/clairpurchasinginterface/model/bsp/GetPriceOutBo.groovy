package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp
/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/4/12
 * Time: 22:10
 */
public class GetPriceOutBo extends CommonParamOutBo {
    /**
     * 价格列表
     */
    private List<PassengerPriceInfo> priceInfoList;

    /**
     * 返回PAT指令内容
     */
    private String patContent;

    public List<PassengerPriceInfo> getPriceInfoList() {
        return priceInfoList;
    }

    public void setPriceInfoList(List<PassengerPriceInfo> priceInfoList) {
        this.priceInfoList = priceInfoList;
    }

    public String getPatContent() {
        return patContent;
    }

    public void setPatContent(String patContent) {
        this.patContent = patContent;
    }
}
