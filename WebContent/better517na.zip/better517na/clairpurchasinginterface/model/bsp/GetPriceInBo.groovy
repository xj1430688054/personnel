package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/4/12
 * Time: 21:13
 */
public class GetPriceInBo extends CommonParamInBo {

    /**
     * 小编码.
     */
    private String smallPnr;

    /**
     * 大编码.
     */
    private String bigPnr;

    /**
     * 大客户编号.
     */
    private String bigCustomerNo;

    /**
     * 航司.
     */
    private String airCode;

    public String getSmallPnr() {
        return smallPnr;
    }

    public void setSmallPnr(String smallPnr) {
        this.smallPnr = smallPnr;
    }

    public String getBigPnr() {
        return bigPnr;
    }

    public void setBigPnr(String bigPnr) {
        this.bigPnr = bigPnr;
    }

    public String getBigCustomerNo() {
        return bigCustomerNo;
    }

    public void setBigCustomerNo(String bigCustomerNo) {
        this.bigCustomerNo = bigCustomerNo;
    }

    public String getAirCode() {
        return airCode;
    }

    public void setAirCode(String airCode) {
        this.airCode = airCode;
    }
}
