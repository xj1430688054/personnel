/*
 * 文件名：VoyageInfo.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： VoyageInfo.java
 * 修改人：caozhenwei
 * 修改时间：2015年5月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

import java.util.Date;

/**
 * 航段对象.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public class VoyageInfo {

    /**
     * 舱位.
     */
    private String seatClass;

    /**
     * 座位状态.
     */
    private SeatStatus seatStatus;

    /**
     * 出发机场三字码.
     */
    private String fromCity;

    /**
     * 到达机场三字码.
     */
    private String toCity;

    /**
     * 起飞时间.
     */
    private String takeoffTime;

    /**
     * 到达时间.
     */
    private String arriveTime;

    /**
     * 航班号.
     */
    private ScheduledFlightInfo scheduledFlight;

    /**
     * 实际承运航班号.
     */
    private ScheduledFlightInfo actualScheduledFlight;

    /**
     * 航段价格.
     */
    private VoyagePriceInfo price;

    /**
     * 出发航站楼.
     */
    private String startTerminalBuilding;

    /**
     * 到达航站楼.
     */
    private String endTerminalBuilding;

    /**
     * 里程数.
     */
    private double mileage;

    /**
     * 是否共享航班.
     */
    private boolean isShare;

    /**
     * 设置舱位.
     * 
     * @return 返回seatClass
     */
    public String getSeatClass() {
        return seatClass;
    }

    /**
     * 获取舱位.
     * 
     * @param seatClass
     *            要设置的seatClass
     */
    public void setSeatClass(String seatClass) {
        this.seatClass = seatClass;
    }

    /**
     * 设置座位状态.
     * 
     * @return 返回seatStatus
     */
    public SeatStatus getSeatStatus() {
        return seatStatus;
    }

    /**
     * 获取座位状态.
     * 
     * @param seatStatus
     *            要设置的seatStatus
     */
    public void setSeatStatus(SeatStatus seatStatus) {
        this.seatStatus = seatStatus;
    }

    /**
     * 设置出发机场三字码.
     * 
     * @return 返回fromCity
     */
    public String getFromCity() {
        return fromCity;
    }

    /**
     * 获取出发机场三字码.
     * 
     * @param fromCity
     *            要设置的fromCity
     */
    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    /**
     * 设置到达机场三字码.
     * 
     * @return 返回toCity
     */
    public String getToCity() {
        return toCity;
    }

    /**
     * 获取到达机场三字码.
     * 
     * @param toCity
     *            要设置的toCity
     */
    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    /**
     * 设置起飞时间.
     * 
     * @return 返回takeoffTime
     */
    public String getTakeoffTime() {
        return takeoffTime;
    }

    /**
     * 获取起飞时间.
     * 
     * @param takeoffTime
     *            要设置的takeoffTime
     */
    public void setTakeoffTime(String takeoffTime) {
        this.takeoffTime = takeoffTime;
    }

    /**
     * 设置到达时间.
     * 
     * @return 返回arriveTime
     */
    public String getArriveTime() {
        return arriveTime;
    }

    /**
     * 获取到达时间.
     * 
     * @param arriveTime
     *            要设置的arriveTime
     */
    public void setArriveTime(String arriveTime) {
        this.arriveTime = arriveTime;
    }

    /**
     * 设置航班号.
     * 
     * @return 返回scheduledFlight
     */
    public ScheduledFlightInfo getScheduledFlight() {
        return scheduledFlight;
    }

    /**
     * 获取航班号.
     * 
     * @param scheduledFlight
     *            要设置的scheduledFlight
     */
    public void setScheduledFlight(ScheduledFlightInfo scheduledFlight) {
        this.scheduledFlight = scheduledFlight;
    }

    /**
     * 设置实际承运航班号.
     * 
     * @return 返回actualScheduledFlight
     */
    public ScheduledFlightInfo getActualScheduledFlight() {
        return actualScheduledFlight;
    }

    /**
     * 获取实际承运航班号.
     * 
     * @param actualScheduledFlight
     *            要设置的actualScheduledFlight
     */
    public void setActualScheduledFlight(ScheduledFlightInfo actualScheduledFlight) {
        this.actualScheduledFlight = actualScheduledFlight;
    }

    /**
     * 设置航段价格.
     * 
     * @return 返回price
     */
    public VoyagePriceInfo getPrice() {
        return price;
    }

    /**
     * 获取航段价格.
     * 
     * @param price
     *            要设置的price
     */
    public void setPrice(VoyagePriceInfo price) {
        this.price = price;
    }

    /**
     * 设置出发航站楼.
     * 
     * @return 返回startTerminalBuilding
     */
    public String getStartTerminalBuilding() {
        return startTerminalBuilding;
    }

    /**
     * 获取出发航站楼.
     * 
     * @param startTerminalBuilding
     *            要设置的startTerminalBuilding
     */
    public void setStartTerminalBuilding(String startTerminalBuilding) {
        this.startTerminalBuilding = startTerminalBuilding;
    }

    /**
     * 设置到达航站楼.
     * 
     * @return 返回endTerminalBuilding
     */
    public String getEndTerminalBuilding() {
        return endTerminalBuilding;
    }

    /**
     * 获取到达航站楼.
     * 
     * @param endTerminalBuilding
     *            要设置的endTerminalBuilding
     */
    public void setEndTerminalBuilding(String endTerminalBuilding) {
        this.endTerminalBuilding = endTerminalBuilding;
    }

    /**
     * 设置里程数.
     * 
     * @return 返回mileage
     */
    public double getMileage() {
        return mileage;
    }

    /**
     * 获取里程数.
     * 
     * @param mileage
     *            要设置的mileage
     */
    public void setMileage(double mileage) {
        this.mileage = mileage;
    }

    /**
     * 设置是否共享航班.
     * 
     * @return 返回isShare
     */
    public boolean getIsShare() {
        return isShare;
    }

    /**
     * 获取是否共享航班.
     * 
     * @param isShares
     *            要设置的isShare
     */
    public void setIsShare(boolean isShares) {
        this.isShare = isShares;
    }
}
