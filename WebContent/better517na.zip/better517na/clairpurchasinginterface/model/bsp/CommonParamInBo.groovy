package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/4/12
 * Time: 21:11
 */
public class CommonParamInBo {
    /**
     * TMCID
     */
    private String tmcID;

    /**
     * 服务商ID
     */
    private String providerID;

    /**
     * 企业ID
     */
    private String corpID;

    /**
     * Office号
     */
    private String office;

    /**
     * 订单号
     */
    private String orderID;

    /**
     * 流水号
     */
    private String transactionID;

    /**
     * 公用执行方法
     */
    private String action;

    public String getTmcID() {
        return tmcID;
    }

    public void setTmcID(String tmcID) {
        this.tmcID = tmcID;
    }

    public String getProviderID() {
        return providerID;
    }

    public void setProviderID(String providerID) {
        this.providerID = providerID;
    }

    public String getCorpID() {
        return corpID;
    }

    public void setCorpID(String corpID) {
        this.corpID = corpID;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
