/*
 * 文件名：TravelType.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： TravelType.java
 * 修改人：caozhenwei
 * 修改时间：2015年6月2日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bsp;

/**
 * 行程类型枚举.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author caozhenwei
 */
public enum TravelType {
    /**
     * 单程.
     */
    Single,

    /**
     * 往返程.
     */
    ComeAndGo,

    /**
     * 联程.
     */
    Transfer,

    /**
     * 缺口程.
     */
    LossVoyage,

    /**
     * 多程（两程以上）.
     */
    MultTransfer

    // public static final int Single = 0;
    //
    // public static final int ComeAndGo = 1;
    //
    // public static final int Transfer = 2;
    //
    // public static final int LossVoyage = 3;
    //
    // public static final int MultTransfer = 4;
}
