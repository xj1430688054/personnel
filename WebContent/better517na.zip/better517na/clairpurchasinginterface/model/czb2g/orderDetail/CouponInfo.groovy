/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CouponInfo {

    private CouponValid couponValid;
    private List<String> serviceReferences;
    public void setCouponValid(CouponValid couponValid) {
         this.couponValid = couponValid;
     }
     public CouponValid getCouponValid() {
         return couponValid;
     }

    public void setServiceReferences(List<String> serviceReferences) {
         this.serviceReferences = serviceReferences;
     }
     public List<String> getServiceReferences() {
         return serviceReferences;
     }

}