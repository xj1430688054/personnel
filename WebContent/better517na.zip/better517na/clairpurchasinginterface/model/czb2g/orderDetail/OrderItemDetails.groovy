/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OrderItemDetails {

    private List<OrderItemDetail> orderItemDetail;
    public void setOrderItemDetail(List<OrderItemDetail> orderItemDetail) {
         this.orderItemDetail = orderItemDetail;
     }
     public List<OrderItemDetail> getOrderItemDetail() {
         return orderItemDetail;
     }

}