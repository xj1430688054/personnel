/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OtherAssociations {

    private List<OtherAssociation> otherAssociation;
    public void setOtherAssociation(List<OtherAssociation> otherAssociation) {
         this.otherAssociation = otherAssociation;
     }
     public List<OtherAssociation> getOtherAssociation() {
         return otherAssociation;
     }

}