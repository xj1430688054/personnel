/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OrderItems {

    private List<OrderItem> orderItem;
    public void setOrderItem(List<OrderItem> orderItem) {
         this.orderItem = orderItem;
     }
     public List<OrderItem> getOrderItem() {
         return orderItem;
     }

}