/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Amendment {

    private ActionType actionType;
    private OfferItem offerItem;
    private TicketDocInfo ticketDocInfo;
    public void setActionType(ActionType actionType) {
         this.actionType = actionType;
     }
     public ActionType getActionType() {
         return actionType;
     }

    public void setOfferItem(OfferItem offerItem) {
         this.offerItem = offerItem;
     }
     public OfferItem getOfferItem() {
         return offerItem;
     }

    public void setTicketDocInfo(TicketDocInfo ticketDocInfo) {
         this.ticketDocInfo = ticketDocInfo;
     }
     public TicketDocInfo getTicketDocInfo() {
         return ticketDocInfo;
     }

}