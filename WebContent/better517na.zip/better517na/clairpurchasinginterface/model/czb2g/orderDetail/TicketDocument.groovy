/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class TicketDocument {

    private String ticketDocNbr;
    private long dateOfIssue;
    private List<CouponInfo> couponInfo;
    private List<String> penaltyReferences;
    public void setTicketDocNbr(String ticketDocNbr) {
         this.ticketDocNbr = ticketDocNbr;
     }
     public String getTicketDocNbr() {
         return ticketDocNbr;
     }

    public void setDateOfIssue(long dateOfIssue) {
         this.dateOfIssue = dateOfIssue;
     }
     public long getDateOfIssue() {
         return dateOfIssue;
     }

    public void setCouponInfo(List<CouponInfo> couponInfo) {
         this.couponInfo = couponInfo;
     }
     public List<CouponInfo> getCouponInfo() {
         return couponInfo;
     }

    public void setPenaltyReferences(List<String> penaltyReferences) {
         this.penaltyReferences = penaltyReferences;
     }
     public List<String> getPenaltyReferences() {
         return penaltyReferences;
     }

}