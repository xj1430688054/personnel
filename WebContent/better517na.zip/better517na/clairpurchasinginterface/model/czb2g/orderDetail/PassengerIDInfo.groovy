/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PassengerIDInfo {

    private List<PassengerDocument> passengerDocument;
    public void setPassengerDocument(List<PassengerDocument> passengerDocument) {
         this.passengerDocument = passengerDocument;
     }
     public List<PassengerDocument> getPassengerDocument() {
         return passengerDocument;
     }

}