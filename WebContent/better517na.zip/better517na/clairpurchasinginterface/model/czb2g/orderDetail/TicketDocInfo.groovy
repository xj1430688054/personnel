/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class TicketDocInfo {

    private String passengerReference;
    private List<TicketDocument> ticketDocument;
    private CarrierFeeInfo carrierFeeInfo;
    String getPassengerReference() {
        return passengerReference
    }

    void setPassengerReference(String passengerReference) {
        this.passengerReference = passengerReference
    }

    List<TicketDocument> getTicketDocument() {
        return ticketDocument
    }

    void setTicketDocument(List<TicketDocument> ticketDocument) {
        this.ticketDocument = ticketDocument
    }

    CarrierFeeInfo getCarrierFeeInfo() {
        return carrierFeeInfo
    }

    void setCarrierFeeInfo(CarrierFeeInfo carrierFeeInfo) {
        this.carrierFeeInfo = carrierFeeInfo
    }
}