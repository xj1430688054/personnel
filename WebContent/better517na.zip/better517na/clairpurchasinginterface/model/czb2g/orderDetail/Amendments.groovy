/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Amendments {

    private List<Amendment> amendment;
    public void setAmendment(List<Amendment> amendment) {
         this.amendment = amendment;
     }
     public List<Amendment> getAmendment() {
         return amendment;
     }

}