/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OrderItemDetail {

    private OrderCommision orderCommision;
    public void setOrderCommision(OrderCommision orderCommision) {
         this.orderCommision = orderCommision;
     }
     public OrderCommision getOrderCommision() {
         return orderCommision;
     }

}