/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CarrierFeeInfo {

    private PaymentForm paymentForm;
    public void setPaymentForm(PaymentForm paymentForm) {
         this.paymentForm = paymentForm;
     }
     public PaymentForm getPaymentForm() {
         return paymentForm;
     }

}