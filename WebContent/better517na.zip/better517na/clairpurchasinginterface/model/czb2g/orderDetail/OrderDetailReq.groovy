package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest

/**
 * @Auther: beitian
 * @Date: 2019/1/25 16:10
 * @Description:
 */
class OrderDetailReq extends CZB2GRequest {

    String orderNum;

    String getOrderNum() {
        return orderNum
    }

    void setOrderNum(String orderNum) {
        this.orderNum = orderNum
    }
}
