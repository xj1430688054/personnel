/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Errors
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Success;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Czb2gOrderDetailResponse {

    private Success success;
    private Response response;
    private String target;
    private Errors errors;

    public void setSuccess(Success success) {
        this.success = success;
    }

    public Success getSuccess() {
        return success;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public Response getResponse() {
        return response;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getTarget() {
        return target;
    }

    Errors getErrors() {
        return errors
    }

    void setErrors(Errors errors) {
        this.errors = errors
    }
}