/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ActionType {

    private String value;
    private String context;
    public void setValue(String value) {
         this.value = value;
     }
     public String getValue() {
         return value;
     }

    public void setContext(String context) {
         this.context = context;
     }
     public String getContext() {
         return context;
     }

}