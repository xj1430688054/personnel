/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class SimpleCurrencyPrice {

    private double value;
    private boolean taxable;
    public void setValue(double value) {
         this.value = value;
     }
     public double getValue() {
         return value;
     }

    public void setTaxable(boolean taxable) {
         this.taxable = taxable;
     }
     public boolean getTaxable() {
         return taxable;
     }

}