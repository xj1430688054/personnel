/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Associations {

    private List<OrderItemID> orderItemID;
    private Passengers passengers;
    private OtherAssociations otherAssociations;
    public void setOrderItemID(List<OrderItemID> orderItemID) {
         this.orderItemID = orderItemID;
     }
     public List<OrderItemID> getOrderItemID() {
         return orderItemID;
     }

    public void setPassengers(Passengers passengers) {
         this.passengers = passengers;
     }
     public Passengers getPassengers() {
         return passengers;
     }

    OtherAssociations getOtherAssociations() {
        return otherAssociations
    }

    void setOtherAssociations(OtherAssociations otherAssociations) {
        this.otherAssociations = otherAssociations
    }
}