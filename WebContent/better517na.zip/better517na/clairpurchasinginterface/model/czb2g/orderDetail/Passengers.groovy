/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Passengers {

    private List<Passenger>passenger;

    private List<PassengerReferences> passengerReferences;
    public void setPassengerReferences(List<PassengerReferences> passengerReferences) {
         this.passengerReferences = passengerReferences;
     }
     public List<PassengerReferences> getPassengerReferences() {
         return passengerReferences;
     }

    List<Passenger> getPassenger() {
        return passenger
    }

    void setPassenger(List<Passenger> passenger) {
        this.passenger = passenger
    }
}