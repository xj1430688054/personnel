/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.orderDetail;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 17:25:24
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PassengerReferences {

    private List<String> refs;
    private String objectKey;
    private Name name;
    private Contacts contacts;
    private PassengerIDInfo passengerIDInfo;
    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

    public void setObjectKey(String objectKey) {
         this.objectKey = objectKey;
     }
     public String getObjectKey() {
         return objectKey;
     }

    public void setName(Name name) {
         this.name = name;
     }
     public Name getName() {
         return name;
     }

    public void setContacts(Contacts contacts) {
         this.contacts = contacts;
     }
     public Contacts getContacts() {
         return contacts;
     }

    public void setPassengerIDInfo(PassengerIDInfo passengerIDInfo) {
         this.passengerIDInfo = passengerIDInfo;
     }
     public PassengerIDInfo getPassengerIDInfo() {
         return passengerIDInfo;
     }

}