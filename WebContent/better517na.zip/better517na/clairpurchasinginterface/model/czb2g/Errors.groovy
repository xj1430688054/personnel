package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/25
 * Time: 14:49
 */
class Errors {
    private List<Error> error;
    public void setError(List<Error> error) {
        this.error = error;
    }
    public List<Error> getError() {
        return error;
    }
}
