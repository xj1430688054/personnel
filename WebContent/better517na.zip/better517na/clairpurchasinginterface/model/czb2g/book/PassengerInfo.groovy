package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/29
 * Time: 11:26
 */
class PassengerInfo {
    /**
     * 乘客姓名.
     */
    private String psgName;

    /**
     * 姓名类型 zh_cn：中文/english :英文.
     */
    private String psgNameType;

    /**
     * 证件类型 （SFZ :身份证,HZ  :护照,JRZ :军人证,TWZ :台胞证,HXZ :回乡证,GATX:港澳通行证,GJHY:国际海员证, YJJZ:外国人永久居住证,LXZ :旅行证,HKB :户口簿,CSZ :出生证明,QT  :其他）
     */
    private String cardType;

    /**
     * 证件号.
     */
    private String cardNo;

    /**
     * 生日yyyy-MM-dd.
     */
    private String birthday;

    /**
     * 性别(男M女F).
     */
    private String gender;

    /**
     * 手机号.
     */
    private String psgPhone;

    String getPsgName() {
        return psgName
    }

    void setPsgName(String psgName) {
        this.psgName = psgName
    }

    String getPsgNameType() {
        return psgNameType
    }

    void setPsgNameType(String psgNameType) {
        this.psgNameType = psgNameType
    }

    String getCardType() {
        return cardType
    }

    void setCardType(String cardType) {
        this.cardType = cardType
    }

    String getCardNo() {
        return cardNo
    }

    void setCardNo(String cardNo) {
        this.cardNo = cardNo
    }

    String getBirthday() {
        return birthday
    }

    void setBirthday(String birthday) {
        this.birthday = birthday
    }

    String getGender() {
        return gender
    }

    void setGender(String gender) {
        this.gender = gender
    }

    String getPsgPhone() {
        return psgPhone
    }

    void setPsgPhone(String psgPhone) {
        this.psgPhone = psgPhone
    }
}
