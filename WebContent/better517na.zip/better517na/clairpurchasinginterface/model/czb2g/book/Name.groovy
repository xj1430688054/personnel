/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Surname;

import java.util.List;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Name {

    private Surname surname;
    private List<Given> given;
    private String title;
    private List<String> middle;
    private List<String> refs;
    private List<String> objectMetaReferences;
    public void setSurname(Surname surname) {
         this.surname = surname;
     }
     public Surname getSurname() {
         return surname;
     }

    public void setGiven(List<Given> given) {
         this.given = given;
     }
     public List<Given> getGiven() {
         return given;
     }

    public void setTitle(String title) {
         this.title = title;
     }
     public String getTitle() {
         return title;
     }

    public void setMiddle(List<String> middle) {
         this.middle = middle;
     }
     public List<String> getMiddle() {
         return middle;
     }

    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

    public void setObjectMetaReferences(List<String> objectMetaReferences) {
         this.objectMetaReferences = objectMetaReferences;
     }
     public List<String> getObjectMetaReferences() {
         return objectMetaReferences;
     }

}