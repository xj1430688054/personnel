/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book;
import java.util.List;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class StopLocations {

    private List<StopLocation> stopLocation;
    public void setStopLocation(List<StopLocation> stopLocation) {
         this.stopLocation = stopLocation;
     }
     public List<StopLocation> getStopLocation() {
         return stopLocation;
     }

}