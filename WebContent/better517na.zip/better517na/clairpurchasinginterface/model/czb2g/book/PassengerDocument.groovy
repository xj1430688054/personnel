/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book;
import java.util.Date;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PassengerDocument {

    private String type;
    private String id;
    private Date birthCountry;
    public void setType(String type) {
         this.type = type;
     }
     public String getType() {
         return type;
     }

    public void setId(String id) {
         this.id = id;
     }
     public String getId() {
         return id;
     }

    public void setBirthCountry(Date birthCountry) {
         this.birthCountry = birthCountry;
     }
     public Date getBirthCountry() {
         return birthCountry;
     }

}