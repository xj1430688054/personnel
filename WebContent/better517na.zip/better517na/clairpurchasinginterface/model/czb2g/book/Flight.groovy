/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.ClassOfService;

import java.util.List;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Flight {

    private String segmentKey;
    private Departure departure;
    private Arrival arrival;
    private MarketingCarrier marketingCarrier;
    private CabinType cabinType;
    private ClassOfService classOfService;
    private Details details;
    private List<String> refs;
    public void setSegmentKey(String segmentKey) {
         this.segmentKey = segmentKey;
     }
     public String getSegmentKey() {
         return segmentKey;
     }

    public void setDeparture(Departure departure) {
         this.departure = departure;
     }
     public Departure getDeparture() {
         return departure;
     }

    public void setArrival(Arrival arrival) {
         this.arrival = arrival;
     }
     public Arrival getArrival() {
         return arrival;
     }

    public void setMarketingCarrier(MarketingCarrier marketingCarrier) {
         this.marketingCarrier = marketingCarrier;
     }
     public MarketingCarrier getMarketingCarrier() {
         return marketingCarrier;
     }

    public void setCabinType(CabinType cabinType) {
         this.cabinType = cabinType;
     }
     public CabinType getCabinType() {
         return cabinType;
     }

    public void setClassOfService(ClassOfService classOfService) {
         this.classOfService = classOfService;
     }
     public ClassOfService getClassOfService() {
         return classOfService;
     }

    public void setDetails(Details details) {
         this.details = details;
     }
     public Details getDetails() {
         return details;
     }

    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

}