/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Contact {

    private EmailContact emailContact;
    private PhoneContact phoneContact;
    private Name name;
    public void setEmailContact(EmailContact emailContact) {
         this.emailContact = emailContact;
     }
     public EmailContact getEmailContact() {
         return emailContact;
     }

    public void setPhoneContact(PhoneContact phoneContact) {
         this.phoneContact = phoneContact;
     }
     public PhoneContact getPhoneContact() {
         return phoneContact;
     }

    public void setName(Name name) {
         this.name = name;
     }
     public Name getName() {
         return name;
     }

}