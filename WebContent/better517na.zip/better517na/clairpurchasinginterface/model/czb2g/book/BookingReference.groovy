/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book;
import java.util.List;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class BookingReference {

    private List<String> refs;
    private Type type;
    private String id;
    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

    public void setType(Type type) {
         this.type = type;
     }
     public Type getType() {
         return type;
     }

    public void setId(String id) {
         this.id = id;
     }
     public String getId() {
         return id;
     }

}