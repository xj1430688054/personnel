package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/29
 * Time: 15:43
 */
class PriceDetails {
    private List<Detail> detail;

    List<Detail> getDetail() {
        return detail
    }

    void setDetail(List<Detail> detail) {
        this.detail = detail
    }
}
