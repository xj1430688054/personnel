/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book;


import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Number;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PhoneContact {

    private List<String> refs;
    private List<Number> number;

    public void setRefs(List<String> refs) {
        this.refs = refs;
    }

    public List<String> getRefs() {
        return refs;
    }

    public void setNumber(List<Number> number) {
        this.number = number;
    }

    public List<Number> getNumber() {
        return number;
    }

}