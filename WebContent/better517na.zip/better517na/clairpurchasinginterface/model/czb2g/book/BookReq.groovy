package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.book

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest
import io.swagger.annotations.ApiModelProperty

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/29
 * Time: 11:23
 */
class BookReq extends CZB2GRequest {
    /**
     * 联系人手机.
     */
    private String contactPhone;
    /**
     * 联系人邮箱.
     */
    private String contactEmail;
    /**
     * 联系人名字.
     */
    private String contactName;
    /**
     * 航段的seg_no/价格类型（0:协议价，1:平台价，2:公布价）如：0/0
     */
    private String fareType;
    /**
     * 乘机人信息.
     */
    private List<PassengerInfo> passengers;

    String getContactPhone() {
        return contactPhone
    }

    void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone
    }

    String getContactEmail() {
        return contactEmail
    }

    void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail
    }

    String getContactName() {
        return contactName
    }

    void setContactName(String contactName) {
        this.contactName = contactName
    }

    String getFareType() {
        return fareType
    }

    void setFareType(String fareType) {
        this.fareType = fareType
    }

    List<PassengerInfo> getPassengers() {
        return passengers
    }

    void setPassengers(List<PassengerInfo> passengers) {
        this.passengers = passengers
    }
}
