/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.accessToken;

/**
 * Auto-generated: 2019-01-24 17:35:44
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class AuthResponse {

    private Status status;
    private AuthAccount authAccount;
    public void setStatus(Status status) {
         this.status = status;
     }
     public Status getStatus() {
         return status;
     }

    public void setAuthAccount(AuthAccount authAccount) {
         this.authAccount = authAccount;
     }
     public AuthAccount getAuthAccount() {
         return authAccount;
     }

}