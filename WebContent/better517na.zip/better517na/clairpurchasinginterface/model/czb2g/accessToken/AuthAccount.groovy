/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.accessToken;

/**
 * Auto-generated: 2019-01-24 17:35:44
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class AuthAccount {

    private String accountID;
    private String accountName;
    public void setAccountID(String accountID) {
         this.accountID = accountID;
     }
     public String getAccountID() {
         return accountID;
     }

    public void setAccountName(String accountName) {
         this.accountName = accountName;
     }
     public String getAccountName() {
         return accountName;
     }

}