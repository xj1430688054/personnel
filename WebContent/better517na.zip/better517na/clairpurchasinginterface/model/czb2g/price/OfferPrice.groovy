/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OfferPrice {

    private List<String> refs;
    private RequestedDate requestedDate;
    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

    public void setRequestedDate(RequestedDate requestedDate) {
         this.requestedDate = requestedDate;
     }
     public RequestedDate getRequestedDate() {
         return requestedDate;
     }

}