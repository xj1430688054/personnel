package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/25
 * Time: 15:53
 */
class PriceReq extends CZB2GRequest {
    /**
     * 乘机人数.
     */
    private int psgNum;

    /**
     * 航段信息 单程则对应一个OriginDestination，若存在中转，则一个OriginDestination下包含两个Flight； 往返对应两个OriginDestination
     */
    List<PriceOriginDestination> priceOriginDestinations;

    int getPsgNum() {
        return psgNum
    }

    void setPsgNum(int psgNum) {
        this.psgNum = psgNum
    }

    List<PriceOriginDestination> getPriceOriginDestinations() {
        return priceOriginDestinations
    }

    void setPriceOriginDestinations(List<PriceOriginDestination> priceOriginDestinations) {
        this.priceOriginDestinations = priceOriginDestinations
    }
}
