/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.Arrival
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.ClassOfService
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.Departure
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.MarketingCarrier;

import java.util.List;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class FlightSegment {

    private Departure departure;
    private Arrival arrival;
    private MarketingCarrier marketingCarrier;
    private Equipment equipment;
    private ClassOfService classOfService;
    private String segmentKey;
    private List<String> refs;
    public void setDeparture(Departure departure) {
         this.departure = departure;
     }
     public Departure getDeparture() {
         return departure;
     }

    public void setArrival(Arrival arrival) {
         this.arrival = arrival;
     }
     public Arrival getArrival() {
         return arrival;
     }

    public void setMarketingCarrier(MarketingCarrier marketingCarrier) {
         this.marketingCarrier = marketingCarrier;
     }
     public MarketingCarrier getMarketingCarrier() {
         return marketingCarrier;
     }

    public void setEquipment(Equipment equipment) {
         this.equipment = equipment;
     }
     public Equipment getEquipment() {
         return equipment;
     }

    public void setClassOfService(ClassOfService classOfService) {
         this.classOfService = classOfService;
     }
     public ClassOfService getClassOfService() {
         return classOfService;
     }

    public void setSegmentKey(String segmentKey) {
         this.segmentKey = segmentKey;
     }
     public String getSegmentKey() {
         return segmentKey;
     }

    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

}