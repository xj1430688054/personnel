/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.shopping.BaseAmount;

import java.util.List;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PriceDetail {

    private BaseAmount baseAmount;
    private Taxes taxes;
    private List<String> originDestinationReferenceOrSegmentReferences;
    public void setBaseAmount(BaseAmount baseAmount) {
         this.baseAmount = baseAmount;
     }
     public BaseAmount getBaseAmount() {
         return baseAmount;
     }

    public void setTaxes(Taxes taxes) {
         this.taxes = taxes;
     }
     public Taxes getTaxes() {
         return taxes;
     }

    public void setOriginDestinationReferenceOrSegmentReferences(List<String> originDestinationReferenceOrSegmentReferences) {
         this.originDestinationReferenceOrSegmentReferences = originDestinationReferenceOrSegmentReferences;
     }
     public List<String> getOriginDestinationReferenceOrSegmentReferences() {
         return originDestinationReferenceOrSegmentReferences;
     }

}