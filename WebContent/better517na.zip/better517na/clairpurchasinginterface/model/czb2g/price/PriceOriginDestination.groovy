package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/28
 * Time: 11:36
 */
class PriceOriginDestination {
    /**
     * 航程RPH.
     */
    private String originDestinationKey;

    /**
     * Flight信息.
     */
    private List<PriceFlight> priceFlights;

    String getOriginDestinationKey() {
        return originDestinationKey
    }

    void setOriginDestinationKey(String originDestinationKey) {
        this.originDestinationKey = originDestinationKey
    }

    List<PriceFlight> getPriceFlights() {
        return priceFlights
    }

    void setPriceFlights(List<PriceFlight> priceFlights) {
        this.priceFlights = priceFlights
    }
}
