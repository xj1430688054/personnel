package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/28
 * Time: 11:34
 */
class PriceFlight {
    /**
     * 起飞机场三字码.
     */
    private String depAirportCode;
    /**
     * 到达机场三字码.
     */
    private String arrAirportCode;
    /**
     * 起飞时间.
     */
    private Date depDate;

    /**
     * 到达时间.
     */
    private Date arrDate;

    /**
     * 共享航班号.
     */
    private String shareFlightNo;

    /**
     * 机型.
     */
    private String aircraftCode;

    /**
     * 舱位的seq.
     */
    private String cabinSeq;

    /**
     * 舱等 头等舱：F，商务舱：C，明珠经济舱：P，经济舱：Y.
     */
    private String cabinClass;String getDepAirportCode() {
        return depAirportCode
    }

    void setDepAirportCode(String depAirportCode) {
        this.depAirportCode = depAirportCode
    }

    String getArrAirportCode() {
        return arrAirportCode
    }

    void setArrAirportCode(String arrAirportCode) {
        this.arrAirportCode = arrAirportCode
    }

    Date getDepDate() {
        return depDate
    }

    void setDepDate(Date depDate) {
        this.depDate = depDate
    }

    Date getArrDate() {
        return arrDate
    }

    void setArrDate(Date arrDate) {
        this.arrDate = arrDate
    }

    String getShareFlightNo() {
        return shareFlightNo
    }

    void setShareFlightNo(String shareFlightNo) {
        this.shareFlightNo = shareFlightNo
    }

    String getAircraftCode() {
        return aircraftCode
    }

    void setAircraftCode(String aircraftCode) {
        this.aircraftCode = aircraftCode
    }

    String getCabinSeq() {
        return cabinSeq
    }

    void setCabinSeq(String cabinSeq) {
        this.cabinSeq = cabinSeq
    }

    String getCabinClass() {
        return cabinClass
    }

    void setCabinClass(String cabinClass) {
        this.cabinClass = cabinClass
    }
}
