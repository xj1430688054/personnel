/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Tax {

    private Amount amount;
    private String taxCode;
    private List<String> collectionPoint;
    private List<String> refs;
    public void setAmount(Amount amount) {
         this.amount = amount;
     }
     public Amount getAmount() {
         return amount;
     }

    public void setTaxCode(String taxCode) {
         this.taxCode = taxCode;
     }
     public String getTaxCode() {
         return taxCode;
     }

    public void setCollectionPoint(List<String> collectionPoint) {
         this.collectionPoint = collectionPoint;
     }
     public List<String> getCollectionPoint() {
         return collectionPoint;
     }

    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

}