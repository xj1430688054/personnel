/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Associations {

    private OtherAssociation otherAssociation;
    public void setOtherAssociation(OtherAssociation otherAssociation) {
         this.otherAssociation = otherAssociation;
     }
     public OtherAssociation getOtherAssociation() {
         return otherAssociation;
     }

}