/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class RequestedDate {

    private PriceDetail priceDetail;
    private List<String> associations;
    public void setPriceDetail(PriceDetail priceDetail) {
         this.priceDetail = priceDetail;
     }
     public PriceDetail getPriceDetail() {
         return priceDetail;
     }

    public void setAssociations(List<String> associations) {
         this.associations = associations;
     }
     public List<String> getAssociations() {
         return associations;
     }

}