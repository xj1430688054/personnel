/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Errors
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Success;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class FlightPriceRS {

    private Success success;
    private PricedFlightOffers pricedFlightOffers;
    private DataLists dataLists;
    private Metadata metadata;
    private String target;
    private Errors errors;

    public void setSuccess(Success success) {
        this.success = success;
    }

    public Success getSuccess() {
        return success;
    }

    public void setPricedFlightOffers(PricedFlightOffers pricedFlightOffers) {
        this.pricedFlightOffers = pricedFlightOffers;
    }

    public PricedFlightOffers getPricedFlightOffers() {
        return pricedFlightOffers;
    }

    public void setDataLists(DataLists dataLists) {
        this.dataLists = dataLists;
    }

    public DataLists getDataLists() {
        return dataLists;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public Metadata getMetadata() {
        return metadata;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getTarget() {
        return target;
    }

    Errors getErrors() {
        return errors
    }

    void setErrors(Errors errors) {
        this.errors = errors
    }
}