/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.price;
import java.util.List;

/**
 * Auto-generated: 2019-01-25 16:18:15
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CurrencyMetadatas {

    private List<CurrencyMetadata> currencyMetadata;
    public void setCurrencyMetadata(List<CurrencyMetadata> currencyMetadata) {
         this.currencyMetadata = currencyMetadata;
     }
     public List<CurrencyMetadata> getCurrencyMetadata() {
         return currencyMetadata;
     }

}