package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/25
 * Time: 14:50
 */
class Error {
    private String value;
    private String code;
    private String shortText;

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    String getShortText() {
        return shortText
    }

    void setShortText(String shortText) {
        this.shortText = shortText
    }
}
