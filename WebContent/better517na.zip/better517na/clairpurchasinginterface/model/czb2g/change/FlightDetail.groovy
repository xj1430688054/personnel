/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.FlightSegmentType

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class FlightDetail {

    private List<String> refs;
    private Stops stops;
    private FlightSegmentType flightSegmentType;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setStops(Stops stops) {
        this.stops = stops;
    }
    public Stops getStops() {
        return stops;
    }
    public void setFlightSegmentType(FlightSegmentType flightSegmentType) {
        this.flightSegmentType = flightSegmentType;
    }
    public FlightSegmentType getFlightSegmentType() {
        return flightSegmentType;
    }
}