/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change;

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OtherAssociation {

    private String type;
    private String referenceValue;
    public void setType(String type) {
        this.type = type;
    }
    public String getType() {
        return type;
    }

    public void setReferenceValue(String referenceValue) {
        this.referenceValue = referenceValue;
    }
    public String getReferenceValue() {
        return referenceValue;
    }

}