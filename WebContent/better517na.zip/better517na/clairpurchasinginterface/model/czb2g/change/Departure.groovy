/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.Terminal

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Departure {

    private List<String> refs;
    private AirportCode airportCode;
    private long date;
    private String time;
    private Terminal terminal;

    public void setTerminal(Terminal terminal) {
        this.terminal = terminal;
    }
    public Terminal getTerminal() {
        return terminal;
    }
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setAirportCode(AirportCode airportCode) {
        this.airportCode = airportCode;
    }
    public AirportCode getAirportCode() {
        return airportCode;
    }

    public void setDate(long date) {
        this.date = date;
    }
    public long getDate() {
        return date;
    }

    public void setTime(String time) {
        this.time = time;
    }
    public String getTime() {
        return time;
    }

}