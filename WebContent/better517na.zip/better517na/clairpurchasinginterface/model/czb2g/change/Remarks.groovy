/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change


/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Remarks {

    private List<String> refs;
    private List<Remark> remark;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setRemark(List<Remark> remark) {
        this.remark = remark;
    }
    public List<Remark> getRemark() {
        return remark;
    }

}