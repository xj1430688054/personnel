/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.PassengerReferences

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Passengers {
    private List<Passenger> passenger;
    private List<PassengerReferences> passengerReferences;
    public void setPassengerReferences(List<PassengerReferences> passengerReferences) {
        this.passengerReferences = passengerReferences;
    }
    public List<PassengerReferences> getPassengerReferences() {
        return passengerReferences;
    }

    public void setPassenger(List<Passenger> passenger) {
        this.passenger = passenger;
    }
    public List<Passenger> getPassenger() {
        return passenger;
    }

}