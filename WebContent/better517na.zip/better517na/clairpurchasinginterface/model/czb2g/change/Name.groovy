/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change


/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Name {

    private Surname surname;
    private List<String> given;
    private List<String> middle;
    private List<String> refs;
    private List<String> objectMetaReferences;
    public void setSurname(Surname surname) {
        this.surname = surname;
    }
    public Surname getSurname() {
        return surname;
    }

    public void setGiven(List<String> given) {
        this.given = given;
    }
    public List<String> getGiven() {
        return given;
    }

    public void setMiddle(List<String> middle) {
        this.middle = middle;
    }
    public List<String> getMiddle() {
        return middle;
    }

    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setObjectMetaReferences(List<String> objectMetaReferences) {
        this.objectMetaReferences = objectMetaReferences;
    }
    public List<String> getObjectMetaReferences() {
        return objectMetaReferences;
    }

}