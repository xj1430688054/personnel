package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.RQPassenger

class ReissueRQ extends CZB2GRequest{

    private String orderNo;
    private String pnr;
    private List<RQPassenger> passengers;
    /**
     * 出发机场三字码(原航班)
     */
    private String oldDepAirportCode;

    /**
     * 出发日期(原航班)
     */
    private String oldDepDate;

    /**
     * 出发时间+08:00(原航班)
     */
    private String oldDepTime;

    /**
     * 到达机场三字码(原航班)
     */
    private String oldArrAirportCode;

    /**
     * 到达日期+08:00(原航班)
     */
    private String oldArrDate;

    /**
     * 到达时间(原航班)
     */
    private String oldArrTime;

    /**
     * 航司二字码(原航班)
     */
    private String oldCarrier;

    /**
     * 航班号.(原航班)
     */
    private String oldFlightNo;

    /**
     * 共享航班号.(原航班)  如果有就有值：航司二字码+航班号
     */
    private String oldShareFlightNo;

    /**
     * 舱位.(原航班)
     */
    private String oldCabinCode;

    /**
     * 机型.(原航班)
     */
    private String oldFlightType;

    /**
     * 出发机场三字码(新航班)
     */
    private String newDepAirportCode;

    /**
     * 出发日期(新航班)
     */
    private String newDepDate;

    /**
     * 出发时间+08:00(新航班)
     */
    private String newDepTime;

    /**
     * 到达机场三字码(新航班)
     */
    private String newArrAirportCode;

    /**
     * 到达日期+08:00(新航班)
     */
    private String newArrDate;

    /**
     * 到达时间(新航班)
     */
    private String newArrTime;

    /**
     * 航司二字码(改升航班)
     */
    private String newCarrier;

    /**
     * 航班号.(改升航班)
     */
    private String newFlightNo;

    /**
     * 舱位.(改升航班)
     */
    private String newCabinCode;

    /**
     * 机型.(改升航班)
     */
    private String newFlightType;

    /**
     * 共享航班号.(改升航班)  如果有就有值：航司二字码+航班号
     */
    private String newShareFlightNo;

    String getNewShareFlightNo() {
        return newShareFlightNo
    }

    void setNewShareFlightNo(String newShareFlightNo) {
        this.newShareFlightNo = newShareFlightNo
    }

    String getOldShareFlightNo() {

        return oldShareFlightNo
    }

    void setOldShareFlightNo(String oldShareFlightNo) {
        this.oldShareFlightNo = oldShareFlightNo
    }

    String getOrderNo() {
        return orderNo
    }

    void setOrderNo(String orderNo) {
        this.orderNo = orderNo
    }

    String getPnr() {
        return pnr
    }

    void setPnr(String pnr) {
        this.pnr = pnr
    }

    List<RQPassenger> getPassengers() {
        return passengers
    }

    void setPassengers(List<RQPassenger> passengers) {
        this.passengers = passengers
    }

    String getOldDepAirportCode() {
        return oldDepAirportCode
    }

    void setOldDepAirportCode(String oldDepAirportCode) {
        this.oldDepAirportCode = oldDepAirportCode
    }

    String getOldDepDate() {
        return oldDepDate
    }

    void setOldDepDate(String oldDepDate) {
        this.oldDepDate = oldDepDate
    }

    String getOldDepTime() {
        return oldDepTime
    }

    void setOldDepTime(String oldDepTime) {
        this.oldDepTime = oldDepTime
    }

    String getOldArrAirportCode() {
        return oldArrAirportCode
    }

    void setOldArrAirportCode(String oldArrAirportCode) {
        this.oldArrAirportCode = oldArrAirportCode
    }

    String getOldArrDate() {
        return oldArrDate
    }

    void setOldArrDate(String oldArrDate) {
        this.oldArrDate = oldArrDate
    }

    String getOldArrTime() {
        return oldArrTime
    }

    void setOldArrTime(String oldArrTime) {
        this.oldArrTime = oldArrTime
    }

    String getOldCarrier() {
        return oldCarrier
    }

    void setOldCarrier(String oldCarrier) {
        this.oldCarrier = oldCarrier
    }

    String getOldFlightNo() {
        return oldFlightNo
    }

    void setOldFlightNo(String oldFlightNo) {
        this.oldFlightNo = oldFlightNo
    }

    String getOldCabinCode() {
        return oldCabinCode
    }

    void setOldCabinCode(String oldCabinCode) {
        this.oldCabinCode = oldCabinCode
    }

    String getOldFlightType() {
        return oldFlightType
    }

    void setOldFlightType(String oldFlightType) {
        this.oldFlightType = oldFlightType
    }

    String getNewDepAirportCode() {
        return newDepAirportCode
    }

    void setNewDepAirportCode(String newDepAirportCode) {
        this.newDepAirportCode = newDepAirportCode
    }

    String getNewDepDate() {
        return newDepDate
    }

    void setNewDepDate(String newDepDate) {
        this.newDepDate = newDepDate
    }

    String getNewDepTime() {
        return newDepTime
    }

    void setNewDepTime(String newDepTime) {
        this.newDepTime = newDepTime
    }

    String getNewArrAirportCode() {
        return newArrAirportCode
    }

    void setNewArrAirportCode(String newArrAirportCode) {
        this.newArrAirportCode = newArrAirportCode
    }

    String getNewArrDate() {
        return newArrDate
    }

    void setNewArrDate(String newArrDate) {
        this.newArrDate = newArrDate
    }

    String getNewArrTime() {
        return newArrTime
    }

    void setNewArrTime(String newArrTime) {
        this.newArrTime = newArrTime
    }

    String getNewCarrier() {
        return newCarrier
    }

    void setNewCarrier(String newCarrier) {
        this.newCarrier = newCarrier
    }

    String getNewFlightNo() {
        return newFlightNo
    }

    void setNewFlightNo(String newFlightNo) {
        this.newFlightNo = newFlightNo
    }

    String getNewCabinCode() {
        return newCabinCode
    }

    void setNewCabinCode(String newCabinCode) {
        this.newCabinCode = newCabinCode
    }

    String getNewFlightType() {
        return newFlightType
    }

    void setNewFlightType(String newFlightType) {
        this.newFlightType = newFlightType
    }
}
