/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Contacts
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Name
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.PassengerIDInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Remarks

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Passenger {

    private List<String> refs;
    private String objectKey;
    private Ptc ptc;
    private Name name;
    private Contacts contacts;
    private Remarks remarks;
    private PassengerIDInfo passengerIDInfo;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }
    public String getObjectKey() {
        return objectKey;
    }

    public void setPtc(Ptc ptc) {
        this.ptc = ptc;
    }
    public Ptc getPtc() {
        return ptc;
    }

    public void setName(Name name) {
        this.name = name;
    }
    public Name getName() {
        return name;
    }

    public void setContacts(Contacts contacts) {
        this.contacts = contacts;
    }
    public Contacts getContacts() {
        return contacts;
    }

    public void setRemarks(Remarks remarks) {
        this.remarks = remarks;
    }
    public Remarks getRemarks() {
        return remarks;
    }

    public void setPassengerIDInfo(PassengerIDInfo passengerIDInfo) {
        this.passengerIDInfo = passengerIDInfo;
    }
    public PassengerIDInfo getPassengerIDInfo() {
        return passengerIDInfo;
    }

}