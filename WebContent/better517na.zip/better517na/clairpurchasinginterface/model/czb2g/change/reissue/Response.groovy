/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.DataList
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.ReShopOffers

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Response {

    private Passengers passengers;
    private ReShopOffers reShopOffers;
    private DataList dataList;
    public void setPassengers(Passengers passengers) {
        this.passengers = passengers;
    }
    public Passengers getPassengers() {
        return passengers;
    }

    public void setReShopOffers(ReShopOffers reShopOffers) {
        this.reShopOffers = reShopOffers;
    }
    public ReShopOffers getReShopOffers() {
        return reShopOffers;
    }

    public void setDataList(DataList dataList) {
        this.dataList = dataList;
    }
    public DataList getDataList() {
        return dataList;
    }

}