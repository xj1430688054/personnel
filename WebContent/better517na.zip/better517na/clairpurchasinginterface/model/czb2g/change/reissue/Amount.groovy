/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Amount {

    private int value;
    private boolean taxable;
    public void setValue(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }

    public void setTaxable(boolean taxable) {
        this.taxable = taxable;
    }
    public boolean getTaxable() {
        return taxable;
    }

}