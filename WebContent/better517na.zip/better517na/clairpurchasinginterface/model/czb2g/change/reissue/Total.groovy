/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Total {

    private Amount amount;
    public void setAmount(Amount amount) {
        this.amount = amount;
    }
    public Amount getAmount() {
        return amount;
    }

}