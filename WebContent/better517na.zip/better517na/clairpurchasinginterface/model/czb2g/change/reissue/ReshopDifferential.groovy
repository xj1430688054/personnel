/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ReshopDifferential {

    private NewOffer newOffer;
    private FeesAmount feesAmount;
    private ReshopDue reshopDue;
    public void setNewOffer(NewOffer newOffer) {
        this.newOffer = newOffer;
    }
    public NewOffer getNewOffer() {
        return newOffer;
    }

    public void setFeesAmount(FeesAmount feesAmount) {
        this.feesAmount = feesAmount;
    }
    public FeesAmount getFeesAmount() {
        return feesAmount;
    }

    public void setReshopDue(ReshopDue reshopDue) {
        this.reshopDue = reshopDue;
    }
    public ReshopDue getReshopDue() {
        return reshopDue;
    }

}