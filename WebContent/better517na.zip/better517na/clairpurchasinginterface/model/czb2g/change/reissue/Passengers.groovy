/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue
import java.util.List;

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Passengers {

    private List<Passenger> passenger;
    public void setPassenger(List<Passenger> passenger) {
        this.passenger = passenger;
    }
    public List<Passenger> getPassenger() {
        return passenger;
    }

}