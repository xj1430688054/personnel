/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ByPassenger {

    private Total total;
    public void setTotal(Total total) {
        this.total = total;
    }
    public Total getTotal() {
        return total;
    }

}