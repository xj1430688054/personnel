package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest
import io.swagger.annotations.ApiModelProperty

/**
 * @Author:chaoran
 * @Description:
 * @DATE:14:51 2019/1/28
 *
 */
class CancelChangeInVo extends CZB2GRequest{
    @ApiModelProperty(
            required = true,
            value = "改签订单号",
            example = "180424143804001967"
    )
    private String changeOrderId;

    private String pnr;

    String getChangeOrderId() {
        return changeOrderId
    }

    void setChangeOrderId(String changeOrderId) {
        this.changeOrderId = changeOrderId
    }

    String getPnr() {
        return pnr
    }

    void setPnr(String pnr) {
        this.pnr = pnr
    }
}
