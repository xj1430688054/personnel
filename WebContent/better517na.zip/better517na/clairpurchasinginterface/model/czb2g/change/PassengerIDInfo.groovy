/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change


/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PassengerIDInfo {

    private Foid foid;
    private List<String> passengerDocument;
    public void setFoid(Foid foid) {
        this.foid = foid;
    }
    public Foid getFoid() {
        return foid;
    }

    public void setPassengerDocument(List<String> passengerDocument) {
        this.passengerDocument = passengerDocument;
    }
    public List<String> getPassengerDocument() {
        return passengerDocument;
    }

}