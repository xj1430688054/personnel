package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Errors
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Success

/**
 * @Author:chaoran
 * @Description:
 * @DATE:11:34 2019/1/30
 *
 */
class ChangeOutVo {
    private Success success;
    private String target;
    private Errors errors;

    ChangeOutVo() {
    }

    public void setSuccess(Success success) {
        this.success = success;
    }
    public Success getSuccess() {
        return success;
    }

    String getTarget() {
        return target
    }

    void setTarget(String target) {
        this.target = target
    }

    Errors getErrors() {
        return errors
    }

    void setErrors(Errors errors) {
        this.errors = errors
    }
}
