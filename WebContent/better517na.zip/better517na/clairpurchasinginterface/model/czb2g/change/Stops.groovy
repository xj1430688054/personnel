/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.StopLocations;

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Stops {

    private int stopQuantity;
    private StopLocations stopLocations;
    public void setStopQuantity(int stopQuantity) {
        this.stopQuantity = stopQuantity;
    }
    public int getStopQuantity() {
        return stopQuantity;
    }

    public void setStopLocations(StopLocations stopLocations) {
        this.stopLocations = stopLocations;
    }
    public StopLocations getStopLocations() {
        return stopLocations;
    }

}