/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange.BookingReference;

import java.util.List;

/**
 * Auto-generated: 2019-01-31 18:24:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class BookingReferences {

    private List<BookingReference> bookingReference;
    public void setBookingReference(List<BookingReference> bookingReference) {
        this.bookingReference = bookingReference;
    }
    public List<BookingReference> getBookingReference() {
        return bookingReference;
    }

}