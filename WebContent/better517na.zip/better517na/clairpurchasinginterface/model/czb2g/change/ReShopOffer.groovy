/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue.ReshopDifferential
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.ReShopPricedOffer

import java.util.List;

/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ReShopOffer {

    private List<String> refs;
    private List<String> descriptionReferences;
    private ReshopDifferential reshopDifferential;
    private ReShopPricedOffer reShopPricedOffer;

    public void setReShopPricedOffer(ReShopPricedOffer reShopPricedOffer) {
        this.reShopPricedOffer = reShopPricedOffer;
    }
    public ReShopPricedOffer getReShopPricedOffer() {
        return reShopPricedOffer;
    }
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setDescriptionReferences(List<String> descriptionReferences) {
        this.descriptionReferences = descriptionReferences;
    }
    public List<String> getDescriptionReferences() {
        return descriptionReferences;
    }

    public void setReshopDifferential(ReshopDifferential reshopDifferential) {
        this.reshopDifferential = reshopDifferential;
    }
    public ReshopDifferential getReshopDifferential() {
        return reshopDifferential;
    }

}