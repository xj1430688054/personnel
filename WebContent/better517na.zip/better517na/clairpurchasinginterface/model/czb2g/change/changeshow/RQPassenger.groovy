package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow

class RQPassenger {

    /**
     * 乘客编号
     */
    private String passengerNo;

    /**
     * 乘客类型
     */
    private String passengerType;

    /**
     * 乘客姓名
     */
    private String passengerName;

    /**
     * 票号
     */
    private String ticketNo;

    /**
     * <!--证件类型 HZ护照 JRZ军人证 TWZ台胞证  SFZ身份证 HXZ回乡证 GATXZ港澳通行证 GJHY国际海员证 YJJZ外国人永久居住证 LXZ旅行证 HKB户口簿 CSZ 出生证明 必填-->
     */
    private String cardType;

    /**
     * 证件号
     */
    private String cardNo;

    /**
     * 联系人电话
     */
    private String contactPhoneNo;

    String getCardType() {
        return cardType
    }

    void setCardType(String cardType) {
        this.cardType = cardType
    }

    String getCardNo() {
        return cardNo
    }

    void setCardNo(String cardNo) {
        this.cardNo = cardNo
    }

    String getPassengerName() {
        return passengerName
    }

    void setPassengerName(String passengerName) {
        this.passengerName = passengerName
    }

    String getTicketNo() {
        return ticketNo
    }

    void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo
    }

    String getContactPhoneNo() {
        return contactPhoneNo
    }

    void setContactPhoneNo(String contactPhoneNo) {
        this.contactPhoneNo = contactPhoneNo
    }

    String getPassengerNo() {
        return passengerNo
    }

    void setPassengerNo(String passengerNo) {
        this.passengerNo = passengerNo
    }

    String getPassengerType() {
        return passengerType
    }

    void setPassengerType(String passengerType) {
        this.passengerType = passengerType
    }
}
