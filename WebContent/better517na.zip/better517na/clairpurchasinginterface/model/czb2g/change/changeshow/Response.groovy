/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.DataList
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Passengers

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Response {

    private Passengers passengers;
    private List<Order> order;
    private TicketDocInfos ticketDocInfos;
    private Amendments amendments;
    private DataList dataList;
    public void setPassengers(Passengers passengers) {
        this.passengers = passengers;
    }
    public Passengers getPassengers() {
        return passengers;
    }

    public void setOrder(List<Order> order) {
        this.order = order;
    }
    public List<Order> getOrder() {
        return order;
    }

    public void setTicketDocInfos(TicketDocInfos ticketDocInfos) {
        this.ticketDocInfos = ticketDocInfos;
    }
    public TicketDocInfos getTicketDocInfos() {
        return ticketDocInfos;
    }

    public void setAmendments(Amendments amendments) {
        this.amendments = amendments;
    }
    public Amendments getAmendments() {
        return amendments;
    }

    public void setDataList(DataList dataList) {
        this.dataList = dataList;
    }
    public DataList getDataList() {
        return dataList;
    }

}