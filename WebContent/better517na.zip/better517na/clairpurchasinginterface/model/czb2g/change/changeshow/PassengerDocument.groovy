/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow;

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class PassengerDocument {

    private String type;
    private String id;
    public void setType(String type) {
        this.type = type;
    }
    public String getType() {
        return type;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getId() {
        return id;
    }

}