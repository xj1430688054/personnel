/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow
/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CouponInfo {

    private CouponValid couponValid;
    private List<String> serviceReferences;
    public void setCouponValid(CouponValid couponValid) {
        this.couponValid = couponValid;
    }
    public CouponValid getCouponValid() {
        return couponValid;
    }

    public void setServiceReferences(List<String> serviceReferences) {
        this.serviceReferences = serviceReferences;
    }
    public List<String> getServiceReferences() {
        return serviceReferences;
    }

}