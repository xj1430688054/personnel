/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow
/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Payment {

    private long dateTime;
    private List<String> refs;
    private Associations associations;
    private Status status;
    private Amount amount;
    public void setDateTime(long dateTime) {
        this.dateTime = dateTime;
    }
    public long getDateTime() {
        return dateTime;
    }

    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    Associations getAssociations() {
        return associations
    }

    void setAssociations(Associations associations) {
        this.associations = associations
    }

    public void setStatus(Status status) {
        this.status = status;
    }
    public Status getStatus() {
        return status;
    }

    public void setAmount(Amount amount) {
        this.amount = amount;
    }
    public Amount getAmount() {
        return amount;
    }

}