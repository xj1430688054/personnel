/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow


/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Price {

    private DetailCurrencyPrice detailCurrencyPrice;
    public void setDetailCurrencyPrice(DetailCurrencyPrice detailCurrencyPrice) {
        this.detailCurrencyPrice = detailCurrencyPrice;
    }
    public DetailCurrencyPrice getDetailCurrencyPrice() {
        return detailCurrencyPrice;
    }

}