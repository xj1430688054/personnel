package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Errors
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Success

class ChangeShowResp {
    private Success success;
    private Response response;
    private String target;
    private Errors errors;
    public void setSuccess(Success success) {
        this.success = success;
    }
    public Success getSuccess() {
        return success;
    }

    public void setResponse(Response response) {
        this.response = response;
    }
    public Response getResponse() {
        return response;
    }

    public void setTarget(String target) {
        this.target = target;
    }
    public String getTarget() {
        return target;
    }

    public Errors getErrors() {
        return errors;
    }

    public void setErrors(Errors errors) {
        this.errors = errors;
    }
}
