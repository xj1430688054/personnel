/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Passengers

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Associations {

    private List<OrderItemID> orderItemID;
    private Passengers passengers;
    private List<String> otherAssociation;
    public void setOrderItemID(List<OrderItemID> orderItemID) {
        this.orderItemID = orderItemID;
    }
    public List<OrderItemID> getOrderItemID() {
        return orderItemID;
    }

    public void setPassengers(Passengers passengers) {
        this.passengers = passengers;
    }
    public Passengers getPassengers() {
        return passengers;
    }

    public void setOtherAssociation(List<String> otherAssociation) {
        this.otherAssociation = otherAssociation;
    }
    public List<String> getOtherAssociation() {
        return otherAssociation;
    }

}