/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow
/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class TicketDocInfo {

    private List<TicketDocument> ticketDocument;
    private String passengerReference;
    public void setTicketDocument(List<TicketDocument> ticketDocument) {
        this.ticketDocument = ticketDocument;
    }
    public List<TicketDocument> getTicketDocument() {
        return ticketDocument;
    }

    public void setPassengerReference(String passengerReference) {
        this.passengerReference = passengerReference;
    }
    public String getPassengerReference() {
        return passengerReference;
    }

}