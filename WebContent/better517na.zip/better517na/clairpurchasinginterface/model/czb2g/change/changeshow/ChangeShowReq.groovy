package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest

class ChangeShowReq extends CZB2GRequest {

    /**
     * 航司二字码
     */
    private String carrier;

    private String orderNo;

    private String pnr;

    private String ebrNo;

    ChangeShowReq() {
    }

    ChangeShowReq(String carrier, String orderNo, String pnr, String ebrNo) {
        this.carrier = carrier
        this.orderNo = orderNo
        this.pnr = pnr
        this.ebrNo = ebrNo
    }

    String getCarrier() {
        return carrier
    }

    void setCarrier(String carrier) {
        this.carrier = carrier
    }

    String getOrderNo() {
        return orderNo
    }

    void setOrderNo(String orderNo) {
        this.orderNo = orderNo
    }

    String getPnr() {
        return pnr
    }

    void setPnr(String pnr) {
        this.pnr = pnr
    }

    String getEbrNo() {
        return ebrNo
    }

    void setEbrNo(String ebrNo) {
        this.ebrNo = ebrNo
    }
}
