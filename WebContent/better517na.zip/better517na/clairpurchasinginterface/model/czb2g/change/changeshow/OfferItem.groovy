/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.OtherAssociation

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OfferItem {

    private List<String> refs;
    private OfferItemID offerItemID;
    private List<OtherAssociation> otherAssociation;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setOfferItemID(OfferItemID offerItemID) {
        this.offerItemID = offerItemID;
    }
    public OfferItemID getOfferItemID() {
        return offerItemID;
    }

    public void setOtherAssociation(List<OtherAssociation> otherAssociation) {
        this.otherAssociation = otherAssociation;
    }
    public List<OtherAssociation> getOtherAssociation() {
        return otherAssociation;
    }

}