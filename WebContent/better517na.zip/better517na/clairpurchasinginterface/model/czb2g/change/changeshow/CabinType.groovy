/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow;
import java.util.List;

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CabinType {

    private List<String> refs;
    private String code;
    private List<String> originDestinationReferences;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setCode(String code) {
        this.code = code;
    }
    public String getCode() {
        return code;
    }

    public void setOriginDestinationReferences(List<String> originDestinationReferences) {
        this.originDestinationReferences = originDestinationReferences;
    }
    public List<String> getOriginDestinationReferences() {
        return originDestinationReferences;
    }

}