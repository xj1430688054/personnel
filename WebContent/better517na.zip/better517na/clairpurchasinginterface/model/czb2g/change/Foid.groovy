/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change
/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Foid {

    private String type;
    private Id id;
    public void setType(String type) {
        this.type = type;
    }
    public String getType() {
        return type;
    }

    public void setId(Id id) {
        this.id = id;
    }
    public Id getId() {
        return id;
    }

}