/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change;

/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Total {

    private int value;
    private boolean taxable;
    public void setValue(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }

    public void setTaxable(boolean taxable) {
        this.taxable = taxable;
    }
    public boolean getTaxable() {
        return taxable;
    }

}