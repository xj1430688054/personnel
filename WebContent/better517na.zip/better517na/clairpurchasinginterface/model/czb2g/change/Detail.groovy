/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change
/**
 * Auto-generated: 2019-01-28 11:52:38
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Detail {

    private SubTotal subTotal;
    private List<String> refs;
    private String type;
    public void setSubTotal(SubTotal subTotal) {
        this.subTotal = subTotal;
    }
    public SubTotal getSubTotal() {
        return subTotal;
    }

    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getType() {
        return type;
    }
}