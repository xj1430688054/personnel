/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change


/**
 * Auto-generated: 2019-01-30 10:34:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ReShopOffers {

    private List<ReShopOffer> reShopOffer;
    public void setReShopOffer(List<ReShopOffer> reShopOffer) {
        this.reShopOffer = reShopOffer;
    }
    public List<ReShopOffer> getReShopOffer() {
        return reShopOffer;
    }

}