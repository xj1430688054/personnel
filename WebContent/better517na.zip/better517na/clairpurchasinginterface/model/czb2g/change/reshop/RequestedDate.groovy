/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop
import java.util.List;

/**
 * Auto-generated: 2019-01-29 11:22:39
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class RequestedDate {

    private List<Associations> associations;
    public void setAssociations(List<Associations> associations) {
        this.associations = associations;
    }
    public List<Associations> getAssociations() {
        return associations;
    }

}