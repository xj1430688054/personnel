/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.FlightSegmentReference

/**
 * Auto-generated: 2019-01-29 11:22:39
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ApplicableFlight {

    private List<String> originDestinationReferences;
    private List<FlightSegmentReference> flightSegmentReference;
    public void setOriginDestinationReferences(List<String> originDestinationReferences) {
        this.originDestinationReferences = originDestinationReferences;
    }
    public List<String> getOriginDestinationReferences() {
        return originDestinationReferences;
    }

    public void setFlightSegmentReference(List<FlightSegmentReference> flightSegmentReference) {
        this.flightSegmentReference = flightSegmentReference;
    }
    public List<FlightSegmentReference> getFlightSegmentReference() {
        return flightSegmentReference;
    }

}