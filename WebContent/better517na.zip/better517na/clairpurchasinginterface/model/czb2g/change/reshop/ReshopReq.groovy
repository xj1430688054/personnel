package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.changeshow.RQPassenger

class ReshopReq extends CZB2GRequest {
    /**
     * 航司二字码
     */
    private String carrier;

    private String orderNo;

    private String pnr;

    private String changeDate;

    private String flightNo;

    private String cabinCode;

    /**
     * 出发机场三字码
     */
    private String depAirportCode;

    /**
     * 出发日期
     */
    private String depDate;

    /**
     * 出发时间+08:00
     */
    private String depTime;

    /**
     * 到达机场三字码
     */
    private String arrAirportCode;

    /**
     * 到达日期+08:00
     */
    private String arrDate;

    /**
     * 到达时间
     */
    private String arrTime;

    private List<RQPassenger> passengers;

    List<RQPassenger> getPassengers() {
        return passengers
    }

    void setPassengers(List<RQPassenger> passengers) {
        this.passengers = passengers
    }

    String getCarrier() {
        return carrier
    }

    void setCarrier(String carrier) {
        this.carrier = carrier
    }

    String getOrderNo() {
        return orderNo
    }

    void setOrderNo(String orderNo) {
        this.orderNo = orderNo
    }

    String getPnr() {
        return pnr
    }

    void setPnr(String pnr) {
        this.pnr = pnr
    }

    String getChangeDate() {
        return changeDate
    }

    void setChangeDate(String changeDate) {
        this.changeDate = changeDate
    }

    String getFlightNo() {
        return flightNo
    }

    void setFlightNo(String flightNo) {
        this.flightNo = flightNo
    }

    String getCabinCode() {
        return cabinCode
    }

    void setCabinCode(String cabinCode) {
        this.cabinCode = cabinCode
    }

    String getDepAirportCode() {
        return depAirportCode
    }

    void setDepAirportCode(String depAirportCode) {
        this.depAirportCode = depAirportCode
    }

    String getDepDate() {
        return depDate
    }

    void setDepDate(String depDate) {
        this.depDate = depDate
    }

    String getDepTime() {
        return depTime
    }

    void setDepTime(String depTime) {
        this.depTime = depTime
    }

    String getArrAirportCode() {
        return arrAirportCode
    }

    void setArrAirportCode(String arrAirportCode) {
        this.arrAirportCode = arrAirportCode
    }

    String getArrDate() {
        return arrDate
    }

    void setArrDate(String arrDate) {
        this.arrDate = arrDate
    }

    String getArrTime() {
        return arrTime
    }

    void setArrTime(String arrTime) {
        this.arrTime = arrTime
    }
}
