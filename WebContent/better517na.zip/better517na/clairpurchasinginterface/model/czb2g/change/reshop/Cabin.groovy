/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.CabinDesignator

/**
 * Auto-generated: 2019-01-29 11:22:39
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Cabin {

    private CabinDesignator cabinDesignator;
    private List<String> refs;
    public void setCabinDesignator(CabinDesignator cabinDesignator) {
        this.cabinDesignator = cabinDesignator;
    }
    public CabinDesignator getCabinDesignator() {
        return cabinDesignator;
    }

    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

}