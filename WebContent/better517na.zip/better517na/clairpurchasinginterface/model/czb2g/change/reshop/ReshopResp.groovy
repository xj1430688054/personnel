package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Errors

public class ReshopResp {

    private Response response;
    private String target;
    private Errors errors;

    public Errors getErrors() {
        return errors;
    }

    public void setErrors(Errors errors) {
        this.errors = errors;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public Response getResponse() {
        return response;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getTarget() {
        return target;
    }


}
