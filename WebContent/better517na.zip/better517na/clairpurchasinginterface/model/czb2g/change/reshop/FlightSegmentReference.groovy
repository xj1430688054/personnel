/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop.Cabin;

/**
 * Auto-generated: 2019-01-29 11:22:39
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class FlightSegmentReference {

    private Cabin cabin;
    private String ref;
    public void setCabin(Cabin cabin) {
        this.cabin = cabin;
    }
    public Cabin getCabin() {
        return cabin;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }
    public String getRef() {
        return ref;
    }

}