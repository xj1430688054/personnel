/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

/**
 * Auto-generated: 2019-01-31 10:10:56
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class OtherAssociation2 {

    private String referenceValue;
    public void setReferenceValue(String referenceValue) {
        this.referenceValue = referenceValue;
    }
    public String getReferenceValue() {
        return referenceValue;
    }

}