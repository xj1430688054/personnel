/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reshop

/**
 * Auto-generated: 2019-01-29 11:22:39
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Associations {

    private ApplicableFlight applicableFlight;
    private OtherAssociation otherAssociation;
    public void setApplicableFlight(ApplicableFlight applicableFlight) {
        this.applicableFlight = applicableFlight;
    }
    public ApplicableFlight getApplicableFlight() {
        return applicableFlight;
    }

    public void setOtherAssociation(OtherAssociation otherAssociation) {
        this.otherAssociation = otherAssociation;
    }
    public OtherAssociation getOtherAssociation() {
        return otherAssociation;
    }

}