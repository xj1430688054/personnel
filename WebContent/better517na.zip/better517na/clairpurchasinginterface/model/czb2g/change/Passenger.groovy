/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change

/**
 * Auto-generated: 2019-01-29 11:22:39
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Passenger {

    private List<String> refs;
    private String objectKey;
    private Name name;
    private Contacts contacts;
    private Remarks remarks;
    private PassengerIDInfo passengerIDInfo;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }
    public String getObjectKey() {
        return objectKey;
    }

    public void setName(Name name) {
        this.name = name;
    }
    public Name getName() {
        return name;
    }

    public void setContacts(Contacts contacts) {
        this.contacts = contacts;
    }
    public Contacts getContacts() {
        return contacts;
    }

    public void setRemarks(Remarks remarks) {
        this.remarks = remarks;
    }
    public Remarks getRemarks() {
        return remarks;
    }

    public void setPassengerIDInfo(PassengerIDInfo passengerIDInfo) {
        this.passengerIDInfo = passengerIDInfo;
    }
    public PassengerIDInfo getPassengerIDInfo() {
        return passengerIDInfo;
    }

}