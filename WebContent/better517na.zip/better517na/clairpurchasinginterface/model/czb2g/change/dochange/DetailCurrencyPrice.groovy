/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Details
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.Total;

import java.util.List;

/**
 * Auto-generated: 2019-01-31 18:24:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class DetailCurrencyPrice {

    private List<String> refs;
    private Total total;
    private Details details;
    private Fees fees;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setTotal(Total total) {
        this.total = total;
    }
    public Total getTotal() {
        return total;
    }

    public void setDetails(Details details) {
        this.details = details;
    }
    public Details getDetails() {
        return details;
    }

    public void setFees(Fees fees) {
        this.fees = fees;
    }
    public Fees getFees() {
        return fees;
    }

}