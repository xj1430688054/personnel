package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange;

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.reissue.ReissueRQ;

public class DoBookRQ extends ReissueRQ {

    private String changePayAmount;

    public String getChangePayAmount() {
        return changePayAmount;
    }

    public void setChangePayAmount(String changePayAmount) {
        this.changePayAmount = changePayAmount;
    }
}
