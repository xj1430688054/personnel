/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.BookingReferences
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.OrderID

/**
 * Auto-generated: 2019-01-31 18:24:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Order {

    private List<String> refs;
    private OrderID orderID;
    private BookingReferences bookingReferences;
    private TotalOrderPrice totalOrderPrice;
    public void setRefs(List<String> refs) {
        this.refs = refs;
    }
    public List<String> getRefs() {
        return refs;
    }

    public void setOrderID(OrderID orderID) {
        this.orderID = orderID;
    }
    public OrderID getOrderID() {
        return orderID;
    }

    public void setBookingReferences(BookingReferences bookingReferences) {
        this.bookingReferences = bookingReferences;
    }
    public BookingReferences getBookingReferences() {
        return bookingReferences;
    }

    public void setTotalOrderPrice(TotalOrderPrice totalOrderPrice) {
        this.totalOrderPrice = totalOrderPrice;
    }
    public TotalOrderPrice getTotalOrderPrice() {
        return totalOrderPrice;
    }

}