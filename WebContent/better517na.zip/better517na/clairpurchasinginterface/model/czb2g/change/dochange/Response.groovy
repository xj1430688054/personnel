/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.change.dochange;
import java.util.List;

/**
 * Auto-generated: 2019-01-31 18:24:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Response {

    private List<Order> order;
    public void setOrder(List<Order> order) {
        this.order = order;
    }
    public List<Order> getOrder() {
        return order;
    }

}