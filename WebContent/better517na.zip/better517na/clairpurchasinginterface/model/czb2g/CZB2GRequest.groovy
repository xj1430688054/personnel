package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2019/1/25
 * Time: 14:25
 */
class CZB2GRequest {
    /**
     * 账号.
     */
    private String account;

    /**
     * 密码.
     */
    private String password;

    /**
     * token.
     */
    private String token;

    String getAccount() {
        return account
    }

    void setAccount(String account) {
        this.account = account
    }

    String getPassword() {
        return password
    }

    void setPassword(String password) {
        this.password = password
    }

    String getToken() {
        return token
    }

    void setToken(String token) {
        this.token = token
    }
}
