package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund

/**
 * Auto-generated: 2019-01-28 14:7:31
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class AddlReferenceIDType {

    private String code;
    private String definition;
    private String tableName;
    private String link;

    String getCode() {
        return code
    }

    void setCode(String code) {
        this.code = code
    }

    String getDefinition() {
        return definition
    }

    void setDefinition(String definition) {
        this.definition = definition
    }

    String getTableName() {
        return tableName
    }

    void setTableName(String tableName) {
        this.tableName = tableName
    }

    String getLink() {
        return link
    }

    void setLink(String link) {
        this.link = link
    }
}
