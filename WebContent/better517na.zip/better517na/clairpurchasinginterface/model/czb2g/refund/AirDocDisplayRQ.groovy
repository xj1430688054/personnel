package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest

/**
 * Auto-generated: 2019-01-28 14:12:1
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class AirDocDisplayRQ extends CZB2GRequest{

//    private Document document;
//    private Query query;
//
//    Document getDocument() {
//        return document
//    }
//
//    void setDocument(Document document) {
//        this.document = document
//    }
//
//    Query getQuery() {
//        return query
//    }
//
//    void setQuery(Query query) {
//        this.query = query
//    }
    private String name;
    private String orderID;
    private String owner;

    String getName() {
        return name
    }

    void setName(String name) {
        this.name = name
    }

    String getOrderID() {
        return orderID
    }

    void setOrderID(String orderID) {
        this.orderID = orderID
    }

    String getOwner() {
        return owner
    }

    void setOwner(String owner) {
        this.owner = owner
    }
}
