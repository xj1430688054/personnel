package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund

/**
 * Auto-generated: 2019-01-28 14:7:31
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Amount {

    private String code;
    private String value;
    private Boolean taxable;

    String getCode() {
        return code
    }

    void setCode(String code) {
        this.code = code
    }

    String getValue() {
        return value
    }

    void setValue(String value) {
        this.value = value
    }

    Boolean getTaxable() {
        return taxable
    }

    void setTaxable(Boolean taxable) {
        this.taxable = taxable
    }
}
