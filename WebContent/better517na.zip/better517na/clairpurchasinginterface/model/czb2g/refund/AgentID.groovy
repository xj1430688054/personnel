package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund

/**
 * Auto-generated: 2019-01-28 14:7:31
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class AgentID {

    private Type type;
    private String ID;

    Type getType() {
        return type
    }

    void setType(Type type) {
        this.type = type
    }

    String getID() {
        return ID
    }

    void setID(String ID) {
        this.ID = ID
    }
}
