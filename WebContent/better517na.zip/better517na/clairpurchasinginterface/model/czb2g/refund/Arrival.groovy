package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundApply.AirportCode

/**
 * Auto-generated: 2019-01-28 15:54:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Arrival {

    private AirportCode airportCode;
    //private String date;
    AirportCode getAirportCode() {
        return airportCode
    }

    void setAirportCode(AirportCode airportCode) {
        this.airportCode = airportCode
    }

    //    String getDate() {
//        return date
//    }
//
//    void setDate(String date) {
//        this.date = date
//    }
}
