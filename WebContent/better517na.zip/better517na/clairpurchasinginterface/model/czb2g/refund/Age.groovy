package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.refund.refundApply.Value

/**
 * Auto-generated: 2019-01-28 15:54:9
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Age {

    private Value value;

    Value getValue() {
        return value
    }

    void setValue(Value value) {
        this.value = value
    }
}
