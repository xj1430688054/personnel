/**
 * Copyright 2019 bejson.com
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g;

/**
 * Auto-generated: 2019-01-29 11:1:34
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Total {

    private BigDecimal value;
    private boolean taxable;

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setTaxable(boolean taxable) {
        this.taxable = taxable;
    }

    public boolean getTaxable() {
        return taxable;
    }

}