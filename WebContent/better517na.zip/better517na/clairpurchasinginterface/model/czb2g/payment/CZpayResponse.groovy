/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Errors
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.Success;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CZpayResponse {

    private Success success;
    private Response response;
    private String target;
    private Errors errors;
    public void setErrors(Errors errors) {
        this.errors = errors;
    }
    public Errors getErrors() {
        return errors;
    }
    public void setSuccess(Success success) {
         this.success = success;
     }
     public Success getSuccess() {
         return success;
     }

    public void setResponse(Response response) {
         this.response = response;
     }
     public Response getResponse() {
         return response;
     }

    public void setTarget(String target) {
         this.target = target;
     }
     public String getTarget() {
         return target;
     }

}