/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Response {

    private TicketDocInfos ticketDocInfos;
    public void setTicketDocInfos(TicketDocInfos ticketDocInfos) {
         this.ticketDocInfos = ticketDocInfos;
     }
     public TicketDocInfos getTicketDocInfos() {
         return ticketDocInfos;
     }

}