/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment;
import java.util.List;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class TicketDocInfo {

    private BookingReferences bookingReferences;
    private Payments payments;
    private List<String> ticketDocument;
    private OrderReference orderReference;
    public void setBookingReferences(BookingReferences bookingReferences) {
         this.bookingReferences = bookingReferences;
     }
     public BookingReferences getBookingReferences() {
         return bookingReferences;
     }

    public void setPayments(Payments payments) {
         this.payments = payments;
     }
     public Payments getPayments() {
         return payments;
     }

    public void setTicketDocument(List<String> ticketDocument) {
         this.ticketDocument = ticketDocument;
     }
     public List<String> getTicketDocument() {
         return ticketDocument;
     }

    public void setOrderReference(OrderReference orderReference) {
         this.orderReference = orderReference;
     }
     public OrderReference getOrderReference() {
         return orderReference;
     }

}