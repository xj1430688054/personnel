/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Amount {

    private double value;
    private boolean taxable;
    private String code;
    public void setValue(double value) {
         this.value = value;
     }
     public double getValue() {
         return value;
     }

    public void setTaxable(boolean taxable) {
         this.taxable = taxable;
     }
     public boolean getTaxable() {
         return taxable;
     }

    public void setCode(String code) {
         this.code = code;
     }
     public String getCode() {
         return code;
     }

}