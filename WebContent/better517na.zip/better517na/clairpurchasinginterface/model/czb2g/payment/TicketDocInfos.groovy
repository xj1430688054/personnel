/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment;
import java.util.List;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class TicketDocInfos {

    private List<TicketDocInfo> ticketDocInfo;
    public void setTicketDocInfo(List<TicketDocInfo> ticketDocInfo) {
         this.ticketDocInfo = ticketDocInfo;
     }
     public List<TicketDocInfo> getTicketDocInfo() {
         return ticketDocInfo;
     }

}