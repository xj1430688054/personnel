/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Method {

    private BankAccount bankAccount;
    public void setBankAccount(BankAccount bankAccount) {
         this.bankAccount = bankAccount;
     }
     public BankAccount getBankAccount() {
         return bankAccount;
     }

}