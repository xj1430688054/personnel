/**
  * Copyright 2019 bejson.com 
  */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment;
import java.util.List;

/**
 * Auto-generated: 2019-01-29 17:25:20
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class BankAccount {

    private BankID bankID;
    private AccountNumber accountNumber;
    private List<String> refs;
    public void setBankID(BankID bankID) {
         this.bankID = bankID;
     }
     public BankID getBankID() {
         return bankID;
     }

    public void setAccountNumber(AccountNumber accountNumber) {
         this.accountNumber = accountNumber;
     }
     public AccountNumber getAccountNumber() {
         return accountNumber;
     }

    public void setRefs(List<String> refs) {
         this.refs = refs;
     }
     public List<String> getRefs() {
         return refs;
     }

}