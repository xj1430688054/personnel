package config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.payment

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.czb2g.CZB2GRequest

/**
 * @Auther: beitian
 * @Date: 2019/1/29 15:23
 * @Description:
 */
class CZPayRequest extends CZB2GRequest {
    /**
     * 后段url
     */
    String subUrl;

    /**
     * 订单号
     */
    String orderId;

    /**
     * PNR
     */
    String pnr;

    /**
     * 订单用户id / 合作方id
     */
    String orderUserId;

    /**
     * 支付银行id
     */
    String payBankId;

    /**
     * 合作方支付单号（平台订单号）
     */
    String ptOrderId;

    /**
     * 合作方签名方式 --MD5
     */
    String signType;

    /**
     * 合作方签名秘钥
     */
    String signSecretKey;

    /**
     * 支付金额(单位：元)
     */
    BigDecimal payMoney;

    String getOrderId() {
        return orderId
    }

    void setOrderId(String orderId) {
        this.orderId = orderId
    }

    String getPnr() {
        return pnr
    }

    void setPnr(String pnr) {
        this.pnr = pnr
    }

    String getOrderUserId() {
        return orderUserId
    }

    void setOrderUserId(String orderUserId) {
        this.orderUserId = orderUserId
    }

    String getPayBankId() {
        return payBankId
    }

    void setPayBankId(String payBankId) {
        this.payBankId = payBankId
    }

    String getSignType() {
        return signType
    }

    void setSignType(String signType) {
        this.signType = signType
    }

    String getSignSecretKey() {
        return signSecretKey
    }

    void setSignSecretKey(String signSecretKey) {
        this.signSecretKey = signSecretKey
    }

    String getSubUrl() {
        return subUrl
    }

    void setSubUrl(String subUrl) {
        this.subUrl = subUrl
    }

    String getPtOrderId() {
        return ptOrderId
    }

    void setPtOrderId(String ptOrderId) {
        this.ptOrderId = ptOrderId
    }

    BigDecimal getPayMoney() {
        return payMoney
    }

    void setPayMoney(BigDecimal payMoney) {
        this.payMoney = payMoney
    }
}
