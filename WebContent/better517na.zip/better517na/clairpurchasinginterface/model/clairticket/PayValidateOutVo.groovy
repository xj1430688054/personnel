package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket

import io.swagger.annotations.ApiModelProperty

class PayValidateOutVo {
    /**
     * 订单总金额.
     */
    @ApiModelProperty(value = "订单总金额", example = "1060", position = 0)
    private BigDecimal totalMoney;

    /**
     * 销售价.
     */
    @ApiModelProperty(value = "销售价(不含税)", example = "1000", position = 1)
    private BigDecimal salePrice;

    /**
     * 票面价.
     */
    @ApiModelProperty(value = "票面价", example = "1000", position = 2)
    private BigDecimal ticketPrice;

    /**
     * 基建.
     */
    @ApiModelProperty(value = "基建费", example = "50", position = 3)
    private BigDecimal airFee;

    /**
     * 燃油.
     */
    @ApiModelProperty(value = "燃油税", example = "10", position = 4)
    private BigDecimal oilTax;BigDecimal getTotalMoney() {
        return totalMoney
    }

    void setTotalMoney(BigDecimal totalMoney) {
        this.totalMoney = totalMoney
    }

    BigDecimal getSalePrice() {
        return salePrice
    }

    void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice
    }

    BigDecimal getTicketPrice() {
        return ticketPrice
    }

    void setTicketPrice(BigDecimal ticketPrice) {
        this.ticketPrice = ticketPrice
    }

    BigDecimal getAirFee() {
        return airFee
    }

    void setAirFee(BigDecimal airFee) {
        this.airFee = airFee
    }

    BigDecimal getOilTax() {
        return oilTax
    }

    void setOilTax(BigDecimal oilTax) {
        this.oilTax = oilTax
    }
}
