package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 16:55
 */
public class VoyageInfo {
    /**
     * 航程序号 （从0开始）
     */
    @ApiModelProperty(value = '航程序号（从0开始）', example = '0')
    private Integer sequence;

    /**
     * 出发城市.
     */
    @ApiModelProperty(value = '出发城市三字码（如CTU）', example = 'CTU')
    private String depCity;

    /**
     * 到达城市.
     */
    @ApiModelProperty(value = '到达城市三字码（如CTU）', example = 'PEK')
    private String arrCity;

    /**
     * 出发城市中文名.
     */
    @ApiModelProperty(value = '出发城市中文名', example = '成都')
    private String depCityDescribe;

    /**
     * 到达城市中文名.
     */
    @ApiModelProperty(value = '到达城市中文名', example = '北京')
    private String arrCityDescribe;

    /**
     * 出发机场.
     */
    @ApiModelProperty(value = '出发机场三字码（如CTU）', example = 'CTU')
    private String depAirport;

    /**
     * 到达机场.
     */
    @ApiModelProperty(value = '到达机场三字码（如CTU）', example = 'PEK')
    private String arrAirport;

    /**
     * 出发机场中文名.
     */
    @ApiModelProperty(value = '出发机场中文名', example = '双流')
    private String depAirportDescribe;

    /**
     * 到达机场中文名.
     */
    @ApiModelProperty(value = '到达机场中文名', example = '首都')
    private String arrAirportDescribe;

    /**
     * 起飞时间.
     */
    @ApiModelProperty(value = '起飞时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 11:00')
    private String depTime;

    /**
     * 到达时间.
     */
    @ApiModelProperty(value = '到达时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 13:00')
    private String arrTime;

    /**
     * 始发航站楼.
     */
    @ApiModelProperty(value = '出发航站楼', example = 'T2')
    private String depTerminal;

    /**
     * 到达航站楼.
     */
    @ApiModelProperty(value = '到达航站楼', example = 'T1')
    private String arrTerminal;

    /**
     * 航司.
     */
    @ApiModelProperty(value = '航司二字码（如MU）', example = 'MU')
    private String airCode;

    /**
     * 航司中文名.
     */
    @ApiModelProperty(value = '航司中文名', example = '东航')
    private String airCodeName;

    /**
     * 机型大小.
     */
    @ApiModelProperty(value = '机型大小（0:小;1:大）', example = '1')
    private String airPlaneSize;

    /**
     * 飞机型号(如：330).
     */
    @ApiModelProperty(value = '飞机型号', example = 'A330')
    private String airPlaneModel;

    /**
     * 航班号.
     */
    @ApiModelProperty(value = '航班号（如MU1234）', example = 'MU1234')
    private String flightNo;

    /**
     * 舱位.
     */
    @ApiModelProperty(value = '舱位', example = 'Y')
    private String cabin;

    /**
     * 舱位等级（1经济舱;2公务舱;3头等舱）.
     */
    @ApiModelProperty(value = '舱位等级（1经济舱;2公务舱;3头等舱）', example = '1')
    private Integer cabinType;

    /**
     * 舱位属性说明.
     * 1:头等公务2:全价3:经济舱位4:全网最低舱
     */
    @ApiModelProperty(value = '舱位属性说明', example = '全价舱')
    private String cabinDescribe;

    /**
     * 经停次数.
     */
    @ApiModelProperty(value = '经停次数', example = '1')
    private Integer stopNum;

    /**
     * 经停城市三字码.
     */
    @ApiModelProperty(value = '经停城市三字码（如CTU）', example = 'PVG')
    private String stopCity;

    /**
     * 经停城市中文名.
     */
    @ApiModelProperty(value = '经停城市中文名', example = '上海')
    private String stopCityDescribe;

    /**
     * 经停机场.
     */
    @ApiModelProperty(value = '经停机场三字码（如CTU）', example = 'PVG')
    private String stopAirport;

    /**
     * 经停机场中文名.
     */
    @ApiModelProperty(value = '经停机场中文名', example = '浦东')
    private String stopAirportDescribe;

    /**
     * 经停到达时间.
     */
    @ApiModelProperty(value = '经停到达时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 12:00')
    private String midArrTime;

    /**
     * 经停起飞时间.
     */
    @ApiModelProperty(value = '经停起飞时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 12:30')
    private String midDepTime;

//    /**
//     * 是否中转（0：没有中转 1：此行程有中转 2：此行程是中转行程）.
//     */
//    @ApiModelProperty(value = '是否中转（0：没有中转 1：此行程有中转 2：此行程是中转行程）', example = '0')
//    private Integer isTransfer;
//
//    /**
//     * 中转航班原航程序号（当IsTransfer=2时，此字段才有值）.
//     */
//    @ApiModelProperty(value = '中转航班原航程序号（当IsTransfer=2时，此字段才有值）', example = '0')
//    private Integer transferOrgSequence;

    /**
     * 是否共享.
     */
    @ApiModelProperty(value = '是否共享')
    private Boolean isShare;

    /**
     * 共享航班真实航班号.
     */
    @ApiModelProperty(value = '共享航班真实航班号', example = 'FM1234')
    private String actualFlightNo;

    /**
     * 销售价.
     */
    @ApiModelProperty(value = '销售价(不含税)')
    private BigDecimal salePrice;

    /**
     * 成人票面价.
     */
    @ApiModelProperty(value = '成人票面价')
    private BigDecimal ticketPrice;

    /**
     * 儿童票面价.
     */
    @ApiModelProperty(value = '儿童票面价')
    private BigDecimal chdTicketPrice;

    /**
     * 婴儿票面价.
     */
    @ApiModelProperty(value = '婴儿票面价')
    private BigDecimal babyTicketPrice;

    /**
     * 成人基建.
     */
    @ApiModelProperty(value = '成人基建', example = '50')
    private BigDecimal aduFee;

    /**
     * 成人燃油.
     */
    @ApiModelProperty(value = '成人燃油')
    private BigDecimal aduTax;

    /**
     * 儿童基建.
     */
    @ApiModelProperty(value = '儿童基建')
    private BigDecimal chdFee;

    /**
     * 儿童燃油.
     */
    @ApiModelProperty(value = '儿童燃油')
    private BigDecimal chdTax;

    /**
     * 婴儿基建.
     */
    @ApiModelProperty(value = '婴儿基建')
    private BigDecimal babyFee;

    /**
     * 婴儿燃油.
     */
    @ApiModelProperty(value = '婴儿燃油')
    private BigDecimal babyTax;

    /**
     * 儿童结算价.
     */
    @ApiModelProperty(value = '儿童结算价')
    private BigDecimal chdSettlePrice;

    /**
     * 婴儿结算价.
     */
    @ApiModelProperty(value = '婴儿结算价')
    private BigDecimal babySettlePrice;

//    /**
//     * 是否标准客规.
//     */
//    @ApiModelProperty(value = '是否标准客规')
//    private Integer isStandardRule;
//
//    /**
//     * 客规.
//     */
//    @ApiModelProperty(value = '客规')
//    private String airRule;

    /**
     * 折扣.
     */
    @ApiModelProperty(value = '折扣', example = '50')
    private Integer discount;

    /**
     * 返点.
     */
    @ApiModelProperty(value = '返点', example = '')
    private BigDecimal aduRate;

    /**
     * 儿童返点.
     */
    @ApiModelProperty(value = '儿童返点', example = '')
    private BigDecimal childRate;

    /**
     * 婴儿返点.
     */
    @ApiModelProperty(value = '婴儿返点', example = '')
    private BigDecimal babyRate;

    /**
     * 头等舱全价.
     */
    @ApiModelProperty(value = '头等舱全价', example = '2700', position = 1)
    private BigDecimal ffullPrice;

    /**
     * 经济舱全价.
     */
    @ApiModelProperty(value = '经济舱全价', example = '1700', position = 1)
    private BigDecimal yfullPrice;

    /**
     * 公务舱全价.
     */
    @ApiModelProperty(value = '公务舱全价', example = '2400', position = 1)
    private BigDecimal cfullPrice;

    /**
     * 当天最低价.
     */
    @ApiModelProperty(value = '当天最低价', example = '2400', position = 1)
    private BigDecimal dayCheapest;

    /**
     * 当前航班最低价.
     */
    @ApiModelProperty(value = '当前航班最低价', example = '2400', position = 1)
    private BigDecimal flightCheapest;

    /**
     * 临近最低价.
     */
    @ApiModelProperty(value = '临近最低价', example = '2400', position = 1)
    private BigDecimal nearCheapest;

    /**
     * 大客户号.
     */
    @ApiModelProperty(value = '大客户号', example = '62343423')
    private String bigCustomerNo;

    /**
     * office号.
     */
    @ApiModelProperty(value = 'office号', example = 'SZX498')
    private String office;

    /**
     * 行李额件数.
     */
    @ApiModelProperty(value = '行李额件数', example = '0')
    private BigDecimal baggageCount;

    /**
     * 行李额重量.
     */
    @ApiModelProperty(value = '行李额重量', example = '0')
    private BigDecimal baggageWeight;

    /**
     * 航程类型(1 去程 2 回程).
     */
    @ApiModelProperty(value = '航程类型（1 去程；2 回程）', example = '1')
    private Integer flightType;

    /**
     * 产品ID(0-标准产品|1-官网产品|2-直减产品|3-两方大客户产品|4-三方大客户户产品|5-飞行达人产品|6-公务员产品).
     */
    @ApiModelProperty(value = '产品ID（0:标准产品 1:官网产品 2:直减产品 3:两方大客户产品 4:三方大客户产品 5:飞行达人产品 6:公务员产品）', example = '3')
    private String productId;

    /**
     * 政策ID.
     */
    @ApiModelProperty(value = '政策ID', example = 'CL|1')
    private String policyId;

    /**
     * 政策额外信息（方便扩展）.
     */
    @ApiModelProperty(value = '政策额外信息（Json字符串）', example = ' ')
    private String policyExInfo;

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getDepCityDescribe() {
        return depCityDescribe;
    }

    public void setDepCityDescribe(String depCityDescribe) {
        this.depCityDescribe = depCityDescribe;
    }

    public String getArrCityDescribe() {
        return arrCityDescribe;
    }

    public void setArrCityDescribe(String arrCityDescribe) {
        this.arrCityDescribe = arrCityDescribe;
    }

    public String getDepAirport() {
        return depAirport;
    }

    public void setDepAirport(String depAirport) {
        this.depAirport = depAirport;
    }

    public String getArrAirport() {
        return arrAirport;
    }

    public void setArrAirport(String arrAirport) {
        this.arrAirport = arrAirport;
    }

    public String getDepAirportDescribe() {
        return depAirportDescribe;
    }

    public void setDepAirportDescribe(String depAirportDescribe) {
        this.depAirportDescribe = depAirportDescribe;
    }

    public String getArrAirportDescribe() {
        return arrAirportDescribe;
    }

    public void setArrAirportDescribe(String arrAirportDescribe) {
        this.arrAirportDescribe = arrAirportDescribe;
    }

    public BigDecimal getAduRate() {
        return aduRate;
    }

    public void setAduRate(BigDecimal aduRate) {
        this.aduRate = aduRate;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    /**
     * @return the discount
     */
    public Integer getDiscount() {
        return discount;
    }

    /**
     * @param discount the discount to set
     */
    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public String getDepCity() {
        return depCity;
    }

    public void setDepCity(String depCity) {
        this.depCity = depCity;
    }

    public String getArrCity() {
        return arrCity;
    }

    public void setArrCity(String arrCity) {
        this.arrCity = arrCity;
    }

    public String getDepTime() {
        return depTime;
    }

    public void setDepTime(String depTime) {
        this.depTime = depTime;
    }

    public String getArrTime() {
        return arrTime;
    }

    public void setArrTime(String arrTime) {
        this.arrTime = arrTime;
    }

    public String getAirCode() {
        return airCode;
    }

    public void setAirCode(String airCode) {
        this.airCode = airCode;
    }

    public String getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    public Integer getCabinType() {
        return cabinType;
    }

    public void setCabinType(Integer cabinType) {
        this.cabinType = cabinType;
    }

    public String getCabinDescribe() {
        return cabinDescribe;
    }

    public void setCabinDescribe(String cabinDescribe) {
        this.cabinDescribe = cabinDescribe;
    }

    public Integer getStopNum() {
        return stopNum;
    }

    public void setStopNum(Integer stopNum) {
        this.stopNum = stopNum;
    }

    public String getStopCity() {
        return stopCity;
    }

    public void setStopCity(String stopCity) {
        this.stopCity = stopCity;
    }

    public String getStopCityDescribe() {
        return stopCityDescribe;
    }

    public void setStopCityDescribe(String stopCityDescribe) {
        this.stopCityDescribe = stopCityDescribe;
    }

    public String getStopAirport() {
        return stopAirport;
    }

    public void setStopAirport(String stopAirport) {
        this.stopAirport = stopAirport;
    }

    public String getStopAirportDescribe() {
        return stopAirportDescribe;
    }

    public void setStopAirportDescribe(String stopAirportDescribe) {
        this.stopAirportDescribe = stopAirportDescribe;
    }

    public String getMidArrTime() {
        return midArrTime;
    }

    public void setMidArrTime(String midArrTime) {
        this.midArrTime = midArrTime;
    }

    public String getMidDepTime() {
        return midDepTime;
    }

    public void setMidDepTime(String midDepTime) {
        this.midDepTime = midDepTime;
    }

    /**
     * @return the cabin
     */
    public String getCabin() {
        return cabin;
    }

    /**
     * @param cabin the cabin to set
     */
    public void setCabin(String cabin) {
        this.cabin = cabin;
    }

//    public Integer getIsTransfer() {
//        return isTransfer;
//    }
//
//    public void setIsTransfer(Integer isTransfer) {
//        this.isTransfer = isTransfer;
//    }
//
//    public Integer getTransferOrgSequence() {
//        return transferOrgSequence;
//    }
//
//    public void setTransferOrgSequence(Integer transferOrgSequence) {
//        this.transferOrgSequence = transferOrgSequence;
//    }

//    public Integer getIsStandardRule() {
//        return isStandardRule;
//    }
//
//    public void setIsStandardRule(Integer isStandardRule) {
//        this.isStandardRule = isStandardRule;
//    }
//
//    public String getAirRule() {
//        return airRule;
//    }
//
//    public void setAirRule(String airRule) {
//        this.airRule = airRule;
//    }

    /**
     * 设置policyExInfo.
     *
     * @return 返回policyExInfo
     */
    public String getPolicyExInfo() {
        return policyExInfo;
    }

    /**
     * 获取policyExInfo.
     *
     * @param policyExInfo 要设置的policyExInfo
     */
    public void setPolicyExInfo(String policyExInfo) {
        this.policyExInfo = policyExInfo;
    }

    public String getBigCustomerNo() {
        return bigCustomerNo;
    }

    public void setBigCustomerNo(String bigCustomerNo) {
        this.bigCustomerNo = bigCustomerNo;
    }

    /**
     * 获取office.
     *
     * @return .
     */
    public String getOffice() {
        return office;
    }

    /**
     * 设置office
     *
     * @param office .
     */
    public void setOffice(String office) {
        this.office = office;
    }

    public BigDecimal getBaggageCount() {
        return baggageCount;
    }

    public void setBaggageCount(BigDecimal baggageCount) {
        this.baggageCount = baggageCount;
    }

    public BigDecimal getBaggageWeight() {
        return baggageWeight;
    }

    public void setBaggageWeight(BigDecimal baggageWeight) {
        this.baggageWeight = baggageWeight;
    }

    public Integer getFlightType() {
        return flightType;
    }

    public void setFlightType(Integer flightType) {
        this.flightType = flightType;
    }

    public Boolean getIsShare() {
        return isShare;
    }

    public void setIsShare(Boolean share) {
        isShare = share;
    }

    public String getActualFlightNo() {
        return actualFlightNo;
    }

    public void setActualFlightNo(String actualFlightNo) {
        this.actualFlightNo = actualFlightNo;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public BigDecimal getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(BigDecimal ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public BigDecimal getChdTicketPrice() {
        return chdTicketPrice;
    }

    public void setChdTicketPrice(BigDecimal chdTicketPrice) {
        this.chdTicketPrice = chdTicketPrice;
    }

    public BigDecimal getBabyTicketPrice() {
        return babyTicketPrice;
    }

    public void setBabyTicketPrice(BigDecimal babyTicketPrice) {
        this.babyTicketPrice = babyTicketPrice;
    }

    public BigDecimal getAduFee() {
        return aduFee;
    }

    public void setAduFee(BigDecimal aduFee) {
        this.aduFee = aduFee;
    }

    public BigDecimal getAduTax() {
        return aduTax;
    }

    public void setAduTax(BigDecimal aduTax) {
        this.aduTax = aduTax;
    }

    public BigDecimal getChdFee() {
        return chdFee;
    }

    public void setChdFee(BigDecimal chdFee) {
        this.chdFee = chdFee;
    }

    public BigDecimal getChdTax() {
        return chdTax;
    }

    public void setChdTax(BigDecimal chdTax) {
        this.chdTax = chdTax;
    }

    public BigDecimal getBabyFee() {
        return babyFee;
    }

    public void setBabyFee(BigDecimal babyFee) {
        this.babyFee = babyFee;
    }

    public BigDecimal getBabyTax() {
        return babyTax;
    }

    public void setBabyTax(BigDecimal babyTax) {
        this.babyTax = babyTax;
    }

    public BigDecimal getChdSettlePrice() {
        return chdSettlePrice;
    }

    public void setChdSettlePrice(BigDecimal chdSettlePrice) {
        this.chdSettlePrice = chdSettlePrice;
    }

    public BigDecimal getBabySettlePrice() {
        return babySettlePrice;
    }

    public void setBabySettlePrice(BigDecimal babySettlePrice) {
        this.babySettlePrice = babySettlePrice;
    }

    public String getAirCodeName() {
        return airCodeName;
    }

    public void setAirCodeName(String airCodeName) {
        this.airCodeName = airCodeName;
    }

    public String getAirPlaneSize() {
        return airPlaneSize;
    }

    public void setAirPlaneSize(String airPlaneSize) {
        this.airPlaneSize = airPlaneSize;
    }

    public BigDecimal getChildRate() {
        return childRate;
    }

    public void setChildRate(BigDecimal childRate) {
        this.childRate = childRate;
    }

    public BigDecimal getBabyRate() {
        return babyRate;
    }

    public void setBabyRate(BigDecimal babyRate) {
        this.babyRate = babyRate;
    }

    public BigDecimal getFfullPrice() {
        return ffullPrice;
    }

    public void setFfullPrice(BigDecimal ffullPrice) {
        this.ffullPrice = ffullPrice;
    }

    public BigDecimal getYfullPrice() {
        return yfullPrice;
    }

    public void setYfullPrice(BigDecimal yfullPrice) {
        this.yfullPrice = yfullPrice;
    }

    public BigDecimal getCfullPrice() {
        return cfullPrice;
    }

    public void setCfullPrice(BigDecimal cfullPrice) {
        this.cfullPrice = cfullPrice;
    }

    public String getAirPlaneModel() {
        return airPlaneModel;
    }

    public void setAirPlaneModel(String airPlaneModel) {
        this.airPlaneModel = airPlaneModel;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public BigDecimal getDayCheapest() {
        return dayCheapest;
    }

    public void setDayCheapest(BigDecimal dayCheapest) {
        this.dayCheapest = dayCheapest;
    }

    public BigDecimal getFlightCheapest() {
        return flightCheapest;
    }

    public void setFlightCheapest(BigDecimal flightCheapest) {
        this.flightCheapest = flightCheapest;
    }

    public BigDecimal getNearCheapest() {
        return nearCheapest;
    }

    public void setNearCheapest(BigDecimal nearCheapest) {
        this.nearCheapest = nearCheapest;
    }

    public String getDepTerminal() {
        return depTerminal
    }

    public void setDepTerminal(String depTerminal) {
        this.depTerminal = depTerminal
    }

    public String getArrTerminal() {
        return arrTerminal
    }

    public void setArrTerminal(String arrTerminal) {
        this.arrTerminal = arrTerminal
    }
}
