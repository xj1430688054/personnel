package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 16:56
 */
public class PassengerInfo {
    /**
     * 乘客姓名.
     */
    @ApiModelProperty(value = '乘客姓名', example = '张三', position = -1)
    private String passengerName;

    /**
     * @证件类型 （0：身份证 1：护照 2：学生证 3：军人证 4：驾驶证 5：回乡证 6：台胞证 7：港澳通行证 8：台湾通行证 9：士兵证 10：临时身份证 11：户口簿 12：警官证 13：出生证明 99：其它）
     */
    @ApiModelProperty(value = '证件类型（0：身份证 1：护照 2：学生证 3：军人证 4：驾驶证 5：回乡证 6：台胞证 7：港澳通行证 8：台湾通行证 9：士兵证 10：临时身份证 11：户口簿 12：警官证 13：出生证明 99：其它）', example = '0')
    private Integer cardType;

    /**
     * @证件号
     */
    @ApiModelProperty(value = '证件号', example = '513021199212188348')
    private String cardNo;

    /**
     * 生日.
     */
    @ApiModelProperty(value = '生日', example = '1990-01-01')
    private String birthday;

    /**
     * 性别(0:男 1：女).
     */
    @ApiModelProperty(value = '性别（0:男 1：女）', example = '0')
    private Integer gender;

    /**
     * 乘客类型（0:成人 1:儿童 2:婴儿）.
     */
    @ApiModelProperty(value = '乘客类型（0:成人 1:儿童 2:婴儿）', example = '0')
    private Integer passengerType;

    /**
     * 手机号.
     */
    @ApiModelProperty(value = '乘客手机号', example = '13888888888')
    private String passengerPhone;

    /**
     * 公务员验证方式 1:公务卡验证，2:财政预算单位校验.
     */
    @ApiModelProperty(value = '公务员验证方式（1:公务卡验证 2:财政预算单位校验）（公务员产品才需要）', example = '1', position = 1)
    private Integer civilServantValidType;

    /**
     * 公务卡开卡银行ID.
     */
    @ApiModelProperty(value = '公务卡开卡银行ID（公务员产品才需要）', example = '1', position = 1)
    private Integer cardBankId;

    /**
     * 公务卡开卡银行名称.
     */
    @ApiModelProperty(value = '公务卡开卡银行名称（公务员产品才需要）', example = '工商银行', position = 1)
    private String cardBankName;

    /**
     * 财政预算单位名称.
     */
    @ApiModelProperty(value = '财政预算单位名称（公务员产品才需要）', example = ' ', position = 1)
    private String budgetUnitName;

    /**
     * 是否打印行程单.
     */
    @ApiModelProperty(value = '是否打印行程单', example = 'false')
    private Boolean needItinerary;

    /**
     * 行程单处理类型(0 按默认处理方式；1 按因私处理).
     */
    @ApiModelProperty(value = '行程单处理类型（0:按默认处理 1:按因私处理）', example = '0')
    private Integer itineraryDealType;

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public Integer getPassengerType() {
        return passengerType;
    }

    public void setPassengerType(Integer passengerType) {
        this.passengerType = passengerType;
    }

    /**
     * @return the gender
     */
    public Integer getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(Integer gender) {
        this.gender = gender;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getPassengerPhone() {
        return passengerPhone;
    }

    public void setPassengerPhone(String passengerPhone) {
        this.passengerPhone = passengerPhone;
    }

    public Integer getCardType() {
        return cardType;
    }

    public void setCardType(Integer cardType) {
        this.cardType = cardType;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    /**
     * @return the civilServantValidType
     */
    public Integer getCivilServantValidType() {
        return civilServantValidType;
    }

    /**
     * @param civilServantValidType the civilServantValidType to set
     */
    public void setCivilServantValidType(Integer civilServantValidType) {
        this.civilServantValidType = civilServantValidType;
    }

    /**
     * @return the cardBankId
     */
    public Integer getCardBankId() {
        return cardBankId;
    }

    /**
     * @param cardBankId the cardBankId to set
     */
    public void setCardBankId(Integer cardBankId) {
        this.cardBankId = cardBankId;
    }

    /**
     * @return the cardBankName
     */
    public String getCardBankName() {
        return cardBankName;
    }

    /**
     * @param cardBankName the cardBankName to set
     */
    public void setCardBankName(String cardBankName) {
        this.cardBankName = cardBankName;
    }

    /**
     * @return the budgetUnitName
     */
    public String getBudgetUnitName() {
        return budgetUnitName;
    }

    /**
     * @param budgetUnitName the budgetUnitName to set
     */
    public void setBudgetUnitName(String budgetUnitName) {
        this.budgetUnitName = budgetUnitName;
    }

    public Boolean getNeedItinerary() {
        return needItinerary;
    }

    public void setNeedItinerary(Boolean needItinerary) {
        this.needItinerary = needItinerary;
    }

    Integer getItineraryDealType() {
        return itineraryDealType
    }

    void setItineraryDealType(Integer itineraryDealType) {
        this.itineraryDealType = itineraryDealType
    }
}
