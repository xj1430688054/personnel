package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 16:44
 */
public class OrderCreateInVo {
    /**
     * 航段信息.
     */
    @ApiModelProperty(value = '航段信息')
    private List<VoyageInfo> voyageList;

    /**
     * 乘机人信息.
     */
    @ApiModelProperty(value = '乘机人信息')
    private List<PassengerInfo> passengerList;

    /**
     * 外部订单号.
     */
    @ApiModelProperty(value = '外部订单号', example = '180321213644407136')
    private String outOrderId;

    /**
     * 行程类型(0:单程 1:往返 2：联程).
     */
    @ApiModelProperty(value = '行程类型（0:单程 1:往返 2：联程）', example = '0')
    private Integer voyageType;

    /**
     * 出行类型(0:因公 1:因私).
     */
    @ApiModelProperty(value = "出行类型(0:因公 1:因私)", example = "0")
    private Integer travelType;

//    /**
//     * 企业编号.
//     */
//    @ApiModelProperty(value = '企业编号', example = '20180312190122222151115')
//    private String cropNo;

    /**
     * 预订人姓名.
     */
    @ApiModelProperty(value = '预订人姓名', example = '碧落')
    private String bookUserName;

    /**
     * 预订人电话.
     */
    @ApiModelProperty(value = '预订人电话', example = '18382212521')
    private String bookUserPhone;

    /**
     * 联系人姓名.
     */
    @ApiModelProperty(value = '联系人姓名', example = '碧落')
    private String linkName;

    /**
     * 联系人电话.
     */
    @ApiModelProperty(value = '联系人电话', example = '18382212521')
    private String linkPhone;

    /**
     * 是否打印行程单.
     */
    @ApiModelProperty(value = '是否打印行程单', example = 'false')
    private Boolean needItinerary;

    /**
     * 邮寄信息.
     */
    @ApiModelProperty(value = '邮寄信息', example = '')
    private DeliveryInfo deliveryInfo;

//    /**
//     * 是否同意生僻字系统转换.
//     */
//    @ApiModelProperty(value = '是否同意生僻字系统转换')
//    private Boolean isRareWordChange;

//    /**
//     * @return 是否同意生僻字系统转换
//     */
//    public Boolean getIsRareWordChange() {
//        return isRareWordChange;
//    }
//
//    /**
//     * @param isRareWordChange 是否同意生僻字系统转换
//     */
//    public void setIsRareWordChange(boolean isRareWordChange) {
//        this.isRareWordChange = isRareWordChange;
//    }

    public String getOutOrderId() {
        return outOrderId;
    }

    public void setOutOrderId(String outOrderId) {
        this.outOrderId = outOrderId;
    }

    public Integer getVoyageType() {
        return voyageType;
    }

    public void setVoyageType(Integer voyageType) {
        this.voyageType = voyageType;
    }

    public String getLinkName() {
        return linkName;
    }

    public void setLinkName(String linkName) {
        this.linkName = linkName;
    }

    public String getLinkPhone() {
        return linkPhone;
    }

    public void setLinkPhone(String linkPhone) {
        this.linkPhone = linkPhone;
    }

    public List<VoyageInfo> getVoyageList() {
        return voyageList;
    }

    public void setVoyageList(List<VoyageInfo> voyageList) {
        this.voyageList = voyageList;
    }

    public List<PassengerInfo> getPassengerList() {
        return passengerList;
    }

    public void setPassengerList(List<PassengerInfo> passengerList) {
        this.passengerList = passengerList;
    }

//    public String getCropNo() {
//        return cropNo;
//    }
//
//    public void setCropNo(String cropNo) {
//        this.cropNo = cropNo;
//    }

    public String getBookUserName() {
        return bookUserName;
    }

    public void setBookUserName(String bookUserName) {
        this.bookUserName = bookUserName;
    }

    public String getBookUserPhone() {
        return bookUserPhone;
    }

    public void setBookUserPhone(String bookUserPhone) {
        this.bookUserPhone = bookUserPhone;
    }

    public DeliveryInfo getDeliveryInfo() {
        return deliveryInfo;
    }

    public void setDeliveryInfo(DeliveryInfo deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
    }

    Boolean getNeedItinerary() {
        return needItinerary
    }

    void setNeedItinerary(Boolean needItinerary) {
        this.needItinerary = needItinerary
    }

    Integer getTravelType() {
        return travelType
    }

    void setTravelType(Integer travelType) {
        this.travelType = travelType
    }
}
