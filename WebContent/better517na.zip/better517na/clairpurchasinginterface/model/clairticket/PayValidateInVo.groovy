package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket

import io.swagger.annotations.ApiModelProperty

class PayValidateInVo {
    /**
     * 订单号.
     */
    @ApiModelProperty(value = "差旅机票订单号", example = "180316100122222151115", required = true)
    private String orderId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
