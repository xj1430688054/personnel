package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/22
 * Time: 15:49
 */
public class QueryVoyageInfo {
    /**
     * @航程序号 （从0开始）
     */
    @ApiModelProperty(value = '航程序号（从0开始）', example = '0')
    private Integer sequence;

    /**
     * @承运人
     */
    @ApiModelProperty(value = '承运人', example = 'MU')
    private String carrier;

    /**
     * @航班号
     */
    @ApiModelProperty(value = '航班号', example = 'MU1234')
    private String flightNo;

    /**
     * @舱位
     */
    @ApiModelProperty(value = '舱位', example = 'M')
    private String cabin;

    /**
     * @出发城市
     */
    @ApiModelProperty(value = '出发城市三字码（如CTU）', example = 'CTU')
    private String deptCity;

    /**
     * @到达城市
     */
    @ApiModelProperty(value = '到达城市三字码（如CTU）', example = 'PEK')
    private String arrCity;

    /**
     * @出发城市中文名
     */
    @ApiModelProperty(value = '出发城市中文名', example = '成都')
    private String deptCityCh;

    /**
     * @到达城市中文名
     */
    @ApiModelProperty(value = '到达城市中文名', example = '北京')
    private String arrCityCh;

    /**
     * @出发机场
     */
    @ApiModelProperty(value = '出发机场三字码（如CTU）', example = 'CTU')
    private String deptAirport;

    /**
     * @到达机场
     */
    @ApiModelProperty(value = '到达机场三字码（如CTU）', example = 'PEK')
    private String arrAirport;

    /**
     * @出发机场中文名
     */
    @ApiModelProperty(value = '出发机场中文名', example = '双流')
    private String deptAirportCh;

    /**
     * @到达机场中文名
     */
    @ApiModelProperty(value = '到达机场中文名', example = '首都')
    private String arrAirportCh;

    /**
     * @起飞时间
     */
    @ApiModelProperty(value = '起飞时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 12:00')
    private String deptTime;

    /**
     * @到达时间
     */
    @ApiModelProperty(value = '到达时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 12:30')
    private String arrTime;

    /**
     * 始发航站楼.
     */
    @ApiModelProperty(value = '出发航站楼', example = 'T2')
    private String depTerminal;

    /**
     * 到达航站楼.
     */
    @ApiModelProperty(value = '到达航站楼', example = 'T1')
    private String arrTerminal;

    /**
     * @是否经停 (0:不经停 1:经停)
     */
    @ApiModelProperty(value = '是否经停（0:不经停 1:经停）', example = '0')
    private Integer stopOver;

    /**
     * @经停城市
     */
    @ApiModelProperty(value = '经停城市', example = ' ')
    private String stopOverCity;

    /**
     * @经停城市中文名
     */
    @ApiModelProperty(value = '经停城市中文名', example = ' ')
    private String stopOverCityCh;

    /**
     * @经停机场
     */
    @ApiModelProperty(value = '经停机场', example = ' ')
    private String stopAirport;

    /**
     * @经停机场中文名
     */
    @ApiModelProperty(value = '经停机场中文名', example = ' ')
    private String stopAirportCh;

    /**
     * @经停起飞时间.
     */
    @ApiModelProperty(value = '经停起飞时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 12:00')
    private String midDepTime;

    /**
     * @经停到达时间.
     */
    @ApiModelProperty(value = '经停到达时间（格式为yyyy-MM-dd HH:mm）', example = '2018-03-20 12:30')
    private String midArrTime;

    /**
     * @是否共享航班 (0:不共享 1:共享)
     */
    @ApiModelProperty(value = '是否共享航班', example = '0')
    private Integer isShare;

    /**
     * @共享真实航班号
     */
    @ApiModelProperty(value = '共享真实航班号', example = 'FM1234')
    private String reallyFlightNo;

    /**
     * @返点
     */
    @ApiModelProperty(value = '返点', example = ' ')
    private String returnPoint;

    /**
     * @大客户号.
     */
    @ApiModelProperty(value = '大客户号', example = '6296354')
    private String bigCustomerNo;

    /**
     * @航程类型 (1 去程 2 回程)
     */
    @ApiModelProperty(value = '航程类型(1 去程 2 回程)', example = '1')
    private Integer flightType;

//    /**
//     * @是否中转行程. （0：没有中转 / 1：此行程有中转 / 2：此行程是中转行程）
//     */
//    @ApiModelProperty(value = '是否中转行程（0：没有中转 / 1：此行程有中转 / 2：此行程是中转行程）', example = '0')
//    private Integer isTransfer;
//
//    /**
//     * @中转航班原航程序号. （当IsTransfer=2时，此字段才有意义）
//     */
//    @ApiModelProperty(value = '中转航班原航程序号（当IsTransfer=2时，此字段才有意义）', example = '0')
//    private Integer transferOrgSequence;

//    /**
//     * 设置isTransfer.
//     *
//     * @return 返回isTransfer
//     */
//    public Integer getIsTransfer() {
//        return isTransfer;
//    }
//
//    /**
//     * 获取isTransfer.
//     *
//     * @param isTransfer 要设置的isTransfer
//     */
//    public void setIsTransfer(Integer isTransfer) {
//        this.isTransfer = isTransfer;
//    }
//
//    /**
//     * 设置transferOrgSequence.
//     *
//     * @return 返回transferOrgSequence
//     */
//    public Integer getTransferOrgSequence() {
//        return transferOrgSequence;
//    }
//
//    /**
//     * 获取transferOrgSequence.
//     *
//     * @param transferOrgSequence 要设置的transferOrgSequence
//     */
//    public void setTransferOrgSequence(Integer transferOrgSequence) {
//        this.transferOrgSequence = transferOrgSequence;
//    }

    /**
     * 设置flightType.
     *
     * @return 返回flightType
     */
    public Integer getFlightType() {
        return flightType;
    }


    /**
     * 获取flightType.
     *
     * @param flightType 要设置的flightType
     */
    public void setFlightType(Integer flightType) {
        this.flightType = flightType;
    }

    public String getBigCustomerNo() {
        return bigCustomerNo;
    }

    public void setBigCustomerNo(String bigCustomerNo) {
        this.bigCustomerNo = bigCustomerNo;
    }

    public String getMidDepTime() {
        return midDepTime;
    }

    public void setMidDepTime(String midDepTime) {
        this.midDepTime = midDepTime;
    }

    /**
     * 经停到达时间.
     *
     * @return 返回经停到达时间
     */
    public String getMidArrTime() {
        return midArrTime;
    }

    /**
     * 经停到达时间.
     *
     * @param time
     *            经停到达时间
     */
    public void setMidArrTime(String time) {
        this.midArrTime = time;
    }

    public String getStopAirport() {
        return stopAirport;
    }

    public void setStopAirport(String stopAirport) {
        this.stopAirport = stopAirport;
    }

    public String getStopAirportCh() {
        return stopAirportCh;
    }

    public void setStopAirportCh(String stopAirportCh) {
        this.stopAirportCh = stopAirportCh;
    }

    /**
     * @return 航程序号
     */
    public Integer getSequence() {
        return sequence;
    }

    /**
     * @param sequence
     *            航程序号.
     */
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    /**
     * @return 承运人
     */
    public String getCarrier() {
        return carrier;
    }

    /**
     * @param carrier
     *            承运人.
     */
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    /**
     * @return 航班号
     */
    public String getFlightNo() {
        return flightNo;
    }

    /**
     * @param flightNo
     *            航班号.
     */
    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    /**
     * @return 舱位
     */
    public String getCabin() {
        return cabin;
    }

    /**
     * @param cabin
     *            舱位.
     */
    public void setCabin(String cabin) {
        this.cabin = cabin;
    }

    /**
     * @return 出发城市
     */
    public String getDeptCity() {
        return deptCity;
    }

    /**
     * @param deptCity
     *            出发城市.
     */
    public void setDeptCity(String deptCity) {
        this.deptCity = deptCity;
    }

    /**
     * @return 到达城市
     */
    public String getArrCity() {
        return arrCity;
    }

    /**
     * @param arrCity
     *            到达城市.
     */
    public void setArrCity(String arrCity) {
        this.arrCity = arrCity;
    }

    /**
     * @return 出发城市中文名
     */
    public String getDeptCityCh() {
        return deptCityCh;
    }

    /**
     * @param deptCityCh
     *            出发城市中文名.
     */
    public void setDeptCityCh(String deptCityCh) {
        this.deptCityCh = deptCityCh;
    }

    /**
     * @return 到达城市中文名
     */
    public String getArrCityCh() {
        return arrCityCh;
    }

    /**
     * @param arrCityCh
     *            到达城市中文名.
     */
    public void setArrCityCh(String arrCityCh) {
        this.arrCityCh = arrCityCh;
    }

    /**
     * @return 出发机场
     */
    public String getDeptAirport() {
        return deptAirport;
    }

    /**
     * @param deptAirport
     *            出发机场.
     */
    public void setDeptAirport(String deptAirport) {
        this.deptAirport = deptAirport;
    }

    /**
     * @return 到达机场
     */
    public String getArrAirport() {
        return arrAirport;
    }

    /**
     * @param arrAirport
     *            到达机场.
     */
    public void setArrAirport(String arrAirport) {
        this.arrAirport = arrAirport;
    }

    /**
     * @return 出发机场中文名
     */
    public String getDeptAirportCh() {
        return deptAirportCh;
    }

    /**
     * @param deptAirportCh
     *            出发机场中文名.
     */
    public void setDeptAirportCh(String deptAirportCh) {
        this.deptAirportCh = deptAirportCh;
    }

    /**
     * @return 到达机场中文名
     */
    public String getArrAirportCh() {
        return arrAirportCh;
    }

    /**
     * @param arrAirportCh
     *            到达机场中文名.
     */
    public void setArrAirportCh(String arrAirportCh) {
        this.arrAirportCh = arrAirportCh;
    }

    /**
     * @return 起飞时间
     */
    public String getDeptTime() {
        return deptTime;
    }

    /**
     * @param deptTime
     *            起飞时间.
     */
    public void setDeptTime(String deptTime) {
        this.deptTime = deptTime;
    }

    /**
     * @return 到达时间
     */
    public String getArrTime() {
        return arrTime;
    }

    /**
     * @param arrTime
     *            到达时间.
     */
    public void setArrTime(String arrTime) {
        this.arrTime = arrTime;
    }

    /**
     * @return 是否经停
     */
    public Integer getStopOver() {
        return stopOver;
    }

    /**
     * @param stopOver
     *            是否经停.
     */
    public void setStopOver(Integer stopOver) {
        this.stopOver = stopOver;
    }

    /**
     * @return 经停城市
     */
    public String getStopOverCity() {
        return stopOverCity;
    }

    /**
     * @param stopOverCity
     *            经停城市.
     */
    public void setStopOverCity(String stopOverCity) {
        this.stopOverCity = stopOverCity;
    }

    /**
     * @return 经停城市中文名
     */
    public String getStopOverCityCh() {
        return stopOverCityCh;
    }

    /**
     * @param stopOverCityCh
     *            经停城市中文名.
     */
    public void setStopOverCityCh(String stopOverCityCh) {
        this.stopOverCityCh = stopOverCityCh;
    }

    /**
     * @return 是否共享航班
     */
    public Integer getIsShare() {
        return isShare;
    }

    /**
     * @param isShare
     *            是否共享航班.
     */
    public void setIsShare(Integer isShare) {
        this.isShare = isShare;
    }

    /**
     * @return 共享真实航班号
     */
    public String getReallyFlightNo() {
        return reallyFlightNo;
    }

    /**
     * @param reallyFlightNo
     *            共享真实航班号.
     */
    public void setReallyFlightNo(String reallyFlightNo) {
        this.reallyFlightNo = reallyFlightNo;
    }

    /**
     * @return 返点
     */
    public String getReturnPoint() {
        return returnPoint;
    }

    /**
     * @param returnPoint
     *            返点.
     */
    public void setReturnPoint(String returnPoint) {
        this.returnPoint = returnPoint;
    }

    public String getDepTerminal() {
        return depTerminal
    }

    public void setDepTerminal(String depTerminal) {
        this.depTerminal = depTerminal
    }

    public String getArrTerminal() {
        return arrTerminal
    }

    public void setArrTerminal(String arrTerminal) {
        this.arrTerminal = arrTerminal
    }
}
