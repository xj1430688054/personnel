package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/22
 * Time: 16:05
 */
public class QueryTicketOrderInVo {
    /**
     * 订单号.
     */
    @ApiModelProperty(value = '差旅机票订单号', example = '180321213644407136')
    private String orderId;

//    /**
//     * 订单类型(0 出票订单，1 改签订单，2 退票订单).
//     */
//    @ApiModelProperty(value = '订单类型(0 出票订单，1 改签订单，2 退票订单)', example = '0')
//    private Integer orderType;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

//    public Integer getOrderType() {
//        return orderType;
//    }
//
//    public void setOrderType(Integer orderType) {
//        this.orderType = orderType;
//    }
}
