package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 18:44
 */
public class PayOrderResVo {
    /**
     * 订单号.
     */
    @ApiModelProperty(value = '机票订单号', example = '180316100122222151115')
    private String orderId;

    /**
     * 订单支付金额.
     */
    @ApiModelProperty(value = '订单支付金额', example = '1050.00')
    private BigDecimal payMoney;

//    /**
//     * 是否变价.
//     */
//    @ApiModelProperty(value = '是否变价', example = 'false')
//    private Boolean isChangePrice = false;

    /**
     * 机票销售价.
     */
    @ApiModelProperty(value = '机票销售价', example = '1000.00')
    private BigDecimal salePrice;

    /**
     * 支付余额类型.
     */
    @ApiModelProperty(value = '支付余额类型（0:现金；1:赊销）', example = '1')
    private Integer balanceType;

    /**
     * 真实支付账号.
     */
    @ApiModelProperty(value = '真实支付账号', example = 'cl15863245487')
    private String payAccount;

    /**
     * 真实支付账号
     * @return 真实支付账号
     */
    public String getPayAccount() {
        return payAccount;
    }

    /**
     * 真实支付账号
     * @param payAccount 真实支付账号
     */
    public void setPayAccount(String payAccount) {
        this.payAccount = payAccount;
    }

    /**
     * 设置balanceType.
     *
     * @return 返回balanceType
     */
    public Integer getBalanceType() {
        return balanceType;
    }

    /**
     * 获取balanceType.
     *
     * @param balanceType
     *            要设置的balanceType
     */
    public void setBalanceType(Integer balanceType) {
        this.balanceType = balanceType;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

//    /**
//     * 设置isChangePrice.
//     *
//     * @return 返回isChangePrice
//     */
//    public Boolean getIsChangePrice() {
//        return isChangePrice;
//    }
//
//    /**
//     * 获取isChangePrice.
//     *
//     * @param isChangePrice
//     *            要设置的isChangePrice
//     */
//    public void setIsChangePrice(Boolean isChangePrice) {
//        this.isChangePrice = isChangePrice;
//    }

    /**
     * 设置orderId.
     *
     * @return 返回orderId
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * 获取orderId.
     *
     * @param orderId
     *            要设置的orderId
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * 设置payMoney.
     *
     * @return 返回payMoney
     */
    public BigDecimal getPayMoney() {
        return payMoney;
    }

    /**
     * 获取payMoney.
     *
     * @param payMoney
     *            要设置的payMoney
     */
    public void setPayMoney(BigDecimal payMoney) {
        this.payMoney = payMoney;
    }
}
