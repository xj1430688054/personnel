package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 18:36
 */
public class PayOrderInVo {
    /**
     * 订单号.
     */
    @ApiModelProperty(value = '机票订单号', example = '180316100122222151115')
    private String orderId;

//    /**
//     * TMC编号.
//     */
//    @ApiModelProperty(value = 'TMC编号', example = '20180312190122222151115')
//    private String tmcNo;

//    /**
//     * 企业编号.
//     */
//    @ApiModelProperty(value = '企业编号', example = '20180312190122222151115')
//    private String cropNo;

    /**
     * 支付总金额.
     */
    @ApiModelProperty(value = '支付总金额', example = '1050.00')
    private BigDecimal payMoney;

    /**
     * 支付方式（1：月结；2：现付;3：预存）.
     */
    @ApiModelProperty(value = '支付方式（1：月结；2：现付;3：预存）', example = '1')
    private Integer payType;

    /**
     * 支付账号
     */
    @ApiModelProperty(value = '支付账号', example = 'cl18382212520')
    private String payAccount;

    /**
     * 支付方式（1：月结；2：现付;3：预存）.
     *
     * @return 返回payType
     */
    public Integer getPayType() {
        return payType;
    }

    /**
     * 支付方式（1：月结；2：现付;3：预存）.
     *
     * @param payType 要设置的payType
     */
    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    /**
     * 设置payMoney.
     *
     * @return 返回payMoney
     */
    public BigDecimal getPayMoney() {
        return payMoney;
    }

    /**
     * 获取payMoney.
     *
     * @param payMoney 要设置的payMoney
     */
    public void setPayMoney(BigDecimal payMoney) {
        this.payMoney = payMoney;
    }

    /**
     * 设置orderId.
     *
     * @return 返回orderId
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * 获取orderId.
     *
     * @param orderId 要设置的orderId
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

//    /**
//     * 设置tmcNo.
//     *
//     * @return 返回tmcNo
//     */
//    public String getTmcNo() {
//        return tmcNo;
//    }
//
//    /**
//     * 获取tmcNo.
//     *
//     * @param tmcNo
//     *            要设置的tmcNo
//     */
//    public void setTmcNo(String tmcNo) {
//        this.tmcNo = tmcNo;
//    }

//    /**
//     * 设置cropNo.
//     *
//     * @return 返回cropNo
//     */
//    public String getCropNo() {
//        return cropNo;
//    }

//    /**
//     * 获取cropNo.
//     *
//     * @param cropNo
//     *            要设置的cropNo
//     */
//    public void setCropNo(String cropNo) {
//        this.cropNo = cropNo;
//    }

    public String getPayAccount() {
        return payAccount;
    }

    public void setPayAccount(String payAccount) {
        this.payAccount = payAccount;
    }
}
