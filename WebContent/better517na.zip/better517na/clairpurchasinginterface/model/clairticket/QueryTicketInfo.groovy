package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/22
 * Time: 15:40
 */
public class QueryTicketInfo {

    /**
     * @票号
     */
    @ApiModelProperty(value = '票号', example = '999-0090489125')
    private String ticketNo;

    /**
     * @乘客姓名
     */
    @ApiModelProperty(value = '乘客姓名', example = '碧落', position = -1)
    private String passengerName;

    /**
     * @乘机人号码
     */
    @ApiModelProperty(value = '乘客电话号码', example = '18382212520')
    private String passengerPhone;

    /**
     * @乘客类型 （0:成人 1:儿童 2:婴儿）
     */
    @ApiModelProperty(value = '乘客类型（0:成人 1:儿童 2:婴儿）', example = '0')
    private Integer passengerType;

//    /**
//     * @乘客类型名称 （0:成人 1:儿童 2:婴儿）
//     */
//    @ApiModelProperty(value = '乘客类型名称', example = '成人')
//    private String passengerTypeName;

    /**
     * @证件类型 （0：身份证 1：护照 2：学生证 3：军人证 4：驾驶证 5：回乡证 6：台胞证 7：港澳通行证 8：台湾通行证 9：士兵证 10：临时身份证 11：户口簿 12：警官证 13：出生证明 99：其它）
     */
    @ApiModelProperty(value = '证件类型（0：身份证 1：护照 2：学生证 3：军人证 4：驾驶证 5：回乡证 6：台胞证 7：港澳通行证 8：台湾通行证 9：士兵证 10：临时身份证 11：户口簿 12：警官证 13：出生证明 99：其它）', example = '0')
    private Integer cardType;

//    /**
//     * @证件类型名称
//     */
//    @ApiModelProperty(value = '证件类型名称', example = '身份证')
//    private String cardTypeName;

    /**
     * @证件号
     */
    @ApiModelProperty(value = '证件号', example = '513021199212188348')
    private String cardNo;

    /**
     * 生日.
     */
    @ApiModelProperty(value = '生日（格式为yyyy-MM-dd）', example = '1990-01-01')
    private String birthday;

    /**
     * @销售价
     */
    @ApiModelProperty(value = '销售价（不含税）', example = '1000')
    private BigDecimal salePrice;

    /**
     * @票面价
     */
    @ApiModelProperty(value = '票面价', example = '1000')
    private BigDecimal ticketPrice;

    /**
     * @燃油费
     */
    @ApiModelProperty(value = '燃油费', example = '0')
    private BigDecimal oilTax;

    /**
     * @机建费
     */
    @ApiModelProperty(value = '机建费', example = '50')
    private BigDecimal airFee;

    public String getPassengerPhone() {
        return passengerPhone;
    }

    public void setPassengerPhone(String passengerPhone) {
        this.passengerPhone = passengerPhone;
    }

    /**
     * @return 票号
     */
    public String getTicketNo() {
        return ticketNo;
    }

    /**
     * @param ticketNo 票号.
     */
    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    /**
     * @return 乘客类型
     */
    public Integer getPassengerType() {
        return passengerType;
    }

    /**
     * @param passengerType 乘客类型.
     */
    public void setPassengerType(Integer passengerType) {
        this.passengerType = passengerType;
    }

//    /**
//     * @return 乘客类型名称
//     */
//    public String getPassengerTypeName() {
//        return passengerTypeName;
//    }
//
//    /**
//     * @param passengerTypeName 乘客类型名称.
//     */
//    public void setPassengerTypeName(String passengerTypeName) {
//        this.passengerTypeName = passengerTypeName;
//    }

    /**
     * @return 证件类型
     */
    public Integer getCardType() {
        return cardType;
    }

    /**
     * @param cardType 证件类型.
     */
    public void setCardType(Integer cardType) {
        this.cardType = cardType;
    }

//    /**
//     * @return 证件类型名称
//     */
//    public String getCardTypeName() {
//        return cardTypeName;
//    }
//
//    /**
//     * @param cardTypeName 证件类型名称.
//     */
//    public void setCardTypeName(String cardTypeName) {
//        this.cardTypeName = cardTypeName;
//    }

    /**
     * @return 证件号
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * @param cardNo 证件号.
     */
    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    /**
     * @return ticketPrice
     */
    public BigDecimal getTicketPrice() {
        return ticketPrice;
    }

    /**
     * @param ticketPrice the ticketPrice to set
     */
    public void setTicketPrice(BigDecimal ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public BigDecimal getOilTax() {
        return oilTax;
    }

    public void setOilTax(BigDecimal oilTax) {
        this.oilTax = oilTax;
    }

    public BigDecimal getAirFee() {
        return airFee;
    }

    public void setAirFee(BigDecimal airFee) {
        this.airFee = airFee;
    }

    String getBirthday() {
        return birthday
    }

    void setBirthday(String birthday) {
        this.birthday = birthday
    }
}
