package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/22
 * Time: 11:58
 */
public class QueryOrderInfo {

    /**
     * 机票订单号
     */
    @ApiModelProperty(value = '机票订单号', example = '180321213644407136')
    private String orderId;

    /**
     * PNR
     */
    @ApiModelProperty(value = 'PNR', example = 'JHF3MH')
    private String pnr;

    /**
     * 大编码
     */
    @ApiModelProperty(value = '大编码', example = 'PKFH6J')
    private String bigPNR;

    /**
     * 订单状态（0 待支付
     * 1 待出票
     * 2 已出票
     * 3 订单取消
     * 4 订单取消，待退款
     * 5 订单取消，已退款
     * 6 补录已出票
     * 7 违规待审核
     * 8 违规审核通过
     * 9 违规审核未通过
     * 10 全部改签
     * 11 部分改签
     * 12 全部退票
     * 13 部分退票
     * 14 部分改签，部分退票）
     */
    @ApiModelProperty(value = '订单状态（0 待支付,1 待出票,2 已出票,3 订单取消,4 订单取消，待退款,5 订单取消，已退款,6 补录已出票,7 违规待审核,8 违规审核通过,9 违规审核未通过,10 全部改签,11 部分改签,12 全部退票,13 部分退票,14 部分改签，部分退票）', example = '0')
    private Integer orderDisplayId;

//    /**
//     * 订单状态名称
//     */
//    @ApiModelProperty(value = '订单状态名称', example = '待支付')
//    private String orderDisplayName;

    /**
     * 订单总金额
     */
    @ApiModelProperty(value = '订单总金额', example = '1050')
    private BigDecimal allTotalMoney;

    /**
     * 创单时间
     */
    @ApiModelProperty(value = '创单时间（格式为yyyy-MM-dd HH:mm:ss）', example = '2018-05-22 18:00:00')
    private String createOrderTime;

    /**
     * 支付时间
     */
    @ApiModelProperty(value = '支付时间（格式为yyyy-MM-dd HH:mm:ss）', example = '2018-05-22 18:01:00')
    private String payTime;

    /**
     * 出票时间
     */
    @ApiModelProperty(value = '出票时间（格式为yyyy-MM-dd HH:mm:ss）', example = '2018-05-22 18:02:00')
    private String outTicketTime;

    /**
     * 联系人姓名.
     */
    @ApiModelProperty(value = '联系人姓名', example = '碧落')
    private String linkName;

    /**
     * 联系人电话.
     */
    @ApiModelProperty(value = '联系人电话', example = '18382212521')
    private String linkPhone;

    /**
     * 支付方式 （0：517钱包 1：支付宝 2：财付通 3：微信 4：银行卡（易联））
     */
    @ApiModelProperty(value = '支付方式（0：517钱包 1：支付宝 2：财付通 3：微信 4：银行卡（易联））', example = '0')
    private Integer payType;

    /**
     * 预订人姓名.
     */
    @ApiModelProperty(value = '预订人姓名', example = '碧落')
    private String bookUserName;

    /**
     * 预订人电话.
     */
    @ApiModelProperty(value = '预订人电话', example = '18382212521')
    private String bookUserPhone;

    /**
     * 外部订单号
     */
    @ApiModelProperty(value = '外部订单号', example = '18382212564564520')
    private String outOrderId;

    /**
     * 行程类型(0:单程 1:往返 2：联程).
     */
    @ApiModelProperty(value = '行程类型（0:单程 1:往返 2：联程）', example = '0')
    private Integer voyageType;

    /**
     * 是否打印行程单.
     */
    @ApiModelProperty(value = '是否打印行程单', example = 'false')
    private Boolean needItinerary;

    /**
     * 邮寄信息.
     */
    @ApiModelProperty(value = '邮寄信息', example = '')
    private DeliveryInfo deliveryInfo;

    /**
     * 设置outOrderID.
     *
     * @return 返回outOrderID
     */
    public String getOutOrderId() {
        return outOrderId;
    }

    /**
     * 获取outOrderId.
     *
     * @param outOrderId 要设置的outOrderId
     */
    public void setOutOrderId(String outOrderId) {
        this.outOrderId = outOrderId;
    }

    /**
     * @return 机票订单号
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId 机票订单号.
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr;
    }

    /**
     * @return 大编码
     */
    public String getBigPNR() {
        return bigPNR;
    }

    /**
     * @param bigPNR 大编码.
     */
    public void setBigPNR(String bigPNR) {
        this.bigPNR = bigPNR;
    }

    /**
     * @return 订单状态
     */
    public Integer getOrderDisplayId() {
        return orderDisplayId;
    }

    /**
     * @param orderDisplayId 订单状态.
     */
    public void setOrderDisplayId(Integer orderDisplayId) {
        this.orderDisplayId = orderDisplayId;
    }

//    /**
//     * @return 订单状态名称
//     */
//    public String getOrderDisplayName() {
//        return orderDisplayName;
//    }
//
//    /**
//     * @param orderDisplayName 订单状态名称.
//     */
//    public void setOrderDisplayName(String orderDisplayName) {
//        this.orderDisplayName = orderDisplayName;
//    }

    public BigDecimal getAllTotalMoney() {
        return allTotalMoney;
    }

    public void setAllTotalMoney(BigDecimal allTotalMoney) {
        this.allTotalMoney = allTotalMoney;
    }

    /**
     * @return 支付时间
     */
    public String getPayTime() {
        return payTime;
    }

    /**
     * @param payTime 支付时间.
     */
    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    /**
     * @return 创单时间
     */
    public String getCreateOrderTime() {
        return createOrderTime;
    }

    /**
     * @param createOrderTime 创单时间.
     */
    public void setCreateOrderTime(String createOrderTime) {
        this.createOrderTime = createOrderTime;
    }

    /**
     * @return 出票时间
     */
    public String getOutTicketTime() {
        return outTicketTime;
    }

    /**
     * @param outTicketTime 出票时间.
     */
    public void setOutTicketTime(String outTicketTime) {
        this.outTicketTime = outTicketTime;
    }

    /**
     * @return 联系人姓名
     */
    public String getLinkName() {
        return linkName;
    }

    /**
     * @param linkName 联系人姓名.
     */
    public void setLinkName(String linkName) {
        this.linkName = linkName;
    }

    /**
     * @return 联系人手机号码
     */
    public String getLinkPhone() {
        return linkPhone;
    }

    /**
     * @param linkPhone 联系人手机号码.
     */
    public void setLinkPhone(String linkPhone) {
        this.linkPhone = linkPhone;
    }

    /**
     * @return payType
     */
    public Integer getPayType() {
        return payType;
    }

    /**
     * @param payType the payType to set
     */
    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public String getBookUserName() {
        return bookUserName;
    }

    public void setBookUserName(String bookUserName) {
        this.bookUserName = bookUserName;
    }

    public String getBookUserPhone() {
        return bookUserPhone;
    }

    public void setBookUserPhone(String bookUserPhone) {
        this.bookUserPhone = bookUserPhone;
    }

    public Integer getVoyageType() {
        return voyageType;
    }

    public void setVoyageType(Integer voyageType) {
        this.voyageType = voyageType;
    }

    public Boolean getNeedItinerary() {
        return needItinerary;
    }

    public void setNeedItinerary(Boolean needItinerary) {
        this.needItinerary = needItinerary;
    }

    public DeliveryInfo getDeliveryInfo() {
        return deliveryInfo;
    }

    public void setDeliveryInfo(DeliveryInfo deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
    }
}
