package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 17:06
 */
public class ResponseVo<T> {
    /**
     * 错误码.
     */
    @ApiModelProperty(value = '错误码', example = '0')
    private String code;

    /**
     * 错误码描述.
     */
    @ApiModelProperty(value = '错误码描述', example = '成功')
    private String msg;

    /**
     * 返回数据.
     */
    @ApiModelProperty(value = '业务参数')
    private T data;

    /**
     * 请求唯一标识.
     */
    @ApiModelProperty(value = '唯一标识', example = '534536456')
    private String requestId;

    /**
     * 响应时间.
     */
    @ApiModelProperty(value = '响应时间（格式为yyyy-MM-dd HH:mm:ss，时区为GMT+8）', example = '2018-06-01 12:00:01')
    private String time;

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    /**
     * @return the data
     */
    public T getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(T data) {
        this.data = data;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }
}
