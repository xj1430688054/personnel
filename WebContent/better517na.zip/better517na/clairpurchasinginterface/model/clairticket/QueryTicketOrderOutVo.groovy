package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;


/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/22
 * Time: 11:55
 */
public class QueryTicketOrderOutVo {
    /**
     * @return 订单信息实体
     */
    @ApiModelProperty(value = '订单信息实体', example = '')
    private QueryOrderInfo orderInfo;

    /**
     * @return 机票信息实体集合
     */
    @ApiModelProperty(value = '机票信息实体集合', example = '')
    private List<QueryTicketInfo> ticketInfoList;

    /**
     * @return 行程信息实体集合
     */
    @ApiModelProperty(value = '行程信息实体集合', example = '')
    private List<QueryVoyageInfo> voyageInfoList;

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public QueryOrderInfo getOrderInfo() {
        return orderInfo;
    }

    /**
     * 获取orderInfo.
     *
     * @param orderInfo
     *            要设置的orderInfo
     */
    public void setOrderInfo(QueryOrderInfo orderInfo) {
        this.orderInfo = orderInfo;
    }

    /**
     * 设置ticketInfoList.
     *
     * @return 返回ticketInfoList
     */
    public List<config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.QueryTicketInfo> getTicketInfoList() {
        return ticketInfoList;
    }

    /**
     * 获取ticketInfoList.
     *
     * @param ticketInfoList
     *            要设置的ticketInfoList
     */
    public void setTicketInfoList(List<config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket.QueryTicketInfo> ticketInfoList) {
        this.ticketInfoList = ticketInfoList;
    }

    /**
     * 设置voyageInfoList.
     *
     * @return 返回voyageInfoList
     */
    public List<QueryVoyageInfo> getVoyageInfoList() {
        return voyageInfoList;
    }

    /**
     * 获取voyageInfoList.
     *
     * @param voyageInfoList
     *            要设置的voyageInfoList
     */
    public void setVoyageInfoList(List<QueryVoyageInfo> voyageInfoList) {
        this.voyageInfoList = voyageInfoList;
    }
}
