package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/20
 * Time: 21:35
 */
public class DeliveryInfo {
    /**
     * 配送方式（1：普通快递
     * 2：上门自取
     * 3：顺丰快递
     * 4：邮政EMS
     * 5：普通到付）.
     */
    @ApiModelProperty(value = '配送方式（1：普通快递 2：上门自取 3：顺丰快递 4：邮政EMS 5：普通到付）', example = '0')
    private Integer deliveryType;

    /**
     * 收件人姓名.
     */
    @ApiModelProperty(value = '收件人姓名', example = '碧落')
    private String recipientName;

    /**
     * 收件人手机号.
     */
    @ApiModelProperty(value = '收件人手机号', example = '18382212521')
    private String recipientPhone;

    /**
     * 邮编地址.
     */
    @ApiModelProperty(value = '邮编地址', example = '四川省成都市金牛区一环路北一段环球广场')
    private String postAddress;

    /**
     * 邮编.
     */
    @ApiModelProperty(value = '邮编', example = '610000')
    private String postCode;

    /**
     * 邮寄费.
     */
    @ApiModelProperty(value = '邮寄费', example = '20')
    private BigDecimal deliveryFee;

    public Integer getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(Integer deliveryType) {
        this.deliveryType = deliveryType;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    public String getRecipientPhone() {
        return recipientPhone;
    }

    public void setRecipientPhone(String recipientPhone) {
        this.recipientPhone = recipientPhone;
    }

    public String getPostAddress() {
        return postAddress;
    }

    public void setPostAddress(String postAddress) {
        this.postAddress = postAddress;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public BigDecimal getDeliveryFee() {
        return deliveryFee;
    }

    public void setDeliveryFee(BigDecimal deliveryFee) {
        this.deliveryFee = deliveryFee;
    }
}
