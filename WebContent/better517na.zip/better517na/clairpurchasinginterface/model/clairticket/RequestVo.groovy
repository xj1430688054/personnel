package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 16:29
 */
public class RequestVo<T> {
    /**
     * 具体业务参数.
     */
    @ApiModelProperty(value = '业务参数')
    private T data;

    /**
     * 接口Pid.
     */
    @ApiModelProperty(value = '接口PID', example = '201707251944002011631218')
    private String pid;

    /**
     * 时间戳. 格式为yyyy-MM-dd HH:mm:ss，时区为GMT+8，例如：2018-01-01 12:00:00
     */
    @ApiModelProperty(value = '时间戳（格式为yyyy-MM-dd HH:mm:ss，时区为GMT+8）', example = '2018-06-01 12:00:00')
    private String timestamp;

    /**
     * 签名.
     */
    @ApiModelProperty(value = '签名', example = 'D1ABF0B6719EBA9ACEE3E1C7049866EA')
    private String sign;

    /**
     * 唯一标识一次请求. [由客户端控制传入,关联每次请求]
     */
    @ApiModelProperty(value = '唯一标识', example = '1526980908814')
    private String requestId;

//    /**
//     * 设备号：由后台生成全局唯一编号保存客户端.
//     */
//    @ApiModelProperty(value = '设备号', example = '96E79218965EB72C92A549DD5A330112')
//    private String mcode;

    /**
     * 程序版本号.
     */
    @ApiModelProperty(value = '版本号', example = '1.0')
    private String version;

    /**
     * @return the pid
     */
    public String getPid() {
        return pid;
    }

    /**
     * @param pid
     *            the pid to set
     */
    public void setPid(String pid) {
        this.pid = pid;
    }

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @param version
     *            the version to set
     */
    public void setVersion(String version) {
        this.version = version;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * @return the timestamp
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * @return the data
     */
    public T getData() {
        return data;
    }

    /**
     * @param data
     *            the data to set
     */
    public void setData(T data) {
        this.data = data;
    }

//    /**
//     * @return the mcode
//     */
//    public String getMcode() {
//        return mcode;
//    }
//
//    /**
//     * @param mcode
//     *            the mcode to set
//     */
//    public void setMcode(String mcode) {
//        this.mcode = mcode;
//    }

    /**
     * @return the sign
     */
    public String getSign() {
        return sign;
    }

    /**
     * @param sign
     *            the sign to set
     */
    public void setSign(String sign) {
        this.sign = sign;
    }
}
