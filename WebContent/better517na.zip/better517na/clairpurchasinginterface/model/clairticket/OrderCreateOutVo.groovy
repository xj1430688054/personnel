package config.groovyFiles.com.better517na.clairpurchasinginterface.model.clairticket;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/5/21
 * Time: 17:09
 */
public class OrderCreateOutVo {
    /**
     * 订单号.
     */
    @ApiModelProperty(value = '差旅机票订单号', example = '180321213644407136')
    private String orderId;

    /**
     * 小编码.
     */
    @ApiModelProperty(value = '小编码', example = 'JSG74F', position = 1)
    private String pnr;

    /**
     * 大编码.
     */
    @ApiModelProperty(value = '大编码', example = 'PD2L1F', position = 2)
    private String bigPnr;

    /**
     * 订单总金额.
     */
    @ApiModelProperty(value = '订单总金额', example = '1050', position = 3)
    private BigDecimal totalMoney;

    /**
     * 销售价.
     */
    @ApiModelProperty(value = '销售价', example = '1000', position = 4)
    private BigDecimal salePrice;

    /**
     * 票面价.
     */
    @ApiModelProperty(value = '票面价', example = '1000', position = 5)
    private BigDecimal ticketPrice;

    /**
     * 基建.
     */
    @ApiModelProperty(value = '基建费', example = '50', position = 6)
    private BigDecimal airFee;

    /**
     * 燃油.
     */
    @ApiModelProperty(value = '燃油税', example = '0', position = 7)
    private BigDecimal oilTax;

    /**
     * 邮寄费.
     */
    @ApiModelProperty(value = '邮寄费', example = '10', position = 8)
    private BigDecimal deliveryFee;

    /**
     * 工本费.
     */
    @ApiModelProperty(value = '工本费', example = '1', position = 9)
    private BigDecimal printCosts;

    /**
     * 服务费.
     */
    @ApiModelProperty(value = '服务费', example = '5', position = 10)
    private BigDecimal serviceFee;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr;
    }

    public String getBigPnr() {
        return bigPnr;
    }

    public void setBigPnr(String bigPnr) {
        this.bigPnr = bigPnr;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    BigDecimal getTicketPrice() {
        return ticketPrice
    }

    void setTicketPrice(BigDecimal ticketPrice) {
        this.ticketPrice = ticketPrice
    }

    public BigDecimal getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(BigDecimal totalMoney) {
        this.totalMoney = totalMoney;
    }

    public BigDecimal getAirFee() {
        return airFee;
    }

    public void setAirFee(BigDecimal airFee) {
        this.airFee = airFee;
    }

    public BigDecimal getOilTax() {
        return oilTax;
    }

    public void setOilTax(BigDecimal oilTax) {
        this.oilTax = oilTax;
    }

    BigDecimal getDeliveryFee() {
        return deliveryFee
    }

    void setDeliveryFee(BigDecimal deliveryFee) {
        this.deliveryFee = deliveryFee
    }

    BigDecimal getPrintCosts() {
        return printCosts
    }

    void setPrintCosts(BigDecimal printCosts) {
        this.printCosts = printCosts
    }

    BigDecimal getServiceFee() {
        return serviceFee
    }

    void setServiceFee(BigDecimal serviceFee) {
        this.serviceFee = serviceFee
    }
}
