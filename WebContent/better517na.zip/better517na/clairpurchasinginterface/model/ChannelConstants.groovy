/*
 * 文件名：ChannelContants.java
 * 版权：Copyright 2007-2015 517na Tech. Co. Ltd. All Rights Reserved.
 * 描述： ChannelContants.java
 * 修改人：guokan
 * 修改时间：2015年5月12日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model;

/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * <p>
 * <pre>
 * </pre>
 *
 * @author gaoshun
 */
public enum ChannelConstants {
    // 0,配置;1,517;2,配置占座+517出票;3,差旅壹号;4,畅E;5,MUB2G;6,qunar去哪儿;7,携程;8,川航B2G;9,航司呼叫中心;10,springAir春秋航空;11,MUB2C;12,3UB2G;13,CZB2G;14,ZHB2C;19,MUB2G3

    /**
     * BSP.
     */
    BSP('0', 'bsp'),

    /**
     * 517NA.
     */
    NA517('1', 'na517'),

    /**
     * 差旅壹号.
     */
    CLAirTicket('3', 'clAirTicket'),

    /**
     * 畅E.
     */
    CHANGE('4', 'changE'),

    /**
     * 东航B2G.
     */
    MUB2G('5', 'mub2g'),

    /**
     * 去哪儿.
     */
    QUNAR('6', 'qunar'),

    /**
     * 春秋航空.
     */
    SPRINGAIR('10', 'springAir'),

    /**
     * 东航B2C.
     */
    MUB2C('11', 'mub2c'),

    /**
     *3UB2G
     */
    THREEUB2G('12','3UVIP'),

    /**
     *CZB2G
     */
    CZB2G('13','czb2g'),

    /**
     *ZHB2C
     */
    ZHB2C('14','zhb2c'),

    /**
     *厦航B2C
     */
    MFB2C('15','mfb2c'),

    /**
     * 江西航空
     */
    RYB2C('16','ryb2c'),

    /**
     *九元航空
     */
    AQARIR('17','aqAir'),

    /**
     * 深航B2G
     */
    ZHB2G('1050','zhb2g'),

    /**
     *东航B2G版本3
     */
    MUB2G3('1040','mub2g3');



    /**
     * 渠道值.
     */
    private String value;

    /**
     * 渠道名.
     */
    private String name;

    /**
     * 构造函数.
     *
     * @param value 值
     */
    private ChannelConstants(String value, String name) {
        this.value = value;
        this.name = name;
    }

    /**
     * {@inheritDoc}.
     */
    public String toString() {
        return value;
    }

    /**
     * 设置value.
     *
     * @return 返回value
     */
    public String getValue() {
        return value;
    }

    /**
     * 获取value.
     *
     * @param value 要设置的value
     */
    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * 通过值匹配.
     *
     * @param value value
     * @return tagEnum
     */
    public static ChannelConstants matchByValue(String value) {
        for (ChannelConstants channel : ChannelConstants.values()) {
            if (value.equals(channel.getValue())) {
                return channel;
            }
        }

        throw new IllegalArgumentException('渠道未实现');
    }
}
