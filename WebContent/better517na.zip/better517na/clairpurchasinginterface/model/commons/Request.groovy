/*
 * 文件名：RequestVo.java
 * 版权：Copyright 2007-2016 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： RequestVo.java
 * 修改人：bole
 * 修改时间：2016年3月29日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.commons;

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo;

/**
 *
 * @author bole
 *
 * @param < T >
 */
public class Request<T> {

    private SupplySystemInfo supplySystemInfo;

    /**
     * 请求业务内容.
     */
    private T body;

    /**
     * 资源ID.
     */
    private String resourceId;

    /**
     * TMC编号.
     */
    private String tmcNum;

    /**
     * 方法名.
     */
    private String func;

    /**
     * 方法分组.
     */
    private String funcGroup;

    /**
     * 版本号.
     */
    private Integer versionCode;

    /**
     * 客户端类型.
     */
    private Integer clientType;

    /**
     * 业务类型 0 国内机票 1 国际票 2 火车票 3 保险.
     */
    private Integer businessType;

    /**
     * 设置businessType.
     *
     * @return 返回businessType
     */
    public Integer getBusinessType() {
        return businessType;
    }

    /**
     * 获取businessType.
     *
     * @param businessType
     *            要设置的businessType.
     */
    public void setBusinessType(Integer businessType) {
        this.businessType = businessType;
    }

    /**
     * @return the versionCode
     */
    public Integer getVersionCode() {
        return versionCode;
    }

    /**
     * @param versionCode
     *            the versionCode to set.
     */
    public void setVersionCode(Integer versionCode) {
        this.versionCode = versionCode;
    }

    /**
     * @return the clientType
     */
    public Integer getClientType() {
        return clientType;
    }

    /**
     * @param clientType
     *            the clientType to set.
     */
    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    /**
     * 设置body.
     *
     * @return 返回body
     */
    public T getBody() {
        return body;
    }

    /**
     * 获取body.
     *
     * @param body
     *            要设置的body.
     */
    public void setBody(T body) {
        this.body = body;
    }

    /**
     * 设置func.
     *
     * @return 返回func
     */
    public String getFunc() {
        return func;
    }

    /**
     * 获取func.
     *
     * @param func
     *            要设置的func.
     */
    public void setFunc(String func) {
        this.func = func;
    }

    /**
     * 设置funcGroup.
     *
     * @return 返回funcGroup
     */
    public String getFuncGroup() {
        return funcGroup;
    }

    /**
     * 获取funcGroup.
     *
     * @param funcGroup
     *            要设置的funcGroup.
     */
    public void setFuncGroup(String funcGroup) {
        this.funcGroup = funcGroup;
    }

    public SupplySystemInfo getSupplySystemInfo() {
        return supplySystemInfo;
    }

    public void setSupplySystemInfo(SupplySystemInfo supplySystemInfo) {
        this.supplySystemInfo = supplySystemInfo;
    }

    /**

     *
     * TODO 获取resourceId.
     *
     * @return .
     */
    public String getResourceId() {
        return resourceId;
    }

    /**
     *
     * TODO 设置resourceId.
     *
     * @param resourceId
     *            要设置的resourceId.
     */
    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    /**
     *
     * TODO 获取TMC编号.
     *
     * @return .
     */
    public String getTmcNum() {
        return tmcNum;
    }

    /**
     *
     * TODO 设置TMCNUm.
     *
     * @param tmcNum
     *            需要设置的TMCNum.
     */
    public void setTmcNum(String tmcNum) {
        this.tmcNum = tmcNum;
    }
}
