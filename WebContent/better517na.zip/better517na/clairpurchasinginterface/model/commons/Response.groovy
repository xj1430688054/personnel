/**
 *
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.model.commons;

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.AgentInfo;

/**
 * 公共回参.
 * @author guolinbo
 * @param < T >
 */
public class Response<T> {

    /**
     * 代理人信息.
     */
    private AgentInfo agentInfo;

    /**
     * 是否成功.
     */
    private Boolean issuccess;

    /**
     * 错误信息.
     */
    private String message;

    /**
     * 业务数据.
     */
    private T data;

    /**
     * @return the issuccess
     */
    public Boolean getIssuccess() {
        return issuccess;
    }

    /**
     * @param issuccess the issuccess to set
     */
    public void setIssuccess(Boolean issuccess) {
        this.issuccess = issuccess;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the data
     */
    public T getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(T data) {
        this.data = data;
    }


}
