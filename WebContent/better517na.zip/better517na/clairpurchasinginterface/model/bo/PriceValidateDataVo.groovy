package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

public class PriceValidateDataVo {
    /**
     * @机票销售价
     */
    private BigDecimal salesPrice;

    /**
     * @燃油费
     */
    private BigDecimal oilrax;

    /**
     * @机建费
     */
    private BigDecimal airrax;
    /**
     * @总金额
     */
    private BigDecimal totalMoney;

    /**
     * @票面价
     */
    private BigDecimal ticketPrice;

    /**
     * 出发城市.
     */
    private String dptCity;

    /**
     * 达到城市.
     */
    private String arrCity;

    /**
     * 起飞时间.
     */
    private Date deptTime;

    /**
     * 航班号.
     */
    private String flightNum;

    /**
     * 舱位
     */
    private String cabin;

    BigDecimal getSalesPrice() {
        return salesPrice
    }

    void setSalesPrice(BigDecimal salesPrice) {
        this.salesPrice = salesPrice
    }

    BigDecimal getOilrax() {
        return oilrax
    }

    void setOilrax(BigDecimal oilrax) {
        this.oilrax = oilrax
    }

    BigDecimal getAirrax() {
        return airrax
    }

    void setAirrax(BigDecimal airrax) {
        this.airrax = airrax
    }

    BigDecimal getTotalMoney() {
        return totalMoney
    }

    void setTotalMoney(BigDecimal totalMoney) {
        this.totalMoney = totalMoney
    }

    BigDecimal getTicketPrice() {
        return ticketPrice
    }

    void setTicketPrice(BigDecimal ticketPrice) {
        this.ticketPrice = ticketPrice
    }

    String getDptCity() {
        return dptCity
    }

    void setDptCity(String dptCity) {
        this.dptCity = dptCity
    }

    String getArrCity() {
        return arrCity
    }

    void setArrCity(String arrCity) {
        this.arrCity = arrCity
    }

    Date getDeptTime() {
        return deptTime
    }

    void setDeptTime(Date deptTime) {
        this.deptTime = deptTime
    }

    String getFlightNum() {
        return flightNum
    }

    void setFlightNum(String flightNum) {
        this.flightNum = flightNum
    }

    String getCabin() {
        return this.cabin;
    }

    void setCabin(String cabin) {
        this.cabin = cabin;
    }
}