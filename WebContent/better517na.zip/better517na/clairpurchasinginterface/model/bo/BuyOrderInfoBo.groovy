package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.businessBaseDBAccessLayer.ISubTable
import com.better517na.clairpurchasinginterface.utils.DateUtil

import javax.persistence.Entity
import javax.persistence.Table
import java.text.ParseException

@Entity
@Table(name = 'BuyOrderInfo')
public class BuyOrderInfoBo implements ISubTable {
    /**
     * @主键ID
     */
    private String keyID;

    /**
     * @订单号
     */
    private String orderId;

    /**
     * @卖出订单号
     */
    private String sellOrderId;

    /**
     * @TMC编号
     */
    private String tMCNo;

    /**
     * @TMC名称
     */
    private String tMCName;

    /**
     * @企业编号
     */
    private String corpNo;

    /**
     * @企业名称
     */
    private String corpName;

    /**
     * @服务商ID
     */
    private String serviceProviderID;

    /**
     * @服务商名称
     */
    private String serviceProviderName;

    /**
     * @供应商ID
     */
    private String supplyId;

    /**
     * @供应商名称
     */
    private String supplyName;

    /**
     * @订单类型
     */
    private Integer orderType;

    /**
     * @订单类型名称
     */
    private String orderTypeName;

    /**
     * @机票类型
     */
    private Integer ticketType;

    /**
     * @行程类型
     */
    private Integer voyageType;

    /**
     * @行程类型名称
     */
    private String voyageTypeName;

    /**
     * @行程
     */
    private String voyageLeg;

    /**
     * @行程EN
     */
    private String voyageLegEn;

    /**
     * @航班号
     */
    private String flightNos;

    /**
     * @乘机人数
     */
    private Integer passengerCount;

    /**
     * @乘机人
     */
    private String passengers;

    /**
     * @乘客类型
     */
    private Integer passengerType;

    /**
     * @起飞时间
     */
    private Date takeOffTime;

    /**
     * @PNR
     */
    private String pNR;

    /**
     * @大编码
     */
    private String bigPNR;

    /**
     * @新PNR
     */
    private String newPnr;

    /**
     * @新大编码
     */
    private String newBigPnr;

    /**
     * @预订来源
     */
    private Integer bookingSource;

    /**
     * @预订来源名称
     */
    private String bookingSourceName;

    /**
     * @订单状态
     */
    private Integer orderDisplayID;

    /**
     * @订单状态名称
     */
    private String orderDisplayName;

    /**
     * @订单子状态
     */
    private Integer orderChildDisplayID;

    /**
     * @订单子状态名称
     */
    private String orderChildDisplayName;

    /**
     * @订单标识
     */
    private Integer orderFlag;
    /**
     * @渠道ID
     */
    private String chanelId;

    /**
     * @出票渠道订单号
     */
    private String chanelOrderId;

    /**
     * @失败原因
     */
    private String failReason;

    /**
     * @机票总金额
     */
    private BigDecimal ticketTotalMoney;

    /**
     * @基建总金额
     */
    private BigDecimal airraxTotalMoney;

    /**
     * @燃油总金额
     */
    private BigDecimal oilraxTotalMoney;

    /**
     * @保险总金额
     */
    private BigDecimal insuranceTotalMoney;

    /**
     * @行程单总金额
     */
    private BigDecimal itineraryTotalMoney;

    /**
     * @税费总金额
     */
    private BigDecimal taxTotalMoney;

    /**
     * @支付手续费
     */
    private BigDecimal payPoundage;

    /**
     * @实际支付金额
     */
    private BigDecimal allPayMoney;

    /**
     * @订单支付方式
     */
    private Integer payType;

    /**
     * @创单时间
     */
    private Date createOrderTime;

    /**
     * @支付时间
     */
    private Date payTime;

    /**
     * @出票时间
     */
    private Date outTicketTime;

    /**
     * @取消出票时间
     */
    private Date cancelTicketTime;

    /**
     * @联系人姓名
     */
    private String linkMan;

    /**
     * @联系人手机号码
     */
    private String linkPhone;

    /**
     * @联系人邮箱地址
     */
    private String linkEmail;

    /**
     * @操作人企业编号
     */
    private String operatorCorpNo;

    /**
     * @操作人企业名称
     */
    private String operatorCorpName;

    /**
     * @操作人部门编号
     */
    private String operatorDeptNo;

    /**
     * @操作人部门名称
     */
    private String operatorDeptName;

    /**
     * @操作人用户编号
     */
    private String operatorUserNo;

    /**
     * @操作人用户姓名
     */
    private String operatorUserName;

    /**
     * @重要等级标识
     */
    private Integer importantLevel;

    /**
     * @备注
     */
    private String remark;

    /**
     * @锁定状态
     */
    private Integer lockStatus;

    /**
     * @锁定账号
     */
    private String lockStaffId;

    /**
     * @锁定人
     */
    private String lockStaffName;

    /**
     * @锁定时间
     */
    private Date lockTime;

    /**
     * @添加时间
     */
    private Date addTime;

    /**
     * @删除标识
     */
    private Integer isDelete;

    /**
     * @ 构造函数
     */
    public BuyOrderInfoBo() {
    }

    /**
     * @return 主键ID
     */
    public String getKeyID() {
        return keyID;
    }

    /**
     * @param keyID 主键ID.
     */
    public void setKeyID(String keyID) {
        this.keyID = keyID;
    }

    /**
     * @return 订单号
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId 订单号.
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return 卖出订单号
     */
    public String getSellOrderId() {
        return sellOrderId;
    }

    /**
     * @param sellOrderId 卖出订单号.
     */
    public void setSellOrderId(String sellOrderId) {
        this.sellOrderId = sellOrderId;
    }

    /**
     * @return TMC编号
     */
    public String getTMCNo() {
        return tMCNo;
    }

    /**
     * @param tMCNo TMC编号.
     */
    public void setTMCNo(String tMCNo) {
        this.tMCNo = tMCNo;
    }

    /**
     * @return TMC名称
     */
    public String getTMCName() {
        return tMCName;
    }

    /**
     * @param tMCName TMC名称.
     */
    public void setTMCName(String tMCName) {
        this.tMCName = tMCName;
    }

    /**
     * @return 企业编号
     */
    public String getCorpNo() {
        return corpNo;
    }

    /**
     * @param corpNo 企业编号.
     */
    public void setCorpNo(String corpNo) {
        this.corpNo = corpNo;
    }

    /**
     * @return 企业名称
     */
    public String getCorpName() {
        return corpName;
    }

    /**
     * @param corpName 企业名称.
     */
    public void setCorpName(String corpName) {
        this.corpName = corpName;
    }

    /**
     * @return 服务商ID
     */
    public String getServiceProviderID() {
        return serviceProviderID;
    }

    /**
     * @param serviceProviderID 服务商ID.
     */
    public void setServiceProviderID(String serviceProviderID) {
        this.serviceProviderID = serviceProviderID;
    }

    /**
     * @return 服务商名称
     */
    public String getServiceProviderName() {
        return serviceProviderName;
    }

    /**
     * @param serviceProviderName 服务商名称.
     */
    public void setServiceProviderName(String serviceProviderName) {
        this.serviceProviderName = serviceProviderName;
    }

    /**
     * @return 供应商ID
     */
    public String getSupplyId() {
        return supplyId;
    }

    /**
     * @param supplyId 供应商ID.
     */
    public void setSupplyId(String supplyId) {
        this.supplyId = supplyId;
    }

    /**
     * @return 供应商名称
     */
    public String getSupplyName() {
        return supplyName;
    }

    /**
     * @param supplyName 供应商名称.
     */
    public void setSupplyName(String supplyName) {
        this.supplyName = supplyName;
    }

    /**
     * @return 订单类型
     */
    public Integer getOrderType() {
        return orderType;
    }

    /**
     * @param orderType 订单类型.
     */
    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    /**
     * @return 订单类型名称
     */
    public String getOrderTypeName() {
        return orderTypeName;
    }

    /**
     * @param orderTypeName 订单类型名称.
     */
    public void setOrderTypeName(String orderTypeName) {
        this.orderTypeName = orderTypeName;
    }

    /**
     * @return 机票类型
     */
    public Integer getTicketType() {
        return ticketType;
    }

    /**
     * @param ticketType 机票类型.
     */
    public void setTicketType(Integer ticketType) {
        this.ticketType = ticketType;
    }

    /**
     * @return 行程类型
     */
    public Integer getVoyageType() {
        return voyageType;
    }

    /**
     * @param voyageType 行程类型.
     */
    public void setVoyageType(Integer voyageType) {
        this.voyageType = voyageType;
    }

    /**
     * @return 行程类型名称
     */
    public String getVoyageTypeName() {
        return voyageTypeName;
    }

    /**
     * @param voyageTypeName 行程类型名称.
     */
    public void setVoyageTypeName(String voyageTypeName) {
        this.voyageTypeName = voyageTypeName;
    }

    /**
     * @return 行程
     */
    public String getVoyageLeg() {
        return voyageLeg;
    }

    /**
     * @param voyageLeg 行程.
     */
    public void setVoyageLeg(String voyageLeg) {
        this.voyageLeg = voyageLeg;
    }

    /**
     * @return 行程EN
     */
    public String getVoyageLegEn() {
        return voyageLegEn;
    }

    /**
     * @param voyageLegEn 行程EN.
     */
    public void setVoyageLegEn(String voyageLegEn) {
        this.voyageLegEn = voyageLegEn;
    }

    /**
     * @return 航班号
     */
    public String getFlightNos() {
        return flightNos;
    }

    /**
     * @param flightNos 航班号.
     */
    public void setFlightNos(String flightNos) {
        this.flightNos = flightNos;
    }

    /**
     * @return 乘机人数
     */
    public Integer getPassengerCount() {
        return passengerCount;
    }

    /**
     * @param passengerCount 乘机人数.
     */
    public void setPassengerCount(Integer passengerCount) {
        this.passengerCount = passengerCount;
    }

    /**
     * @return 乘机人
     */
    public String getPassengers() {
        return passengers;
    }

    /**
     * @param passengers 乘机人.
     */
    public void setPassengers(String passengers) {
        this.passengers = passengers;
    }

    /**
     * @return 乘客类型
     */
    public Integer getPassengerType() {
        return passengerType;
    }

    /**
     * @param passengerType 乘客类型.
     */
    public void setPassengerType(Integer passengerType) {
        this.passengerType = passengerType;
    }

    /**
     * @return 起飞时间
     */
    public Date getTakeOffTime() {
        return takeOffTime;
    }

    /**
     * @param takeOffTime 起飞时间.
     */
    public void setTakeOffTime(Date takeOffTime) {
        this.takeOffTime = takeOffTime;
    }

    /**
     * @return PNR
     */
    public String getPNR() {
        return pNR;
    }

    /**
     * @param pNRt PNR.
     */
    public void setPNR(String pNRt) {
        this.pNR = pNRt;
    }

    /**
     * @return 大编码
     */
    public String getBigPNR() {
        return bigPNR;
    }

    /**
     * @param bigPNR 大编码.
     */
    public void setBigPNR(String bigPNR) {
        this.bigPNR = bigPNR;
    }

    /**
     * @return 新PNR
     */
    public String getNewPnr() {
        return newPnr;
    }

    /**
     * @param newPnr 新PNR.
     */
    public void setNewPnr(String newPnr) {
        this.newPnr = newPnr;
    }

    /**
     * @return 新大编码
     */
    public String getNewBigPnr() {
        return newBigPnr;
    }

    /**
     * @param newBigPnr 新大编码.
     */
    public void setNewBigPnr(String newBigPnr) {
        this.newBigPnr = newBigPnr;
    }

    /**
     * @return 预订来源
     */
    public Integer getBookingSource() {
        return bookingSource;
    }

    /**
     * @param bookingSource 预订来源.
     */
    public void setBookingSource(Integer bookingSource) {
        this.bookingSource = bookingSource;
    }

    /**
     * @return 预订来源名称
     */
    public String getBookingSourceName() {
        return bookingSourceName;
    }

    /**
     * @param bookingSourceName 预订来源名称.
     */
    public void setBookingSourceName(String bookingSourceName) {
        this.bookingSourceName = bookingSourceName;
    }

    /**
     * @return 订单状态
     */
    public Integer getOrderDisplayID() {
        return orderDisplayID;
    }

    /**
     * @param orderDisplayID 订单状态.
     */
    public void setOrderDisplayID(Integer orderDisplayID) {
        this.orderDisplayID = orderDisplayID;
    }

    /**
     * @return 订单状态名称
     */
    public String getOrderDisplayName() {
        return orderDisplayName;
    }

    /**
     * @param orderDisplayName 订单状态名称.
     */
    public void setOrderDisplayName(String orderDisplayName) {
        this.orderDisplayName = orderDisplayName;
    }

    /**
     * @return 订单子状态
     */
    public Integer getOrderChildDisplayID() {
        return orderChildDisplayID;
    }

    /**
     * @param orderChildDisplayID 订单子状态.
     */
    public void setOrderChildDisplayID(Integer orderChildDisplayID) {
        this.orderChildDisplayID = orderChildDisplayID;
    }

    /**
     * @return 订单子状态名称
     */
    public String getOrderChildDisplayName() {
        return orderChildDisplayName;
    }

    /**
     * @param orderChildDisplayName 订单子状态名称.
     */
    public void setOrderChildDisplayName(String orderChildDisplayName) {
        this.orderChildDisplayName = orderChildDisplayName;
    }

    /**
     * @return 订单标识
     */
    public Integer getOrderFlag() {
        return orderFlag;
    }

    /**
     * @param orderFlag 订单标识.
     */
    public void setOrderFlag(Integer orderFlag) {
        this.orderFlag = orderFlag;
    }

    /**
     * @return 渠道ID
     */
    public String getChanelId() {
        return chanelId;
    }

    /**
     * @param chanelId 渠道ID.
     */
    public void setChanelId(String chanelId) {
        this.chanelId = chanelId;
    }

    /**
     * @return 出票渠道订单号
     */
    public String getChanelOrderId() {
        return chanelOrderId;
    }

    /**
     * @param chanelOrderId 出票渠道订单号.
     */
    public void setChanelOrderId(String chanelOrderId) {
        this.chanelOrderId = chanelOrderId;
    }

    /**
     * @return 失败原因
     */
    public String getFailReason() {
        return failReason;
    }

    /**
     * @param failReason 失败原因.
     */
    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }

    /**
     * @return 机票总金额
     */
    public BigDecimal getTicketTotalMoney() {
        return ticketTotalMoney;
    }

    /**
     * @param ticketTotalMoney 机票总金额.
     */
    public void setTicketTotalMoney(BigDecimal ticketTotalMoney) {
        this.ticketTotalMoney = ticketTotalMoney;
    }

    /**
     * @return 基建总金额
     */
    public BigDecimal getAirraxTotalMoney() {
        return airraxTotalMoney;
    }

    /**
     * @param airraxTotalMoney 基建总金额.
     */
    public void setAirraxTotalMoney(BigDecimal airraxTotalMoney) {
        this.airraxTotalMoney = airraxTotalMoney;
    }

    /**
     * @return 燃油总金额
     */
    public BigDecimal getOilraxTotalMoney() {
        return oilraxTotalMoney;
    }

    /**
     * @param oilraxTotalMoney 燃油总金额.
     */
    public void setOilraxTotalMoney(BigDecimal oilraxTotalMoney) {
        this.oilraxTotalMoney = oilraxTotalMoney;
    }

    /**
     * @return 保险总金额
     */
    public BigDecimal getInsuranceTotalMoney() {
        return insuranceTotalMoney;
    }

    /**
     * @param insuranceTotalMoney 保险总金额.
     */
    public void setInsuranceTotalMoney(BigDecimal insuranceTotalMoney) {
        this.insuranceTotalMoney = insuranceTotalMoney;
    }

    /**
     * @return 行程单总金额
     */
    public BigDecimal getItineraryTotalMoney() {
        return itineraryTotalMoney;
    }

    /**
     * @param itineraryTotalMoney 行程单总金额.
     */
    public void setItineraryTotalMoney(BigDecimal itineraryTotalMoney) {
        this.itineraryTotalMoney = itineraryTotalMoney;
    }

    /**
     * @return 税费总金额
     */
    public BigDecimal getTaxTotalMoney() {
        return taxTotalMoney;
    }

    /**
     * @param taxTotalMoney 税费总金额.
     */
    public void setTaxTotalMoney(BigDecimal taxTotalMoney) {
        this.taxTotalMoney = taxTotalMoney;
    }

    /**
     * @return 支付手续费
     */
    public BigDecimal getPayPoundage() {
        return payPoundage;
    }

    /**
     * @param payPoundage 支付手续费.
     */
    public void setPayPoundage(BigDecimal payPoundage) {
        this.payPoundage = payPoundage;
    }

    /**
     * @return 实际支付金额
     */
    public BigDecimal getAllPayMoney() {
        return allPayMoney;
    }

    /**
     * @param allPayMoney 实际支付金额.
     */
    public void setAllPayMoney(BigDecimal allPayMoney) {
        this.allPayMoney = allPayMoney;
    }

    /**
     * @return 订单支付方式
     */
    public Integer getPayType() {
        return payType;
    }

    /**
     * @param payType 订单支付方式.
     */
    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    /**
     * @return 创单时间
     */
    public Date getCreateOrderTime() {
        return createOrderTime;
    }

    /**
     * @param createOrderTime 创单时间.
     */
    public void setCreateOrderTime(Date createOrderTime) {
        this.createOrderTime = createOrderTime;
    }

    /**
     * @return 支付时间
     */
    public Date getPayTime() {
        return payTime;
    }

    /**
     * @param payTime 支付时间.
     */
    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    /**
     * @return 出票时间
     */
    public Date getOutTicketTime() {
        return outTicketTime;
    }

    /**
     * @param outTicketTime 出票时间.
     */
    public void setOutTicketTime(Date outTicketTime) {
        this.outTicketTime = outTicketTime;
    }

    /**
     * @return 取消出票时间
     */
    public Date getCancelTicketTime() {
        return cancelTicketTime;
    }

    /**
     * @param cancelTicketTime 取消出票时间.
     */
    public void setCancelTicketTime(Date cancelTicketTime) {
        this.cancelTicketTime = cancelTicketTime;
    }

    /**
     * @return 联系人姓名
     */
    public String getLinkMan() {
        return linkMan;
    }

    /**
     * @param linkMan 联系人姓名.
     */
    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan;
    }

    /**
     * @return 联系人手机号码
     */
    public String getLinkPhone() {
        return linkPhone;
    }

    /**
     * @param linkPhone 联系人手机号码.
     */
    public void setLinkPhone(String linkPhone) {
        this.linkPhone = linkPhone;
    }

    /**
     * @return 联系人邮箱地址
     */
    public String getLinkEmail() {
        return linkEmail;
    }

    /**
     * @param linkEmail 联系人邮箱地址.
     */
    public void setLinkEmail(String linkEmail) {
        this.linkEmail = linkEmail;
    }

    /**
     * @return 操作人企业编号
     */
    public String getOperatorCorpNo() {
        return operatorCorpNo;
    }

    /**
     * @param operatorCorpNo 操作人企业编号.
     */
    public void setOperatorCorpNo(String operatorCorpNo) {
        this.operatorCorpNo = operatorCorpNo;
    }

    /**
     * @return 操作人企业名称
     */
    public String getOperatorCorpName() {
        return operatorCorpName;
    }

    /**
     * @param operatorCorpName 操作人企业名称.
     */
    public void setOperatorCorpName(String operatorCorpName) {
        this.operatorCorpName = operatorCorpName;
    }

    /**
     * @return 操作人部门编号
     */
    public String getOperatorDeptNo() {
        return operatorDeptNo;
    }

    /**
     * @param operatorDeptNo 操作人部门编号.
     */
    public void setOperatorDeptNo(String operatorDeptNo) {
        this.operatorDeptNo = operatorDeptNo;
    }

    /**
     * @return 操作人部门名称
     */
    public String getOperatorDeptName() {
        return operatorDeptName;
    }

    /**
     * @param operatorDeptName 操作人部门名称.
     */
    public void setOperatorDeptName(String operatorDeptName) {
        this.operatorDeptName = operatorDeptName;
    }

    /**
     * @return 操作人用户编号
     */
    public String getOperatorUserNo() {
        return operatorUserNo;
    }

    /**
     * @param operatorUserNo 操作人用户编号.
     */
    public void setOperatorUserNo(String operatorUserNo) {
        this.operatorUserNo = operatorUserNo;
    }

    /**
     * @return 操作人用户姓名
     */
    public String getOperatorUserName() {
        return operatorUserName;
    }

    /**
     * @param operatorUserName 操作人用户姓名.
     */
    public void setOperatorUserName(String operatorUserName) {
        this.operatorUserName = operatorUserName;
    }

    /**
     * @return 重要等级标识
     */
    public Integer getImportantLevel() {
        return importantLevel;
    }

    /**
     * @param importantLevel 重要等级标识.
     */
    public void setImportantLevel(Integer importantLevel) {
        this.importantLevel = importantLevel;
    }

    /**
     * @return 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark 备注.
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return 锁定状态
     */
    public Integer getLockStatus() {
        return lockStatus;
    }

    /**
     * @param lockStatus 锁定状态.
     */
    public void setLockStatus(Integer lockStatus) {
        this.lockStatus = lockStatus;
    }

    /**
     * @return 锁定账号
     */
    public String getLockStaffId() {
        return lockStaffId;
    }

    /**
     * @param lockStaffId 锁定账号.
     */
    public void setLockStaffId(String lockStaffId) {
        this.lockStaffId = lockStaffId;
    }

    /**
     * @return 锁定人
     */
    public String getLockStaffName() {
        return lockStaffName;
    }

    /**
     * @param lockStaffName 锁定人.
     */
    public void setLockStaffName(String lockStaffName) {
        this.lockStaffName = lockStaffName;
    }

    /**
     * @return 锁定时间
     */
    public Date getLockTime() {
        return lockTime;
    }

    /**
     * @param lockTime 锁定时间.
     */
    public void setLockTime(Date lockTime) {
        this.lockTime = lockTime;
    }

    /**
     * @return 添加时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * @param addTime 添加时间.
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * @return 删除标识
     */
    public Integer getIsDelete() {
        return isDelete;
    }

    /**
     * @param isDelete 删除标识.
     */
    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    @Override
    public Date getBizTime() {
        try {
            String sellOrderId = StringUtil.isNullOrEmpty(this.sellOrderId) ? this.keyID : this.sellOrderId;
            return DateUtil.keyIdToDate(sellOrderId);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String getHashKey() {
        return null;
    }

    @Override
    public String getSpecialKey() {
        return null;
    }
}
