package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

import javax.persistence.Entity

@Entity
public class BuyTicketInfoBo {
    /**
     * @票号
     */
    private String ticketNo;

    /**
     * @乘客姓名
     */
    private String userName;

    /**
     * @乘客英文名
     */
    private String userEnglishName;

    /**
     * @乘客序号
     */
    private Integer passengerIndex;

    /**
     * @乘客类型 0:成人 / 1:儿童 / 2:婴儿
     */
    private Integer passengerType;

    /**
     * @乘客类型名称 0:成人 / 1:儿童 / 2:婴儿
     */
    private String passengerTypeName;

    /**
     * @乘机人性别 0:男 / 1：女
     */
    private Integer passengerGender;

    /**
     * @乘客身份
     */
    private Integer identity;

    /**
     * @证件类型 0：身份证 / 1：护照 / 2：学生证 / 3：军人证 / 4：驾驶证 / 5：回乡证 / 6：台胞证 / 7：港澳通行证 / 8：台湾通行证 / 9：士兵证 / 10：临时身份证 / 11：户口簿 / 12：警官证 / 13：出生证明 / 99：其它
     */
    private Integer cardType;

    /**
     * @证件类型名称 0：身份证 / 1：护照 / 2：学生证 / 3：军人证 / 4：驾驶证 / 5：回乡证 / 6：台胞证 / 7：港澳通行证 / 8：台湾通行证 / 9：士兵证 / 10：临时身份证 / 11：户口簿 / 12：警官证 / 13：出生证明 / 99：其它
     */
    private String cardTypeName;

    /**
     * @证件号
     */
    private String cardNo;

    /**
     * @出生年月日
     */
    private String birthDay;

    /**
     * @国籍
     */
    private String international;

    /**
     * @乘客电话号码
     */
    private String passengerPhoneNum;

    /**
     * @航段
     */
    private String voyageLeg;

    /**
     * @航段EN
     */
    private String voyageLegEn;

    /**
     * @机票销售价
     */
    private BigDecimal salesPrice;

    /**
     * @燃油费
     */
    private BigDecimal oilrax;

    /**
     * @机建费
     */
    private BigDecimal airrax;

    /**
     * @是否要行程单
     */
    private Integer needItinerary;

    /**
     * @行程单金额
     */
    private BigDecimal itineraryMoney;

    /**
     * @是否要保险
     */
    private Integer needInsurance;

    /**
     * @保险金额
     */
    private BigDecimal insuranceMoney;

    /**
     * @是否要保险发票
     */
    private Integer isNeedInsInvoice;

    /**
     * @总金额
     */
    private BigDecimal totalMoney;

    /**
     * @票面价
     */
    private BigDecimal ticketPrice;

    /**
     * @总税费
     */
    private BigDecimal tax;

    /**
     * @证件有效期时间
     */
    private Date cardValidityTime;

    /**
     * @退改标识
     */
    private Integer refundFlag;

    /**
     * @是否退改
     */
    private Integer isRefundFlag;

    /**
     * @是否退改名称
     */
    private String isRefundFlagName;

    /**
     * @退改修改时间
     */
    private Date refundChangeModifyTime;

    /**
     * @公务员验证方式
     */
    private Integer civilServantValidType;

    /**
     * @公务卡开卡银行ID
     */
    private Integer cardBankID;

    /**
     * @公务卡开卡银行名称
     */
    private String cardBankName;

    /**
     * @财政预算单位名称
     */
    private String budgetUnitName;

    /**
     * @发照国代码
     */
    private String issueCountry;

    /**
     * @ 构造函数
     */
    public BuyTicketInfoBo() {
    }

    /**
     * @return 票号
     */
    public String getTicketNo() {
        return ticketNo;
    }

    /**
     * @param ticketNo 票号.
     */
    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    /**
     * @return 乘客姓名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName 乘客姓名.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return 乘客英文名
     */
    public String getUserEnglishName() {
        return userEnglishName;
    }

    /**
     * @param userEnglishName 乘客英文名.
     */
    public void setUserEnglishName(String userEnglishName) {
        this.userEnglishName = userEnglishName;
    }

    /**
     * @return 乘客序号
     */
    public Integer getPassengerIndex() {
        return passengerIndex;
    }

    /**
     * @param passengerIndex 乘客序号.
     */
    public void setPassengerIndex(Integer passengerIndex) {
        this.passengerIndex = passengerIndex;
    }

    /**
     * @return 乘客类型
     */
    public Integer getPassengerType() {
        return passengerType;
    }

    /**
     * @param passengerType 乘客类型.
     */
    public void setPassengerType(Integer passengerType) {
        this.passengerType = passengerType;
    }

    /**
     * @return 乘客类型名称
     */
    public String getPassengerTypeName() {
        return passengerTypeName;
    }

    /**
     * @param passengerTypeName 乘客类型名称.
     */
    public void setPassengerTypeName(String passengerTypeName) {
        this.passengerTypeName = passengerTypeName;
    }

    /**
     * @return 乘机人性别
     */
    public Integer getPassengerGender() {
        return passengerGender;
    }

    /**
     * @param passengerGender 乘机人性别.
     */
    public void setPassengerGender(Integer passengerGender) {
        this.passengerGender = passengerGender;
    }

    /**
     * @return 乘客身份
     */
    public Integer getIdentity() {
        return identity;
    }

    /**
     * @param identity 乘客身份.
     */
    public void setIdentity(Integer identity) {
        this.identity = identity;
    }

    /**
     * @return 证件类型
     */
    public Integer getCardType() {
        return cardType;
    }

    /**
     * @param cardType 证件类型.
     */
    public void setCardType(Integer cardType) {
        this.cardType = cardType;
    }

    /**
     * @return 证件类型名称
     */
    public String getCardTypeName() {
        return cardTypeName;
    }

    /**
     * @param cardTypeName 证件类型名称.
     */
    public void setCardTypeName(String cardTypeName) {
        this.cardTypeName = cardTypeName;
    }

    /**
     * @return 证件号
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * @param cardNo 证件号.
     */
    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    /**
     * @return 出生年月日
     */
    public String getBirthDay() {
        return birthDay;
    }

    /**
     * @param birthDay 出生年月日.
     */
    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    /**
     * @return 国籍
     */
    public String getInternational() {
        return international;
    }

    /**
     * @param international 国籍.
     */
    public void setInternational(String international) {
        this.international = international;
    }

    /**
     * @return 乘客电话号码
     */
    public String getPassengerPhoneNum() {
        return passengerPhoneNum;
    }

    /**
     * @param passengerPhoneNum 乘客电话号码.
     */
    public void setPassengerPhoneNum(String passengerPhoneNum) {
        this.passengerPhoneNum = passengerPhoneNum;
    }

    /**
     * @return 航段
     */
    public String getVoyageLeg() {
        return voyageLeg;
    }

    /**
     * @param voyageLeg 航段.
     */
    public void setVoyageLeg(String voyageLeg) {
        this.voyageLeg = voyageLeg;
    }

    /**
     * @return 航段EN
     */
    public String getVoyageLegEn() {
        return voyageLegEn;
    }

    /**
     * @param voyageLegEn 航段EN.
     */
    public void setVoyageLegEn(String voyageLegEn) {
        this.voyageLegEn = voyageLegEn;
    }

    /**
     * @return 机票销售价
     */
    public BigDecimal getSalesPrice() {
        return salesPrice;
    }

    /**
     * @param salesPrice 机票销售价.
     */
    public void setSalesPrice(BigDecimal salesPrice) {
        this.salesPrice = salesPrice;
    }

    /**
     * @return 燃油费
     */
    public BigDecimal getOilrax() {
        return oilrax;
    }

    /**
     * @param oilrax 燃油费.
     */
    public void setOilrax(BigDecimal oilrax) {
        this.oilrax = oilrax;
    }

    /**
     * @return 机建费
     */
    public BigDecimal getAirrax() {
        return airrax;
    }

    /**
     * @param airrax 机建费.
     */
    public void setAirrax(BigDecimal airrax) {
        this.airrax = airrax;
    }

    /**
     * @return 是否要行程单
     */
    public Integer getNeedItinerary() {
        return needItinerary;
    }

    /**
     * @param needItinerary 是否要行程单.
     */
    public void setNeedItinerary(Integer needItinerary) {
        this.needItinerary = needItinerary;
    }

    /**
     * @return 行程单金额
     */
    public BigDecimal getItineraryMoney() {
        return itineraryMoney;
    }

    /**
     * @param itineraryMoney 行程单金额.
     */
    public void setItineraryMoney(BigDecimal itineraryMoney) {
        this.itineraryMoney = itineraryMoney;
    }

    /**
     * @return 是否要保险
     */
    public Integer getNeedInsurance() {
        return needInsurance;
    }

    /**
     * @param needInsurance 是否要保险.
     */
    public void setNeedInsurance(Integer needInsurance) {
        this.needInsurance = needInsurance;
    }

    /**
     * @return 保险金额
     */
    public BigDecimal getInsuranceMoney() {
        return insuranceMoney;
    }

    /**
     * @param insuranceMoney 保险金额.
     */
    public void setInsuranceMoney(BigDecimal insuranceMoney) {
        this.insuranceMoney = insuranceMoney;
    }

    /**
     * @return 是否要保险发票
     */
    public Integer getIsNeedInsInvoice() {
        return isNeedInsInvoice;
    }

    /**
     * @param isNeedInsInvoice 是否要保险发票.
     */
    public void setIsNeedInsInvoice(Integer isNeedInsInvoice) {
        this.isNeedInsInvoice = isNeedInsInvoice;
    }

    /**
     * @return 总金额
     */
    public BigDecimal getTotalMoney() {
        return totalMoney;
    }

    /**
     * @param totalMoney 总金额.
     */
    public void setTotalMoney(BigDecimal totalMoney) {
        this.totalMoney = totalMoney;
    }

    /**
     * @return 票面价
     */
    public BigDecimal getTicketPrice() {
        return ticketPrice;
    }

    /**
     * @param ticketPrice 票面价.
     */
    public void setTicketPrice(BigDecimal ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    /**
     * @return 总税费
     */
    public BigDecimal getTax() {
        return tax;
    }

    /**
     * @param tax 总税费.
     */
    public void setTax(BigDecimal tax) {
        this.tax = tax;
    }

    /**
     * @return 证件有效期时间
     */
    public Date getCardValidityTime() {
        return cardValidityTime;
    }

    /**
     * @param cardValidityTime 证件有效期时间.
     */
    public void setCardValidityTime(Date cardValidityTime) {
        this.cardValidityTime = cardValidityTime;
    }

    /**
     * @return 退改标识
     */
    public Integer getRefundFlag() {
        return refundFlag;
    }

    /**
     * @param refundFlag 退改标识.
     */
    public void setRefundFlag(Integer refundFlag) {
        this.refundFlag = refundFlag;
    }

    /**
     * @return 是否退改
     */
    public Integer getIsRefundFlag() {
        return isRefundFlag;
    }

    /**
     * @param isRefundFlag 是否退改.
     */
    public void setIsRefundFlag(Integer isRefundFlag) {
        this.isRefundFlag = isRefundFlag;
    }

    /**
     * @return 是否退改名称
     */
    public String getIsRefundFlagName() {
        return isRefundFlagName;
    }

    /**
     * @param isRefundFlagName 是否退改名称.
     */
    public void setIsRefundFlagName(String isRefundFlagName) {
        this.isRefundFlagName = isRefundFlagName;
    }

    /**
     * @return 退改修改时间
     */
    public Date getRefundChangeModifyTime() {
        return refundChangeModifyTime;
    }

    /**
     * @param refundChangeModifyTime 退改修改时间.
     */
    public void setRefundChangeModifyTime(Date refundChangeModifyTime) {
        this.refundChangeModifyTime = refundChangeModifyTime;
    }

    /**
     * @return 公务员验证方式
     */
    public Integer getCivilServantValidType() {
        return civilServantValidType;
    }

    /**
     * @param civilServantValidType 公务员验证方式.
     */
    public void setCivilServantValidType(Integer civilServantValidType) {
        this.civilServantValidType = civilServantValidType;
    }

    /**
     * @return 公务卡开卡银行ID
     */
    public Integer getCardBankID() {
        return cardBankID;
    }

    /**
     * @param cardBankID 公务卡开卡银行ID.
     */
    public void setCardBankID(Integer cardBankID) {
        this.cardBankID = cardBankID;
    }

    /**
     * @return 公务卡开卡银行名称
     */
    public String getCardBankName() {
        return cardBankName;
    }

    /**
     * @param cardBankName 公务卡开卡银行名称.
     */
    public void setCardBankName(String cardBankName) {
        this.cardBankName = cardBankName;
    }

    /**
     * @return 财政预算单位名称
     */
    public String getBudgetUnitName() {
        return budgetUnitName;
    }

    /**
     * @param budgetUnitName 财政预算单位名称.
     */
    public void setBudgetUnitName(String budgetUnitName) {
        this.budgetUnitName = budgetUnitName;
    }

    /**
     * @return 发照国代码
     */
    public String getIssueCountry() {
        return issueCountry;
    }

    /**
     * @param issueCountry 发照国代码.
     */
    public void setIssueCountry(String issueCountry) {
        this.issueCountry = issueCountry;
    }
}
