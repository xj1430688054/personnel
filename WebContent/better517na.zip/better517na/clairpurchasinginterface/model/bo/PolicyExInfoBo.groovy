package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/10/24
 * Time: 9:44
 */
class PolicyExInfoBo {
    /**
     * 航司协议折扣（协议价/Y公布运价）.
     */
    private String airAgentDiscount;

    /**
     * 原始舱位折扣.
     */
    private String oriClassDiscount;

    /**
     * 公布运价高价.
     */
    private String publicHighPrice;

    /**
     * 公布运价低价.
     */
    private String publicLowPrice;

    /**
     * 是否委托客服预定.
     */
    private String isDelegateOrder;

    /**
     * salePrice.
     */
    private String salePrice;

    /**
     * 计算折扣.
     */
    private String calculateDiscount;

    /**
     * prefMoney.
     */
    private String prefMoney;

    /**
     * policyExInfo.
     */
    private String policyExInfo;

    /**
     * 春秋航空航段ID
     */
    private String ch_segId;

    /**
     * 春秋航空商务座打包增值产品ID
     */
    private String ch_subProdId;

    /**
     * 春秋航空商务座销售设置ID
     */
    private String ch_saleSegId;

    /**
     * 设置oriClassDiscount.
     *
     * @return 返回oriClassDiscount
     */
    public String getOriClassDiscount() {
        return oriClassDiscount;
    }

    /**
     * 获取oriClassDiscount.
     *
     * @param oriClassDiscount 要设置的oriClassDiscount
     */
    public void setOriClassDiscount(String oriClassDiscount) {
        this.oriClassDiscount = oriClassDiscount;
    }

    /**
     * 设置publicHighPrice.
     *
     * @return 返回publicHighPrice
     */
    public String getPublicHighPrice() {
        return publicHighPrice;
    }

    /**
     * 获取publicHighPrice.
     *
     * @param publicHighPrice 要设置的publicHighPrice
     */
    public void setPublicHighPrice(String publicHighPrice) {
        this.publicHighPrice = publicHighPrice;
    }

    /**
     * 设置publicLowPrice.
     *
     * @return 返回publicLowPrice
     */
    public String getPublicLowPrice() {
        return publicLowPrice;
    }

    /**
     * 获取publicLowPrice.
     *
     * @param publicLowPrice 要设置的publicLowPrice
     */
    public void setPublicLowPrice(String publicLowPrice) {
        this.publicLowPrice = publicLowPrice;
    }

    /**
     * 设置isDelegateOrder.
     *
     * @return 返回isDelegateOrder
     */
    public String getIsDelegateOrder() {
        return isDelegateOrder;
    }

    /**
     * 获取isDelegateOrder.
     *
     * @param isDelegateOrder 要设置的isDelegateOrder
     */
    public void setIsDelegateOrder(String isDelegateOrder) {
        this.isDelegateOrder = isDelegateOrder;
    }

    /**
     * 设置salePrice.
     *
     * @return 返回salePrice
     */
    public String getSalePrice() {
        return salePrice;
    }

    /**
     * 获取salePrice.
     *
     * @param salePrice 要设置的salePrice
     */
    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }

    /**
     * 设置calculateDiscount.
     *
     * @return 返回calculateDiscount
     */
    public String getCalculateDiscount() {
        return calculateDiscount;
    }

    /**
     * 获取calculateDiscount.
     *
     * @param calculateDiscount 要设置的calculateDiscount
     */
    public void setCalculateDiscount(String calculateDiscount) {
        this.calculateDiscount = calculateDiscount;
    }

    /**
     * 设置prefMoney.
     *
     * @return 返回prefMoney
     */
    public String getPrefMoney() {
        return prefMoney;
    }

    /**
     * 获取prefMoney.
     *
     * @param prefMoney 要设置的prefMoney
     */
    public void setPrefMoney(String prefMoney) {
        this.prefMoney = prefMoney;
    }

    public String getAirAgentDiscount() {
        return airAgentDiscount;
    }

    public void setAirAgentDiscount(String airAgentDiscount) {
        this.airAgentDiscount = airAgentDiscount;
    }

    public String getPolicyExInfo() {
        return policyExInfo;
    }

    public void setPolicyExInfo(String policyExInfo) {
        this.policyExInfo = policyExInfo;
    }

    public String getCh_segId() {
        return ch_segId;
    }

    public void setCh_segId(String ch_segId) {
        this.ch_segId = ch_segId;
    }

    public String getCh_subProdId() {
        return ch_subProdId;
    }

    public void setCh_subProdId(String ch_subProdId) {
        this.ch_subProdId = ch_subProdId;
    }

    public String getCh_saleSegId() {
        return ch_saleSegId;
    }

    public void setCh_saleSegId(String ch_saleSegId) {
        this.ch_saleSegId = ch_saleSegId;
    }
}
