package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.businessBaseDBAccessLayer.ISubTable
import com.better517na.clairpurchasinginterface.utils.DateUtil

import javax.persistence.Entity
import javax.persistence.Table
import java.text.ParseException

@Entity
@Table(name = 'BuyVoyageInfo')
public class BuyVoyageInfoBo implements ISubTable {
    /**
     * @主键ID
     */
    private String keyID;

    /**
     * @机票订单号
     */
    private String orderId;

    /**
     * @航程序号
     */
    private Integer sequence;

    /**
     * @承运人
     */
    private String carrier;

    /**
     * @承运人名称
     */
    private String carrierName;

    /**
     * @航班号
     */
    private String flightNo;

    /**
     * @舱位
     */
    private String cabin;

    /**
     * @舱位中文名
     */
    private String cabinName;

    /**
     * @机型
     */
    private String planType;

    /**
     * @出发城市
     */
    private String deptCity;

    /**
     * @到达城市
     */
    private String arrCity;

    /**
     * @出发城市中文名
     */
    private String deptCityCh;

    /**
     * @到达城市中文名
     */
    private String arrCityCh;

    /**
     * @出发机场
     */
    private String deptAirport;

    /**
     * @到达机场
     */
    private String arrAirport;

    /**
     * @出发机场中文名
     */
    private String deptAirportCh;

    /**
     * @到达机场中文名
     */
    private String arrAirportCh;

    /**
     * @起飞时间
     */
    private Date deptTime;

    /**
     * @到达时间
     */
    private Date arrTime;

    /**
     * @出发航站楼
     */
    private String orgJetquay;

    /**
     * @到达航站楼
     */
    private String dstJetquay;

    /**
     * @折扣
     */
    private String discount;

    /**
     * @是否经停
     */
    private Integer stopOver;

    /**
     * @经停城市
     */
    private String stopOverCity;

    /**
     * @经停城市中文名
     */
    private String stopOverCityCh;

    /**
     * @经停机场
     */
    private String sOAirport;

    /**
     * @经停机场中文名
     */
    private String sOAirportCh;

    /**
     * @经停起飞时间
     */
    private Date midTakeOffTime;

    /**
     * @经停到达时间
     */
    private Date midArrTime;

    /**
     * @是否中转行程
     */
    private Integer isTransfer;

    /**
     * @中转航班原航程序号
     */
    private Integer transferOrgSequence;

    /**
     * @是否共享航班
     */
    private Integer isShare;

    /**
     * @共享真实航班号
     */
    private String reallyFlightNo;

    /**
     * @政策ID
     */
    private String policyId;

    /**
     * @返点
     */
    private String returnPoint;

    /**
     * @是否本航票
     */
    private Integer isSelfCarrierTicket;

    /**
     * @大客户号
     */
    private String largeCustomerNum;

    /**
     * @是否标准客规
     */
    private Integer isStandardRule;

    /**
     * @非标准客规内容
     */
    private String unStandardRule;

    /**
     * @政策平台类型
     */
    private Integer policyPlattype;

    /**
     * @政策价格来源
     */
    private String priceSource;

    /**
     * @政策标识
     */
    private Integer policySign;

    /**
     * @行李额件数
     */
    private BigDecimal baggageCount;

    /**
     * @行李额重量
     */
    private BigDecimal baggageWeight;

    /**
     * @是否红眼
     */
    private Integer isNightFlight;

    /**
     * @航程类型
     */
    private Integer flightType;

    /**
     * @飞机型号
     */
    private String planModel;

    /**
     * @飞行时间
     */
    private String flyTime;

    /**
     * @产品ID
     */
    private String subProductId;

    /**
     * @政策扩展字段
     */
    private String policyExInfo;

    /**
     * @备注
     */
    private String remark;

    /**
     * @添加时间
     */
    private Date addTime;

    /**
     * @删除标识
     */
    private Integer isDelete;

    /*
    *深航添加
    * sessionid
    */
    private String sid;

    String getSid() {
        return sid
    }

    void setSid(String sid) {
        this.sid = sid
    }
/**
     * @ 构造函数
     */
    public BuyVoyageInfoBo() {
    }

    /**
     * @return 主键ID
     */
    public String getKeyID() {
        return keyID;
    }

    /**
     * @param keyID 主键ID.
     */
    public void setKeyID(String keyID) {
        this.keyID = keyID;
    }

    /**
     * @return 机票订单号
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId 机票订单号.
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return 航程序号
     */
    public Integer getSequence() {
        return sequence;
    }

    /**
     * @param sequence 航程序号.
     */
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    /**
     * @return 承运人
     */
    public String getCarrier() {
        return carrier;
    }

    /**
     * @param carrier 承运人.
     */
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    /**
     * @return 承运人名称
     */
    public String getCarrierName() {
        return carrierName;
    }

    /**
     * @param carrierName 承运人名称.
     */
    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    /**
     * @return 航班号
     */
    public String getFlightNo() {
        return flightNo;
    }

    /**
     * @param flightNo 航班号.
     */
    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    /**
     * @return 舱位
     */
    public String getCabin() {
        return cabin;
    }

    /**
     * @param cabin 舱位.
     */
    public void setCabin(String cabin) {
        this.cabin = cabin;
    }

    /**
     * @return 舱位中文名
     */
    public String getCabinName() {
        return cabinName;
    }

    /**
     * @param cabinName 舱位中文名.
     */
    public void setCabinName(String cabinName) {
        this.cabinName = cabinName;
    }

    /**
     * @return 机型
     */
    public String getPlanType() {
        return planType;
    }

    /**
     * @param planType 机型.
     */
    public void setPlanType(String planType) {
        this.planType = planType;
    }

    /**
     * @return 出发城市
     */
    public String getDeptCity() {
        return deptCity;
    }

    /**
     * @param deptCity 出发城市.
     */
    public void setDeptCity(String deptCity) {
        this.deptCity = deptCity;
    }

    /**
     * @return 到达城市
     */
    public String getArrCity() {
        return arrCity;
    }

    /**
     * @param arrCity 到达城市.
     */
    public void setArrCity(String arrCity) {
        this.arrCity = arrCity;
    }

    /**
     * @return 出发城市中文名
     */
    public String getDeptCityCh() {
        return deptCityCh;
    }

    /**
     * @param deptCityCh 出发城市中文名.
     */
    public void setDeptCityCh(String deptCityCh) {
        this.deptCityCh = deptCityCh;
    }

    /**
     * @return 到达城市中文名
     */
    public String getArrCityCh() {
        return arrCityCh;
    }

    /**
     * @param arrCityCh 到达城市中文名.
     */
    public void setArrCityCh(String arrCityCh) {
        this.arrCityCh = arrCityCh;
    }

    /**
     * @return 出发机场
     */
    public String getDeptAirport() {
        return deptAirport;
    }

    /**
     * @param deptAirport 出发机场.
     */
    public void setDeptAirport(String deptAirport) {
        this.deptAirport = deptAirport;
    }

    /**
     * @return 到达机场
     */
    public String getArrAirport() {
        return arrAirport;
    }

    /**
     * @param arrAirport 到达机场.
     */
    public void setArrAirport(String arrAirport) {
        this.arrAirport = arrAirport;
    }

    /**
     * @return 出发机场中文名
     */
    public String getDeptAirportCh() {
        return deptAirportCh;
    }

    /**
     * @param deptAirportCh 出发机场中文名.
     */
    public void setDeptAirportCh(String deptAirportCh) {
        this.deptAirportCh = deptAirportCh;
    }

    /**
     * @return 到达机场中文名
     */
    public String getArrAirportCh() {
        return arrAirportCh;
    }

    /**
     * @param arrAirportCh 到达机场中文名.
     */
    public void setArrAirportCh(String arrAirportCh) {
        this.arrAirportCh = arrAirportCh;
    }

    /**
     * @return 起飞时间
     */
    public Date getDeptTime() {
        return deptTime;
    }

    /**
     * @param deptTime 起飞时间.
     */
    public void setDeptTime(Date deptTime) {
        this.deptTime = deptTime;
    }

    /**
     * @return 到达时间
     */
    public Date getArrTime() {
        return arrTime;
    }

    /**
     * @param arrTime 到达时间.
     */
    public void setArrTime(Date arrTime) {
        this.arrTime = arrTime;
    }

    /**
     * @return 出发航站楼
     */
    public String getOrgJetquay() {
        return orgJetquay;
    }

    /**
     * @param orgJetquay 出发航站楼.
     */
    public void setOrgJetquay(String orgJetquay) {
        this.orgJetquay = orgJetquay;
    }

    /**
     * @return 到达航站楼
     */
    public String getDstJetquay() {
        return dstJetquay;
    }

    /**
     * @param dstJetquay 到达航站楼.
     */
    public void setDstJetquay(String dstJetquay) {
        this.dstJetquay = dstJetquay;
    }

    /**
     * @return 折扣
     */
    public String getDiscount() {
        return discount;
    }

    /**
     * @param discount 折扣.
     */
    public void setDiscount(String discount) {
        this.discount = discount;
    }

    /**
     * @return 是否经停
     */
    public Integer getStopOver() {
        return stopOver;
    }

    /**
     * @param stopOver 是否经停.
     */
    public void setStopOver(Integer stopOver) {
        this.stopOver = stopOver;
    }

    /**
     * @return 经停城市
     */
    public String getStopOverCity() {
        return stopOverCity;
    }

    /**
     * @param stopOverCity 经停城市.
     */
    public void setStopOverCity(String stopOverCity) {
        this.stopOverCity = stopOverCity;
    }

    /**
     * @return 经停城市中文名
     */
    public String getStopOverCityCh() {
        return stopOverCityCh;
    }

    /**
     * @param stopOverCityCh 经停城市中文名.
     */
    public void setStopOverCityCh(String stopOverCityCh) {
        this.stopOverCityCh = stopOverCityCh;
    }

    /**
     * @return 经停机场
     */
    public String getSOAirport() {
        return sOAirport;
    }

    /**
     * @param sOAirport 经停机场.
     */
    public void setSOAirport(String sOAirport) {
        this.sOAirport = sOAirport;
    }

    /**
     * @return 经停机场中文名
     */
    public String getSOAirportCh() {
        return sOAirportCh;
    }

    /**
     * @param sOAirportCh 经停机场中文名.
     */
    public void setSOAirportCh(String sOAirportCh) {
        this.sOAirportCh = sOAirportCh;
    }

    /**
     * @return 经停起飞时间
     */
    public Date getMidTakeOffTime() {
        return midTakeOffTime;
    }

    /**
     * @param midTakeOffTime 经停起飞时间.
     */
    public void setMidTakeOffTime(Date midTakeOffTime) {
        this.midTakeOffTime = midTakeOffTime;
    }

    /**
     * @return 经停到达时间
     */
    public Date getMidArrTime() {
        return midArrTime;
    }

    /**
     * @param midArrTime 经停到达时间.
     */
    public void setMidArrTime(Date midArrTime) {
        this.midArrTime = midArrTime;
    }

    /**
     * @return 是否中转行程
     */
    public Integer getIsTransfer() {
        return isTransfer;
    }

    /**
     * @param isTransfer 是否中转行程.
     */
    public void setIsTransfer(Integer isTransfer) {
        this.isTransfer = isTransfer;
    }

    /**
     * @return 中转航班原航程序号
     */
    public Integer getTransferOrgSequence() {
        return transferOrgSequence;
    }

    /**
     * @param transferOrgSequence 中转航班原航程序号.
     */
    public void setTransferOrgSequence(Integer transferOrgSequence) {
        this.transferOrgSequence = transferOrgSequence;
    }

    /**
     * @return 是否共享航班
     */
    public Integer getIsShare() {
        return isShare;
    }

    /**
     * @param isShare 是否共享航班.
     */
    public void setIsShare(Integer isShare) {
        this.isShare = isShare;
    }

    /**
     * @return 共享真实航班号
     */
    public String getReallyFlightNo() {
        return reallyFlightNo;
    }

    /**
     * @param reallyFlightNo 共享真实航班号.
     */
    public void setReallyFlightNo(String reallyFlightNo) {
        this.reallyFlightNo = reallyFlightNo;
    }

    /**
     * @return 政策ID
     */
    public String getPolicyId() {
        return policyId;
    }

    /**
     * @param policyId 政策ID.
     */
    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    /**
     * @return 返点
     */
    public String getReturnPoint() {
        return returnPoint;
    }

    /**
     * @param returnPoint 返点.
     */
    public void setReturnPoint(String returnPoint) {
        this.returnPoint = returnPoint;
    }

    /**
     * @return 是否本航票
     */
    public Integer getIsSelfCarrierTicket() {
        return isSelfCarrierTicket;
    }

    /**
     * @param isSelfCarrierTicket 是否本航票.
     */
    public void setIsSelfCarrierTicket(Integer isSelfCarrierTicket) {
        this.isSelfCarrierTicket = isSelfCarrierTicket;
    }

    /**
     * @return 大客户号
     */
    public String getLargeCustomerNum() {
        return largeCustomerNum;
    }

    /**
     * @param largeCustomerNum 大客户号.
     */
    public void setLargeCustomerNum(String largeCustomerNum) {
        this.largeCustomerNum = largeCustomerNum;
    }

    /**
     * @return 是否标准客规
     */
    public Integer getIsStandardRule() {
        return isStandardRule;
    }

    /**
     * @param isStandardRule 是否标准客规.
     */
    public void setIsStandardRule(Integer isStandardRule) {
        this.isStandardRule = isStandardRule;
    }

    /**
     * @return 非标准客规内容
     */
    public String getUnStandardRule() {
        return unStandardRule;
    }

    /**
     * @param unStandardRule 非标准客规内容.
     */
    public void setUnStandardRule(String unStandardRule) {
        this.unStandardRule = unStandardRule;
    }

    /**
     * @return 政策平台类型
     */
    public Integer getPolicyPlattype() {
        return policyPlattype;
    }

    /**
     * @param policyPlattype 政策平台类型.
     */
    public void setPolicyPlattype(Integer policyPlattype) {
        this.policyPlattype = policyPlattype;
    }

    /**
     * @return 政策价格来源
     */
    public String getPriceSource() {
        return priceSource;
    }

    /**
     * @param priceSource 政策价格来源.
     */
    public void setPriceSource(String priceSource) {
        this.priceSource = priceSource;
    }

    /**
     * @return 政策标识
     */
    public Integer getPolicySign() {
        return policySign;
    }

    /**
     * @param policySign 政策标识.
     */
    public void setPolicySign(Integer policySign) {
        this.policySign = policySign;
    }

    /**
     * @return 行李额件数
     */
    public BigDecimal getBaggageCount() {
        return baggageCount;
    }

    /**
     * @param baggageCount 行李额件数.
     */
    public void setBaggageCount(BigDecimal baggageCount) {
        this.baggageCount = baggageCount;
    }

    /**
     * @return 行李额重量
     */
    public BigDecimal getBaggageWeight() {
        return baggageWeight;
    }

    /**
     * @param baggageWeight 行李额重量.
     */
    public void setBaggageWeight(BigDecimal baggageWeight) {
        this.baggageWeight = baggageWeight;
    }

    /**
     * @return 是否红眼
     */
    public Integer getIsNightFlight() {
        return isNightFlight;
    }

    /**
     * @param isNightFlight 是否红眼.
     */
    public void setIsNightFlight(Integer isNightFlight) {
        this.isNightFlight = isNightFlight;
    }

    /**
     * @return 航程类型
     */
    public Integer getFlightType() {
        return flightType;
    }

    /**
     * @param flightType 航程类型.
     */
    public void setFlightType(Integer flightType) {
        this.flightType = flightType;
    }

    /**
     * @return 飞机型号
     */
    public String getPlanModel() {
        return planModel;
    }

    /**
     * @param planModel 飞机型号.
     */
    public void setPlanModel(String planModel) {
        this.planModel = planModel;
    }

    /**
     * @return 飞行时间
     */
    public String getFlyTime() {
        return flyTime;
    }

    /**
     * @param flyTime 飞行时间.
     */
    public void setFlyTime(String flyTime) {
        this.flyTime = flyTime;
    }

    /**
     * @return 产品ID
     */
    public String getSubProductId() {
        return subProductId;
    }

    /**
     * @param subProductId 产品ID.
     */
    public void setSubProductId(String subProductId) {
        this.subProductId = subProductId;
    }

    /**
     * @return 政策扩展字段
     */
    public String getPolicyExInfo() {
        return policyExInfo;
    }

    /**
     * @param policyExInfo 政策扩展字段.
     */
    public void setPolicyExInfo(String policyExInfo) {
        this.policyExInfo = policyExInfo;
    }

    /**
     * @return 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark 备注.
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return 添加时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * @param addTime 添加时间.
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * @return 删除标识
     */
    public Integer getIsDelete() {
        return isDelete;
    }

    /**
     * @param isDelete 删除标识.
     */
    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    @Override
    public Date getBizTime() {
        try {
            String sellOrderId = StringUtil.isNullOrEmpty(this.orderId) ? this.keyID : this.orderId;
            return DateUtil.keyIdToDate(sellOrderId);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String getHashKey() {
        return null;
    }

    @Override
    public String getSpecialKey() {
        return null;
    }
}
