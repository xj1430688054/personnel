package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

public class PriceValidateBaseVo {
    /**
     * 添加字段注释.
     */
    private Date time;
    /**
     * 添加字段注释.
     */
    private String priceValidatejson;
    /**
     * 添加字段注释.
     */
    private Integer jsontype;
    /**
     * 添加字段注释.
     */
    private String desc;

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public Date getTime() {
        return time
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public void setTime(Date time) {
        this.time = time
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public String getPriceValidatejson() {
        return priceValidatejson
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public void setPriceValidatejson(String priceValidatejson) {
        this.priceValidatejson = priceValidatejson
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public Integer getJsontype() {
        return jsontype
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public void setJsontype(Integer jsontype) {
        this.jsontype = jsontype
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public String getDesc() {
        return desc
    }

    /**
     * 设置orderInfo.
     *
     * @return 返回orderInfo
     */
    public void setDesc(String desc) {
        this.desc = desc
    }
}
