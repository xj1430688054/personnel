package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.businessBaseDBAccessLayer.ISubTable
import com.better517na.clairpurchasinginterface.utils.DateUtil

import javax.persistence.Entity
import javax.persistence.Table
import java.text.ParseException

@Entity
@Table(name = 'BuyOrderExtend')
public class BuyOrderExtendBo implements ISubTable {
    /**
     * @KeyId
     */
    private String keyId;

    /**
     * @订单号
     */
    private String orderId;

    /**
     * @卖出订单号
     */
    private String sellOrderId;

    /**
     * @订座Office
     */
    private String bookOffice;

    /**
     * @出票Office
     */
    private String outTicketOffice;

    /**
     * @出票渠道账号
     */
    private String outTicketAccount;

    /**
     * @出票支付账号
     */
    private String outTicketPayAccount;

    /**
     * @行程单配送方式
     */
    private Integer itineraryDispatchTypeID;

    /**
     * @行程单配送方式名称
     */
    private String itineraryDispatchTypeName;

    /**
     * @行程单快递费
     */
    private BigDecimal itineraryExpressMoney;

    /**
     * @收件人姓名
     */
    private String recipientName;

    /**
     * @收件地址
     */
    private String postAddress;

    /**
     * @收件人电话号码
     */
    private String recipientPhoneNum;

    /**
     * @行程单创单状态
     */
    private Integer itineryCreateState;

    /**
     * @行程单创单状态描述
     */
    private String itineryCreateStateDes;

    /**
     * @行程单创单失败理由
     */
    private String itineryFailReason;

    /**
     * @行程单申请订单号
     */
    private String itineryOrderId;

    /**
     * @Key1
     */
    private String key1;

    /**
     * @Key2
     */
    private String key2;

    /**
     * @Key3
     */
    private String key3;

    /**
     * @Key4
     */
    private String key4;

    /**
     * @Key5
     */
    private String key5;

    /**
     * @Key6
     */
    private Integer key6;

    /**
     * @Key7
     */
    private Integer key7;

    /**
     * @Key8
     */
    private Date key8;

    /**
     * @Key9
     */
    private Date key9;

    /**
     * @Key10
     */
    private Date key10;

    /**
     * @添加时间
     */
    private Date addTime;

    /**
     * @删除标识
     */
    private Integer isDelete;

    /**
     * @ 构造函数
     */
    public BuyOrderExtendBo() {
    }

    /**
     * @return KeyId
     */
    public String getKeyId() {
        return keyId;
    }

    /**
     * @param keyId KeyId.
     */
    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    /**
     * @return 订单号
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId 订单号.
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return 卖出订单号
     */
    public String getSellOrderId() {
        return sellOrderId;
    }

    /**
     * @param sellOrderId 卖出订单号.
     */
    public void setSellOrderId(String sellOrderId) {
        this.sellOrderId = sellOrderId;
    }

    /**
     * @return 订座Office
     */
    public String getBookOffice() {
        return bookOffice;
    }

    /**
     * @param bookOffice 订座Office.
     */
    public void setBookOffice(String bookOffice) {
        this.bookOffice = bookOffice;
    }

    /**
     * @return 出票Office
     */
    public String getOutTicketOffice() {
        return outTicketOffice;
    }

    /**
     * @param outTicketOffice 出票Office.
     */
    public void setOutTicketOffice(String outTicketOffice) {
        this.outTicketOffice = outTicketOffice;
    }

    /**
     * @return 出票渠道账号
     */
    public String getOutTicketAccount() {
        return outTicketAccount;
    }

    /**
     * @param outTicketAccount 出票渠道账号.
     */
    public void setOutTicketAccount(String outTicketAccount) {
        this.outTicketAccount = outTicketAccount;
    }

    /**
     * @return 出票支付账号
     */
    public String getOutTicketPayAccount() {
        return outTicketPayAccount;
    }

    /**
     * @param outTicketPayAccount 出票支付账号.
     */
    public void setOutTicketPayAccount(String outTicketPayAccount) {
        this.outTicketPayAccount = outTicketPayAccount;
    }

    /**
     * @return 行程单配送方式
     */
    public Integer getItineraryDispatchTypeID() {
        return itineraryDispatchTypeID;
    }

    /**
     * @param itineraryDispatchTypeID 行程单配送方式.
     */
    public void setItineraryDispatchTypeID(Integer itineraryDispatchTypeID) {
        this.itineraryDispatchTypeID = itineraryDispatchTypeID;
    }

    /**
     * @return 行程单配送方式名称
     */
    public String getItineraryDispatchTypeName() {
        return itineraryDispatchTypeName;
    }

    /**
     * @param itineraryDispatchTypeName 行程单配送方式名称.
     */
    public void setItineraryDispatchTypeName(String itineraryDispatchTypeName) {
        this.itineraryDispatchTypeName = itineraryDispatchTypeName;
    }

    /**
     * @return 行程单快递费
     */
    public BigDecimal getItineraryExpressMoney() {
        return itineraryExpressMoney;
    }

    /**
     * @param itineraryExpressMoney 行程单快递费.
     */
    public void setItineraryExpressMoney(BigDecimal itineraryExpressMoney) {
        this.itineraryExpressMoney = itineraryExpressMoney;
    }

    /**
     * @return 收件人姓名
     */
    public String getRecipientName() {
        return recipientName;
    }

    /**
     * @param recipientName 收件人姓名.
     */
    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    /**
     * @return 收件地址
     */
    public String getPostAddress() {
        return postAddress;
    }

    /**
     * @param postAddress 收件地址.
     */
    public void setPostAddress(String postAddress) {
        this.postAddress = postAddress;
    }

    /**
     * @return 收件人电话号码
     */
    public String getRecipientPhoneNum() {
        return recipientPhoneNum;
    }

    /**
     * @param recipientPhoneNum 收件人电话号码.
     */
    public void setRecipientPhoneNum(String recipientPhoneNum) {
        this.recipientPhoneNum = recipientPhoneNum;
    }

    /**
     * @return 行程单创单状态
     */
    public Integer getItineryCreateState() {
        return itineryCreateState;
    }

    /**
     * @param itineryCreateState 行程单创单状态.
     */
    public void setItineryCreateState(Integer itineryCreateState) {
        this.itineryCreateState = itineryCreateState;
    }

    /**
     * @return 行程单创单状态描述
     */
    public String getItineryCreateStateDes() {
        return itineryCreateStateDes;
    }

    /**
     * @param itineryCreateStateDes 行程单创单状态描述.
     */
    public void setItineryCreateStateDes(String itineryCreateStateDes) {
        this.itineryCreateStateDes = itineryCreateStateDes;
    }

    /**
     * @return 行程单创单失败理由
     */
    public String getItineryFailReason() {
        return itineryFailReason;
    }

    /**
     * @param itineryFailReason 行程单创单失败理由.
     */
    public void setItineryFailReason(String itineryFailReason) {
        this.itineryFailReason = itineryFailReason;
    }

    /**
     * @return 行程单申请订单号
     */
    public String getItineryOrderId() {
        return itineryOrderId;
    }

    /**
     * @param itineryOrderId 行程单申请订单号.
     */
    public void setItineryOrderId(String itineryOrderId) {
        this.itineryOrderId = itineryOrderId;
    }

    /**
     * @return Key1
     */
    public String getKey1() {
        return key1;
    }

    /**
     * @param key1 Key1.
     */
    public void setKey1(String key1) {
        this.key1 = key1;
    }

    /**
     * @return Key2
     */
    public String getKey2() {
        return key2;
    }

    /**
     * @param key2 Key2.
     */
    public void setKey2(String key2) {
        this.key2 = key2;
    }

    /**
     * @return Key3
     */
    public String getKey3() {
        return key3;
    }

    /**
     * @param key3 Key3.
     */
    public void setKey3(String key3) {
        this.key3 = key3;
    }

    /**
     * @return Key4
     */
    public String getKey4() {
        return key4;
    }

    /**
     * @param key4 Key4.
     */
    public void setKey4(String key4) {
        this.key4 = key4;
    }

    /**
     * @return Key5
     */
    public String getKey5() {
        return key5;
    }

    /**
     * @param key5 Key5.
     */
    public void setKey5(String key5) {
        this.key5 = key5;
    }

    /**
     * @return Key6
     */
    public Integer getKey6() {
        return key6;
    }

    /**
     * @param key6 Key6.
     */
    public void setKey6(Integer key6) {
        this.key6 = key6;
    }

    /**
     * @return Key7
     */
    public Integer getKey7() {
        return key7;
    }

    /**
     * @param key7 Key7.
     */
    public void setKey7(Integer key7) {
        this.key7 = key7;
    }

    /**
     * @return Key8
     */
    public Date getKey8() {
        return key8;
    }

    /**
     * @param key8 Key8.
     */
    public void setKey8(Date key8) {
        this.key8 = key8;
    }

    /**
     * @return Key9
     */
    public Date getKey9() {
        return key9;
    }

    /**
     * @param key9 Key9.
     */
    public void setKey9(Date key9) {
        this.key9 = key9;
    }

    /**
     * @return Key10
     */
    public Date getKey10() {
        return key10;
    }

    /**
     * @param key10 Key10.
     */
    public void setKey10(Date key10) {
        this.key10 = key10;
    }

    /**
     * @return 添加时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * @param addTime 添加时间.
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * @return 删除标识
     */
    public Integer getIsDelete() {
        return isDelete;
    }

    /**
     * @param isDelete 删除标识.
     */
    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    @Override
    public Date getBizTime() {
        try {
            String sellOrderId = StringUtil.isNullOrEmpty(this.sellOrderId) ? this.keyId : this.sellOrderId;
            return DateUtil.keyIdToDate(sellOrderId);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String getHashKey() {
        return null;
    }

    @Override
    public String getSpecialKey() {
        return null;
    }
}
