package config.groovyFiles.com.better517na.clairpurchasinginterface.model.bo

import io.swagger.annotations.ApiModelProperty

public class PassengerInfoBo {
    /**
     * @票号
     */
    @ApiModelProperty(value = '票号')
    private String ticketNo;

    /**
     * @乘客姓名
     */
    @ApiModelProperty(value = '乘客姓名')
    private String userName;

    /**
     * @乘客类型名称
     */
    @ApiModelProperty(value = '乘客类型名称')
    private String passengerTypeName;

    /**
     * @证件号
     */
    @ApiModelProperty(value = '证件号')
    private String cardNo;

    /**
     * 出票价格
     */
    @ApiModelProperty(value = '出票价格')
    private String buyPrice;

    /**
     * @return 票号
     */
    public String getTicketNo() {
        return ticketNo;
    }

    /**
     * @param ticketNo
     *            票号.
     */
    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    /**
     * @return 乘客姓名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName
     *            乘客姓名.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return 乘客类型名称
     */
    public String getPassengerTypeName() {
        return passengerTypeName;
    }

    /**
     * @param passengerTypeName
     *            乘客类型名称.
     */
    public void setPassengerTypeName(String passengerTypeName) {
        this.passengerTypeName = passengerTypeName;
    }

    /**
     * @return 证件号
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * @param cardNo
     *            证件号.
     */
    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    /**
     * @return   出票价格
     * */
    public String getBuyPrice() {
        return buyPrice
    }

    /**
     * @param buyPrice
     *            证件号.
     */
    public void setBuyPrice(String buyPrice) {
        this.buyPrice = buyPrice
    }
}
