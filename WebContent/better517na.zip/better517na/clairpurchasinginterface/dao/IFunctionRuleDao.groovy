package config.groovyFiles.com.better517na.clairpurchasinginterface.dao

import com.better517na.clairpurchasinginterface.model.FunctionRule


public interface IFunctionRuleDao {

    /**
     * 根据业务名称和方法获取可用规则,且规则已经排好了序
     * @param tableName
     * @param businessName
     * @param method
     * @return
     */
    List<FunctionRule> getSortedFunctionRulesByBusinessNameAndMethod(String tableName, String businessName, String method);

}