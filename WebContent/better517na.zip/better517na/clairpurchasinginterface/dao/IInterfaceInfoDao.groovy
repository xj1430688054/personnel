package config.groovyFiles.com.better517na.clairpurchasinginterface.dao

import com.better517na.clairpurchasinginterface.model.InterfaceInfo


public interface IInterfaceInfoDao {

    InterfaceInfo getInterfaceInfoByKeyId(String tableName, String keyId);
}
