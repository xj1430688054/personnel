/*
 * 文件名：ISupplySystemInfoDao.java
 * 版权：Copyright 2007-2018 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： ISupplySystemInfoDao.java
 * 修改人：qiyue
 * 修改时间：2018年4月11日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.dao
/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author qiyue
 */
public interface ISupplySystemInfoDao {
	public List<com.better517na.clairpurchasinginterface.model.SupplySystemInfo> getAllSupplySystemInfoByKeyID(String keyID, String tableName, int pageCount);
}
