package config.groovyFiles.com.better517na.clairpurchasinginterface.dao.impl

import com.better517na.clairpurchasinginterface.model.NotifyPurchasingInterfaceInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.dao.INotifyPurchasingInterfaceInfoDao
import org.springframework.stereotype.Component

@Component('notifyPurchasingInterfaceInfoDao')
public class NotifyPurchasingInterfaceInfoDaoImpl extends BaseDaoImpl implements INotifyPurchasingInterfaceInfoDao{
    @Override
    List<NotifyPurchasingInterfaceInfo> getALLNotifyPurchasingInterfaceInfoByKeyID(String keyID, String tableName, int pageCount) {
       Map<String,Object> map=new HashMap<>();
       map.put('tableName',tableName);
       map.put('keyID',keyID);
       map.put('pageCount',pageCount);
       List<NotifyPurchasingInterfaceInfo> notifyPurchasingInterfaceInfoList= this.sqlSessionRead.selectList('INotifyPurchasingInterfaceInfoDao.getAllNotifyPurchasingInterfaceInfoByKeyID', map);
       return notifyPurchasingInterfaceInfoList;
    }
}
