/*
 * 文件名：SupplySystemInfoDaoImpl.java
 * 版权：Copyright 2007-2018 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： SupplySystemInfoDaoImpl.java
 * 修改人：qiyue
 * 修改时间：2018年4月11日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.dao.impl

import config.groovyFiles.com.better517na.clairpurchasinginterface.dao.ISupplySystemInfoDao
import org.springframework.stereotype.Component

/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 *
 * <pre>
 * </pre>
 *
 * @author gaoshun
 */
@Component("SupplySystemInfoDao")
public class SupplySystemInfoDaoImpl extends BaseDaoImpl implements ISupplySystemInfoDao {

	/**
	 * {@inheritDoc}.
	 */
	@Override
	public List<com.better517na.clairpurchasinginterface.model.SupplySystemInfo> getAllSupplySystemInfoByKeyID(String keyID, String tableName, int pageCount) {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<>();
		map.put("tableName", tableName);
		map.put("keyID", keyID);
		map.put("pageCount", pageCount);
		return this.sqlSessionRead.selectList("ISupplySystemInfoDao.getAllSupplySystemInfoByKeyID", map);
	}
}
