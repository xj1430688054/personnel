package config.groovyFiles.com.better517na.clairpurchasinginterface.dao.impl

import com.better517na.clairpurchasinginterface.model.InterfaceInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.dao.IInterfaceInfoDao
import org.springframework.stereotype.Component

@Component
public class InterfaceInfoDaoImpl extends BaseDaoImpl implements IInterfaceInfoDao {

    @Override
    public InterfaceInfo getInterfaceInfoByKeyId(String tableName, String keyId) {
        Map<String, Object> map = new HashMap<>();
        map.put("tableName", tableName);
        map.put("keyId", keyId);
        List<InterfaceInfo> infos = this.sqlSessionRead.selectList("IInterfaceInfoDao.getInterfaceInfoByKeyId", map);
        if (infos.isEmpty()) {
            return null;
        } else {
            return infos.get(0);
        }
    }
}
