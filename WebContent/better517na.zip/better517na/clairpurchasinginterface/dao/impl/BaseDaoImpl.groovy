/*
 * 文件名：BaseDaoImpl.java
 * 版权：Copyright 2007-2018 517na Tech. Co. Ltd. All Rights Reserved. 
 * 描述： BaseDaoImpl.java
 * 修改人：qiyue
 * 修改时间：2018年4月11日
 * 修改内容：新增
 */
package config.groovyFiles.com.better517na.clairpurchasinginterface.dao.impl;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 * 
 * <pre>
 * </pre>
 * 
 * @author qiyue
 */
@Component("baseDao")
public class BaseDaoImpl {
	/**
	 * .
	 */
	@Resource(name = "sqlSessionWrite")
	protected SqlSessionTemplate sqlSessionWrite;

	/**
	 * .
	 */
	@Resource(name = "sqlSessionRead")
	protected SqlSessionTemplate sqlSessionRead;

	/**
	 * 添加方法注释.
	 * 
	 * @return 1
	 */
	public SqlSessionTemplate getSqlSessionWrite() {
		return sqlSessionWrite;
	}

	/**
	 * 添加方法注释.
	 * 
	 * @param sqlSessionWrite
	 *            1
	 */
	public void setSqlSessionWrite(SqlSessionTemplate sqlSessionWrite) {
		this.sqlSessionWrite = sqlSessionWrite;
	}

	/**
	 * 添加方法注释.
	 * 
	 * @return 1
	 */
	public SqlSessionTemplate getSqlSessionRead() {
		return sqlSessionRead;
	}

	/**
	 * 添加方法注释.
	 * 
	 * @param sqlSessionRead
	 *            1
	 */
	public void setSqlSessionRead(SqlSessionTemplate sqlSessionRead) {
		this.sqlSessionRead = sqlSessionRead;
	}

}
