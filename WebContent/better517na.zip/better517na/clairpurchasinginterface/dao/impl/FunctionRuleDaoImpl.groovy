package config.groovyFiles.com.better517na.clairpurchasinginterface.dao.impl

import com.better517na.clairpurchasinginterface.model.FunctionRule
import config.groovyFiles.com.better517na.clairpurchasinginterface.dao.IFunctionRuleDao
import org.springframework.stereotype.Component

@Component
public class FunctionRuleDaoImpl  extends BaseDaoImpl implements IFunctionRuleDao {
    @Override
    public List<FunctionRule> getSortedFunctionRulesByBusinessNameAndMethod(String tableName, String businessName, String method) {
        Map<String, Object> map = new HashMap<>();
        map.put("tableName", tableName);
        map.put("businessName", businessName);
        map.put("method", method);
        return this.sqlSessionRead.selectList("IFunctionRuleDao.getSortedFunctionRulesByBusinessNameAndMethod", map);
    }
}
