package config.groovyFiles.com.better517na.clairpurchasinginterface.dao

import com.better517na.clairpurchasinginterface.model.NotifyPurchasingInterfaceInfo

/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 *
 * <pre>
 * </pre>
 *
 * @author qingjiu
 */
public interface INotifyPurchasingInterfaceInfoDao {
  public List<NotifyPurchasingInterfaceInfo> getALLNotifyPurchasingInterfaceInfoByKeyID(String keyID, String tableName, int pageCount);
}