package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.JavaServiceRouteHelper.util.StringUtil
import com.better517na.clairpurchasinginterface.commons.ParamBusinessHelper;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.ChannelConstants;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.SupplySystemInfo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.InterfaceChannel
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IAirTicketFlightPriceService;
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IAirTicketService
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IChangeService
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IReverseService
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.cache.SupplySystemInfoCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * TODO 添加类的一句话简单描述.
 * Author: biluo
 * Date: 2018/6/21
 * Time: 11:16
 */
@Controller
public class BaseController {
    /**
     * 上下文.
     */
    @Autowired
    ApplicationContext context;

    @Autowired
    SupplySystemInfoCache supplySystemInfoCache;

    /**
     * 统一参数帮助类.
     */
    @Autowired
    ParamBusinessHelper paramHelper;

    protected IAirTicketService getServiceImpl(@RequestBody RequestVo<?> requestVo) {
        String name = ChannelConstants.matchByValue(requestVo.getSupplySystemInfo().getChannelID()).getName();
        IAirTicketService iAirTicketService = (IAirTicketService) context.getBean(name);
        return iAirTicketService;
    }


    /**
     * 获取逆向退票实体类
     * @param requestVo
     * @return
     */
    protected IReverseService getReverseService(@RequestBody RequestVo<?> requestVo) {
        String name = "";
        this.buildRequestSupplyInfo(requestVo);
        if(null != requestVo && requestVo.getSupplySystemInfo() != null) {
            name = ChannelConstants.matchByValue(requestVo.getSupplySystemInfo().getChannelID()).getName();
        }
        if (name!=ChannelConstants.BSP.getName()) {
            name = name + 'Refund';
            IReverseService iAirTicketService = (IReverseService) context.getBean(name); ;
            return iAirTicketService;
        } else {
            return null;
        }
    }

    /**
     * 获取逆向改签实体类
     * @param requestVo
     * @return
     */
    protected IChangeService getChangeService(@RequestBody RequestVo<?> requestVo) {
        String name = "";
        this.buildRequestSupplyInfo(requestVo);
        if(null != requestVo && requestVo.getSupplySystemInfo() != null) {
            name = ChannelConstants.matchByValue(requestVo.getSupplySystemInfo().getChannelID()).getName();
        }
        if (name!=ChannelConstants.BSP.getName()) {
            name = name + "Change";
            IChangeService iAirTicketService = (IChangeService) context.getBean(name);
            return iAirTicketService;
        } else {
            return null;
        }
    }

    protected void buildSupplyInfo(RequestVo<?> requestVo) {
        List<SupplySystemInfo> supplySystemInfo = null;
        if (requestVo.getSupplySystemInfo() != null && StringUtil.isNullOrEmpty(requestVo.getSupplySystemInfo().getInterfaceUrl()) && !StringUtil.isNullOrEmpty(requestVo.getSupplySystemInfo().getTmcID())) {
            supplySystemInfo = supplySystemInfoCache.getSupplierSystemInfo(requestVo.getSupplySystemInfo().getTmcID(), requestVo.getSupplySystemInfo().getSupplyId());
            if (supplySystemInfo == null || supplySystemInfo.size() == 0) {
                throw new Exception("获取供应信息失败");
            }
            requestVo.setSupplySystemInfo(supplySystemInfo.get(0));
        }
    }

    protected  SupplySystemInfo getSupplySystemInfo(RequestVo<?> requestVo) {
        SupplySystemInfo result = null;
        try{
            def lstResult = supplySystemInfoCache.getSupplierSystemInfo(requestVo.getSupplySystemInfo().getTmcID(), requestVo.getSupplySystemInfo().getSupplyId());
            result = lstResult.find {o -> requestVo.getSupplySystemInfo().getChannelID().trim() == o.getChannelID().trim() && requestVo.getSupplySystemInfo().getBussiID() == o.getBussiID()};
        } catch (Exception e) {
            throw new IllegalArgumentException('未获取到渠道供应信息:' + e.getMessage());
        }
        return result;
    }

    private void buildRequestSupplyInfo(RequestVo<?> requestVo) {
        if (null == requestVo.getSupplySystemInfo() || requestVo.getSupplySystemInfo().getInterfaceUrl() == null ||
                requestVo.getSupplySystemInfo().getInterfaceUrl().isEmpty()) {
            if (requestVo.getSupplySystemInfo().getBussiID() == null ||  requestVo.getSupplySystemInfo().getBussiID() == 0) {
                //没有默认取机票业务
                requestVo.getSupplySystemInfo().setBussiID(1);
            }

            def ret = this.getSupplySystemInfo(requestVo);
            if(ret != null) {
                requestVo.setSupplySystemInfo(ret);
            }
        }
    }

    /**
     * 获取异常的全堆栈信息
     *
     * @param e 异常
     * @return 全堆栈信息.
     */
    public static String getFullStrFromException(Throwable e) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter)
        try {
            e.printStackTrace(writer);
            StringBuffer buffer = stringWriter.getBuffer();
            return buffer.toString();
        } catch (IOException e1) {
            e1.printStackTrace();
            return '';
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
                if (stringWriter != null) {
                    stringWriter.close();
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
