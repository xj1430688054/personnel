package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.ChannelID
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelRefundParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelApplyRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelQueryRefundInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.OutChannelQueryRefundRateVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.InChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.OutChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.InChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.OutChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundOrder.InRefundOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.RefundOrder.OutRefundOrderInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.canRefundLeg.InCanRefundLegVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.refund.canRefundLeg.OutCanRefundLegVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IReverseService
import io.swagger.annotations.ApiOperation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.refund.InChannelChangOrRefundVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.RetrunChangOrRefundReasonVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.impl.zhb2g.ZHB2GRefundServiceImpl
import javax.annotation.Resource
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ReturnChannelChangLegVo

import javax.ws.rs.HEAD

@RestController
@RequestMapping(value = '/refundApi')
public class AirTicketRefundController extends BaseController {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * MUB2G渠道改签.
     */
    @Resource(name = 'zhb2gRefund')
    private ZHB2GRefundServiceImpl zHB2GRefundServiceImpl;

    @ApiOperation(value = '申请退票', notes = '申请退票')
    @PostMapping(value = '/returnTicket')
    public ResponseVo<OutChannelApplyRefundVo> returnTicket(@RequestBody RequestVo<InChannelRefundParamVo> argsDto) {
        ResponseVo<OutChannelApplyRefundVo> responseVo = new ResponseVo<OutChannelApplyRefundVo>();
        try {
            if (null == argsDto || argsDto.getBody() == null || argsDto.getBody().getArgDto() == null ||
                    argsDto.getBody().getArgDto().getBuyReverseOrderInfo() == null || argsDto.getBody().getArgDto().getBuyReverseOrderInfo().getChanelOrderId().isEmpty() ||
                    argsDto.getBody().getArgDto().getBuyReverseTicketInfos() == null) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }
            IReverseService service = this.getReverseService(argsDto);
            if (service != null) {
                responseVo = service.returnTicket(argsDto);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '退票接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    @ApiOperation(value = '查询退票手续费', notes = '查询退票手续费')
    @PostMapping(value = '/queryReturnTicketRate')
    public ResponseVo<OutChannelQueryRefundRateVo> queryReturnTicketRate(
            @RequestBody RequestVo<InChannelRefundParamVo> argsDto) {
        ResponseVo<OutChannelQueryRefundRateVo> responseVo = new ResponseVo<OutChannelQueryRefundRateVo>();
        try {
            if (null == argsDto || argsDto.getBody() == null || argsDto.getBody().getArgDto() == null ||
                    argsDto.getBody().getArgDto().getBuyReverseOrderInfo() == null || argsDto.getBody().getArgDto().getBuyReverseOrderInfo().getChanelOrderId().isEmpty() ||
                    argsDto.getBody().getArgDto().getBuyReverseTicketInfos() == null) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }
            IReverseService service = this.getReverseService(argsDto);
            if(service != null) {
                responseVo = service.queryReturnTicketRate(argsDto);
                responseVo.setSuccess(true);
            }else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '查询退票手续费接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    @ApiOperation(value = '查询退票订单详情', notes = '查询退票订单详情')
    @PostMapping(value = '/getRefundOrderDetail')
    public ResponseVo<OutChannelQueryRefundInfoVo> getRefundOrderDetail(
            @RequestBody RequestVo<InChannelRefundParamVo> argsDto) {
        ResponseVo<OutChannelQueryRefundInfoVo> responseVo = new ResponseVo<OutChannelQueryRefundInfoVo>();
        try {
            if (null == argsDto || null == argsDto.getBody() || null == argsDto.getBody().getArgDto() ||
                    null == argsDto.getBody().getArgDto().getBuyReverseOrderInfo() || null == argsDto.getBody().getArgDto().getBuyReverseOrderInfo().getChannelRefundOrderId()) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }
            IReverseService service = this.getReverseService(argsDto);
            if(service!= null) {
                responseVo = service.getRefundOrderDetail(argsDto);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '查询退票订单详情接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * gaokai 2019-11-23
      * @param argsDto
     * @return
     */

    @ApiOperation(value = '获取改签或者退票原因', notes = '获取改签或者退票原因')
    @PostMapping(value = '/getChangOrRefundReason')
    public ResponseVo<RetrunChangOrRefundReasonVo> getChangOrRefundReason(
            @RequestBody RequestVo<InChannelChangOrRefundVo> argsDto) {
        ResponseVo<RetrunChangOrRefundReasonVo> responseVo = new ResponseVo<RetrunChangOrRefundReasonVo>();
        try {
            if (null == argsDto || null == argsDto.getBody() || null == argsDto.getBody().getLb()) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }

            if (!('10001'== argsDto.getBody().getLb()||('10002'== argsDto.getBody().getLb()))) {
                responseVo.setMsg('参数值无效');
                responseVo.setSuccess(false);
                return responseVo;
            }
            if (ChannelID.ZHB2G.getName().equals(argsDto.getSupplySystemInfo().getChannelID())){
                responseVo = zHB2GRefundServiceImpl.getChangOrRefundReason(argsDto);

            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '获取改签或者退票原因接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * gaokai 2019-11-23
     * @param argsDto
     * @return
     */

    @ApiOperation(value = '获取可改签航段', notes = '获取可改签航段')
    @PostMapping(value = '/getChannelChangeLeg')
    public ResponseVo<OutChannelChangeValidateTktStateParaVo> getChannelChangeLeg(
            @RequestBody RequestVo<InChannelChangeValidateTktStateParaVo> argsDto) {
        ResponseVo<OutChannelChangeValidateTktStateParaVo> responseVo = new ResponseVo<OutChannelChangeValidateTktStateParaVo>();
        try {
            if (null == argsDto || null == argsDto.getBody() || "".equals(argsDto.getBody().getChannelOrderId())||
                    null == argsDto.getSupplySystemInfo().getInterfaceUrl()) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }

            if (ChannelID.ZHB2G.getName().equals(argsDto.getSupplySystemInfo().getChannelID())) {
                responseVo = zHB2GRefundServiceImpl.getChannelChangeLeg(argsDto);

            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '获取改签或者退票原因接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }


    /**
     * 获取退票订单列表
     * @return
     */
    @ApiOperation(value = '获取退票订单列表', notes = '获取退票订单列表')
    @PostMapping(value = '/queryRefundOrder')
    public ResponseVo<OutRefundOrderInfoVo> queryRefundOrder(
            @RequestBody RequestVo<InRefundOrderInfoVo> argsDto){
        ResponseVo<OutRefundOrderInfoVo> responseVo = new ResponseVo<OutRefundOrderInfoVo>();
        try {
            if (null == argsDto || null == argsDto.getBody()
                    || null == argsDto.getBody().getSqrqs() || null == argsDto.getBody().getSqrqz()) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }
            if (null == argsDto.getSupplySystemInfo().getInterfaceUrl()||"".equals(argsDto.getSupplySystemInfo().getInterfaceUrl())) {
                responseVo.setMsg('查询服务的地址不可为空');
                responseVo.setSuccess(false);
                return responseVo;
            }

            if (ChannelID.ZHB2G.getName().equals(argsDto.getSupplySystemInfo().getChannelID())) {
                responseVo = zHB2GRefundServiceImpl.queryRefundOrder(argsDto);
            }else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }

        }catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '获取退票订单列表接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 获取可退票航段接口
     * @return
     */
    @ApiOperation(value = '获取可退票航段接口', notes = '获取可退票航段接口')
    @PostMapping(value = '/getCanRefundLeg')
    public ResponseVo<OutCanRefundLegVo> getCanRefundLeg(
            @RequestBody RequestVo<InCanRefundLegVo> argsDto){
        ResponseVo<OutCanRefundLegVo> responseVo = new ResponseVo<OutCanRefundLegVo>();
        try {
            if (null == argsDto || null == argsDto.getBody()
                    || null == argsDto.getBody().getDdbh() || "".equals(argsDto.getBody().getDdbh())) {
                responseVo.setMsg('未传入参数');
                responseVo.setSuccess(false);
                return responseVo;
            }
            if (null == argsDto.getSupplySystemInfo().getInterfaceUrl()||"".equals(argsDto.getSupplySystemInfo().getInterfaceUrl())) {
                responseVo.setMsg('查询服务的地址不可为空');
                responseVo.setSuccess(false);
                return responseVo;
            }

            if (ChannelID.ZHB2G.getName().equals(argsDto.getSupplySystemInfo().getChannelID())) {
                responseVo = zHB2GRefundServiceImpl.getCanRefundLeg(argsDto);
            }else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }

        }catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '获取可退票航段接口异常', getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

}
