package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ResponseVo
import io.swagger.annotations.ApiOperation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IZhB2GServices
import javax.annotation.Resource

/**
 * 深航b2g controller类
 */
@RestController
@RequestMapping(value = "/zhb2gAri")
class  ZhB2gController extends BaseController {


    @Resource(name = "airIZhB2GServices")
    private IZhB2GServices iZhB2GServices;
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

/**
 * 获取订单列表
 */





}
