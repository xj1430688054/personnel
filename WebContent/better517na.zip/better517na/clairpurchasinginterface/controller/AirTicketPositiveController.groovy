package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.ceair.b2g.client.vo.order.cancel.input.CancelOrderReq
import com.ceair.b2g.client.vo.order.cancel.output.CancelOrderRes
import com.better517na.clairpurchasinginterface.utils.StringUtil
import com.ceair.b2g.client.vo.pricing.input.EcQueryReq
import com.ceair.b2g.client.vo.pricing.output.EcQueryRes
import com.ceair.b2g.client.vo.tax.input.OrderTaxReq
import com.ceair.b2g.client.vo.tax.output.OrderTaxRes;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.ChangeQueryFlightVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelCancelChangeNewVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IAirTicketService;
import com.better517na.logcompontent.business.LogBusiness;
import com.better517na.logcompontent.model.MLogException;
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.cache.SupplySystemInfoCache;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = '/airticketpositive')
public class AirTicketPositiveController extends BaseController {

    /**
     * 供应商信息缓存
     */
    /* @Autowired
     private SupplySystemInfoCache supplySystemInfoCache;*/

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @ApiOperation(value = '询价', notes = '询价')
    @PostMapping(value = '/queryPrice')
    public ResponseVo<QueryPriceRes> queryPrice(@RequestBody RequestVo<QueryPriceParamVo> requestVo) {
        ResponseVo<QueryPriceRes> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.queryPrice(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '询价接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    @ApiOperation(value = '创单', notes = '创单')
    @PostMapping(value = '/createOrder')
    public ResponseVo<CreateOrderRes> createOrder(@RequestBody RequestVo<TicketBuyOrderInfoVo> requestVo) {
        ResponseVo<CreateOrderRes> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.createOrder(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '创单接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 查询订单信息
     *
     * @param requestVo 请求参数
     * @return 返回结果
     */
    @ApiOperation(value = '查询订单信息', notes = '查询订单信息')
    @PostMapping(value = '/queryOrderDetail')
    public ResponseVo<OutQueryOrderInfoVo> queryOrderDetail(@RequestBody RequestVo<InQueryOrderInfoVo> requestVo) {
        ResponseVo<OutQueryOrderInfoVo> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.queryOrderDetail(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '查询订单接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 支付并出票
     *
     * @param requestVo 出票入参
     * @return 返回结果
     */
    @ApiOperation(value = '支付并出票', notes = '支付并出票')
    @PostMapping(value = '/ticketing')
    public ResponseVo<OutTicketingVo> ticketing(@RequestBody RequestVo<InTicketingVo> requestVo) {
        ResponseVo<OutTicketingVo> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.ticketing(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '支付接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }


    @ApiOperation(value = '订单取消', notes = '订单取消')
    @PostMapping(value = '/cancel')
    public ResponseVo<CancelOrderRes> cancelOrder(@RequestBody RequestVo<CancelOrderReq> requestVo) {
        ResponseVo<CancelOrderRes> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.cancel(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '支付接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 支付前校验.
     *
     * @param requestVo 出票入参
     * @return 返回结果
     */
    @ApiOperation(value = '支付前校验', notes = '支付前校验')
    @PostMapping(value = '/payValidate')
    public ResponseVo<OutPayValidateVo> payValidate(@RequestBody RequestVo<InPayValidateVo> requestVo) {
        ResponseVo<OutPayValidateVo> responseVo = new ResponseVo<>();
        try {
            // 获取供应商信息
            this.buildSupplyInfo(requestVo);
            // 判断是否验价，不验价直接返回结果
            if ((requestVo.getSupplySystemInfo().getInterfaceSetting() & 2) == 2) {
                IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
                responseVo = iAirTicketService.payValidate(requestVo);
            } else {
                OutPayValidateVo payValidateVo = new OutPayValidateVo();
                payValidateVo.setChangePrice(false);

                responseVo.setResult(payValidateVo);
                responseVo.setSuccess(true);
            }
        }
        catch (Exception e) {
            String exString = getFullStrFromException(e);
            if (exString.contains("渠道未实现") || exString.contains("No bean named")) {
                responseVo.setSuccess(true);
                OutPayValidateVo payValidateVo = new OutPayValidateVo();
                payValidateVo.setChangePrice(false);
                responseVo.setResult(payValidateVo)
            } else {
                responseVo.setMsg(e.getMessage());
                responseVo.setSuccess(false);
            }

            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '支付前校验接口异常', this.getFullStrFromException(e)));
        }

        return responseVo;
    }

    /**
     * 票号校验.
     *
     * @param requestVo 票号校验入参
     * @return 返回结果
     */
    @ApiOperation(value = '票号校验', notes = '票号校验')
    @PostMapping(value = '/ticketNoCheck')
    public ResponseVo<OutTicketNoCheckVo> ticketNoCheck(@RequestBody RequestVo<InTicketNoCheckVo> requestVo) {
        ResponseVo<OutTicketNoCheckVo> responseVo = new ResponseVo<>();

        try {

            // 先校验票号格式
            String ticketNo = requestVo.getBody().getTicketNo();
            if ((ticketNo.contains('-') && ticketNo.length() != 14) || (!ticketNo.contains('-') && ticketNo.length() != 13)) {
                responseVo.setMsg('票号格式错误，请重新输入！');
                responseVo.setSuccess(false);
                return responseVo;
            }

            String realChannel = '';
            if (requestVo.getSupplySystemInfo().getChannelID().equals('0')) {
                realChannel = '0';
            }

            // 判断走哪个渠道  原始渠道1^原始渠道2^原始渠道3|真实验证渠道1#原始渠道4^原始渠道5^原始渠道6|真实验证渠道2
            String channel = this.paramHelper.getSysParam('CLYPG_CLJY_TicketNoCheckChannel','');
            if (!StringUtil.isStringParamNotLegal(channel)) {
                String[] realChannels = channel.split('#');
                for (String realChannelTemp : realChannels) {
                    String[] channels = realChannelTemp.split('\\|')[0].split('\\^');
                    if (channels.contains(requestVo.getSupplySystemInfo().getChannelID())) {
                        realChannel = realChannelTemp.split('\\|')[1];
                        break;
                    }
                }
            }

            // 不支持的渠道、Office为空，无法验证，则不验证
            if (StringUtil.isStringParamNotLegal(realChannel) || StringUtil.isStringParamNotLegal(requestVo.getBody().getOffice())) {
                responseVo.setSuccess(true);
                OutTicketNoCheckVo ticketNoCheckVo = new OutTicketNoCheckVo();
                responseVo.setResult(ticketNoCheckVo)
                return responseVo;
            }

            requestVo.getSupplySystemInfo().setChannelID(realChannel);
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.ticketNoCheck(requestVo);
        }
        catch (Exception ex) {
            String exString = getFullStrFromException(ex);
            if (exString.contains('渠道未实现') || exString.contains('方法未实现') || exString.contains('No bean named')) {
                responseVo.setSuccess(true);
                OutTicketNoCheckVo ticketNoCheckVo = new OutTicketNoCheckVo();
                responseVo.setResult(ticketNoCheckVo)
            } else {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '票号校验接口异常', exString));
                responseVo.setMsg('票号校验异常，请重试！');
                responseVo.setSuccess(false);
            }
        }

        return responseVo;
    }
    /**
     * 运价查询.
     *
     * @param requestVo 运价查询入参
     * @return 返回结果
     */
    @ApiOperation(value = '运价查询', notes = '运价查询')
    @PostMapping(value = '/ecFareQuery')
    public ResponseVo<EcQueryRes> ecFareQuery(@RequestBody RequestVo<EcQueryReq> requestVo) {
        ResponseVo<EcQueryRes> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.ecFareQuery(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '运价查询接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;

    }

    /**
     * 税费查询.
     *
     * @param requestVo 税费查询入参
     * @return 返回结果
     */
    @ApiOperation(value = '税费查询', notes = '税费查询')
    @PostMapping(value = '/orderTax')
    public ResponseVo<OrderTaxRes> orderTax(@RequestBody RequestVo<OrderTaxReq> requestVo) {
        ResponseVo<OrderTaxRes> responseVo = new ResponseVo<>();
        try {
            IAirTicketService iAirTicketService = this.getServiceImpl(requestVo);
            responseVo = iAirTicketService.orderTax(requestVo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '税费查询接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;

    }

}
