package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.clairpurchasinginterface.utils.GsonUtil
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.ApiOperation;
import com.better517na.javaloghelper.util.LogUtil;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.commons.Response;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.request.CancleInsuranceOrderRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.request.CreateInsuranceOrderRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.request.NotifyInsuranceInsureRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.request.NotifyInsurancePayRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.request.QueryInsuranceOrderRequest;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.response.CancleInsuranceOrderResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.response.CreateInsuranceOrderResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.response.NotifyInsuraceInsureResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.response.NotifyInsurancePayResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.insurance.response.QueryInsuranceOrderResponse;
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.ITicketInsuranceService;
/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 *
 * <pre>
 * </pre>
 *
 * @author qiyue
 */
@RestController
@RequestMapping(value = "/ticketinsurance")
public class TicketInsuranceController {

    @Autowired
    private ITicketInsuranceService iTicketInsuranceService;

    @ApiOperation(value = "查询保险订单信息", notes = "接口查询保险订单信息,用于回填卖出保险订单")
    @PostMapping(value = "/queryInsuranceOrder")
    public Response<QueryInsuranceOrderResponse> queryInsuranceOrder(@RequestBody QueryInsuranceOrderRequest request) {
        Response<QueryInsuranceOrderResponse> response = new Response<>();
        try {
            QueryInsuranceOrderResponse queryInsuranceOrderResponse = iTicketInsuranceService
                    .queryInsuranceOrder(request);
            boolean issuccess = true;
            if (StringUtils.isEmpty(queryInsuranceOrderResponse.isSuccess())
                    || "FALSE".equals(queryInsuranceOrderResponse.isSuccess().trim().toUpperCase())) {
                issuccess = false;
            }
            response.setIssuccess(issuccess);
            response.setMessage(queryInsuranceOrderResponse.getTransactionID());
            response.setData(queryInsuranceOrderResponse);
        } catch (Exception e) {
            e.printStackTrace();
            response.setIssuccess(false);
            response.setMessage(e.getMessage());
            LogUtil.writeExceptionLog(e, "接口查询保险订单信息异常");
        }
        return response;
    }

    @ApiOperation(value = "保险创单", notes = "接口保险创单")
    @PostMapping(value = "/insuranceCreateOrder")
    public Response<CreateInsuranceOrderResponse> insuranceCreateOrder(
            @RequestBody CreateInsuranceOrderRequest request) {
        Response<CreateInsuranceOrderResponse> response = new Response<>();
        try {
            CreateInsuranceOrderResponse createInsuranceOrderResponse = iTicketInsuranceService
                    .insuranceCreateOrder(request);
            response.setIssuccess(createInsuranceOrderResponse.isResult());
            response.setMessage(createInsuranceOrderResponse.getRemark());
            response.setData(createInsuranceOrderResponse);
        } catch (Exception e) {
            e.printStackTrace();
            response.setIssuccess(false);
            response.setMessage(e.getMessage());
            String resp=GsonUtil.gson.toJson(response);
            String param=  GsonUtil.gson.toJson(request);
            println ("接口保险创单异常 【入参：】"+param+ "  ;【响应参数：】"+resp+"  ;errorMessage:"+e.getMessage());
            LogUtil.writeExceptionLog(e, "接口保险创单异常");
        }
        return response;
    }

    @ApiOperation(value = "通知保险支付", notes = "通知接口支付")
    @PostMapping(value = "/notifyInsurancePayOrder")
    public Response<NotifyInsurancePayResponse> notifyInsurancePayOrder(
            @RequestBody NotifyInsurancePayRequest request) {
        Response<NotifyInsurancePayResponse> response = new Response<>();
        try {
            NotifyInsurancePayResponse notifyInsurancePayResponse = iTicketInsuranceService
                    .notifyInsurancePayOrder(request);
            response.setIssuccess(notifyInsurancePayResponse.isResult());
            response.setMessage(notifyInsurancePayResponse.getRemark());
            response.setData(notifyInsurancePayResponse);
        } catch (Exception e) {
            e.printStackTrace();
            response.setIssuccess(false);
            response.setMessage(e.getMessage());
            LogUtil.writeExceptionLog(e, "接口保险通知支付异常");
        }
        return response;
    }

    @ApiOperation(value = "通知保险投保", notes = "通知接口投保")
    @PostMapping(value = "/notifyInsuranceInSure")
    public Response<NotifyInsuraceInsureResponse> notifyInsuranceInSure(
            @RequestBody NotifyInsuranceInsureRequest request) {
        Response<NotifyInsuraceInsureResponse> response = new Response<>();
        try {
            NotifyInsuraceInsureResponse notifyInsuraceInsureResponse = iTicketInsuranceService
                    .notifyInsuranceInSure(request);
            response.setIssuccess(notifyInsuraceInsureResponse.isResult());
            response.setMessage(notifyInsuraceInsureResponse.getRemark());
            response.setData(notifyInsuraceInsureResponse);
        } catch (Exception e) {
            e.printStackTrace();
            response.setIssuccess(false);
            response.setMessage(e.getMessage());
            LogUtil.writeExceptionLog(e, "接口保险通知投保异常");
        }
        return response;
    }

    @ApiOperation(value = "通知接口撤保", notes = "通知接口撤保")
    @PostMapping(value = "/notifyInsuranceCancel")
    public Response<CancleInsuranceOrderResponse> notifyInsuranceCancel(
            @RequestBody CancleInsuranceOrderRequest request) {
        Response<CancleInsuranceOrderResponse> response = new Response<>();
        try {
            CancleInsuranceOrderResponse cancleInsuranceOrderResponse = iTicketInsuranceService
                    .notifyInsuranceCancel(request);
            boolean issuccess = true;
            if (StringUtils.isEmpty(cancleInsuranceOrderResponse.isSuccess())
                    || "FALSE".equals(cancleInsuranceOrderResponse.isSuccess().trim().toUpperCase())) {
                issuccess = false;
            }
            response.setIssuccess(issuccess);
            response.setMessage(cancleInsuranceOrderResponse.getRemark());
            response.setData(cancleInsuranceOrderResponse);
        } catch (Exception e) {
            e.printStackTrace();
            response.setIssuccess(false);
            response.setMessage(e.getMessage());
            LogUtil.writeExceptionLog(e, "接口保险撤保异常");
        }
        return response;
    }

}

