package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IQueryRefundOrderDetailService
import io.swagger.annotations.ApiOperation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping(value = '/refund')
public class QueryRefundOrderDetailController {

    private static final String RPUFS = 'RPUFacadeService';

    @Autowired
    private IQueryRefundOrderDetailService queryReverseOrderDetailService;

    @ApiOperation(value = '申请退票', notes = '申请退票')
    @PostMapping(value = '/returnTicket')
    public ResponseVo<OutTicketRefundResponse> returnTicket(@RequestBody PurchaseInterArgsDto argssDto) {
        ResponseVo<OutTicketRefundResponse> response = new ResponseVo();
        BuyReverseOrderTicketDetailDto argDto = argssDto.getArgDto();
        SupplySystemInfoPo supply = argssDto.getSupply();
        if ('5'.equals(supply.getChannelID())) {
            // 为了不修改之前的代码 接口调用的入参就在这里构造了
            RequestVo<InReturnTicketVo> requestVo = new RequestVo<>();
            requestVo.setChannel(supply.getChannelID());
            InReturnTicketVo inReturnTicketVo = new InReturnTicketVo();
            inReturnTicketVo.setIsVoluntaryRefund(argDto.getBuyReverseOrderInfo().getRefundType() == 0 ? true : false);
            inReturnTicketVo.setRefundReason(argDto.getBuyReverseOrderInfo().getApplyRefundReasonText());
            inReturnTicketVo.setProposer(argDto.getBuyReverseOrderInfo().getLinkMan());
            inReturnTicketVo.setLinkTelphone(argDto.getBuyReverseOrderInfo().getLinkPhone());
            OutQueryTicketOrderInfoVo ticketOrderInfo = new OutQueryTicketOrderInfoVo();
            List<ReturnTicketInfoVo> ticketInfoList = new ArrayList<>();
            for (BuyReverseTicketInfo tic : argDto.getBuyReverseTicketInfos()) {
                ReturnTicketInfoVo tick = new ReturnTicketInfoVo();
                String passengerType = '';
                if (tic.getPassengerType() == 0) {
                    passengerType = '成人';
                } else if (tic.getPassengerType() == 1) {
                    passengerType = '儿童';
                } else if (tic.getPassengerType() == 2) {
                    passengerType = '婴儿';
                }
                tick.setPassengerType(passengerType);
                tick.setTicketNo(tic.getTicketNo());
                tick.setPassengerName(tic.getUserName());
                tick.setCertNo(tic.getCardNo());
                ticketInfoList.add(tick);
            }
            ticketOrderInfo.setTicketInfoList(ticketInfoList);
            inReturnTicketVo.setTicketOrderInfo(ticketOrderInfo);
            requestVo.setBody(inReturnTicketVo);
            UserInfoVo user = new UserInfoVo();
            //为了不修改之前的代码 在这里给userInfo赋值
            user.setUserDesc(supply.getSecurityCode());
            user.setUserName(supply.getInterfaceAccount());
            user.setPassWord(supply.getInterfacePassWord());
            user.setUserSegment(supply.getpID());
            String url = supply.getInterfaceUrl() + RPUFS;
            requestVo.setUser(user);
            response = queryReverseOrderDetailService.returnTicket(requestVo, url);
            return response;
        } else {
            response.setErrorCode(StatusCodeVo.ERROR);
            response.setErrorContent('接口未实现');
            return response;
        }
    }

    @ApiOperation(value = '查询退票手续费', notes = '查询退票手续费')
    @PostMapping(value = '/queryReturnTicketRate')
    public ResponseVo<OutQueryReturnTicketRateVo> queryReturnTicketRate(@RequestBody PurchaseInterArgsDto argsDto) {
//        SupplySystemInfo supply = dto.getSupplySystemInfo();
        ResponseVo<OutQueryReturnTicketRateVo> response = new ResponseVo<>();
        //为了不修改之前的代码 在这里给请求参数赋值
        BuyReverseOrderTicketDetailDto argDto = argsDto.getArgDto();
        SupplySystemInfoPo supply = argsDto.getSupply();
        UserInfoVo user = new UserInfoVo();
        RequestVo<InQueryReturnTicketRateVo> requestVo = new RequestVo<>();
        InQueryReturnTicketRateVo inQueryReturnTicketRateVo = new InQueryReturnTicketRateVo();
        inQueryReturnTicketRateVo.setReturnType(argDto.getBuyReverseOrderInfo().getRefundType() == 0 ? '自愿' : '非自愿');
        List<ReturnTicketInfoVo> ticketList = new ArrayList<ReturnTicketInfoVo>();
        for (BuyReverseTicketInfo tic : argDto.getBuyReverseTicketInfos()) {
            ReturnTicketInfoVo tick = new ReturnTicketInfoVo();
            tick.setPassengerName(tic.getUserName());
            tick.setTicketNo(tic.getTicketNo());
            ticketList.add(tick);
        }
        inQueryReturnTicketRateVo.setTicketList(ticketList);
        requestVo.setBody(inQueryReturnTicketRateVo);
        user.setUserDesc(supply.getSecurityCode());
        user.setUserName(supply.getInterfaceAccount());
        user.setPassWord(supply.getInterfacePassWord());
        user.setUserSegment(supply.getpID());
        requestVo.setUser(user);
        String url = supply.getInterfaceUrl() + RPUFS;
        response = queryReverseOrderDetailService.queryReturnTicketRate(requestVo, url);

        return response;
    }

    @ApiOperation(value = '查询退票订单详情', notes = '查询退票订单详情')
    @PostMapping(value = '/getRefundOrderDetail')
    public ResponseVo<BuyReverseOrderTicketDetailDto> getRefundOrderDetail(@RequestBody PurchaseInterArgsDto argssDto) {
        ResponseVo<BuyReverseOrderTicketDetailDto> response = new ResponseVo();
        BuyReverseOrderTicketDetailDto argDto = argssDto.getArgDto();
        SupplySystemInfoPo supply = argssDto.getSupply();
        if ('5'.equals(supply.getChannelID())) {
            response = queryReverseOrderDetailService.getRefundOrderDetail(argDto, supply);
        } else {
            response.setErrorCode(StatusCodeVo.NOT_FOUND_INTERFACE);
            response.setErrorContent('接口未实现');
        }
        return response;
    }
}
