package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeCheckReq
import com.ceair.b2g.client.vo.postupgrade.input.PostUpgradeTaxReq
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeCheckRes
import com.ceair.b2g.client.vo.postupgrade.output.PostUpgradeTaxRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.ChannelID
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.ChangeQueryFlightVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.InChannelCancelChangeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.InChannelChangeParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelApplyChangeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelCancelChangeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelChangePayNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelQueryChangeFeeNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.OutChannelQueryChangeInfoNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.OutChannelQueryFlightNewVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.OutChannelQueryFlightVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.InChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.ChangLeg.OutChannelChangeValidateTktStateParaVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.InChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.changelist.OutChangeOrderListVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IChangeService
import io.swagger.annotations.ApiOperation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping(value = '/changeApi')
public class AirTicketChangeController extends BaseController {
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 申请改签.
     * @param requestVo 请求.
     * @return 返回.
     */
    @ApiOperation(value = '渠道申请改签', notes = '申请改签')
    @PostMapping(value = '/channelApplyChange')
    public ResponseVo<OutChannelApplyChangeNewVo> channelApplyChange(@RequestBody RequestVo<InChannelChangeParamVo> requestVo) {
        ResponseVo<OutChannelApplyChangeNewVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if(service != null) {
                responseVo = service.channelApplyChange(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道申请改签异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage().length()>500? e.getMessage().substring(0,499):e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 查询改签手续费.
     * @param requestVo 请求.
     * @return 返回.
     */
    @ApiOperation(value = '查询改签手续费', notes = '查询改签手续费')
    @PostMapping(value = '/channelQueryChangeFee')
    public ResponseVo<OutChannelQueryChangeFeeNewVo> channelQueryChangeFee(@RequestBody RequestVo<InChannelChangeParamVo> requestVo) {
        ResponseVo<OutChannelQueryChangeFeeNewVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if(service!= null) {
                responseVo = service.channelQueryChangeFee(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道查询改签手续费异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage().length()>500? e.getMessage().substring(0,499):e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 改签支付.
     * @param requestVo 请求.
     * @return 返回.
     */
    @ApiOperation(value = '改签支付', notes = '改签支付')
    @PostMapping(value = '/channelChangePay')
    public ResponseVo<OutChannelChangePayNewVo> channelChangePay(@RequestBody RequestVo<InChannelChangeParamVo> requestVo) {
        ResponseVo<OutChannelChangePayNewVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if(service != null) {
                responseVo = service.channelChangePay(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道改签支付异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage().length()>500? e.getMessage().substring(0,499):e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 查询买入改签信息.
     * @param requestVo 请求.
     * @return 返回.
     */
    @ApiOperation(value = '查询接口改签订单信息', notes = '查询改签订单信息')
    @PostMapping(value = '/channelQueryChangeInfo')
    public ResponseVo<OutChannelQueryChangeInfoNewVo> channelQueryChangeInfo(@RequestBody RequestVo<InChannelChangeParamVo> requestVo) {
        ResponseVo<OutChannelQueryChangeInfoNewVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if (service != null) {
                responseVo = service.channelQueryChangeInfo(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道查询改签订单异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    /**
     * 查询航班信息.
     * @param requestVo 请求.
     * @return 返回.
     */
    @ApiOperation(value = '查询航班信息', notes = '查询航班信息')
    @PostMapping(value = '/channelQueryFlightInfo')
    public ResponseVo<OutChannelQueryFlightNewVo> channelQueryFlightInfo(@RequestBody RequestVo<ChangeQueryFlightVo> requestVo) {
        ResponseVo<OutChannelQueryFlightVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if(service != null) {
                responseVo = service.channelQueryFlightInfo(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道查询航班信息异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }


    @ApiOperation(value = '取消改签', notes = '取消改签')
    @PostMapping(value = '/channelCancelChange')
    public ResponseVo<OutChannelCancelChangeNewVo> channelCancelChange(@RequestBody RequestVo<InChannelCancelChangeNewVo> requestVo) {
        ResponseVo<OutChannelCancelChangeNewVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if (service != null) {
                responseVo = service.channelCancelChange(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道取消改签订单异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    @ApiOperation(value = '获取改签订单列表', notes = '深航获取改签订单列表')
    @PostMapping(value = '/getChangeList')
    public ResponseVo<OutChangeOrderListVo> getOrderList(@RequestBody RequestVo<InChangeOrderListVo> requestVo) {
        ResponseVo<OutChangeOrderListVo> responseVo = new ResponseVo();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if (service != null) {
                responseVo = service.getChangeList(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道取消改签订单异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }

    @ApiOperation(value = '国际改期查税', notes = '国际改期查税')
    @PostMapping(value = '/postUpgradeTax')
    public ResponseVo<PostUpgradeTaxRes> postUpgradeTax(@RequestBody RequestVo<PostUpgradeTaxReq> requestVo){
        ResponseVo<PostUpgradeTaxRes> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if(service != null) {
                responseVo = service.postUpgradeTax(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '国际改期查税信息异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }
    @ApiOperation(value = '机票状态及改升政策查询', notes = '机票状态及改升政策查询')
    @PostMapping(value = '/postUpgradeCheck')
    public ResponseVo<OutChannelChangeValidateTktStateParaVo> postUpgradeCheck(@RequestBody RequestVo<InChannelChangeValidateTktStateParaVo> requestVo) {
        ResponseVo<OutChannelChangeValidateTktStateParaVo> responseVo = new ResponseVo<>();
        try {
            IChangeService service = this.getChangeService(requestVo);
            if (service != null) {
                    responseVo = service.postUpgradeCheck(requestVo);
            } else {
                responseVo.setSuccess(false);
                responseVo.setResult(null);
                responseVo.setMsg("接口未实现")
            }
        } catch (Exception e) {
            //深航
            if (ChannelID.ZHB2G.getName().equals(requestVo.getSupplySystemInfo().getChannelID())) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '获取可改签航段接口失败', this.getFullStrFromException(e)));
                }
//            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '机票状态及改升政策查询异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }
}
