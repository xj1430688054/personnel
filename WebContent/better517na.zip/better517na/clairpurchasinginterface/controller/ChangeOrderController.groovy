package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.business.IChannelChange
import config.groovyFiles.com.better517na.clairpurchasinginterface.enums.ChannelID
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.change.*
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.InChannelFlightInfoVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flight.OutChannelQueryFlightVo
import io.swagger.annotations.ApiOperation
import org.apache.commons.lang.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

import javax.annotation.Resource

/**
 *
 */
@RestController
@RequestMapping(value = '/change')
public class ChangeOrderController {
    /**
     * MUB2G渠道改签.
     */
    @Resource(name = 'mUB2GChannelChangeImpl')
    private IChannelChange mUB2GChannelChangeImpl;

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @ApiOperation(value = '渠道申请改签', notes = '申请改签')
    @PostMapping(value = '/channelApplyChange')
    public ResponseVo<OutChannelApplyChangeVo> channelApplyChange(
            @RequestBody RequestVo<InChannelApplyChangeVo> requestVo) {
        ResponseVo<OutChannelApplyChangeVo> outChannelApplyChangeVoResponseVo = new ResponseVo<OutChannelApplyChangeVo>();
        try {
            if (requestVo == null || requestVo.getBody() == null || requestVo.getBody().getSupplySystemInfo() == null) {
                outChannelApplyChangeVoResponseVo.setErrorCode(10000);
                outChannelApplyChangeVoResponseVo.setErrorContent('传入参数为空');
                return outChannelApplyChangeVoResponseVo;
            }

            OutChannelApplyChangeVo outChannelApplyChangeVo = null;
            if (ChannelID.MUB2G.getName().equals(requestVo.getBody().getSupplySystemInfo().getChannelID())) {
                outChannelApplyChangeVo = mUB2GChannelChangeImpl.channelApplyChange(requestVo.getBody());
            } else {
                outChannelApplyChangeVoResponseVo.setErrorCode(10001);
                outChannelApplyChangeVoResponseVo.setErrorContent('接口未实现 ');
            }

            outChannelApplyChangeVoResponseVo.setBody(outChannelApplyChangeVo);
        } catch (Throwable e) {
            e.printStackTrace();
            String changeFailReason = StringUtils.isNotEmpty(e.getMessage()) ? e.getMessage() : '渠道申请改签异常';
            outChannelApplyChangeVoResponseVo.setErrorCode(99999);
            outChannelApplyChangeVoResponseVo.setErrorContent(changeFailReason);
            outChannelApplyChangeVoResponseVo.setChannelDesc(changeFailReason);
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '渠道申请改签异常', this.getFullStrFromException(e)));
        }
        return outChannelApplyChangeVoResponseVo;
    }

    @ApiOperation(value = '查询改签手续费', notes = '查询改签手续费')
    @PostMapping(value = '/channelQueryChangeFee')
    public ResponseVo<OutChannelQueryChangeFeeVo> channelQueryChangeFee(
            @RequestBody RequestVo<InChannelQueryChangeFeeVo> requestVo) {

        ResponseVo<OutChannelQueryChangeFeeVo> responseVo = new ResponseVo<>();
        try {
            if (requestVo == null || requestVo.getBody() == null || requestVo.getBody().getSupplySystemInfo() == null) {
                responseVo.setErrorCode(10000);
                responseVo.setErrorContent('传入参数为空');
                return responseVo;
            }

            OutChannelQueryChangeFeeVo outChannelApplyChangeVo = null;
            if (ChannelID.MUB2G.getName().equals(requestVo.getBody().getSupplySystemInfo().getChannelID())) {
                outChannelApplyChangeVo = mUB2GChannelChangeImpl.channelQueryChangeFee(requestVo.getBody());
            } else {
                responseVo.setErrorCode(10001);
                responseVo.setErrorContent('接口未实现 ');
            }

            responseVo.setBody(outChannelApplyChangeVo);
        } catch (Exception ex) {
            String changeFailReason = StringUtils.isNotEmpty(ex.getMessage()) ? ex.getMessage() : '渠道查询改签手续费异常';
            responseVo.setErrorCode(99999);
            responseVo.setErrorContent(changeFailReason);
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '渠道查询改签手续费异常', ex));
        }
        return responseVo;
    }

    @ApiOperation(value = '改签支付', notes = '改签支付')
    @PostMapping(value = '/channelChangePay')
    public ResponseVo<OutChannelChangePayVo> channelChangePay(@RequestBody RequestVo<InChannelChangePayVo> requestVo) {
        ResponseVo<OutChannelChangePayVo> responseVo = new ResponseVo<>();
        try {
            if (requestVo == null || requestVo.getBody() == null || requestVo.getBody().getSupplySystemInfo() == null) {
                responseVo.setErrorCode(10000);
                responseVo.setErrorContent('传入参数为空');
                return responseVo;
            }
            OutChannelChangePayVo outChannelChangePayVo = null;
            if (ChannelID.MUB2G.getName().equals(requestVo.getBody().getSupplySystemInfo().getChannelID())) {
                outChannelChangePayVo = mUB2GChannelChangeImpl.channelChangePay(requestVo.getBody());
            } else {
                responseVo.setErrorCode(10001);
                responseVo.setErrorContent('接口未实现 ');
            }

            responseVo.setBody(outChannelChangePayVo);
        } catch (Exception ex) {
            responseVo.setErrorCode(99999);
            responseVo.setErrorContent('渠道改签支付异常');
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '渠道改签支付异常', ex));
        }
        return responseVo;
    }

    @ApiOperation(value = '查询接口改签订单信息', notes = '查询买入改签信息')
    @PostMapping(value = '/channelQueryChangeInfo')
    public ResponseVo<OutChannelQueryChangeInfoVo> channelQueryChangeInfo(
            @RequestBody RequestVo<InChannelQueryChangeInfoVo> requestVo) {
        ResponseVo<OutChannelQueryChangeInfoVo> responseVo = new ResponseVo<>();
        try {
            if (requestVo == null || requestVo.getBody() == null || requestVo.getBody().getSupplySystemInfo() == null) {
                responseVo.setErrorCode(10000);
                responseVo.setErrorContent('传入参数为空');
                return responseVo;
            }
            OutChannelQueryChangeInfoVo outChannelQueryChangeInfoVo = null;
            if (ChannelID.MUB2G.getName().equals(requestVo.getBody().getSupplySystemInfo().getChannelID())) {
                outChannelQueryChangeInfoVo = mUB2GChannelChangeImpl.channelQueryChangeInfo(requestVo.getBody());
            } else {
                responseVo.setErrorCode(10001);
                responseVo.setErrorContent('接口未实现 ');
            }
            responseVo.setBody(outChannelQueryChangeInfoVo);
        } catch (Exception ex) {
            responseVo.setErrorCode(99999);
            responseVo.setErrorContent('渠道查询改签订单信息异常');
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '渠道查询改签订单信息异常', ex));
        }
        return responseVo;
    }


    @ApiOperation(value = '查询航班信息', notes = '查询航班信息')
    @PostMapping(value = '/queryFlightInfo')
    public ResponseVo<OutChannelQueryFlightVo> queryFlightInfo(
            @RequestBody RequestVo<InChannelFlightInfoVo> requestVo) {
        ResponseVo<OutChannelQueryFlightVo> responseVo = new ResponseVo<>();
        try {
            if (requestVo == null || requestVo.getBody() == null || requestVo.getBody().getSupplySystemInfo() == null) {
                responseVo.setErrorCode(10000);
                responseVo.setErrorContent('传入参数为空');
                return responseVo;
            }
            OutChannelQueryFlightVo outQueryFlightVo = null;
            if (ChannelID.MUB2G.getName().equals(requestVo.getBody().getSupplySystemInfo().getChannelID())) {
                outQueryFlightVo = mUB2GChannelChangeImpl.queryFlightInfo(requestVo.getBody());
            } else {
                responseVo.setErrorCode(10001);
                responseVo.setErrorContent('接口未实现');
            }
            responseVo.setBody(outQueryFlightVo);
        } catch (Exception ex) {
            responseVo.setErrorCode(99999);
            responseVo.setErrorContent('渠道查询航班信息费异常');
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Info, '渠道查询航班信息异常', ex));
        }
        return responseVo;
    }

    /**
     * 获取异常的全堆栈信息
     *
     * @param e 异常
     * @return 全堆栈信息.
     */
    public static String getFullStrFromException(Throwable e) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter)
        try {
            e.printStackTrace(writer);
            StringBuffer buffer = stringWriter.getBuffer();
            return buffer.toString();
        } catch (IOException e1) {
            e1.printStackTrace();
            return '';
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
                if (stringWriter != null) {
                    stringWriter.close();
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
