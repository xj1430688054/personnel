package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.Response
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.qunar.searchprice.SearchPriceResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.RequestVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.GuangFaShoppingVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightSegIDParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QueryFlightsBatchParam
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.flightPrice.QunarParamVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.CabinList.SearchPriceZHResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.CabinList.Zhb2gCabinRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.getRemark.GetRemarkResult
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.getRemark.Zhb2gGetRemarkRequest
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.InGetOrderListReqVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.zhb2g.GetOrderListVo.OutGetOrderListResVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IAirTicketFlightPriceService
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.IZhB2GServices
import io.swagger.annotations.ApiOperation
import org.apache.commons.lang.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

import javax.annotation.Resource

/**
 * TODO 添加类的一句话简单描述.
 * <p>
 * TODO 详细描述
 * <p>
 * TODO 示例代码
 *
 * <pre>
 * </pre>
 *
 * @author qiyue
 */
@RestController
@RequestMapping(value = "/flightprice")
public class AirTicketFlightPriceController extends BaseController {


    @Resource(name = "airTicketFlightPriceService")
    private IAirTicketFlightPriceService airTicketFlightPriceService;
    @Resource(name = "zhb2gService")
    private IZhB2GServices iZhB2GServices
    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    @ApiOperation(value = '官网价格', notes = '去哪儿')
    @PostMapping(value = '/qunarQueryCabin')
    public Response<SearchPriceResult> qunarQueryCabin(@RequestBody RequestVo<QunarParamVo> requestVo) {
        Response<SearchPriceResult> searchPriceResponseVo = new Response<SearchPriceResult>();
        //入参判空
        if (requestVo == null || requestVo.getSupplySystemInfo() == null || requestVo.getBody() == null) {
            searchPriceResponseVo.setCode(2000);
            searchPriceResponseVo.setMessage("传入参数为空");
            return searchPriceResponseVo;
        } else {
            try {
                //调用
                searchPriceResponseVo = airTicketFlightPriceService.qunarQueryCabin(requestVo);
            } catch (Exception e) {
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '查询【去哪儿】接口运价异常', this.getFullStrFromException(e)));
                searchPriceResponseVo.setMessage("调用去哪儿接口运价异常")
                searchPriceResponseVo.setCode(2002);
            }
        }

        return searchPriceResponseVo;
    }

    @ApiOperation(value = 'AV+运价', notes = '广发shopping')
    @PostMapping(value = '/guangfaQueryFlight')
    public ResponseVo<String> guangfaQueryFlight(@RequestBody GuangFaShoppingVo guangFaShoppingVo) {
        ResponseVo<String> responseVo = new ResponseVo<String>();
        String result = "";
        //参数校验
        if (guangFaShoppingVo == null || guangFaShoppingVo.getUrl() == null || StringUtils.isEmpty(guangFaShoppingVo.getFromcity()) || StringUtils.isEmpty(guangFaShoppingVo.getTocity()) || StringUtils.isEmpty(guangFaShoppingVo.getDate())
                || StringUtils.isEmpty(guangFaShoppingVo.getAvNeed()) || StringUtils.isEmpty(guangFaShoppingVo.getPsnNeed()) || StringUtils.isEmpty(guangFaShoppingVo.getPsAvBind()) || StringUtils.isEmpty(guangFaShoppingVo.getIsPsDateBindsNeeded())
                || StringUtils.isEmpty(guangFaShoppingVo.getFaresNeed()) || StringUtils.isEmpty(guangFaShoppingVo.getIsRefundReissueRuleNeeded()) || StringUtils.isEmpty(guangFaShoppingVo.getIsRefundReissueTextRuleNeeded()) || StringUtils.isEmpty(guangFaShoppingVo.getNotOpenedClassNeeded())
                || StringUtils.isEmpty(guangFaShoppingVo.getIsSpecificClassAllPriceZvalueNeeded()) || StringUtils.isEmpty(guangFaShoppingVo.getIsCompressedResultNeeded()) || StringUtils.isEmpty(guangFaShoppingVo.getRuleTypeNeeded()) || StringUtils.isEmpty(guangFaShoppingVo.getFormat())
                || StringUtils.isEmpty(guangFaShoppingVo.getLowestOrAll()) || StringUtils.isEmpty(guangFaShoppingVo.getFareSource()) || StringUtils.isEmpty(guangFaShoppingVo.getIsZKeyNeeded()) || StringUtils.isEmpty(guangFaShoppingVo.getIsJourneyModel()) || StringUtils.isEmpty(guangFaShoppingVo.getJourneyType())) {

            responseVo.setSuccess(false);
            responseVo.setMsg("参数不合法（为空）");
            return responseVo;
        } else {
            try {
                result = airTicketFlightPriceService.guangfaQueryFlight(guangFaShoppingVo);
                responseVo.setSuccess(true);
                responseVo.setMsg("成功");
                responseVo.setResult(result);
            } catch (Exception e) {
                responseVo.setSuccess(false);
                responseVo.setMsg("调用接口异常");
                responseVo.setResult(null);
                e.printStackTrace();
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '查询【广发】接口运价异常', this.getFullStrFromException(e)));
            }
        }

        return responseVo;
    }

    @ApiOperation(value = '航班查询(按出发、到达、起飞日期 查询航班信息)', notes = '航班查询标准接口,按ChannelID区分资源渠道')
    @PostMapping(value = '/queryFlight')
    public ResponseVo<QueryFlightResult> queryFlight(@RequestBody QueryFlightRequest<QueryFlightParam> param){
        //searchFlightsOtaDay
        ResponseVo<QueryFlightResult> responseVo=new ResponseVo();
        try{
            responseVo=airTicketFlightPriceService.queryFlight(param);
        }catch (Exception ex){
            responseVo.setMsg(ex.getMessage());
            responseVo.setSuccess(false);
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error,'航班查询异常',this.getFullStrFromException(ex)));
        }
        return  responseVo;
    }

    @ApiOperation(value = '批量航班查询(按出发、到达、查询天数范围 查询航班信息)', notes = '航班查询标准接口,按ChannelID区分资源渠道')
    @PostMapping(value = '/queryFlightsBatch')
    public ResponseVo<QueryFlightResult> queryFlightsBatch(@RequestBody QueryFlightRequest<QueryFlightsBatchParam> param){
        //searchFlightsBatch
        ResponseVo<QueryFlightResult> responseVo=new ResponseVo();
        try{
            responseVo=airTicketFlightPriceService.queryFlightsBatch(param);
        }catch (Exception ex){
            responseVo.setMsg(ex.getMessage());
            responseVo.setSuccess(false);
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error,'批量航班查询异常',this.getFullStrFromException(ex)));
        }
        return  responseVo;
    }

    @ApiOperation(value = '航班查询(按SegID查询航班信息)', notes = '春秋航空按SegID查询航班信息')
    @PostMapping(value = '/queryFlightBySegID')
    public ResponseVo<QueryFlightResult> queryFlightBySegID(@RequestBody QueryFlightRequest<QueryFlightSegIDParam> param){
        //searchFlightsBySegId2
        ResponseVo<QueryFlightResult> responseVo=new ResponseVo();
        try{
            responseVo=airTicketFlightPriceService.queryFlightBySegID(param);
        }catch (Exception ex){
            responseVo.setMsg(ex.getMessage());
            responseVo.setSuccess(false);
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error,'航班查询(按SegID查询航班信息)异常',this.getFullStrFromException(ex)));
        }
        return  responseVo;
    }

    @ApiOperation(value = '展开更多舱位', notes = '深航')
    @PostMapping(value = '/queryMoreCabin')
    public ResponseVo<SearchPriceZHResult> queryMoreCabin(@RequestBody RequestVo<Zhb2gCabinRequest> requestVo){
        ResponseVo<SearchPriceZHResult> responseVo = new ResponseVo();
        SearchPriceZHResult result = null;
       //传入参数非空校验
        if(requestVo==null||requestVo.getSupplySystemInfo()==null||requestVo.getBody()==null
            ||requestVo.getBody().getHbh()==null||requestVo.getBody().getSid()==null||requestVo.getSupplySystemInfo().getInterfaceUrl()==null){
            responseVo.setSuccess(false);
            responseVo.setMsg("参数不合法（为空）");
           return responseVo;
       }else{
           try {
               result =iZhB2GServices.queryMoreCabin(requestVo);
               responseVo.setSuccess(true);
               responseVo.setMsg("成功");
               responseVo.setResult(result);
           }catch(Exception ex){
               responseVo.setMsg(ex.getMessage());
               responseVo.setSuccess(false);
               logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error,'展开更多舱位接口异常',this.getFullStrFromException(ex)));
           }
           return responseVo;
       }

    }
    @ApiOperation(value = '获取退票规则', notes = '深航')
    @PostMapping(value = '/getRemark')
    public ResponseVo<GetRemarkResult> getRemark(@RequestBody RequestVo<Zhb2gGetRemarkRequest> requestVo){
        ResponseVo<GetRemarkResult> responseVo = new ResponseVo();
        GetRemarkResult result = null;
        //传入参数非空校验
        if(requestVo==null||requestVo.getBody().getSid()==null||requestVo.getBody().getZcid()==null
                ||requestVo.getBody().getHbh()==null||requestVo.getBody().getCw()==null||requestVo.getBody().getCwzk()==null){
            responseVo.setSuccess(false);
            responseVo.setMsg("参数不合法（为空）");
            return responseVo;
        }else{
            try {
                result =iZhB2GServices.getRemark(requestVo);
                responseVo.setSuccess(true);
                responseVo.setMsg("成功");
                responseVo.setResult(result);
            }catch(Exception ex){
                responseVo.setMsg(ex.getMessage());
                responseVo.setSuccess(false);
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error,'获取退票规则接口异常',this.getFullStrFromException(ex)));
            }
            return responseVo;
        }

    }
/**
 * 深航获取订单列表接口
 * @param requestVo
 * @return
 */
    @ApiOperation(value = '获取订单列表', notes = '深航获取订单列表')
    @PostMapping(value = '/getOrderList')
    public ResponseVo<OutGetOrderListResVo> getOrderList(@RequestBody RequestVo<InGetOrderListReqVo > requestVo) {
        ResponseVo<OutGetOrderListResVo> responseVo = new ResponseVo();

        //传入参数非空校验
        if(requestVo==null||requestVo.getSupplySystemInfo()==null||requestVo.getBody()==null){
            responseVo.setSuccess(false);
            responseVo.setMsg("参数不合法（为空）");
            return responseVo;
        }else {
            try {
                responseVo = iZhB2GServices.getOrderList(requestVo);
               /* responseVo.setSuccess(true);
                responseVo.setMsg("成功");*/
            } catch (Exception ex) {
                responseVo.setMsg(ex.getMessage());
                responseVo.setSuccess(false);
                logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '获取订单列表接口异常', this.getFullStrFromException(ex)));
            }
            return responseVo;
        }
    }
}

