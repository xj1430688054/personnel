package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusArgs
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.ExtractTicketNoStatusRes
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.ITicketNoService
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

import javax.annotation.Resource

/**
 * 机票票号处理controller
 */
@RestController
@RequestMapping(value = "/ticketNo")
class TicketNoController extends BaseController {

    @Resource
    ITicketNoService ticketNoService;

    /**
     * 提取票号状态
     * @return
     */
    @ApiOperation(value = "提取机票票号状态", notes = "提取机票票号状态")
    @PostMapping(value = "/extractTicketNoStatus")
    public ResponseVo<ExtractTicketNoStatusRes> extractTicketNoStatus(@RequestBody ExtractTicketNoStatusArgs args) {
        ResponseVo<ExtractTicketNoStatusRes> response = ticketNoService.extractTicketNoStatus(args)
        return response;
    }
}
