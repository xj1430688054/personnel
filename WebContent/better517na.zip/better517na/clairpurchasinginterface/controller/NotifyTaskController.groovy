package config.groovyFiles.com.better517na.clairpurchasinginterface.controller

import com.better517na.clairpurchasinginterface.model.NotifyPurchasingInterfaceInfo
import com.better517na.logcompontent.business.LogBusiness
import com.better517na.logcompontent.model.MLogException
import com.better517na.logcompontent.util.ExceptionLevel
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.to.ResponseVo
import config.groovyFiles.com.better517na.clairpurchasinginterface.model.vo.notify.NotifyFillBackTicketNoInVo;
import config.groovyFiles.com.better517na.clairpurchasinginterface.service.INotifyTaskService
import config.groovyFiles.com.better517na.clairpurchasinginterface.util.cache.NotifyPurchasingInterfaceInfoCache
import io.swagger.annotations.ApiOperation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.ApplicationContext
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

import javax.annotation.Resource

@RestController
@RequestMapping(value = '/notify')
public class NotifyTaskController extends BaseController {
    /**
     * 上下文.
     */
    @Autowired
    ApplicationContext context;

    /**
     * 日志组件.
     */
    @Autowired
    private LogBusiness logBusiness;

    /**
     * 通知采购缓存信息
     */
    @Resource(name = 'notifyPurchasingInterfaceInfoCache')
    private NotifyPurchasingInterfaceInfoCache notifyPurchasingInterfaceInfoCache;

    @ApiOperation(value = '票号回填', notes = '票号回填')
    @PostMapping(value = '/notifyFillBackTicketNo')
    public ResponseVo<String> notifyFillBackTicketNo(
            @RequestBody NotifyFillBackTicketNoInVo notifyFillBackTicketNoInVo) {
        ResponseVo<String> responseVo = new ResponseVo<>();
        try {
            if (notifyFillBackTicketNoInVo == null || notifyFillBackTicketNoInVo.getOrderInfo() == null || notifyFillBackTicketNoInVo.getTicketInfoList() == null || notifyFillBackTicketNoInVo.getTicketInfoList().size() == 0) {
                responseVo.setSuccess(false);
                responseVo.setMsg("入参错误")
                return responseVo;
            }

            String cropNo = notifyFillBackTicketNoInVo.orderInfo.getBookingUserCorpNo();
            NotifyPurchasingInterfaceInfo notifyPurchasingInterfaceInfo = notifyPurchasingInterfaceInfoCache.getNotifyPurchasingInterfaceInfo(cropNo, 1, 0);
            if (notifyPurchasingInterfaceInfo == null) {
                responseVo.setSuccess(true); // 未配置采购通知信息，说明不需要通知
                responseVo.setMsg("未配置采购通知信息则不通知")
                return responseVo;
            }

            INotifyTaskService iNotifyTaskService = (INotifyTaskService) context.getBean(notifyPurchasingInterfaceInfo.getNotifyChannelID());
            responseVo = iNotifyTaskService.notifyFillBackTicketNo(notifyFillBackTicketNoInVo, notifyPurchasingInterfaceInfo);
        } catch (Exception e) {
            logBusiness.writeExceptionLog(new MLogException(ExceptionLevel.Error, '回填通知接口异常', this.getFullStrFromException(e)));
            responseVo.setMsg(e.getMessage());
            responseVo.setSuccess(false);
        }
        return responseVo;
    }
}
