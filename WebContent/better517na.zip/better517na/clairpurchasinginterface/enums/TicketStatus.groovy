package config.groovyFiles.com.better517na.clairpurchasinginterface.enums

public enum TicketStatus {
    OPEN_FOR_USE(0,'OPEN_FOR_USE'),
    VOID(1,'VOID'),
    REFUNDED(2,'REFUNDED'),
    USED_FLOWN(3,'USED_FLOWN'),
    SUSPENDED(4,'SUSPENDED'),
    CHECKED_IN(5,'CHECKED_IN'),
    LIFT_BOARDED(6,'LIFT_BOARDED'),
    EXCHANGED(7,'EXCHANGED'),
    FIM_EXCH(8,'FIM_EXCH'),
    None(9,'None'),
    CPN_NOTE(10,'CPN_NOTE'),
    N(11,'N'),
    G(12,'G');

    private Integer id;
    private String name;

    public TicketStatus(Integer id, String name) {
        this.id = id
        this.name = name
    }

    public Integer getId() {
        return id
    }

    public void setId(Integer id) {
        this.id = id
    }

    public String getName() {
        return name
    }

    public void setName(String name) {
        this.name = name
    }
}
