package config.groovyFiles.com.better517na.clairpurchasinginterface.enums;

/**
 * ParamBusinessHelper的getSysParam方法获取的统一参数
 */
public enum SysParamID {
    CPPT_CP('CPPT_CP_CHANGEURL', ''),
    CPPT_HSJH('CPPT_HSJH_MUB2GRETURNTICKETURL', ''),
    GWCP_CP('GWCP_CP_CPPTNOPAYDEPTANDCUSTOMERNO', ''),
    CPPT_CP_B2G('CPPT_CP_B2GPAYINFO', '');

    private String name;

    private String value;

    SysParamID(String name, String value) {
        this.name = name;
        this.value = value;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
