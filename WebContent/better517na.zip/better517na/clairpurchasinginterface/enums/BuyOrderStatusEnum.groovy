package config.groovyFiles.com.better517na.clairpurchasinginterface.enums;

/**
 * 卖出改签订单状态
 * @Author echoyu on 2018/4/20
 * @Description
 */
public enum BuyOrderStatusEnum {
    WaitCheck(1, '改签申请，等待审核', '改签申请，等待审核'),
    WaitPay(2, '审核通过，等待付款', '审核通过，等待付款'),
    WaitDeal(3, '支付成功，等待处理', '支付成功，等待处理'),
    SUCCESSD(4, '改签成功，交易结束', '改签成功，交易结束'),//OrderProcessStatus
    FAILURE(5, '改签失败，交易结束', '改签失败，交易结束');

    private Integer id;
    private String name;
    private String descip;

    BuyOrderStatusEnum(Integer id, String name, String descip) {
        this.id = id;
        this.name = name;
        this.descip = descip;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescip() {
        return descip;
    }

    public void setDescip(String descip) {
        this.descip = descip;
    }
}
