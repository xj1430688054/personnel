package com.example.eurekademoserver;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekademoserverApplicationTests {



}
